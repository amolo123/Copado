Check Image comparison - PreBind
    #Author=shraddha Patil
    [Documentation]           Check Image comparison
    [Arguments]               ${imageno}                  ${doctype_}
    ${image1}=                LogScreenshot

    IF                        "${doctype_}" == "Admitted_Quote"

        IF                    "${province_check}"=="Arizona"
            ${BASE_IMAGE_PATH}=                           Set Variable                ${CURDIR}/../images/quote/AZ
        ELSE IF               "${province_check}"=="California"
            ${BASE_IMAGE_PATH}=                           Set Variable                ${CURDIR}/../images/quote/CA
        ELSE IF               "${province_check}"=="Texas"
            ${BASE_IMAGE_PATH}=                           Set Variable                ${CURDIR}/../images/quote/TX
        ELSE IF               "${province_check}"=="Oregon"
            ${BASE_IMAGE_PATH}=                           Set Variable                ${CURDIR}/../images/quote/OR
        ELSE IF               "${province_check}"=="Alaska"
            ${BASE_IMAGE_PATH}=                           Set Variable                ${CURDIR}/../images/quote/AK
        END

        CompareImages         ${image1}                   quote${imageno}.png         tolerance=${tolerance}

    ELSE IF                   "${doctype_}" == "Quote_SL"

        IF                    "${province_check}"=="Arizona"
            ${BASE_IMAGE_PATH}=                           Set Variable                ${CURDIR}/../images/quoteSL/AZ
        ELSE IF               "${province_check}"=="California"
            ${BASE_IMAGE_PATH}=                           Set Variable                ${CURDIR}/../images/quoteSL/CA
        ELSE IF               "${province_check}"=="Texas"
            ${BASE_IMAGE_PATH}=                           Set Variable                ${CURDIR}/../images/quoteSL/TX
        ELSE IF               "${province_check}"=="Oregon"
            ${BASE_IMAGE_PATH}=                           Set Variable                ${CURDIR}/../images/quoteSL/OR
        ELSE IF               "${province_check}"=="Alaska"
            ${BASE_IMAGE_PATH}=                           Set Variable                ${CURDIR}/../images/quoteSL/AK
        END

        CompareImages         ${image1}                   quote${imageno}.png         tolerance=${tolerance}

    ELSE IF                   "${doctype_}" == "Account_Summary"

        IF                    "${province_check}"=="Arizona"
            ${BASE_IMAGE_PATH}=                           Set Variable                ${CURDIR}/../images/AccountSummary/AZ
        ELSE IF               "${province_check}"=="California"
            ${BASE_IMAGE_PATH}=                           Set Variable                ${CURDIR}/../images/AccountSummary/CA
        ELSE IF               "${province_check}"=="Texas"
            ${BASE_IMAGE_PATH}=                           Set Variable                ${CURDIR}/../images/AccountSummary/TX
        ELSE IF               "${province_check}"=="Oregon"
            ${BASE_IMAGE_PATH}=                           Set Variable                ${CURDIR}/../images/AccountSummary/OR
        ELSE IF               "${province_check}"=="Alaska"
            ${BASE_IMAGE_PATH}=                           Set Variable                ${CURDIR}/../images/AccountSummary/AK
        END

        CompareImages         ${image1}                   AccountSummary${imageno}.png                            tolerance=${tolerance}

    ELSE IF                   "${doctype_}" == "Account_Summary_SL"

        IF                    "${province_check}"=="Arizona"
            ${BASE_IMAGE_PATH}=                           Set Variable                ${CURDIR}/../images/Account_Summary_SL/AZ
        ELSE IF               "${province_check}"=="California"
            ${BASE_IMAGE_PATH}=                           Set Variable                ${CURDIR}/../images/Account_Summary_SL/CA
        ELSE IF               "${province_check}"=="Texas"
            ${BASE_IMAGE_PATH}=                           Set Variable                ${CURDIR}/../images/Account_Summary_SL/TX
        ELSE IF               "${province_check}"=="New York"
            ${BASE_IMAGE_PATH}=                           Set Variable                ${CURDIR}/../images/Account_Summary_SL/NY
        ELSE IF               "${province_check}"=="Alaska"
            ${BASE_IMAGE_PATH}=                           Set Variable                ${CURDIR}/../images/Account_Summary_SL/AK
        END

        CompareImages         ${image1}                   AccountSummary${imageno}.png                            tolerance=${tolerance}


    ELSE IF                   "${doctype_}" == "Indication"

        IF                    "${province_check}"=="Arizona"
            ${BASE_IMAGE_PATH}=                           Set Variable                ${CURDIR}/../images/Indication/AZ
        ELSE IF               "${province_check}"=="California"
            ${BASE_IMAGE_PATH}=                           Set Variable                ${CURDIR}/../images/Indication/CA
        ELSE IF               "${province_check}"=="Texas"
            ${BASE_IMAGE_PATH}=                           Set Variable                ${CURDIR}/../images/Indication/TX
        ELSE IF               "${province_check}"=="Oregon"
            ${BASE_IMAGE_PATH}=                           Set Variable                ${CURDIR}/../images/Indication/OR
        ELSE IF               "${province_check}"=="Alaska"
            ${BASE_IMAGE_PATH}=                           Set Variable                ${CURDIR}/../images/Indication/AK
        END

        CompareImages         ${image1}                   Indication${imageno}.png    tolerance=${tolerance}


    ELSE IF                   "${doctype_}" == "StreamlineRW"

        IF                    "${province_check}"=="Arizona"
            ${BASE_IMAGE_PATH}=                           Set Variable                ${CURDIR}/../images/StreamlineRW/AZ
        ELSE IF               "${province_check}"=="California"
            ${BASE_IMAGE_PATH}=                           Set Variable                ${CURDIR}/../images/StreamlineRW/CA
        ELSE IF               "${province_check}"=="Texas"
            ${BASE_IMAGE_PATH}=                           Set Variable                ${CURDIR}/../images/StreamlineRW/TX
        ELSE IF               "${province_check}"=="Oregon"
            ${BASE_IMAGE_PATH}=                           Set Variable                ${CURDIR}/../images/StreamlineRW/OR
        ELSE IF               "${province_check}"=="Alaska"
            ${BASE_IMAGE_PATH}=                           Set Variable                ${CURDIR}/../images/StreamlineRW/AK
        END

        CompareImages         ${image1}                   StreamlineRW${imageno}.png                              tolerance=${tolerance}
    
    ELSE IF                   "${doctype_}" == "Streamline"

        IF                    "${province_check}"=="Arizona"
            ${BASE_IMAGE_PATH}=                           Set Variable                ${CURDIR}/../images/StreamlineRW_SL/AZ
        ELSE IF               "${province_check}"=="California"
            ${BASE_IMAGE_PATH}=                           Set Variable                ${CURDIR}/../images/StreamlineRW_SL/CA
        ELSE IF               "${province_check}"=="Texas"
            ${BASE_IMAGE_PATH}=                           Set Variable                ${CURDIR}/../images/StreamlineRW_SL/TX
        ELSE IF               "${province_check}"=="New York"
            ${BASE_IMAGE_PATH}=                           Set Variable                ${CURDIR}/../images/StreamlineRW_SL/NY
        ELSE IF               "${province_check}"=="Alaska"
            ${BASE_IMAGE_PATH}=                           Set Variable                ${CURDIR}/../images/StreamlineRW_SL/AK
        END

        CompareImages         ${image1}                   Streamline${imageno}.png                              tolerance=${tolerance}

    END