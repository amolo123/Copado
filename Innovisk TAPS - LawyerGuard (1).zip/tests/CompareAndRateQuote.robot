*** Settings ***
Library                         QWeb
Library                         QForce
Library                         FakerLibrary
Library                         String
Library                         BuiltIn
Library                         DateTime
Library                         RetryFailed                 global_retries=${retry_count}
Resource                        ../resources/common.robot
Resource                        ../PageObjects/PageObjects_Account.robot
Resource                        ../PageObjects/PageObjects_HomePage.robot
Resource                        ../PageObjects/PageObjects_Submission.robot
Resource                        ../PageObjects/PageObjects_InusredInfo.robot
Resource                        ../PageObjects/PageObjects_SubmissionInit.robot
Resource                        ../PageObjects/PageObjects_SubmissionInfo.robot
Resource                        ../PageObjects/PageObjects_UnderwrittingAnalysis.robot
Resource                        ../PageObjects/PageObjects_CompareAndRateQuote.robot

Suite Setup                     Setup Browser
Suite Teardown                  CloseAllBrowsers



*** Test Cases ***

Verify Header section of Quote Console: Documents Generation and New Quote 
    #TCID=94093
    #Author=Amol Gaymukhe
    [Documentation]             Functionality on Insured Info Page
    [Tags]                      Smoke_Test_LGO_Admitted     Smoke_Test
    Creating an account with a state California
    Validate LaweyrGuard New submission Fields
    VerifyText                  Underwriter Workbench
    Add Account name on Insured info page
    Click on save button
    Add Attorney
    Click on NEXT:Submission Info
    Select broker Contact Source
    Add Details In SubmissionInfo Page
    ClickText                   NEXT:Underwriter Analysis >
    VerifyText                  Underwriting Analysis
    Add Area Of Practice
    Sleep                       20s
    ClickText                   Qualify Submission
    Sleep                       30s
    Validate Header Fields On Compare and Rate quote
    Generate Document In Rated                              Indication
    Generate Document In Rated                              Account Summary
    Generate Document In Quoted                             Quote Proposal
    Generate Document In Quoted                             Streamlined Renewal
    New Quote Button



Verify Header section of Quote Console: SRP and Bulk Rate 
    #TCID=94093
    #Author=Amol Gaymukhe
    [Documentation]             Functionality on Insured Info Page
    [Tags]                      Smoke_Test_LGO_Admitted     Smoke_Test
    Creating a new Account
    Validate LaweyrGuard New submission Fields
    VerifyText                  Underwriter Workbench
    Add Account name on Insured info page
    Click on save button
    Add Attorney
    Click on NEXT:Submission Info
    Select broker Contact Source
    Add Details In SubmissionInfo Page
    ClickText                   NEXT:Underwriter Analysis >
    VerifyText                  Underwriting Analysis
    Add Area Of Practice
    Sleep                       20s
    ClickText                   Qualify Submission
    Sleep                       30s
    Verify SRP Value
    Verify Bulk Rate



Verify Header section of Quote Console: Internal Referal 
    #TCID=94093
    #Author=Amol Gaymukhe
    [Documentation]             Functionality on Insured Info Page
    [Tags]                      Smoke_Test_LGO_Admitted     Smoke_Test

    Creating a new Account
    Validate LaweyrGuard New submission Fields
    VerifyText                  Underwriter Workbench
    Add Account name on Insured info page
    Click on save button
    Add Attorney
    Click on NEXT:Submission Info
    Select broker Contact Source
    Add Details In SubmissionInfo Page
    ClickText                   NEXT:Underwriter Analysis >
    VerifyText                  Underwriting Analysis
    Add Area Of Practice
    Sleep                       20s
    ClickText                   Qualify Submission
    Sleep                       30s
    Vaidate Refer Functionality Fields
    Add Internal Refer

Verify Header section of Quote Console: External Referal
    #TCID=94093
    #Author=Amol Gaymukhe
    [Documentation]             Functionality on Insured Info Page
    [Tags]                      Smoke_Test_LGO_Admitted     Smoke_Test

    Creating a new Account
    Validate LaweyrGuard New submission Fields
    VerifyText                  Underwriter Workbench
    Add Account name on Insured info page
    # VerifyInputValue          Contact Record Type         Attorney                    timeout=2s
    Click on save button
    Add Attorney
    Click on NEXT:Submission Info
    Select broker Contact Source
    Add Details In SubmissionInfo Page
    ClickText                   NEXT:Underwriter Analysis >
    VerifyText                  Underwriting Analysis
    Add Area Of Practice
    Sleep                       20s
    ClickText                   Qualify Submission
    Sleep                       30s
    RefreshPage
    Vaidate Refer Functionality Fields
    Add External Refer



Verify the functionality of Limits And Deductibles section on Quote console
    #TCID=94097
    #Author=Amol Gaymukhe
    [Documentation]             Functionality To Check Limits and Deductibles
    [Tags]                      Smoke_Test_LGO_Admitted     Smoke_Test
    Creating a new Account
    Validate LaweyrGuard New submission Fields
    VerifyText                  Underwriter Workbench
    Add Account name on Insured info page
    Click on save button
    Add Attorney
    Click on NEXT:Submission Info
    Select broker Contact Source
    Add Details In SubmissionInfo Page
    ClickText                   NEXT:Underwriter Analysis >
    VerifyText                  Underwriting Analysis
    Add Area Of Practice
    Sleep                       20s
    ClickText                   Qualify Submission
    Sleep                       30s
    RefreshPage
    Validate Limit and Deductibles



Verify the main Quote Console Component on screen(in dark colour)below quote console header:Premium seek and Dropdown values
    #TCID=94095
    #Author=Amol Gaymukhe
    [Documentation]             Functionality To Check Quote Console Component
    [Tags]                      Smoke_Test_LGO_Admitted     Smoke_Test
    Creating a new Account
    Validate LaweyrGuard New submission Fields
    VerifyText                  Underwriter Workbench
    Add Account name on Insured info page
    Click on save button
    Add Attorney
    Click on NEXT:Submission Info
    Select broker Contact Source
    Add Details In SubmissionInfo Page
    ClickText                   NEXT:Underwriter Analysis >
    VerifyText                  Underwriting Analysis
    Add Area Of Practice
    Sleep                       20s
    ClickText                   Qualify Submission
    Sleep                       30s
    RefreshPage
    Validate Quote Console Header Fields
    Validate Premium Seek
    Validate DropDown Values
    Operations on DropDown Values



Verify the functionality of Expand All and Collapse All
    #TCID=94096
    #Author=Amol Gaymukhe
    [Documentation]             Functionality of Expand All Collapse All
    [Tags]                      Smoke_Test_LGO_Admitted     Smoke_Test
    Creating a new Account
    Validate LaweyrGuard New submission Fields
    VerifyText                  Underwriter Workbench
    Add Account name on Insured info page
    Click on save button
    Add Attorney
    Click on NEXT:Submission Info
    Select broker Contact Source
    Add Details In SubmissionInfo Page
    ClickText                   NEXT:Underwriter Analysis >
    VerifyText                  Underwriting Analysis
    Sleep                       20s
    Add Area Of Practice
    Sleep                       20s
    ClickText                   Qualify Submission
    Sleep                       30s
    Verify Expand All Collapse All Fields

Verify the functionality of Area Of Practice section on Quote Console 
    #TCID=94098
    #Author=Amol Gaymukhe
    [Documentation]             Functionality of Expand All Collapse All
    [Tags]                      Smoke_Test_LGO_Admitted     Smoke_Test
    Creating a new Account
    Validate LaweyrGuard New submission Fields
    VerifyText                  Underwriter Workbench
    Add Account name on Insured info page
    Click on save button
    Add Attorney
    Click on NEXT:Submission Info
    Select broker Contact Source
    Add Details In SubmissionInfo Page
    ClickText                   NEXT:Underwriter Analysis >
    VerifyText                  Underwriting Analysis
    Sleep                       20s
    Add Area Of Practice
    ClickText                   Qualify Submission
    Sleep                       30s
    Verify Area Of Practice section on Quote Console



Verify the functionality of Litigation History section on Quote Console.
    #TCID=94099
    #Author=Amol Gaymukhe
    [Documentation]             Functionality of Expand All Collapse All
    [Tags]                      Smoke_Test_LGO_Admitted     Smoke_Test
    Creating a new Account
    Validate LaweyrGuard New submission Fields
    VerifyText                  Underwriter Workbench
    Add Account name on Insured info page
    Click on save button
    Add Attorney
    Click on NEXT:Submission Info
    Select broker Contact Source
    Add Details In SubmissionInfo Page
    ClickText                   NEXT:Underwriter Analysis >
    VerifyText                  Underwriting Analysis
    Add Area Of Practice
    Add Litigation History On Underwriter Analysis Page
    Sleep                       20s
    ClickText                   Qualify Submission
    Sleep                       30s
    Verify Litigation History on Quote Console

Verify the functionality of Credit/debit Information section on Quote Console
    #TCID=94100
    #Author=Amol Gaymukhe
    [Documentation]             Functionality of Expand All Collapse All
    [Tags]                      Smoke_Test_LGO_Admitted     Smoke_Test
    Creating a new Account
    Validate LaweyrGuard New submission Fields
    VerifyText                  Underwriter Workbench       timeout=12s
    Add Account name on Insured info page
    Click on save button
    Add Attorney
    Click on NEXT:Submission Info
    Select broker Contact Source
    Add Details In SubmissionInfo Page
    ClickText                   NEXT:Underwriter Analysis >
    VerifyText                  Underwriting Analysis
    Add Area Of Practice
    Add Litigation History On Underwriter Analysis Page
    Sleep                       20s
    ClickText                   Qualify Submission
    Sleep                       30s
    Validate Credit Debit Fields
    Verify Credit Debit Fields and Functionality


Verify the functionality of Quote Data section on Quote Console 
    #TCID=94101
    #Author=Amol Gaymukhe
    [Documentation]             Functionality of Expand All Collapse All
    [Tags]                      Smoke_Test_LGO_Admitted     Smoke_Test
    Creating a new Account
    Validate LaweyrGuard New submission Fields
    VerifyText                  Underwriter Workbench       timeout=12s
    Add Account name on Insured info page
    Click on save button
    Add Attorney
    Click on NEXT:Submission Info
    Select broker Contact Source
    Add Details In SubmissionInfo Page
    ClickText                   NEXT:Underwriter Analysis >
    VerifyText                  Underwriting Analysis
    Add Area Of Practice
    Add Litigation History On Underwriter Analysis Page
    Sleep                       20s
    ClickText                   Qualify Submission
    Sleep                       30s
    Validate Quote Data Fields
    Edit Quote data Fields and verify rating


Verify the functionality of Goal Seek section on Quote Console 
    #TCID=94101
    #Author=Amol Gaymukhe
    [Documentation]             Functionality of Expand All Collapse All
    [Tags]                      Smoke_Test_LGO_Admitted     Smoke_Test
    Creating an account with a state Connecticut
    Validate LaweyrGuard New submission Fields
    VerifyText                  Underwriter Workbench       timeout=12s
    Add Account name on Insured info page
    Click on save button
    Add Attorney
    Click on NEXT:Submission Info
    Select broker Contact Source
    Add Details In SubmissionInfo Page
    ClickText                   NEXT:Underwriter Analysis >
    VerifyText                  Underwriting Analysis
    Add Area Of Practice
    Add Litigation History On Underwriter Analysis Page
    Sleep                       20s
    ClickText                   Qualify Submission
    Sleep                       30s
    Click On Rate
    Click On Goal Seek
    Validate GOAL Seek Fields
    ClickText                   Ignore and Return
    Enter Data On Schedule Rating For Goal Seek
    Click On Save
    Click On Rate
    VerifyText                  Quote Console               timeout=45s
    Sleep                       45s
    RefreshPage
    Click On Rate
    Click On Goal Seek
    Goal Seek Operation
    Click On Bind
