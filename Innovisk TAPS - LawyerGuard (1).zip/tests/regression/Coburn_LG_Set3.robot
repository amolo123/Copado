*** Settings ***
Library                         QWeb
Library                         QForce
Library                         FakerLibrary
Library                         String
Library                         BuiltIn
Library                         DateTime
Library                         RetryFailed                 global_retries=${retry_count}
Resource                        ../../resources/common.robot
Resource                        ../../resources/ReadPDF.robot
Resource                        ../../PageObjects/PageObjects_Account.robot
Resource                        ../../PageObjects/PageObjects_HomePage.robot
Resource                        ../../PageObjects/PageObjects_Submission.robot
Resource                        ../../PageObjects/PageObjects_InusredInfo.robot
Resource                        ../../PageObjects/PageObjects_SubmissionInit.robot
Resource                        ../../PageObjects/PageObjects_SubmissionInfo.robot
Resource                        ../../PageObjects/PageObjects_UnderwrittingAnalysis.robot
Resource                        ../../PageObjects/PageObjects_UnderwrittingAnalysis.robot
Resource                        ../../PageObjects/Surplus_Lines/PageObjects_SL_UnderwriterAnalysis.robot
Resource                        ../../PageObjects/PageObjects_CompareAndRateQuote.robot
Resource                        ../../PageObjects/PageObjects_PolicyPage.robot
Resource                        ../../PageObjects/Coburn/AdmittedLG/Billingrecord_Page.robot
Resource                        ../../PageObjects/PageObjects_PDFRead.robot

Library                         ../../libraries/graph.py
Resource                        ../../resources/graph.resource

Suite Setup                     Setup Browser
Suite Teardown                  CloseAllBrowsers

*** Test Cases ***

Admitted: Validate Billing Record for Cancel & Replace, Flat cancellation
    #TCID=
    #Author= Shraddha T Patil
    [Documentation]             Validate Cancel & Replace, Flat cancellation
    [Tags]                      LGO_Coburn
    Creating a new Account
    Validate LaweyrGuard New submission Fields
    VerifyText                  Underwriter Workbench
    Add Account name on Insured info page
    Click on save button
    Add Attorney
    Click on NEXT:Submission Info
    Select broker Contact Source
    Add Details In SubmissionInfo Page
    ClickText                   NEXT:Underwriter Analysis >
    VerifyText                  Underwriting Analysis
    Add Area Of Practice
    Sleep                       20s
    ClickText                   Qualify Submission
    Sleep                       30s
    Click On Bind
    Get Details for Billing Record document validation
    Change Policy Functionality                             Cancel & Replace
    Select Change Cancel & Replacement Input
    Edit Limit Fields and verify rating after Cancel Replace
    Click On Bind After Cancel Replace Correction for admitted
    Get Details for Billing Record document validation
    Open Billing Record         Generated 
    Download Invoice
    Move to outputdir
    Verify Content on billing record PDF                    Cancel & Replace            ${uniqueName}
    Empty Directory command
    Navigate to policy Page from Billing record page
    ClickElement                //records-hoverable-link//span[contains(text(), 'P-')]
    Change Policy Functionality                             Flat Cancellation
    Select Flat Cancellation Input
    Click On Rate After Amendment
    Click On Bind After Amendment
    Open Billing Record         Flat Cancellation
    Download Invoice
    Move to outputdir
    Verify Content on billing record PDF                    Flat Cancellation           ${uniqueName}
    Empty Directory command
    Log To Console              ------ On Policy Page -------

Non- Admitted: Validate Billing Record for Cancel & Replace, Flat cancellation Primary
    #TCID=
    #Author= Shraddha T Patil
    [Documentation]             Validate Cancel & Replace, Flat cancellation
    [Tags]                      LGO_Coburn
    Creating a new Account state NY
    Checking Next Button On New Submission For SL           LawyerGuard_SL
    VerifyText                  Underwriter Workbench
    Add Account name on Insured info page
    Enter Territory data on Insured Info Page SL            New York: Remainder of State
    Click on save button
    Add Attorney
    Click on NEXT:Submission Info
    Select broker Contact Source
    Entering Submission_Info Details for SL                 Primary                     12/06/2024
    ClickText                   NEXT:Underwriter Analysis >
    VerifyText                  Underwriting Analysis
    Add Area Of Practice for SL
    Sleep                       20s
    Add Details In Underwriter Analysis Tab for SL
    Sleep                       20s
    ClickText                   Qualify Submission
    Sleep                       30s
    Click On Bind For SL        Individual broker license
    VerifyText                  Policy Name
    Get Details for Billing Record document validation
    Change Policy Functionality                             Cancel & Replace
    Select Change Cancel & Replacement Input
    Edit Limit Fields and verify rating after Cancel Replace
    Click On Bind After Cancel Replace Correction
    Get Details for Billing Record document validation
    Open Billing Record         Cancel & Replace
    Download Invoice
    Move to outputdir
    Verify Content on billing record PDF                    Cancel & Replace            ${uniqueName}
    Empty Directory command
    ClickElement                //records-hoverable-link//span[contains(text(), 'P-')]
    Change Policy Functionality                             Flat Cancellation
    Select Flat Cancellation Input
    Click On Rate After Amendment
    Click Bind SL After Amendment
    Open Billing Record         Flat Cancellation
    Download Invoice
    Move to outputdir
    Verify Content on billing record PDF                    Flat Cancellation           ${uniqueName}
    Empty Directory command
    Log To Console              ------ On Policy Page -------



Non- Admitted: Validate Billing Record for Cancel & Replace, Flat cancellation Excess
    #TCID=
    #Author= Shraddha T Patil
    [Documentation]             Validate Cancel & Replace, Flat cancellation
    [Tags]                      LGO_Coburn
    Creating a new Account state NY
    Checking Next Button On New Submission For SL           LawyerGuard_SL
    VerifyText                  Underwriter Workbench
    Add Account name on Insured info page
    Enter Territory data on Insured Info Page SL            New York: Remainder of State
    Click on save button
    Add Attorney
    Click on NEXT:Submission Info
    Select broker Contact Source
    Entering Submission_Info Details for SL                 Excess                      12/06/2024
    ClickText                   NEXT:Underwriter Analysis >
    VerifyText                  Underwriting Analysis
    Add Area Of Practice for SL
    Sleep                       20s
    Add Details In Underwriter Analysis Tab for SL
    Sleep                       20s
    ClickText                   Qualify Submission
    Sleep                       30s
    Add Premium to Excess Fields
    Rate Quote
    Click On Bind For SL        Individual broker license
    VerifyText                  Policy Name
    Get Details for Billing Record document validation
    Change Policy Functionality                             Cancel & Replace
    Select Change Cancel & Replacement Input
    Edit Limit Fields and verify rating after Cancel Replace
    Click On Bind After Cancel Replace Correction
    Get Details for Billing Record document validation
    Open Billing Record         Cancel & Replace
    Download Invoice
    Move to outputdir
    Verify Content on billing record PDF                    Cancel & Replace            ${uniqueName}
    Empty Directory command
    ClickElement                //records-hoverable-link//span[contains(text(), 'P-')]
    Change Policy Functionality                             Flat Cancellation
    Select Flat Cancellation Input
    Click On Rate After Amendment
    Click Bind SL After Amendment
    Open Billing Record         Flat Cancellation
    Download Invoice
    Move to outputdir
    Verify Content on billing record PDF                    Flat Cancellation           ${uniqueName}
    Empty Directory command
    Log To Console              ------ On Policy Page -------