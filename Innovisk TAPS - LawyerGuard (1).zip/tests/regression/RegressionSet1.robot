*** Settings ***
Library                         QWeb
Library                         QForce
Library                         FakerLibrary
Library                         String
Library                         BuiltIn
Library                         DateTime
Library                         RetryFailed                 global_retries=${retry_count}
Resource                        ../../resources/common.robot
Resource                        ../../PageObjects/PageObjects_Account.robot
Resource                        ../../PageObjects/PageObjects_HomePage.robot
Resource                        ../../PageObjects/PageObjects_Submission.robot
Resource                        ../../PageObjects/PageObjects_InusredInfo.robot
Resource                        ../../PageObjects/PageObjects_SubmissionInit.robot
Resource                        ../../PageObjects/PageObjects_SubmissionInfo.robot
Resource                        ../../PageObjects/PageObjects_UnderwrittingAnalysis.robot
Resource                        ../../PageObjects/PageObjects_CompareAndRateQuote.robot
Resource                        ../../PageObjects/PageObjects_PolicyPage.robot
Library                         ../../libraries/MailLib.py                              ${tenant_id}         ${client_id_mail}        ${client_secret_mail}

Library                         ../../libraries/graph.py
Resource                        ../../resources/graph.resource

Suite Setup                     Setup Browser
Suite Teardown                  CloseAllBrowsers

#Test Teardown                  Empty Directory             /home/executor/Downloads




*** Test Cases ***

Verify Header section of Quote Console: All Documents Generation and Renewal 
    #TCID=68891,68892,68893,68894
    #Author=Amol Gaymukhe
    [Documentation]             Verifying All Documents Generation and after Renewal
    [Tags]                      Regression_Test_LGO_Admitted                            Regression_Test
    Creating a new Account
    Validate LaweyrGuard New submission Fields
    VerifyText                  Underwriter Workbench
    Add Account name on Insured info page
    Click on save button
    Add Attorney
    Click on NEXT:Submission Info
    Select broker Contact Source
    Add Details In SubmissionInfo Page
    ClickText                   NEXT:Underwriter Analysis >
    VerifyText                  Underwriting Analysis
    Add Area Of Practice
    Sleep                       30s
    ClickText                   Qualify Submission
    Sleep                       30s
    Validate Header Fields On Compare and Rate quote
    Generate Document In Quoted                             Quote Proposal
    Generate Document In Quoted                             Streamlined Renewal
    Generate Document In Rated                              Indication
    Generate Document In Rated                              Account Summary
    Click On Rate
    Click On Bind
    Create a Renewal Flow
    Generate Document In Quoted after Renewal               Quote Proposal
    Generate Document In Quoted after Renewal               Streamlined Renewal
    Generate Document In Rated After Renewal                Indication
    Generate Document In Rated After Renewal                Account Summary

Check Email Sent Validate- Email Transmittals 
    #TCID=68888
    #Author=Amol Gaymukhe
    [Documentation]             Validate Email Transmittals for Binder Endorsement Policy SOA
    [Tags]                      Regression_Test_LGO_Admitted                            Regression_Test
    Creating a new Account
    Validate LaweyrGuard New submission Fields
    VerifyText                  Underwriter Workbench
    Add Account name on Insured info page
    Click on save button
    Add Attorney
    Click on NEXT:Submission Info
    Select broker Contact Source
    Add Details In SubmissionInfo Page
    ClickText                   NEXT:Underwriter Analysis >
    VerifyText                  Underwriting Analysis
    Add Area Of Practice
    Sleep                       30s
    ClickText                   Qualify Submission
    Sleep                       30s
    Click On Bind
    Send Mail On Policy Page    Binder Transmittal
    #Send Mail On Policy Page                               Endorsement Transmittal
    Sleep                       30s
    Send Mail On Policy Page    Policy Transmittal
    Send Mail On Policy Page    SOA Transmittal


Validate Renewal Commission-Ensure commission matches the assigned Broker Account Product Percentages    
    #TCID=68895
    #Author=Amol Gaymukhe
    [Documentation]             Functionality to check commission percentage on Renewal
    [Tags]                      Regression_Test_LGO_Admitted                            Regression_Test
    Creating a new Account
    Validate LaweyrGuard New submission Fields
    VerifyText                  Underwriter Workbench
    Add Account name on Insured info page
    Click on save button
    Add Attorney
    Click on NEXT:Submission Info
    Select broker Contact Source
    Add Details In SubmissionInfo Page
    ClickText                   NEXT:Underwriter Analysis >
    VerifyText                  Underwriting Analysis
    Add Area Of Practice
    Sleep                       30s
    ClickText                   Qualify Submission
    Sleep                       30s
    Click On Bind
    Create a Renewal Flow
    Get Default percentage on renewal and Verify matching


Verify Adding multiple forms in amendments and renewing the policy
    #TCID=120053
    #Author=Amol Gaymukhe
    [Documentation]             Functionality to check Renewal
    [Tags]                      Regression_Test_LGO_Admitted                            Regression_Test
    Creating an account with a state California
    Validate LaweyrGuard New submission Fields
    VerifyText                  Underwriter Workbench
    Add Account name on Insured info page
    Click on save button
    Add Attorney
    Click on NEXT:Submission Info
    Select broker Contact Source
    Add Details In SubmissionInfo Page
    ClickText                   NEXT:Underwriter Analysis >
    VerifyText                  Underwriting Analysis
    Add Area Of Practice
    Sleep                       30s
    ClickText                   Qualify Submission
    Sleep                       30s
    Click On Bind
    Change Policy Functionality                             Amendment
    Select Change Endorsement Input
    Edit Limit Fields and verify rating after amendment
    Add Endorsement             Additional Named Insured
    Add Endorsement             Additional Named Insured with Scheduled Retro Date
    Click Rate after adding endorsement
    Click On Bind After Amendment multiple
    Change Policy Functionality                             Amendment
    Select Change Endorsement Input
    Add Endorsement             Worldwide Coverage Territory
    Add Endorsement             Professional Services Extension
    Click Rate after adding endorsement
    Click On Bind After Amendment multiple
    Create a Renewal Flow
    Get Default percentage on renewal and Verify matching
    

   