*** Settings ***
Library                         QWeb
Library                         QForce
#Library                        QVision
Library                         FakerLibrary
Library                         String
Library                         BuiltIn
Library                         DateTime
Library                         ../../../libraries/read_docx.py
Resource                        ../../../resources/common.robot
Resource                        ../../../resources/ReadPDF.robot
Resource                        ../../../PageObjects/PageObjects_Account.robot
Resource                        ../../../PageObjects/PageObjects_HomePage.robot
Resource                        ../../../PageObjects/PageObjects_Submission.robot
Resource                        ../../../PageObjects/PageObjects_InusredInfo.robot
Resource                        ../../../PageObjects/PageObjects_SubmissionInit.robot
Resource                        ../../../PageObjects/PageObjects_SubmissionInfo.robot
Resource                        ../../../PageObjects/PageObjects_UnderwrittingAnalysis.robot
Resource                        ../../../PageObjects/PageObjects_CompareAndRateQuote.robot
Resource                        ../../../PageObjects/PageObjects_PDFRead.robot
Resource                        ../../../resources/PageSelection.robot
Resource                        ../../../PageObjects/Surplus_Lines/PageObjects_SL_UnderwriterAnalysis.robot
Resource                        ../../../PageObjects/GetLatestDownloadedDocxFile.robot
Resource                        ../../../PageObjects/PageObject_QImage_Common.robot

Library                         RetryFailed                 global_retries=${retry_count}


Suite Setup                     Setup Browser
Suite Teardown                  CloseAllBrowsers

*** Test Cases ***

Verify Account Sumary With spacing and font for Admitted Product
    #Author=Shraddha T Patil
    [Documentation]             Verify Indication document
    [Tags]                      Smoke_Test_LGO_Admitted     Smoke_Test
    Creating an account with a state California
    Validate LaweyrGuard New submission Fields
    VerifyText                  Underwriter Workbench
    Add Account name on Insured info page
    # VerifyInputValue          Contact Record Type         Attorney                    timeout=2s
    Click on save button
    Add Attorney
    Click on NEXT:Submission Info
    Select broker Contact Source
    Add Details In SubmissionInfo Page
    ClickText                   NEXT:Underwriter Analysis >
    VerifyText                  Underwriting Analysis
    Sleep                       20s
    Add Area Of Practice
    TypeText                    //label[text()\='Years']/parent::*//input               5
    ClickText                   Save                        anchor=Qualify Submission
    ClickText                   Qualify Submission          delay=5s
    Sleep                       30s
    #RefreshPage
    Generate Document In Rated                              Account Summary
    Open word document in online Word
    Set Global Variable         ${billingaddressState}      California
    Check Image comparison - PreBind - Account Summary      1                           accountsummary            ${billingaddressState}    0.84
    Scroll page                 SECTION 2 - SUBMISSION INFORMATION
    Check Image comparison - PreBind - Account Summary      2                           accountsummary            ${billingaddressState}    0.84
    Scroll page                 INTERNAL PROCEDURES
    Check Image comparison - PreBind - Account Summary      3                           accountsummary            ${billingaddressState}    0.84
    Scroll page                 SECTION 3 -
    Check Image comparison - PreBind - Account Summary      4                           accountsummary            ${billingaddressState}    0.84
    Scroll page                 SECTION 4 - COMPARE & RATE QUOTES
    #Check Image comparison - PreBind - Account Summary     5                           accountsummary            ${billingaddressState}    0.84
    Scroll page                ENDORSEMENTS
    Check Image comparison - PreBind - Account Summary      6                           accountsummary            ${billingaddressState}    0.84
    Scroll page                 FACTOR SUMMARY QUOTE
    Check Image comparison - PreBind - Account Summary      7                           accountsummary            ${billingaddressState}    0.84



Verify Account Sumary With spacing and font for SL Product
    #Author=Shraddha T Patil
    [Documentation]             Verify Account Summary document
    [Tags]                      Smoke_Test_LGO_Admitted     Smoke_Test
    Creating an account with a state California
    Checking Next Button On New Submission For SL           LawyerGuard_SL
    VerifyText                  Underwriter Workbench
    Add Account name on Insured info page
    Enter Territory data on Insured Info Page SL            New York: Remainder of State
    Click on save button
    Add Attorney
    Click on NEXT:Submission Info
    Select broker Contact Source
    Entering Submission_Info Details for SL                 Primary                     12/06/2024
    ClickText                   NEXT:Underwriter Analysis >
    VerifyText                  Underwriting Analysis
    Add Area Of Practice
    Add Details In Underwriter Analysis Tab for SL
    ClickText                   Save                        anchor=Qualify Submission
    ClickText                   Qualify Submission          delay=5s
    Sleep                       30s
    VerifyText                  Quote Console
    Generate Document In Rated                              Account Summary
    Open word document in online Word
    # Open new window and convert to PDF
    # Open PDF in Chrome        ${uniqueName}               ACCOUNT SUMMARY
    # Sleep                     10s
    Set Global Variable         ${billingaddressState}      California
    # Check Image comparison - PreBind - Account Summary    1                           accountsummarysl          ${billingaddressState}    0.879
    # Scroll page               SECTION 2 - SUBMISSION INFORMATION
    # Check Image comparison - PreBind - Account Summary    2                           accountsummarysl          ${billingaddressState}    0.862
    # Scroll page               INTERNAL PROCEDURES
    # Check Image comparison - PreBind - Account Summary    3                           accountsummarysl          ${billingaddressState}    0.940
    # Scroll page               SECTION 3 -
    # Check Image comparison - PreBind - Account Summary    4                           accountsummarysl          ${billingaddressState}    0.849
    # Scroll page               SECTION 4 - COMPARE & RATE QUOTES
    # Check Image comparison - PreBind - Account Summary    5                           accountsummarysl          ${billingaddressState}    0.866
    # Scroll page               ENDORSEMENTS
    # Check Image comparison - PreBind - Account Summary    6                           accountsummarysl          ${billingaddressState}    0.888
    # Scroll page               FACTOR SUMMARY QUOTE
    # Check Image comparison - PreBind - Account Summary    7                           accountsummarysl          ${billingaddressState}    0.910

    Check Image comparison - PreBind - Account Summary      1                           accountsummarysl          ${billingaddressState}    0.84
    Scroll page                 SECTION 2 - SUBMISSION INFORMATION
    Check Image comparison - PreBind - Account Summary      2                           accountsummarysl          ${billingaddressState}    0.84
    Scroll page                 INTERNAL PROCEDURES
    Check Image comparison - PreBind - Account Summary      3                           accountsummarysl          ${billingaddressState}    0.84
    Scroll page                 SECTION 3 -
    Check Image comparison - PreBind - Account Summary      4                           accountsummarysl          ${billingaddressState}    0.84
    Scroll page                 SECTION 4 - COMPARE & RATE QUOTES
    Check Image comparison - PreBind - Account Summary      5                           accountsummarysl          ${billingaddressState}    0.84
    Scroll page                 ENDORSEMENTS
    Check Image comparison - PreBind - Account Summary      6                           accountsummarysl          ${billingaddressState}    0.84
    Scroll page                 FACTOR SUMMARY QUOTE
    Check Image comparison - PreBind - Account Summary      7                           accountsummarysl          ${billingaddressState}    0.84

