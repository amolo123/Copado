*** Settings ***
Library                         QWeb
Library                         QForce
#Library                        QVision
Library                         FakerLibrary
Library                         String
Library                         BuiltIn
Library                         DateTime
Library                         ../../../libraries/read_docx.py
Resource                        ../../../resources/common.robot
Resource                        ../../../resources/ReadPDF.robot
Resource                        ../../../PageObjects/PageObjects_Account.robot
Resource                        ../../../PageObjects/PageObjects_HomePage.robot
Resource                        ../../../PageObjects/PageObjects_Submission.robot
Resource                        ../../../PageObjects/PageObjects_InusredInfo.robot
Resource                        ../../../PageObjects/PageObjects_SubmissionInit.robot
Resource                        ../../../PageObjects/PageObjects_SubmissionInfo.robot
Resource                        ../../../PageObjects/PageObjects_UnderwrittingAnalysis.robot
Resource                        ../../../PageObjects/PageObjects_CompareAndRateQuote.robot
Resource                        ../../../PageObjects/PageObjects_PDFRead.robot
Resource                        ../../../resources/PageSelection.robot
Resource                        ../../../PageObjects/Surplus_Lines/PageObjects_SL_UnderwriterAnalysis.robot
Resource                        ../../../PageObjects/GetLatestDownloadedDocxFile.robot
Resource                        ../../../PageObjects/PageObject_QImage_Common.robot
Resource                        ../../../PageObjects/PageObjects_CompareAndRateQuote.robot

Library                         RetryFailed                 global_retries=${retry_count}


Suite Setup                     Setup Browser
Suite Teardown                  CloseAllBrowsers

*** Test Cases ***

Verify Indication With spacing and font for Admitted Product
    #Author=Piki Lubana
    [Documentation]             Verify Indication document
    [Tags]                      Smoke_Test_LGO_Admitted     Smoke_Test
    
    Creating a new Account
    Validate LaweyrGuard New submission Fields
    VerifyText                  Underwriter Workbench
    Add Account name on Insured info page
    # VerifyInputValue          Contact Record Type         Attorney                    timeout=2s
    Click on save button
    Add Attorney
    Click on NEXT:Submission Info
    Select broker Contact Source
    Add Details In SubmissionInfo Page
    ClickText                   NEXT:Underwriter Analysis >
    VerifyText                  Underwriting Analysis
    Sleep                       20s
    Add Area Of Practice
    TypeText                    //label[text()\='Years']/parent::*//input               5
    ClickText                   Save                        anchor=Qualify Submission
    ClickText                   Qualify Submission          delay=5s
    Sleep                       30s
    #Validate Header Fields On Compare and Rate quote
    RefreshPage
    Generate Document In Rated                            Indication
    Open PDF in Chrome          ${uniqueName}               BALLPARK
    Check Image comparison - PreBind                        1                           Indication            ${billingaddressState}
    Select PDF Page 2           LawyerGuard
    Check Image comparison - PreBind                        2                           Indication            ${billingaddressState}
    # Select PDF Page 3           LawyerGuard