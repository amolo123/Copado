*** Settings ***
Library                         QWeb
Library                         QForce
Library                         FakerLibrary
Library                         String
Library                         BuiltIn
Library                         DateTime
Library                         RetryFailed                 global_retries=${retry_count}
Resource                        ../../resources/common.robot
Resource                        ../../resources/ReadPDF.robot
Resource                        ../../PageObjects/PageObjects_Account.robot
Resource                        ../../PageObjects/PageObjects_HomePage.robot
Resource                        ../../PageObjects/PageObjects_Submission.robot
Resource                        ../../PageObjects/PageObjects_InusredInfo.robot
Resource                        ../../PageObjects/PageObjects_SubmissionInit.robot
Resource                        ../../PageObjects/PageObjects_SubmissionInfo.robot
Resource                        ../../PageObjects/PageObjects_UnderwrittingAnalysis.robot
Resource                        ../../PageObjects/PageObjects_CompareAndRateQuote.robot
Resource                        ../../PageObjects/PageObjects_PolicyPage.robot
Library                         ../../libraries/MailLib.py                              ${tenant_id}         ${client_id_mail}        ${client_secret_mail}

Library                         ../../libraries/graph.py
Resource                        ../../resources/graph.resource

Suite Setup                     Setup Browser
Suite Teardown                  CloseAllBrowsers

#Test Teardown                  Empty Directory             /home/executor/Downloads



*** Test Cases ***

Verify Header section of Quote Console: SRP and Bulk Rate 
    #TCID=69220
    #Author=Amol Gaymukhe
    [Documentation]             Verify Bulk rate functionality
    [Tags]                      Regression_Test_LGO_Admitted                            Regression_Test
    Creating a new Account
    Validate LaweyrGuard New submission Fields
    VerifyText                  Underwriter Workbench
    Add Account name on Insured info page
    Click on save button
    Add Attorney
    Click on NEXT:Submission Info
    Select broker Contact Source
    Add Details In SubmissionInfo Page
    ClickText                   NEXT:Underwriter Analysis >
    VerifyText                  Underwriting Analysis
    Add Area Of Practice
    ClickText                   Qualify Submission
    Sleep                       30s
    Verify SRP Value
    Verify Bulk Rate


Verify Header section of Quote Console: Internal Referal 
    #TCID=69222
    #Author=Amol Gaymukhe
    [Documentation]             Verify Internal Refer Functionality
    [Tags]                      Regression_Test_LGO_Admitted                            Regression_Test

    Creating a new Account
    Validate LaweyrGuard New submission Fields
    VerifyText                  Underwriter Workbench
    Add Account name on Insured info page
    Click on save button
    Add Attorney
    Click on NEXT:Submission Info
    Select broker Contact Source
    Add Details In SubmissionInfo Page
    ClickText                   NEXT:Underwriter Analysis >
    VerifyText                  Underwriting Analysis
    Add Area Of Practice
    ClickText                   Qualify Submission
    Sleep                       30s
    Vaidate Refer Functionality Fields
    Add Internal Refer


Refer Functionality : External Refer
    #TCID=69221
    #Author=Amol Gaymukhe
    [Documentation]             Verify Internal External Functionality
    [Tags]                      Regression_Test_LGO_Admitted                            Regression_Test

    Creating a new Account
    Validate LaweyrGuard New submission Fields
    VerifyText                  Underwriter Workbench
    Add Account name on Insured info page
    Click on save button
    Add Attorney
    Click on NEXT:Submission Info
    Select broker Contact Source
    Add Details In SubmissionInfo Page
    ClickText                   NEXT:Underwriter Analysis >
    VerifyText                  Underwriting Analysis
    Add Area Of Practice
    ClickText                   Qualify Submission
    Sleep                       30s
    Vaidate Refer Functionality Fields
    Add External Refer


Amendment-Adding additional limits / Updating factor values
    #TCID=68896
    #Author=Amol Gaymukhe
    [Documentation]             Adding additional limits / Updating factor values
    [Tags]                      Regression_Test_LGO_Admitted                            Regression_Test
    Creating a new Account
    Validate LaweyrGuard New submission Fields
    VerifyText                  Underwriter Workbench
    Add Account name on Insured info page
    Click on save button
    Add Attorney
    Click on NEXT:Submission Info
    Select broker Contact Source
    Add Details In SubmissionInfo Page
    ClickText                   NEXT:Underwriter Analysis >
    VerifyText                  Underwriting Analysis
    Add Area Of Practice
    ClickText                   Qualify Submission
    Sleep                       30s
    Click On Bind
    Change Policy Functionality                             Amendment
    Select Change Endorsement Input
    Edit Limit Fields and verify rating after amendment



Name Change Address Change -Policy Change Document generation, and ensure documents are not printing Taxes/Fees/ Return Premium/Additional Premium
    #TCID=68902
    #Author=Amol Gaymukhe
    [Documentation]             Name Change Address Change -Policy Change Document generation
    [Tags]                      Regression_Test_LGO_Admitted                            Regression_Test
    Creating a new Account
    Validate LaweyrGuard New submission Fields
    VerifyText                  Underwriter Workbench
    Add Account name on Insured info page
    Click on save button
    Add Attorney
    Click on NEXT:Submission Info
    Select broker Contact Source
    Add Details In SubmissionInfo Page
    ClickText                   NEXT:Underwriter Analysis >
    VerifyText                  Underwriting Analysis
    Add Area Of Practice
    ClickText                   Qualify Submission
    Sleep                       30s
    Click On Bind
    Change Policy Functionality                             Name Change
    Select Change Name Input
    Change Policy Functionality                             Address Change
    Select Change Address Input

Extended Reporting Period - Firm 
    #TCID=68903
    #Author=Amol Gaymukhe
    [Documentation]             Extended reporting period
    [Tags]                      Regression_Test_LGO_Admitted                            Regression_Test
    Creating a new Account
    Validate LaweyrGuard New submission Fields
    VerifyText                  Underwriter Workbench
    Add Account name on Insured info page
    Click on save button
    Add Attorney
    Click on NEXT:Submission Info
    Select broker Contact Source
    Add Details In SubmissionInfo Page
    ClickText                   NEXT:Underwriter Analysis >
    VerifyText                  Underwriting Analysis
    Add Area Of Practice
    ClickText                   Qualify Submission
    Sleep                       30s
    Click On Bind
    Change Policy Functionality                             Midterm Cancellation
    Select Change Midterm Cancellation Input
    Click On Bind After Amendment multiple
    Change Policy Functionality                             Extended Reporting Period
    Select Change ERP date Input
    Click On Bind After Amendment multiple


Validate Open subjectivities are not being listed and displayed on the Binder Email transmittal    
    #TCID=69216
    #Author=Amol Gaymukhe
    [Documentation]             Open subjectivities are not being listed and displayed on the Binder Email transmittal
    [Tags]                      Regression_Test_LGO_Admitted                            Regression_Test
    Creating a new Account
    Validate LaweyrGuard New submission Fields
    VerifyText                  Underwriter Workbench
    Add Account name on Insured info page
    Click on save button
    Add Attorney
    Click on NEXT:Submission Info
    Select broker Contact Source
    Add Details In SubmissionInfo Page
    ClickText                   NEXT:Underwriter Analysis >
    VerifyText                  Underwriting Analysis
    Add Area Of Practice
    Add Subjectivity On Underwriter Analysis Page
    ClickText                   Qualify Submission
    Sleep                       30s
    Click On Bind
    Send Binder Transmittal Mail And Check Outstanding Subjectivities



Amendment -Additional Premium / Return Premium    
    #TCID=68886
    #Author=Amol Gaymukhe
    [Documentation]             Amendment -Additional Premium / Return Premium
    [Tags]                      Regression_Test_LGO_Admitted                            Regression_Test
    Creating a new Account
    Validate LaweyrGuard New submission Fields
    VerifyText                  Underwriter Workbench
    Add Account name on Insured info page
    Click on save button
    Add Attorney
    Click on NEXT:Submission Info
    Select broker Contact Source
    Add Details In SubmissionInfo Page
    ClickText                   NEXT:Underwriter Analysis >
    VerifyText                  Underwriting Analysis
    Add Area Of Practice
    ClickText                   Qualify Submission
    Sleep                       30s
    RefreshPage
    Click On Bind
    Change Policy Functionality                             Amendment
    Select Change Endorsement Input
    Input Data in Predecessor Firm On Underwriter Analysis
    ClickText                   Save
    Sleep                       5s
    ClickText                   Compare & Rate Quotes
    Click On Rate After Amendment
    Sleep                       5s
    Click On Bind After Amendment multiple
    Sleep                       10s
    Send Mail On Policy Page    Endorsement Transmittal
    Generate Document On Policy Page                        ChangeEndorsement
    Sleep                       40s
    Move to outputdir
    Sleep                       40s
    Test PDF File               Premium Determination
    Test PDF File               Limits/Exposure
    Test PDF File               Self-Insured Retention or Deductible

