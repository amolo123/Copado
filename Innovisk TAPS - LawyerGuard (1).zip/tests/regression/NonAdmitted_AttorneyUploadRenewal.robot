*** Settings ***
Library                         QWeb
Library                         QForce
Library                         FakerLibrary
Library                         String
Library                         BuiltIn
Library                         DateTime
Library                         RetryFailed                 global_retries=${retry_count}
Resource                        ../../resources/common.robot
Resource                        ../../PageObjects/PageObjects_Account.robot
Resource                        ../../PageObjects/PageObjects_HomePage.robot
Resource                        ../../PageObjects/PageObjects_Submission.robot
Resource                        ../../PageObjects/PageObjects_InusredInfo.robot
Resource                        ../../PageObjects/PageObjects_SubmissionInit.robot
Resource                        ../../PageObjects/PageObjects_SubmissionInfo.robot
Resource                        ../../PageObjects/PageObjects_CheckEndorsements.robot
Resource                        ../../PageObjects/PageObjects_UnderwrittingAnalysis.robot
Resource                        ../../PageObjects/Surplus_Lines/PageObjects_SL_UnderwriterAnalysis.robot
Resource                        ../../PageObjects/PageObjects_CompareAndRateQuote.robot
Resource                        ../../PageObjects/PageObjects_Quote.robot
Resource                        ../../PageObjects/PageObjects_PolicyPage.robot
Resource                        ../../PageObjects/PageObjects_PolicyPage.robot
Resource                        ../../PageObjects/PageObjects_Quote.robot

Library                         RetryFailed                 global_retries=${retry_count}
Suite Setup                     Setup Browser
Suite Teardown                  CloseAllBrowsers

Test Teardown                  Empty Directory             /home/executor/Downloads


*** Test Cases ***
Validate Upload Attorney on renewal for primary
    #TCID=120094
    #Author=Rugveda
    [Documentation]             Functionality on Insured Info Page
    [Tags]                      Regression_Test_LGO_NONAdmitted                         Regression_Test
    Creating a new Account state NY
    Checking Next Button On New Submission For SL           LawyerGuard_SL
    VerifyText                  Underwriter Workbench
    Add Account name on Insured info page
    Enter Territory data on Insured Info Page SL            New York: Remainder of State
    Click on save button
    Add Static Attorney
    ${value}=                   GetInputValue               Number Of Attorneys
    Set Global Variable         ${value}
    Click on NEXT:Submission Info
    Select broker Contact Source
    Entering Submission_Info Details for SL                 Primary                     12/06/2024
    ClickText                   NEXT:Underwriter Analysis >
    VerifyText                  Underwriting Analysis
    Add Area Of Practice
    Add Details In Underwriter Analysis Tab for SL
    ClickText                   Qualify Submission
    Sleep                       30s
    Click On Bind For SL        Individual broker license
    VerifyText                  Policy Name
    Sleep                       10s
    Renewal flow for upload attorney
    Account click
    VerifyText                  Recently Viewed             timeout=120s
    ClickText                   ${uniquename}
    Import Attorneys
    #ClickText                  Policies                    anchor=Details
    #UseTable                   Policy Name
    #ClickText                  P-                          anchor=Policy Name
    ClickText                   Submissions                 anchor=Details
    ClickElement                //table[@aria-label\='Submissions']/tbody/tr[1]//th//a
    # GoTo                      ${url}
    Compare Attorneys On Renewal
    ClickText                   NEXT:Submission Info >
    ClickText                   NEXT:Underwriter Analysis >
    VerifyText                  Underwriting Analysis
    Add Area Of Practice
    Sleep                       30s
    ClickText                   Qualify Submission
    Sleep                       30s
    Click On Rate
    Click On Bind
    Log To Console              ------ Renewal Flow Successfull ---------

Validate Upload Attorney on Renewal for Excess
    #TCID=120095
    #Author=Rugveda
    [Documentation]             Functionality on Insured Info Page
    [Tags]                      Regression_Test_LGO_NONAdmitted                         Regression_Test
    Creating a new Account state NY
    Checking Next Button On New Submission For SL           LawyerGuard_SL
    VerifyText                  Underwriter Workbench
    Add Account name on Insured info page
    Enter Territory data on Insured Info Page SL            New York: Remainder of State
    Click on save button
    Add Static Attorney
    ${value}=                   GetInputValue               Number Of Attorneys
    Set Global Variable         ${value}
    Click on NEXT:Submission Info
    Select broker Contact Source
    Entering Submission_Info Details for SL                 Excess                      12/06/2024
    ClickText                   NEXT:Underwriter Analysis >
    VerifyText                  Underwriting Analysis
    Add Area Of Practice for SL
    Add Details In Underwriter Analysis Tab for SL
    ClickText                   Qualify Submission
    Sleep                       30s
    Add Premium to Excess Fields
    Rate Quote
    Sleep                       30s
    Click On Bind For SL        Individual broker license
    VerifyText                  Policy Name
    Sleep                       10s
    Renewal flow for upload attorney
    ClickText                   < PREVIOUS:Insured Info
    Account click
    VerifyText                  Recently Viewed             timeout=120s
    ClickText                   ${uniquename}
    Import Attorneys
    #ClickText                  Policies                    anchor=Details
    #UseTable                   Policy Name
    #ClickText                  P-                          anchor=Policy Name
    ClickText                   Submissions                 anchor=Details
    ClickElement                //table[@aria-label\='Submissions']/tbody/tr[1]//th//a
    # GoTo                      ${url}
    Compare Attorneys On Renewal
    ClickText                   NEXT:Submission Info >
    ClickText                   NEXT:Underwriter Analysis >
    VerifyText                  Underwriting Analysis
    Add Area Of Practice
    Sleep                       30s
    ClickText                   Qualify Submission
    Sleep                       30s
    Click On Rate
    Click On Bind
    Log To Console              ------ Renewal Flow Successfull ---------
