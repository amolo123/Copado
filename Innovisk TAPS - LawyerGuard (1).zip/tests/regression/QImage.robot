*** Settings ***
Library                         QWeb
Library                         QForce
#Library                        QVision
Library                         FakerLibrary
Library                         String
Library                         BuiltIn
Library                         DateTime
Resource                        ../../resources/common.robot
Resource                        ../../resources/ReadPDF.robot
Resource                        ../../PageObjects/PageObjects_Account.robot
Resource                        ../../PageObjects/PageObjects_HomePage.robot
Resource                        ../../PageObjects/PageObjects_Submission.robot
Resource                        ../../PageObjects/PageObjects_InusredInfo.robot
Resource                        ../../PageObjects/PageObjects_SubmissionInit.robot
Resource                        ../../PageObjects/PageObjects_SubmissionInfo.robot
Resource                        ../../PageObjects/PageObjects_UnderwrittingAnalysis.robot
Resource                        ../../PageObjects/PageObjects_CompareAndRateQuote.robot
Resource                        ../../PageObjects/PageObjects_PDFRead.robot
Resource                        ../../resources/PageSelection.robot
Resource                        ../../PageObjects/Surplus_Lines/PageObjects_SL_UnderwriterAnalysis.robot

Library                         RetryFailed                 global_retries=${retry_count}

Suite Setup                     Setup Browser
Suite Teardown                  CloseAllBrowsers


*** Test Cases ***

Verify Account Sumary With spacing and font for Admitted Product
    #Author=Shraddha T Patil
    [Documentation]             Verify Indication document
    [Tags]                      Smoke_Test_LGO_Admitted     Smoke_Test
    Creating a new Account
    Validate LaweyrGuard New submission Fields
    VerifyText                  Underwriter Workbench
    Add Account name on Insured info page
    # VerifyInputValue          Contact Record Type         Attorney                    timeout=2s
    Click on save button
    Add Attorney
    Click on NEXT:Submission Info
    Select broker Contact Source
    Add Details In SubmissionInfo Page
    ClickText                   NEXT:Underwriter Analysis >
    VerifyText                  Underwriting Analysis
    Sleep                       20s
    Add Area Of Practice
    TypeText                    //label[text()\='Years']/parent::*//input               5
    ClickText                   Save                        anchor=Qualify Submission
    ClickText                   Qualify Submission          delay=5s
    Sleep                       30s
    RefreshPage
    Generate Document In Rated                              Account Summary
    Sleep                       10s
    Go To                       chrome://downloads
    ${date}=                    Get Current Date            increment=5days             result_format=%-m-%-d-%Y
    QVision.ClickText           ACCOUNT SUMMARY - ${uniqueName}, ${date}
    SwitchWindow                1
    #SwitchWindow               2
    Check Image comparison for Account Summary              1
    Select PDF Page 2
    Check Image comparison for Quote letter                 2
    Select PDF Page 3
    Check Image comparison for Quote letter                 3
    Select PDF Page 4
    Check Image comparison for Quote letter                 4
    Select PDF Page 5
    Check Image comparison for Quote letter                 5