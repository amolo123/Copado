*** Settings ***
Library                         QWeb
Library                         QForce
Library                         FakerLibrary
Library                         String
Library                         BuiltIn
Library                         DateTime
Library                         RetryFailed                 global_retries=${retry_count}
Resource                        ../../resources/common.robot
Resource                        ../../resources/ReadPDF.robot
Resource                        ../../PageObjects/PageObjects_Account.robot
Resource                        ../../PageObjects/PageObjects_HomePage.robot
Resource                        ../../PageObjects/PageObjects_Submission.robot
Resource                        ../../PageObjects/PageObjects_InusredInfo.robot
Resource                        ../../PageObjects/PageObjects_SubmissionInit.robot
Resource                        ../../PageObjects/PageObjects_SubmissionInfo.robot
Resource                        ../../PageObjects/PageObjects_UnderwrittingAnalysis.robot
Resource                        ../../PageObjects/PageObjects_CompareAndRateQuote.robot
Resource                        ../../PageObjects/PageObjects_PolicyPage.robot
Library                         ../../libraries/MailLib.py                              ${tenant_id}         ${client_id_mail}        ${client_secret_mail}

Library                         ../../libraries/graph.py
Resource                        ../../resources/graph.resource

Suite Setup                     Setup Browser
Suite Teardown                  CloseAllBrowsers

#Test Teardown                  Empty Directory             /home/executor/Downloads




*** Test Cases ***

Validate Ability to select Territory if zip code does not exist in database for rating
    #TCID=68886
    #Author=Amol Gaymukhe
    [Documentation]             Functionality on Insured Info Page
    [Tags]                      Regression_Test_LGO_Admitted                            Regression_Test
    Creating a new Account
    Validate LaweyrGuard New submission Fields
    VerifyText                  Underwriter Workbench
    Add Account name on Insured info page
    Remove Pin Code and Check Broker input page


Amendment --Policy Change document generation
    #TCID=68897
    #Author=Amol Gaymukhe
    [Documentation]             Functionality on Insured Info Page
    [Tags]                      Regression_Test_LGO_Admitted                            Regression_Test
    Creating a new Account
    Validate LaweyrGuard New submission Fields
    VerifyText                  Underwriter Workbench
    Add Account name on Insured info page
    Click on save button
    Add Attorney
    Click on NEXT:Submission Info
    Select broker Contact Source
    Add Details In SubmissionInfo Page
    ClickText                   NEXT:Underwriter Analysis >
    VerifyText                  Underwriting Analysis
    Add Area Of Practice
    Sleep                       20s
    ClickText                   Qualify Submission
    Sleep                       30s
    Click On Bind
    Change Policy Functionality                             Amendment
    Select Change Endorsement Input
    Input Data in Predecessor Firm On Underwriter Analysis
    ClickText                   Save
    Sleep                       5s
    ClickText                   Compare & Rate Quotes
    Click On Rate After Amendment
    Click On Bind After Amendment multiple
    Sleep                       30s
    Generate Document On Policy Page                        ChangeEndorsement
    Sleep                       10s
    Move to outputdir
    Test PDF File               Premium Determination
    Test PDF File               Limits/Exposure
    Test PDF File               Self-Insured Retention or Deductible



Validate Midterm Cancellation
    #TCID=68900
    #Author=Amol Gaymukhe
    [Documentation]             Functionality on Insured Info Page
    [Tags]                      Regression_Test_LGO_Admitted                            Regression_Test
    Creating a new Account
    Validate LaweyrGuard New submission Fields
    VerifyText                  Underwriter Workbench
    Add Account name on Insured info page
    Click on save button
    Add Attorney
    Click on NEXT:Submission Info
    Select broker Contact Source
    Add Details In SubmissionInfo Page
    ClickText                   NEXT:Underwriter Analysis >
    VerifyText                  Underwriting Analysis
    Add Area Of Practice
    Sleep                       20s
    ClickText                   Qualify Submission
    Sleep                       30s
    Click On Bind
    Change Policy Functionality                             Midterm Cancellation
    Select Change Midterm Cancellation Input
    Click On Bind After Amendment multiple
    Click Quote On Policy Page
    VerifyText                  Midterm Cancellation



Extension -Policy Change document generation, verify dates
    #TCID=68901
    #Author=Amol Gaymukhe
    [Documentation]             Functionality on Insured Info Page
    [Tags]                      Regression_Test_LGO_Admitted                            Regression_Test
    Creating a new Account
    Validate LaweyrGuard New submission Fields
    VerifyText                  Underwriter Workbench
    Add Account name on Insured info page
    Click on save button
    Add Attorney
    Click on NEXT:Submission Info
    Select broker Contact Source
    Add Details In SubmissionInfo Page
    ClickText                   NEXT:Underwriter Analysis >
    VerifyText                  Underwriting Analysis
    Add Area Of Practice
    Sleep                       20s
    ClickText                   Qualify Submission
    Sleep                       30s
    Click On Bind
    Change Policy Functionality                             Extension
    Select Change Extension Input
    Click On Bind After Amendment
    Click Quote On Policy Page
    VerifyText                  Extension



Validate BOR
    #TCID=74712
    #Author=Amol Gaymukhe
    [Documentation]             Functionality on Insured Info Page
    [Tags]                      Regression_Test_LGO_Admitted                            Regression_Test
    Creating a new Account
    Validate LaweyrGuard New submission Fields
    VerifyText                  Underwriter Workbench
    Add Account name on Insured info page
    Click on save button
    Add Attorney
    Click on NEXT:Submission Info
    Select broker Contact Source
    Add Details In SubmissionInfo Page
    ClickText                   NEXT:Underwriter Analysis >
    VerifyText                  Underwriting Analysis
    Add Area Of Practice
    Sleep                       20s
    ClickText                   Qualify Submission
    Sleep                       30s
    Click On Bind
    Change Policy Functionality                             Broker of Record (BOR)
    Select BOR Input
    ClickText                   Quote                       anchor=Emails
    Sleep                       10s
    VerifyText                  Broker of Record (BOR)
    VerifyText                  ${uniquename} 2
    Sleep                       30
    #Home
    #ClickText                  Policies
    # ClickElement              (//force-lookup//a)[1]

    # ClickText                 ${uniquename}
    RefreshPage
    ClickText                   Quote                       anchor=Emails
    VerifyText                  ${uniquename}               anchor=Quote Name
    VerifyText                  Bound                       anchor=Status
    VerifyText                  Bound                       anchor=3



Validate Name Change
    #TCID=74713
    #Author=Amol Gaymukhe
    [Documentation]             Functionality on Insured Info Page
    [Tags]                      Regression_Test_LGO_Admitted                            Regression_Test
    Creating a new Account
    Validate LaweyrGuard New submission Fields
    VerifyText                  Underwriter Workbench
    Add Account name on Insured info page
    Click on save button
    Add Attorney
    Click on NEXT:Submission Info
    Select broker Contact Source
    Add Details In SubmissionInfo Page
    ClickText                   NEXT:Underwriter Analysis >
    VerifyText                  Underwriting Analysis
    Sleep                       20s
    Add Area Of Practice
    ClickText                   Qualify Submission
    Sleep                       30s
    Click On Bind
    Sleep                       20s
    Change Policy Functionality                             Name Change
    Select Change Name Input
    Click Quote On Policy Page
    VerifyText                  Name Change
    VerifyText                  ${uniquename} 2
    Sleep                       30
    #Home
    # ClickText                 Policies
    # ClickElement              (//force-lookup//a)[1]
    RefreshPage
    ClickText                   Quote                       anchor=Emails
    VerifyText                  ${uniquename} 2             anchor=Quote Name
    VerifyText                  Bound                       anchor=Status
    VerifyText                  Bound                       anchor=3


Validate change policy - Address change
    #TCID=74716
    #Author=Amol Gaymukhe
    [Documentation]             Functionality on Insured Info Page
    [Tags]                      Regression_Test_LGO_Admitted                            Regression_Test
    Creating a new Account
    Validate LaweyrGuard New submission Fields
    VerifyText                  Underwriter Workbench
    Add Account name on Insured info page
    Click on save button
    Add Attorney
    Click on NEXT:Submission Info
    Select broker Contact Source
    Add Details In SubmissionInfo Page
    ClickText                   NEXT:Underwriter Analysis >
    VerifyText                  Underwriting Analysis
    Sleep                       20s
    Add Area Of Practice
    ClickText                   Qualify Submission
    Sleep                       30s
    Click On Bind
    Change Policy Functionality                             Address Change
    Select Change Address Input
    Click Quote On Policy Page
    VerifyText                  Address Change
    VerifyText                  ${uniquename} 2
    Sleep                       30
    #ClickText                  Policies                    anchor=Emails
    #ClickElement               (//th[@data-label\='Policy Name']//a)[1]
    RefreshPage
    Click Quote On Policy Page
    VerifyText                  Address Change
    VerifyText                  New Business
    VerifyText                  Bound                       anchor=Address Change
    VerifyText                  Bound                       anchor=New Business





Validate Litigation History entered in NB is carried For Renewal 
    #TCID=79428
    #Author=Amol Gaymukhe
    [Documentation]             Validate Amendment and predecessorFirmChange
    [Tags]                      Regression_Test_LGO_Admitted                            Regression_Test
    Creating a new Account
    Validate LaweyrGuard New submission Fields
    VerifyText                  Underwriter Workbench
    Add Account name on Insured info page
    Click on save button
    Add Attorney
    Click on NEXT:Submission Info
    Select broker Contact Source
    Add Details In SubmissionInfo Page
    ClickText                   NEXT:Underwriter Analysis >
    VerifyText                  Underwriting Analysis
    Add Area Of Practice
    Add Litigation History On Underwriter Analysis Page
    Sleep                       30s
    ClickText                   Qualify Submission
    Sleep                       30s
    Select Endorsements
    #Click On Rate
    Click On Bind
    Create a Renewal Flow
    Verify Litigation History after Renewal


Extended Reported Period - Name Individual 
    #TCID=93728
    #Author=Amol Gaymukhe
    [Documentation]             Functionality on Insured Info Page
    [Tags]                      Regression_Test_LGO_Admitted                            Regression_Test
    Creating a new Account
    Validate LaweyrGuard New submission Fields
    VerifyText                  Underwriter Workbench
    Add Account name on Insured info page
    Click on save button
    Add Attorney
    Click on NEXT:Submission Info
    Select broker Contact Source
    Add Details In SubmissionInfo Page
    ClickText                   NEXT:Underwriter Analysis >
    VerifyText                  Underwriting Analysis
    Add Area Of Practice
    Sleep                       20s
    ClickText                   Qualify Submission
    Sleep                       30s
    Click On Bind
    Change Policy Functionality                             Midterm Cancellation
    Select Change Midterm Cancellation Input
    Click On Bind After Amendment
    Change Policy Functionality                             Extended Reporting Period
    Select Change ERP date Input
    Click On Bind After Amendment
    Click Quote On Policy Page
    VerifyText                  Midterm Cancellation
    VerifyText                  Extended Reporting Period
