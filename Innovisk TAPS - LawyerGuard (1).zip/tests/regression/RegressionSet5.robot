*** Settings ***
Library                         QWeb
Library                         QForce
Library                         FakerLibrary
Library                         String
Library                         BuiltIn
Library                         DateTime
Library                         RetryFailed                 global_retries=${retry_count}
Resource                        ../../resources/common.robot
Resource                        ../../resources/ReadPDF.robot
Resource                        ../../PageObjects/PageObjects_Account.robot
Resource                        ../../PageObjects/PageObjects_HomePage.robot
Resource                        ../../PageObjects/PageObjects_Submission.robot
Resource                        ../../PageObjects/PageObjects_InusredInfo.robot
Resource                        ../../PageObjects/PageObjects_SubmissionInit.robot
Resource                        ../../PageObjects/PageObjects_SubmissionInfo.robot
Resource                        ../../PageObjects/PageObjects_UnderwrittingAnalysis.robot
Resource                        ../../PageObjects/PageObjects_CompareAndRateQuote.robot
Resource                        ../../PageObjects/PageObjects_PolicyPage.robot
Library                         ../../libraries/MailLib.py                              ${tenant_id}         ${client_id_mail}        ${client_secret_mail}

Library                         ../../libraries/graph.py
Resource                        ../../resources/graph.resource

Suite Setup                     Setup Browser
Suite Teardown                  CloseAllBrowsers

#Test Teardown                  Empty Directory             /home/executor/Downloads



*** Test Cases ***
NB - Workflow status regression 
    #TCID=86672
    #Author=Amol Gaymukhe
    [Documentation]             Verify Workflow Status
    [Tags]                      Regression_Test_LGO_Admitted                            Regression_Test
    Creating a new Account
    Validate LaweyrGuard New submission Fields
    VerifyText                  Underwriter Workbench
    Add Account name on Insured info page
    Click on save button
    Add Attorney
    Click on NEXT:Submission Info
    Select broker Contact Source
    Add Details In SubmissionInfo Page
    ClickText                   NEXT:Underwriter Analysis >
    VerifyText                  Underwriting Analysis
    Add Area Of Practice
    Sleep                       20s
    ClickText                   Qualify Submission
    Sleep                       30s
    Send Mail On Submission Page                            Indication Transmittal
    ClickText                   Submission Info
    Check WorkFlow Status Indication Release
    Add Subjectivity On Underwriter Analysis Page
    ClickText                   Save                        anchor=Qualify Submission
    ClickText                   Compare & Rate Quotes
    Send Mail On Submission Page                            Quote Transmittal
    Check WorkFlow Status Quote Release


Validate for CT STATE - New Business flow by changing factors
    #TCID=68881
    #Author=Amol Gaymukhe
    [Documentation]             Check NB for CT State
    [Tags]                      Regression_Test_LGO_Admitted                            Regression_Test
    Creating an account with a state Connecticut
    Validate LaweyrGuard New submission Fields
    VerifyText                  Underwriter Workbench
    Add Account name on Insured info page
    Click on save button
    Add Attorney
    Click on NEXT:Submission Info
    Select broker Contact Source
    Add Details In SubmissionInfo Page
    ClickText                   NEXT:Underwriter Analysis >
    VerifyText                  Underwriting Analysis
    Add Area Of Practice
    Add Litigation History On Underwriter Analysis Page
    Sleep                       20s
    ClickText                   Qualify Submission
    Sleep                       30s
    Edit Limit Fields and verify rating


New Business-Rate, Quote, Bind- CA state
    #TCID=68882
    #Author=Amol Gaymukhe
    [Documentation]             Check NB for CT State
    [Tags]                      Regression_Test_LGO_Admitted                            Regression_Test
    Creating an account with a state California
    Validate LaweyrGuard New submission Fields
    VerifyText                  Underwriter Workbench
    Add Account name on Insured info page
    Click on save button
    Add Attorney
    Click on NEXT:Submission Info
    Select broker Contact Source
    Add Details In SubmissionInfo Page
    ClickText                   NEXT:Underwriter Analysis >
    VerifyText                  Underwriting Analysis
    Add Area Of Practice
    Sleep                       20s
    ClickText                   Qualify Submission
    Sleep                       30s
    Click On Bind


Validate Flat Cancellation
    #TCID=68899
    #Author=Amol Gaymukhe
    [Documentation]             Validate Flat Cancellation
    [Tags]                      Regression_Test_LGO_Admitted                            Regression_Test

    Creating a new Account
    Validate LaweyrGuard New submission Fields
    VerifyText                  Underwriter Workbench
    Add Account name on Insured info page
    Click on save button
    Add Attorney
    Click on NEXT:Submission Info
    Select broker Contact Source
    Add Details In SubmissionInfo Page
    ClickText                   NEXT:Underwriter Analysis >
    VerifyText                  Underwriting Analysis
    Add Area Of Practice
    Sleep                       20s
    ClickText                   Qualify Submission
    Sleep                       30s
    Click On Bind
    Change Policy Functionality                             Flat Cancellation
    Select flat cancellation Input
    Click On Bind After Amendment
    Click Quote On Policy Page
    VerifyText                  Flat Cancellation

Validate - Generate Binder doc
    #TCID=79055
    #Author=Amol Gaymukhe
    [Documentation]             Validate Binder
    [Tags]                      Regression_Test_LGO_Admitted                            Regression_Test
    Creating a new Account
    Validate LaweyrGuard New submission Fields
    VerifyText                  Underwriter Workbench
    Add Account name on Insured info page
    Click on save button
    Add Attorney
    Click on NEXT:Submission Info
    Select broker Contact Source
    Add Details In SubmissionInfo Page
    ClickText                   NEXT:Underwriter Analysis >
    VerifyText                  Underwriting Analysis
    Add Area Of Practice
    Sleep                       20s
    ClickText                   Qualify Submission
    Sleep                       30s
    Click On Bind
    Sleep                       10s
    Generate Document On Policy Page                        Binder

Validate Commission Overridden For Nb
    #TCID=79251
    #Author=Amol Gaymukhe
    [Documentation]             Validate Binder
    [Tags]                      Regression_Test_LGO_Admitted                            Regression_Test
    Creating a new Account
    Validate LaweyrGuard New submission Fields
    VerifyText                  Underwriter Workbench
    Add Account name on Insured info page
    Click on save button
    Add Attorney
    Click on NEXT:Submission Info
    Select broker Contact Source
    Add Details In SubmissionInfo Page
    ClickText                   NEXT:Underwriter Analysis >
    VerifyText                  Underwriting Analysis
    Add Area Of Practice
    Sleep                       20s
    ClickText                   Qualify Submission
    Sleep                       30s
    Commision Overridde check
    Click On Rate
    VerifyText                  Commission has been overridden, please check commission.

Renewal Workflow status - Send email transmittals
    #TCID=86671
    #Author=Amol Gaymukhe
    [Documentation]             Validate Binder
    [Tags]                      Regression_Test_LGO_Admitted                            Regression_Test
    Creating a new Account
    Validate LaweyrGuard New submission Fields
    VerifyText                  Underwriter Workbench
    Add Account name on Insured info page
    Click on save button
    Add Attorney
    Click on NEXT:Submission Info
    Select broker Contact Source
    Add Details In SubmissionInfo Page
    ClickText                   NEXT:Underwriter Analysis >
    VerifyText                  Underwriting Analysis
    Add Area Of Practice
    Sleep                       20s
    ClickText                   Qualify Submission
    Sleep                       30s
    Click On Bind
    Create a Renewal Flow
    ClickText                   Underwriting Analysis
    ClickText                   Qualify Submission
    Sleep                       30s
    ClickElement                //a/span[text()\='Submission Info']
    Check WorkFlow Status Initial Review
    Send Mail On Submission Page                            Additional Information Request
    ClickElement                //span[text()\='Underwriting Analysis']
    ClickElement                //span[text()\='Submission Info']
    Check WorkFlow Additional Information Requested