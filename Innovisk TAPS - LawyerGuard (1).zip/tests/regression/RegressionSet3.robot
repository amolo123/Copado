*** Settings ***
Library                         QWeb
Library                         QForce
Library                         FakerLibrary
Library                         String
Library                         BuiltIn
Library                         DateTime
Library                         RetryFailed                 global_retries=${retry_count}
Resource                        ../../resources/common.robot
Resource                        ../../resources/ReadPDF.robot
Resource                        ../../PageObjects/PageObjects_Account.robot
Resource                        ../../PageObjects/PageObjects_HomePage.robot
Resource                        ../../PageObjects/PageObjects_Submission.robot
Resource                        ../../PageObjects/PageObjects_InusredInfo.robot
Resource                        ../../PageObjects/PageObjects_SubmissionInit.robot
Resource                        ../../PageObjects/PageObjects_SubmissionInfo.robot
Resource                        ../../PageObjects/PageObjects_UnderwrittingAnalysis.robot
Resource                        ../../PageObjects/PageObjects_CompareAndRateQuote.robot
Resource                        ../../PageObjects/PageObjects_PolicyPage.robot
Library                         ../../libraries/MailLib.py                              ${tenant_id}         ${client_id_mail}        ${client_secret_mail}

Library                         ../../libraries/graph.py
Resource                        ../../resources/graph.resource

Suite Setup                     Setup Browser
Suite Teardown                  CloseAllBrowsers

# Test Teardown                 Empty Directory             ${downloads_folder}
# Test Teardown                 Empty Directory             ${downloads_folder}




*** Test Cases ***

Validate Not Quoted Email transmittal is not sending out the mapped information
    #TCID=86476
    #Author=Amol Gaymukhe
    [Documentation]             Not Quoted Email transmittal is not sending out the mapped information
    [Tags]                      Regression_Test_LGO_Admitted                            Regression_Test
    Creating a new Account
    Validate LaweyrGuard New submission Fields
    VerifyText                  Underwriter Workbench
    Add Account name on Insured info page
    Click on save button
    Add Attorney
    Click on NEXT:Submission Info
    Select broker Contact Source
    Add Details In SubmissionInfo Page
    ClickText                   NEXT:Underwriter Analysis >
    VerifyText                  Underwriting Analysis
    Add Area Of Practice
    Sleep                       10s
    ClickText                   Qualify Submission
    Sleep                       30s
    Edit Quote data Fields and verify rating
    Send Mail On Submission Page                            Not Quoted - Pricing
    Verify Email Contains same limit and deductibles 

    # Validating only open subjectivity is mentioned in the quote proposal, Indication
    #                           #TCID=79627
    #                           #Author=Amol Gaymukhe
    #                           [Documentation]             only open subjectivity is mentioned in the quote proposal, Indication
    #                           [Tags]                      Account                     regression           smoke
    #                           Creating a new Account
    #                           Validate LaweyrGuard New submission Fields
    #                           VerifyText                  Underwriter Workbench
    #                           Add Account name on Insured info page
    #                           Click on save button
    #                           Add Attorney
    #                           Click on NEXT:Submission Info
    #                           Select broker Contact Source
    #                           Add Details In SubmissionInfo Page
    #                           ClickText                   NEXT:Underwriter Analysis >
    #                           VerifyText                  Underwriting Analysis
    #                           Add Area Of Practice
    #                           Add Subjectivity On Underwriter Analysis Page
    #                           Add Closed Subjectivity On Underwriter Analysis Page
    #                           ClickText                   Qualify Submission
    #                           Sleep                       30s
    #                           Generate Document In Rated                              Indication
    #                           Move to outputdir
    #                           Test PDF File               Annual hours for Of Counsel, Contractors, and/or Part-Time attorneys
    #                           Test PDF File               Answer the following question on the supplement
    #                           Test PDF File               Amend the Area of Practice grid to equal 100%
    #                           Generate Document In Quoted                             Quote Proposal
    #                           Sleep                       10s
    #                           Move to outputdir
    #                           Test PDF File               Annual hours for Of Counsel, Contractors, and/or Part-Time attorneys
    #                           Test PDF File               Answer the following question on the supplement
    #                           Test PDF File               Amend the Area of Practice grid to equal 100%


Validate Cancel and Replace
    #TCID=74711
    #Author=Amol Gaymukhe
    [Documentation]             Validate Cancel and replace
    [Tags]                      Regression_Test_LGO_Admitted                            Regression_Test
    Creating a new Account
    Validate LaweyrGuard New submission Fields
    VerifyText                  Underwriter Workbench
    Add Account name on Insured info page
    Click on save button
    Add Attorney
    Click on NEXT:Submission Info
    Select broker Contact Source
    Add Details In SubmissionInfo Page
    ClickText                   NEXT:Underwriter Analysis >
    VerifyText                  Underwriting Analysis
    Add Area Of Practice
    Sleep                       10s
    ClickText                   Qualify Submission
    Sleep                       30s
    Click On Bind
    Change Policy Functionality                             Cancel & Replace
    Select Change Cancel & Replacement Input
    Edit Limit Fields and verify rating after Cancel Replace
    Click On Bind After Cancel Replace Correction
    Verify Coverage Cancel replace on policy quote



    # Validate When Predecessor Firm was already processed in the previous amendment, the following amendment has 'predecessorFirmsChange' TRUE when the field was not updated.
    #                           #TCID=72436
    #                           #Author=Amol Gaymukhe
    #                           [Documentation]             Validate Amendment and predecessorFirmChange
    #                           [Tags]                      Account                     regression           smoke
    #                           Creating a new Account
    #                           Validate LaweyrGuard New submission Fields
    #                           VerifyText                  Underwriter Workbench
    #                           Add Account name on Insured info page
    #                           Click on save button
    #                           Add Attorney
    #                           Click on NEXT:Submission Info
    #                           Select broker Contact Source
    #                           Add Details In SubmissionInfo Page
    #                           ClickText                   NEXT:Underwriter Analysis >
    #                           VerifyText                  Underwriting Analysis
    #                           Add Area Of Practice
    #                           ClickText                   Qualify Submission
    #                           Sleep                       30s
    #                           Click On Bind
    #                           Change Policy Functionality                             Amendment
    #                           Select Change Endorsement Input
    #                           Input Data in Predecessor Firm On Underwriter Analysis
    #                           ClickText                   Save
    #                           Sleep                       3s
    #                           ClickText                   Compare & Rate Quotes
    #                           Click On Rate After Amendment
    #                           Click On Bind After Amendment
    #                           Sleep                       30s
    #                           Generate Document On Policy Page                        Endorsement
    #                           Sleep                       5s
    #                           Move to outputdir
    #                           Test PDF File               Predecessor Firm(s): Test Predecessor Data



    # Validate 'No additional quote-specific endorsements' is showing up on Quote Proposal Document when there are endorsements that do apply (& Potentially Account Summary)
    #                           #TCID=77342
    #                           #Author=Amol Gaymukhe
    #                           [Documentation]             No additional quote-specific endorsements' is showing up on Quote Proposal Document
    #                           [Tags]                      Account                     regression           smoke
    #                           Creating a new Account
    #                           Validate LaweyrGuard New submission Fields
    #                           VerifyText                  Underwriter Workbench
    #                           Add Account name on Insured info page
    #                           Click on save button
    #                           Add Attorney
    #                           Click on NEXT:Submission Info
    #                           Select broker Contact Source
    #                           Add Details In SubmissionInfo Page
    #                           ClickText                   NEXT:Underwriter Analysis >
    #                           VerifyText                  Underwriting Analysis
    #                           Add Area Of Practice
    #                           ClickText                   Qualify Submission
    #                           Sleep                       30s
    #                           Select Endorsements
    #                           Generate Document In Quoted                             Quote Proposal
    #                           Move to outputdir
    #                           Test PDF File               ALFA Endorsement
    #                           Test PDF File               Additional Named Insured


Validate Account Summary - information is missing from Section 1 (total attorney) & 4 on renewal (multiple quotes), Expiring row should not print incorrect data and missing info on last page 
    #TCID=79036
    #Author=Amol Gaymukhe
    [Documentation]             Account Summary - information is missing from Section 1 (total attorney)
    [Tags]                      Regression_Test_LGO_Admitted                            Regression_Test
    Creating a new Account
    Validate LaweyrGuard New submission Fields
    VerifyText                  Underwriter Workbench
    Add Account name on Insured info page
    Click on save button
    Add Attorney
    Click on NEXT:Submission Info
    Select broker Contact Source
    Add Details In SubmissionInfo Page
    ClickText                   NEXT:Underwriter Analysis >
    VerifyText                  Underwriting Analysis
    Add Area Of Practice
    Sleep                       20s
    ClickText                   Qualify Submission
    Sleep                       30s
    Click On Bind
    Sleep                       30s
    Create a Renewal Flow
    Edit Limit and Verify Rating on first quote
    Sleep                       30s
    Generate Document Account Summary                       Account Summary
    Sleep                       10s
    Get WORD document and attach it to log
    Should Contain              ${read_doc}                 $6,000,000/
    Should Contain              ${read_doc}                 $6,000,000/
    Should Contain              ${read_doc}                 $1,000,000/
    Should Contain              ${read_doc}                 $1,000,000/



Validate Not Quoted Pricing email Functionality with limits and Deductibles for NB and Renewal
    #TCID=79427
    #Author=Amol Gaymukhe
    [Documentation]             Not Quoted Pricing email Functionality with limits and Deductibles
    [Tags]                      Regression_Test_LGO_Admitted                            Regression_Test
    Creating a new Account
    Validate LaweyrGuard New submission Fields
    VerifyText                  Underwriter Workbench
    Add Account name on Insured info page
    Click on save button
    Add Attorney
    Click on NEXT:Submission Info
    Select broker Contact Source
    Add Details In SubmissionInfo Page
    ClickText                   NEXT:Underwriter Analysis >
    VerifyText                  Underwriting Analysis
    Add Area Of Practice
    Sleep                       10s
    ClickText                   Qualify Submission
    Sleep                       30s
    Edit Limit Fields and verify rating
    Send Non Quoted Transmittal Mail And Check limits
    Click On Bind
    Create a Renewal Flow
    Send Non Quoted Transmittal Mail And Check limits


Validate Send an email for a quoted quote.
    #TCID=79624
    #Author=Amol Gaymukhe
    [Documentation]             Validate Send an email for a quoted quote.
    [Tags]                      Regression_Test_LGO_Admitted                            Regression_Test
    Creating a new Account
    Validate LaweyrGuard New submission Fields
    VerifyText                  Underwriter Workbench
    Add Account name on Insured info page
    Click on save button
    Add Attorney
    Click on NEXT:Submission Info
    Select broker Contact Source
    Add Details In SubmissionInfo Page
    ClickText                   NEXT:Underwriter Analysis >
    VerifyText                  Underwriting Analysis
    Add Area Of Practice
    Sleep                       20s
    ClickText                   Qualify Submission
    Sleep                       30s
    Edit Limit Fields and verify rating
    Send Non Quoted Transmittal Mail And Check limits
    Send Mail On Submission Page                            Not Quoted - Pricing
    Should Contain              ${body}                     Limit of Liability: Each Claim ($2000000), Aggregate ($3000000), Limit Type (Defense Expenses Within Limit). Deductible: Each Claim ($1000), Aggregate (None), Deductible Type (Damages and Defense Expenses).


Validate the quote proposal, Streamline , account summary, and indication document for renewal.
    #TCID=79625
    #Author=Amol Gaymukhe
    [Documentation]             quote proposal, Streamline , account summary, and indication document for renewal.
    [Tags]                      Regression_Test_LGO_Admitted                            Regression_Test
    Creating a new Account
    Validate LaweyrGuard New submission Fields
    VerifyText                  Underwriter Workbench
    Add Account name on Insured info page
    Click on save button
    Add Attorney
    Click on NEXT:Submission Info
    Select broker Contact Source
    Add Details In SubmissionInfo Page
    ClickText                   NEXT:Underwriter Analysis >
    VerifyText                  Underwriting Analysis
    Add Area Of Practice
    Sleep                       20s
    ClickText                   Qualify Submission
    Sleep                       30s
    Click On Bind
    Create a Renewal Flow
    Generate Document In Rated After Renewal                Indication
    Sleep                       5s
    Generate Document In Rated After Renewal                Account Summary
    Sleep                       5s
    Generate Document In Quoted after Renewal               Quote Proposal
    Sleep                       5s
    Generate Document In Quoted after Renewal               Streamlined Renewal
    Sleep                       5s




Validation of policy. Document for renewal and new business  
    #TCID=79626
    #Author=Amol Gaymukhe
    [Documentation]             Validation of policy. Document for renewal and new business
    [Tags]                      Regression_Test_LGO_Admitted                            Regression_Test
    Creating a new Account
    Validate LaweyrGuard New submission Fields
    VerifyText                  Underwriter Workbench
    Add Account name on Insured info page
    Click on save button
    Add Attorney
    Click on NEXT:Submission Info
    Select broker Contact Source
    Add Details In SubmissionInfo Page
    ClickText                   NEXT:Underwriter Analysis >
    VerifyText                  Underwriting Analysis
    Add Area Of Practice
    Add Litigation History On Underwriter Analysis Page
    Add Subjectivity On Underwriter Analysis Page
    ClickText                   Qualify Submission
    Sleep                       30s
    Select Endorsements
    Sleep                       30s
    Click On Rate
    Get all the Read PDF details in Quoted
    Click On Bind
    Sleep                       25s
    Generate Document On Policy Page                        PolicyForm
    Sleep                       25s
    Move to outputdir
    # Should Contain            ${AllPDFtext}               Test Claim
    # Should Contain            ${AllPDFtext}               ${pdf_statetaxes}
    # Should Contain            ${AllPDFtext}               ${pdf_policyperiod2}
    Test PDF File               Policy
    Log To Console              ${pdf_statetaxes}
    Should Contain              ${AllPDFtext}               ${pdf_statetaxes}
    Should Contain              ${AllPDFtext}               ${fromdate1}
    Should Contain              ${AllPDFtext}               ${todate1}

    # Test PDF File             ${pdf_statetaxes}
    # Test PDF File             ${pdf_policyperiod2}





