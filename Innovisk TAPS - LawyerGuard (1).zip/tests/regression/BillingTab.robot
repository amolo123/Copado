*** Settings ***
Library                         QWeb
Library                         QForce
Library                         FakerLibrary
Library                         String
Library                         BuiltIn
Library                         DateTime
Library                         RetryFailed                 global_retries=${retry_count}
Resource                        ../../resources/common.robot
Resource                        ../../resources/ReadPDF.robot
Resource                        ../../PageObjects/PageObjects_Account.robot
Resource                        ../../PageObjects/PageObjects_HomePage.robot
Resource                        ../../PageObjects/PageObjects_Submission.robot
Resource                        ../../PageObjects/PageObjects_InusredInfo.robot
Resource                        ../../PageObjects/PageObjects_SubmissionInit.robot
Resource                        ../../PageObjects/PageObjects_SubmissionInfo.robot
Resource                        ../../PageObjects/PageObjects_UnderwrittingAnalysis.robot
Resource                        ../../PageObjects/Surplus_Lines/PageObjects_SL_UnderwriterAnalysis.robot
Resource                        ../../PageObjects/PageObjects_CompareAndRateQuote.robot
Resource                        ../../PageObjects/PageObjects_PolicyPage.robot
Resource                        ../../PageObjects/PageObjects_Quote.robot
Resource                        ../PolicyScreen.robot
Resource                        ../Surplus_Lines/SL_Quote_Screen.robot
Resource                        ../../PageObjects/Coburn/AdmittedLG/Billingrecord_Page.robot

Library                         ../../libraries/graph.py
Resource                        ../../resources/graph.resource

Suite Setup                     Setup Browser
Suite Teardown                  CloseAllBrowsers


*** Test Cases ***
Validate Billing Record For LG Admitted

    [Documentation]             Validate Billing tab
    [Tags]                      LGO_Coburn                  

    Creating a new Account
    Validate LaweyrGuard New submission Fields
    VerifyText                  Underwriter Workbench
    Add Account name on Insured info page
    Click on save button
    Add Attorney
    Click on NEXT:Submission Info
    Select broker Contact Source
    Add Details In SubmissionInfo Page
    ClickText                   NEXT:Underwriter Analysis >
    VerifyText                  Underwriting Analysis
    Add Area Of Practice
    ClickText                   Qualify Submission
    Sleep                       30s
    Click On Bind
    Get data to Validate on Billing Record
    Open Billing Record         NB
    Verify Static fields On Billing Record Page
    Validate Dynamic feilds on Billing Record               ${PolicyNumber_BR}          ${QuoteNameBill}        ${uniqueName}               ${broker_contact_coburn}            Lawyerguard    CALIFORNIA INS CO    Lawyerguard

*** Test Cases ***
Validate Billing Record For LG Primary

    [Documentation]             Validate Billing tab Primary
    [Tags]                      LGO_Coburn                  

    Creating a new Account state NY
    Checking Next Button On New Submission For SL           LawyerGuard_SL
    VerifyText                  Underwriter Workbench
    Add Account name on Insured info page
    Enter Territory data on Insured Info Page SL            New York: Remainder of State
    Click on save button
    Add Attorney
    Click on NEXT:Submission Info
    Select broker Contact Source
    Entering Submission_Info Details for SL                 Primary                     12/06/2024
    ClickText                   NEXT:Underwriter Analysis >
    VerifyText                  Underwriting Analysis
    Add Area Of Practice for SL
    Add Details In Underwriter Analysis Tab for SL
    ClickText                   Qualify Submission
    Sleep                       30s
    Click On Bind For SL        Individual broker license
    #VerifyText                 Policy Name
    Get data to Validate on Billing Record
    Open Billing Record         NB
    Verify Static fields On Billing Record Page
    Validate Dynamic feilds on Billing Record               ${PolicyNumber_BR}          ${QuoteNameBill}        ${uniqueName}               ${broker_contact_coburn}            Lawyerguard    CALIFORNIA INS CO    Lawyerguard

Validate Billing Record For LG Excess

    [Documentation]             Validate Billing tab Excess
    [Tags]                      LGO_Coburn                  

    Creating a new Account state NY
    Checking Next Button On New Submission For SL           LawyerGuard_SL
    VerifyText                  Underwriter Workbench
    Add Account name on Insured info page
    Enter Territory data on Insured Info Page SL            New York: Remainder of State
    Click on save button
    Add Attorney
    Click on NEXT:Submission Info
    Select broker Contact Source
    Entering Submission_Info Details for SL                 Excess                      12/06/2024
    ClickText                   NEXT:Underwriter Analysis >
    VerifyText                  Underwriting Analysis
    Add Area Of Practice for SL
    Sleep                       10s
    Add Details In Underwriter Analysis Tab for SL
    ClickText                   Qualify Submission
    Sleep                       30s
    Add Premium to Excess Fields
    Rate Quote
    Click On Bind For SL        Individual broker license
    #VerifyText                 Policy Name
    Get data to Validate on Billing Record
    Open Billing Record         NB
    Verify Static fields On Billing Record Page
    Validate Dynamic feilds on Billing Record               ${PolicyNumber_BR}          ${QuoteNameBill}        ${uniqueName}               ${broker_contact_coburn}            Lawyerguard    CALIFORNIA INS CO    Lawyerguard