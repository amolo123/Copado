*** Settings ***
Library                         QWeb
Library                         QForce
Library                         FakerLibrary
Library                         String
Library                         BuiltIn
Library                         DateTime
Library                         RetryFailed                 global_retries=${retry_count}
Resource                        ../../resources/common.robot
Resource                        ../../resources/ReadPDF.robot
Resource                        ../../PageObjects/PageObjects_Account.robot
Resource                        ../../PageObjects/PageObjects_HomePage.robot
Resource                        ../../PageObjects/PageObjects_Submission.robot
Resource                        ../../PageObjects/PageObjects_InusredInfo.robot
Resource                        ../../PageObjects/PageObjects_SubmissionInit.robot
Resource                        ../../PageObjects/PageObjects_SubmissionInfo.robot
Resource                        ../../PageObjects/PageObjects_UnderwrittingAnalysis.robot
Resource                        ../../PageObjects/PageObjects_UnderwrittingAnalysis.robot
Resource                        ../../PageObjects/Surplus_Lines/PageObjects_SL_UnderwriterAnalysis.robot
Resource                        ../../PageObjects/PageObjects_CompareAndRateQuote.robot
Resource                        ../../PageObjects/PageObjects_PolicyPage.robot
Resource                        ../../PageObjects/Coburn/AdmittedLG/Billingrecord_Page.robot
Resource                        ../../PageObjects/PageObjects_PDFRead.robot

Library                         ../../libraries/graph.py
Resource                        ../../resources/graph.resource

Suite Setup                     Setup Browser
Suite Teardown                  CloseAllBrowsers

*** Test Cases ***

Admitted: Validate Billing Record for Extension & Extended Reporting Period
    #TCID=
    #Author= Shraddha T Patil
    [Documentation]             Extension & Extended Reporting Period
    [Tags]                      LGO_Coburn
    Creating an account with a state California
    Validate LaweyrGuard New submission Fields
    VerifyText                  Underwriter Workbench
    Add Account name on Insured info page
    Click on save button
    Add Attorney
    Click on NEXT:Submission Info
    Select broker Contact Source
    Add Details In SubmissionInfo Page
    ClickText                   NEXT:Underwriter Analysis >
    VerifyText                  Underwriting Analysis
    Add Area Of Practice
    Sleep                       20s
    ClickText                   Qualify Submission
    Sleep                       30s
    Click On Bind
    Get Details for Billing Record document validation
    Change Policy Functionality                             Extension
    Select Change Extension Input
    Click On Rate After Amendment
    Click On Bind After Amendment
    Get Details for Billing Record document validation
    Open Billing Record         Extension
    Download Invoice
    Move to outputdir
    Verify Content on billing record PDF                    Extension                   ${uniqueName}
    Empty Directory command
    ClickElement                //records-hoverable-link//span[contains(text(), 'P-')]
    Change Policy Functionality                             Midterm Cancellation
    Select flat cancellation Input
    Click On Rate After Amendment
    Click On Bind After Amendment
    Change Policy Functionality                             Extended Reporting Period
    Select Change ERP date Input
    Click On Rate After Amendment
    Click On Bind After Amendment
    Get Details for Billing Record document validation
    Open Billing Record         Extended Reporting Period
    Download Invoice
    Move to outputdir
    Verify Content on billing record PDF                    Extended Reporting          ${uniqueName}
    Empty Directory command


Non-Admitted: Validate Billing Record for Extension & Extended Reporting Period Primary
    #TCID=
    #Author= Shraddha T Patil
    [Documentation]             Extension & Extended Reporting Period
    [Tags]                      LGO_Coburn
    Creating a new Account state NY
    Checking Next Button On New Submission For SL           LawyerGuard_SL
    VerifyText                  Underwriter Workbench
    Add Account name on Insured info page
    Enter Territory data on Insured Info Page SL            New York: Remainder of State
    Click on save button
    Add Attorney
    Click on NEXT:Submission Info
    Select broker Contact Source
    Entering Submission_Info Details for SL                 Primary                     12/06/2024
    ClickText                   NEXT:Underwriter Analysis >
    VerifyText                  Underwriting Analysis
    Add Area Of Practice for SL
    Sleep                       20s
    Add Details In Underwriter Analysis Tab for SL
    Sleep                       20s
    ClickText                   Qualify Submission
    Sleep                       30s
    Click On Bind For SL        Individual broker license
    VerifyText                  Policy Name
    Get Details for Billing Record document validation
    Change Policy Functionality                             Extension
    Select Change Extension Input
    Click On Rate After Amendment
    Click Bind SL After Amendment
    Get Details for Billing Record document validation
    Open Billing Record         Extension
    Download Invoice
    Move to outputdir
    Verify Content on billing record PDF                    Extension                   ${uniqueName}
    Empty Directory command
    ClickElement                //records-hoverable-link//span[contains(text(), 'P-')]
    Change Policy Functionality                             Midterm Cancellation
    Select flat cancellation Input
    Click On Rate After Amendment
    Click Bind SL After Amendment
    Change Policy Functionality                             Extended Reporting Period
    Select Change ERP date Input
    Click On Rate After Amendment
    Click Bind SL After Amendment
    Get Details for Billing Record document validation
    Open Billing Record         Extended Reporting Period
    Download Invoice
    Move to outputdir
    Verify Content on billing record PDF                    Extended Reporting          ${uniqueName}
    Empty Directory command



Non-Admitted: Validate Billing Record for Extension & Extended Reporting Period Excess         
    #TCID=
    #Author= Shraddha T Patil
    [Documentation]             Extension & Extended Reporting Period
    [Tags]                      LGO_Coburn
    Creating an account with a state California
    Checking Next Button On New Submission For SL           LawyerGuard_SL
    VerifyText                  Underwriter Workbench
    Add Account name on Insured info page
    Enter Territory data on Insured Info Page SL            California: Remainder of State
    Click on save button
    Add Attorney
    Click on NEXT:Submission Info
    Select broker Contact Source
    Entering Submission_Info Details for SL                 Excess                      12/06/2024
    ClickText                   NEXT:Underwriter Analysis >
    VerifyText                  Underwriting Analysis
    Add Area Of Practice for SL
    Sleep                       20s
    Add Details In Underwriter Analysis Tab for SL
    Sleep                       20s
    ClickText                   Qualify Submission
    Sleep                       30s
    Add Premium to Excess Fields
    Rate Quote
    Click On Bind For SL        Individual broker license
    VerifyText                  Policy Name
    Get Details for Billing Record document validation
    Change Policy Functionality                             Extension
    Select Change Extension Input
    Click On Rate After Amendment
    Click Bind SL After Amendment
    Get Details for Billing Record document validation
    Open Billing Record         Extension
    Download Invoice
    Move to outputdir
    Verify Content on billing record PDF                    Extension                   ${uniqueName}
    Empty Directory command
    ClickElement                //records-hoverable-link//span[contains(text(), 'P-')]
    Change Policy Functionality                             Midterm Cancellation
    Select flat cancellation Input
    Click On Rate After Amendment
    Click Bind SL After Amendment
    Change Policy Functionality                             Extended Reporting Period
    Select Change ERP date Input
    Click On Rate After Amendment
    Click Bind SL After Amendment
    Get Details for Billing Record document validation
    Open Billing Record         Extended Reporting Period
    Download Invoice
    Move to outputdir
    Verify Content on billing record PDF                    Extended Reporting          ${uniqueName}
    Empty Directory command