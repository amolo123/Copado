*** Settings ***
Library                         QWeb
Library                         QForce
Library                         FakerLibrary
Library                         String
Library                         BuiltIn
Library                         DateTime
Library                         RetryFailed                 global_retries=${retry_count}
Resource                        ../../resources/common.robot
Resource                        ../../PageObjects/PageObjects_Account.robot
Resource                        ../../PageObjects/PageObjects_HomePage.robot
Resource                        ../../PageObjects/PageObjects_Submission.robot
Resource                        ../../PageObjects/PageObjects_InusredInfo.robot
Resource                        ../../PageObjects/PageObjects_SubmissionInit.robot
Resource                        ../../PageObjects/PageObjects_SubmissionInfo.robot
Resource                        ../../PageObjects/PageObjects_UnderwrittingAnalysis.robot
Resource                        ../../PageObjects/PageObjects_CompareAndRateQuote.robot
Resource                        ../../PageObjects/PageObjects_PolicyPage.robot
Library                         ../../libraries/MailLib.py                              ${tenant_id}         ${client_id_mail}        ${client_secret_mail}

Library                         ../../libraries/graph.py
Resource                        ../../resources/graph.resource

Suite Setup                     Setup Browser
Suite Teardown                  CloseAllBrowsers



*** Test Cases ***
LGO Send Email on Submission
    [Documentation]             Functionality on Insured Info Page
    [Tags]                      Regression_Test_LGO_Admitted                            Regression_Test
    Creating a new Account
    Validate LaweyrGuard New submission Fields
    VerifyText                  Underwriter Workbench
    Add Account name on Insured info page
    Click on save button
    Add Attorney
    Click on NEXT:Submission Info
    Select broker Contact Source
    Add Details In SubmissionInfo Page
    ClickText                   NEXT:Underwriter Analysis >
    VerifyText                  Underwriting Analysis
    Add Area Of Practice
    Sleep                       20s
    ClickText                   Qualify Submission
    Sleep                       30s
    Send Mail On Submission Page                            Additional Information Request
    Send Mail On Submission Page                            BOR Acknowledgement Midterm
    Send Mail On Submission Page                            BOR Acknowledgement New/Renewal
    Send Mail On Submission Page                            BOR Countermanding
    Send Mail On Submission Page                            Claim Verification
    Send Mail On Submission Page                            Coverage Expired – File Closed Transmittal
    Send Mail On Submission Page                            Declination
    Send Mail On Submission Page                            Duplicate Submission
    Send Mail On Submission Page                            Indication Transmittal
    Send Mail On Submission Page                            LG Firm Changes
    Send Mail On Submission Page                            Non-Renewal Transmittal
    Send Mail On Submission Page                            Not Quoted - Pricing
    Send Mail On Submission Page                            Quote Transmittal
    Send Mail On Submission Page                            Streamline Proposal Follow Up Transmittal


