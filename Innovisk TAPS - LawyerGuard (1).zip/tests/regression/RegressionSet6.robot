*** Settings ***
Library                         QWeb
Library                         QForce
Library                         FakerLibrary
Library                         String
Library                         BuiltIn
Library                         DateTime
Library                         RetryFailed                 global_retries=${retry_count}
Resource                        ../../resources/common.robot
Resource                        ../../resources/ReadPDF.robot
Resource                        ../../PageObjects/PageObjects_Account.robot
Resource                        ../../PageObjects/PageObjects_HomePage.robot
Resource                        ../../PageObjects/PageObjects_Submission.robot
Resource                        ../../PageObjects/PageObjects_InusredInfo.robot
Resource                        ../../PageObjects/PageObjects_SubmissionInit.robot
Resource                        ../../PageObjects/PageObjects_SubmissionInfo.robot
Resource                        ../../PageObjects/PageObjects_UnderwrittingAnalysis.robot
Resource                        ../../PageObjects/PageObjects_CompareAndRateQuote.robot
Resource                        ../../PageObjects/PageObjects_PolicyPage.robot
Library                         ../../libraries/MailLib.py                              ${tenant_id}         ${client_id_mail}        ${client_secret_mail}

Library                         ../../libraries/graph.py
Resource                        ../../resources/graph.resource

Suite Setup                     Setup Browser
Suite Teardown                  CloseAllBrowsers

#Test Teardown                  Empty Directory             /home/executor/Downloads




*** Test Cases ***

Validating only open subjectivity is mentioned in the quote proposal, Indication    
    #TCID=79627
    #Author=Amol Gaymukhe
    [Documentation]             only open subjectivity is mentioned in the quote proposal, Indication
    [Tags]                      Regression_Test_LGO_Admitted                            Regression_Test

    Creating a new Account
    Validate LaweyrGuard New submission Fields
    VerifyText                  Underwriter Workbench
    Add Account name on Insured info page
    Click on save button
    Add Attorney
    Click on NEXT:Submission Info
    Select broker Contact Source
    Add Details In SubmissionInfo Page
    ClickText                   NEXT:Underwriter Analysis >
    VerifyText                  Underwriting Analysis
    Add Area Of Practice
    Add Subjectivity On Underwriter Analysis Page
    Sleep                       20s
    ClickText                   Qualify Submission
    Sleep                       30s
    Generate Document In Rated                              Indication
    Sleep                       30s
    Move to outputdir
    Test PDF File               Annual hours for Of Counsel, Contractors, and/or Part-Time attorneys
    Test PDF File               Amend the Area of Practice grid to equal 100%
    Test PDF File               Alternative higher limit offered assumes no exposure changes
    Generate Document In Quoted                             Quote Proposal
    Sleep                       30s
    Move to outputdir
    Test PDF File               Annual hours for Of Counsel, Contractors, and/or Part-Time attorneys
    Test PDF File               Amend the Area of Practice grid to equal 100%
    Test PDF File               Alternative higher limit offered assumes no exposure changes


Validate When Predecessor Firm was already processed in the previous amendment, the following amendment has 'predecessorFirmsChange' TRUE when the field was not updated.    
    #TCID=72436
    #Author=Amol Gaymukhe
    [Documentation]             Validate Amendment and predecessorFirmChange
    [Tags]                      Regression_Test_LGO_Admitted                            Regression_Test
    Creating a new Account
    Validate LaweyrGuard New submission Fields
    VerifyText                  Underwriter Workbench
    Add Account name on Insured info page
    Click on save button
    Add Attorney
    Click on NEXT:Submission Info
    Select broker Contact Source
    Add Details In SubmissionInfo Page
    ClickText                   NEXT:Underwriter Analysis >
    VerifyText                  Underwriting Analysis
    Sleep                       20s
    Add Area Of Practice
    Sleep                       20s
    ClickText                   Qualify Submission
    Sleep                       30s
    Click On Bind
    Change Policy Functionality                             Amendment
    Select Change Endorsement Input
    Input Data in Predecessor Firm On Underwriter Analysis
    ClickText                   Save
    Sleep                       3s
    ClickText                   Compare & Rate Quotes
    Click On Rate After Amendment
    Click On Bind After Amendment
    Sleep                       20s
    Generate Document On Policy Page                        ChangeEndorsement
    Sleep                       10s
    Move to outputdir
    Test PDF File               Predecessor Firm(s): Test Predecessor Data


Validate 'No additional quote-specific endorsements' is showing up on Quote Proposal Document when there are endorsements that do apply (& Potentially Account Summary)
    #TCID=77342
    #Author=Amol Gaymukhe
    [Documentation]             No additional quote-specific endorsements' is showing up on Quote Proposal Document
    [Tags]                      Regression_Test_LGO_Admitted                            Regression_Test
    Creating a new Account
    Validate LaweyrGuard New submission Fields
    VerifyText                  Underwriter Workbench
    Add Account name on Insured info page
    Click on save button
    Add Attorney
    Click on NEXT:Submission Info
    Select broker Contact Source
    Add Details In SubmissionInfo Page
    ClickText                   NEXT:Underwriter Analysis >
    VerifyText                  Underwriting Analysis
    Add Area Of Practice
    Sleep                       5s
    ClickText                   Qualify Submission
    Sleep                       30s
    Select Endorsements
    Generate Document In Quoted                             Quote Proposal
    Sleep                       10s
    Move to outputdir
    Test PDF File               ALFA Endorsement
    Test PDF File               Additional Named Insured
