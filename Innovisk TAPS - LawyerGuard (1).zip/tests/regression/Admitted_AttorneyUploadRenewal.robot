*** Settings ***
Library                         QWeb
Library                         QForce
Library                         FakerLibrary
Library                         String
Library                         BuiltIn
Library                         DateTime
Library                         RetryFailed                 global_retries=${retry_count}
Resource                        ../../resources/common.robot
Resource                        ../../PageObjects/PageObjects_Account.robot
Resource                        ../../PageObjects/PageObjects_HomePage.robot
Resource                        ../../PageObjects/PageObjects_Submission.robot
Resource                        ../../PageObjects/PageObjects_InusredInfo.robot
Resource                        ../../PageObjects/PageObjects_SubmissionInit.robot
Resource                        ../../PageObjects/PageObjects_SubmissionInfo.robot
Resource                        ../../PageObjects/PageObjects_UnderwrittingAnalysis.robot
Resource                        ../../PageObjects/PageObjects_CompareAndRateQuote.robot
Resource                        ../../PageObjects/PageObjects_PolicyPage.robot
Resource                        ../Contacts_datadriven.robot
Library                         ../../libraries/MailLib.py                              ${tenant_id}         ${client_id_mail}        ${client_secret_mail}

Library                         ../../libraries/graph.py
Resource                        ../../resources/graph.resource

Suite Setup                     Setup Browser
Suite Teardown                  CloseAllBrowsers

Test Teardown                   Empty Directory             /home/executor/Downloads



*** Test Cases ***
Validate Upload Attorney on renewal
    #TCID=120093
    #Author=Rugveda
    [Documentation]             Upload Attorney on renewal
    [Tags]                      Regression_Test_LGO_Admitted                            Regression_Test
    Creating an account with a state California
    Validate LaweyrGuard New submission Fields
    VerifyText                  Underwriter Workbench
    Add Account name on Insured info page
    Click on save button
    Add Static Attorney
    ${value}=                   GetInputValue               Number Of Attorneys
    Set Global Variable         ${value}
    Click on NEXT:Submission Info
    Select broker Contact Source
    Add Details In SubmissionInfo Page
    ClickText                   NEXT:Underwriter Analysis >
    VerifyText                  Underwriting Analysis
    Add Area Of Practice
    Sleep                       30s
    ClickText                   Qualify Submission
    Sleep                       30s
    Click On Bind
    Renewal flow for upload attorney
    Account click
    VerifyText                  Recently Viewed             timeout=120s
    ClickText                   ${uniquename}
    Import Attorneys
    #ClickText                  Policies                    anchor=Details
    #UseTable                   Policy Name
    #ClickText                  P-                          anchor=Policy Name
    ClickText                   Submissions                 anchor=Details
    ClickElement                //table[@aria-label\='Submissions']/tbody/tr[1]//th//a
    # GoTo                      ${url}
    Compare Attorneys On Renewal
    ClickText                   NEXT:Submission Info >
    ClickText                   NEXT:Underwriter Analysis >
    VerifyText                  Underwriting Analysis
    Add Area Of Practice
    Sleep                       30s
    ClickText                   Qualify Submission
    Sleep                       30s
    Click On Rate
    Click On Bind
    Log To Console              ------ Renewal Flow Successfull ---------
