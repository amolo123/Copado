*** Settings ***
Resource                        ../resources/common.robot
Resource                        ../PageObjects/PageObjects_Account.robot
Resource                        ../PageObjects/PageObjects_HomePage.robot
Resource                        ../PageObjects/PageObjects_Submission.robot
Resource                        ../PageObjects/PageObjects_InusredInfo.robot
Resource                        ../PageObjects/PageObjects_SubmissionInit.robot
Resource                        ../PageObjects/PageObjects_SubmissionInfo.robot
Resource                        ../PageObjects/PageObjects_UnderwrittingAnalysis.robot

Library                         RetryFailed                 global_retries=${retry_count}
Suite Setup                     Setup Browser
Suite Teardown                  CloseAllBrowsers



*** Test Cases ***

Verify all the sections on Underwriting Analysis Tab with Save and Qualify Button Functionality 
    # Author = Amol Gaymukhe
    #TC=94108
    [Documentation]             Entering                    Details in Insured Info Tab
    [Tags]                      Smoke_Test_LGO_Admitted     Smoke_Test
    Creating a new Account
    Validate LaweyrGuard New submission Fields
    VerifyText                  Underwriter Workbench
    Add Account name on Insured info page
    # VerifyInputValue          Contact Record Type         Attorney                    timeout=2s
    Click on save button
    Add Attorney
    Click on NEXT:Submission Info
    Select broker Contact Source
    Validate SubmissionInfo New submission Fields
    Verify SubmissionInfo Page Input Details
    Verify Decline Close and Reopen
    ClickText                   NA
    ClickText                   Move to Selected            parent=LIGHTNING-BUTTON-ICON
    ClickText                   Save
    VerifyText                  Success
    Sleep                       5s
    ClickText                   NEXT:Underwriter Analysis >
    VerifyText                  Underwriting Analysis
    Verify Underwriting Analysis Page Elements
    Validate Attributes
    Add Area Of Practice
    Add Details In Underwriter Analysis Tab

Verify all the names for Area of Practice Description on AOP  
    #Author=Amol Gaymukhe
    #TC=94357
    [Documentation]             Entering                    Details in Insured Info Tab
    [Tags]                      Smoke_Test_LGO_Admitted     Smoke_Test

    Creating an account with a state California
    Validate LaweyrGuard New submission Fields
    VerifyText                  Underwriter Workbench
    Add Account name on Insured info page
    # VerifyInputValue          Contact Record Type         Attorney                    timeout=2s
    Click on save button
    Add Attorney
    Click on NEXT:Submission Info
    Select broker Contact Source
    #Validate SubmissionInfo New submission Fields
    Verify SubmissionInfo Page Input Details
    ClickText                   NA
    ClickText                   Move to Selected            parent=LIGHTNING-BUTTON-ICON
    ClickText                   Save
    VerifyText                  Success
    Sleep                       5s
    ClickText                   NEXT:Underwriter Analysis >
    Verify Area Of Practice     AOP
    Verify AOP Search Functionality                         AOP
