*** Settings ***
Resource                        ../resources/common.robot
Resource                        ../PageObjects/PageObjects_Account.robot
Resource                        ../PageObjects/PageObjects_HomePage.robot
Resource                        ../PageObjects/PageObjects_Submission.robot
Resource                        ../PageObjects/PageObjects_InusredInfo.robot
Resource                        ../PageObjects/PageObjects_SubmissionInit.robot
Resource                        ../PageObjects/PageObjects_SubmissionInfo.robot
Library                         RetryFailed                 global_retries=${retry_count}
Suite Setup                     Setup Browser
Suite Teardown                  CloseAllBrowsers



*** Test Cases ***

Verify Save Button and Next Submission Info Functionality on Submission Init Form 
    # Author = Amol Gaymukhe
    #TC=93943
    [Documentation]             Entering                    Details in Insured Info Tab
    [Tags]                      Smoke_Test_LGO_Admitted     Smoke_Test

    Creating a new Account
    Validate LaweyrGuard New submission Fields
    VerifyText                  Underwriter Workbench
    Add Account name on Insured info page
    # VerifyInputValue          Contact Record Type         Attorney                    timeout=2s
    Click on save button
    Add Attorney
    Click on NEXT:Submission Info
    Select broker Contact Source
    Verify SubmissionInfo Page Input Details
    Validate SubmissionInfo New submission Fields
    Add Details In SubmissionInfo Page
    Verify Decline Close and Reopen








