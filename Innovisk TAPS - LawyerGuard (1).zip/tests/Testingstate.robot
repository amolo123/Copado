*** Settings ***
Resource               ../resources/common.robot
Resource               ../PageObjects/PageObjects_Account.robot
Resource               ../PageObjects/PageObjects_HomePage.robot
Resource               ../PageObjects/PageObjects_Submission.robot
Library                RetryFailed                 global_retries=${retry_count}
Suite Setup            Setup Browser
Suite Teardown         CloseAllBrowsers


*** Test Cases ***
Validate Creation of Business Account : Save Button 
    # Author = Amol
    #TC=93876
    [Documentation]    Creating an Account and Verifying
    [Tags]             Smoke_Test_LGO_Admitted     Smoke_Test
    Home
    # Authenticate     ${client_id}                ${client_secret}            ${username}    ${password}    sandbox=True
    # Update Record    Account                     001Ek00000YXq97IAD          State__c=New York