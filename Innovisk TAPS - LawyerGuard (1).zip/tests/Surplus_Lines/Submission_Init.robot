*** Settings ***
Resource                        ../../resources/common.robot
Resource                        ../../PageObjects/PageObjects_Account.robot
Resource                        ../../PageObjects/PageObjects_HomePage.robot
Resource                        ../../PageObjects/PageObjects_Submission.robot
Resource                        ../../PageObjects/PageObjects_InusredInfo.robot
Resource                        ../../PageObjects/PageObjects_SubmissionInit.robot
Resource                        ../../PageObjects/PageObjects_SubmissionInfo.robot
Library                         RetryFailed                 global_retries=${retry_count}
Suite Setup                     Setup Browser
Suite Teardown                  CloseAllBrowsers


*** Test Cases ***

Verify Save Button and Next Submission Info Functionality on Submission Init Form Primary
    # Author = Shraddha
    #TC=108152
    [Documentation]             Entering                    Details in Insured Info Tab
    [Tags]                      Smoke_Test_LGO_NONAdmitted                              Smoke_Test

    Creating a new Account state NY
    Checking Next Button On New Submission For SL           LawyerGuard_SL
    #Validate LaweyrGuard New submission Fields SL
    VerifyText                  Underwriter Workbench
    Add Account name on Insured info page
    Enter Territory data on Insured Info Page SL            New York: Remainder of State
    # VerifyInputValue          Contact Record Type         Attorney                    timeout=2s
    Click on save button
    Add Attorney
    Click on NEXT:Submission Info
    Validate Submission Init on Submission info page SL     Primary
    Select broker Contact Source

Verify Save Button and Next Submission Info Functionality on Submission Init Form Excess
    # Author = Shraddha
    #TC=108153
    [Documentation]             Entering                    Details in Insured Info Tab
    [Tags]                      Smoke_Test_LGO_NONAdmitted                              Smoke_Test

    Creating a new Account state NY
    Checking Next Button On New Submission For SL           LawyerGuard_SL
    #Validate LaweyrGuard New submission Fields SL
    VerifyText                  Underwriter Workbench
    Add Account name on Insured info page
    Enter Territory data on Insured Info Page SL            New York: Remainder of State
    # VerifyInputValue          Contact Record Type         Attorney                    timeout=2s
    Click on save button
    Add Attorney
    Click on NEXT:Submission Info
    Validate Submission Init on Submission info page SL Excess                          Excess
    Select broker Contact Source



