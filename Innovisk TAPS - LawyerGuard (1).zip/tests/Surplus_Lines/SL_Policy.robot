*** Settings ***
Resource                        ../../resources/common.robot
Resource                        ../../PageObjects/PageObjects_Account.robot
Resource                        ../../PageObjects/PageObjects_HomePage.robot
Resource                        ../../PageObjects/PageObjects_Submission.robot
Resource                        ../../PageObjects/PageObjects_InusredInfo.robot
Resource                        ../../PageObjects/PageObjects_SubmissionInit.robot
Resource                        ../../PageObjects/PageObjects_SubmissionInfo.robot
Resource                        ../../PageObjects/PageObjects_CheckEndorsements.robot
Resource                        ../../PageObjects/PageObjects_UnderwrittingAnalysis.robot
Resource                        ../../PageObjects/Surplus_Lines/PageObjects_SL_UnderwriterAnalysis.robot
Resource                        ../../PageObjects/PageObjects_CompareAndRateQuote.robot
Resource                        ../../PageObjects/PageObjects_Quote.robot
Resource                        ../../PageObjects/PageObjects_PolicyPage.robot
Resource                        ../../PageObjects/PageObjects_PolicyPage.robot
Resource                        ../../PageObjects/PageObjects_Quote.robot

Library                         RetryFailed                 global_retries=${retry_count}
Suite Setup                     Setup Browser
Suite Teardown                  CloseAllBrowsers




*** Test Cases ***


Verify Policy Page with all tabs, fields and Buttons for Primary
    #TCID=
    #Author=Shraddha
    [Documentation]             Functionality on Insured Info Page
    [Tags]                      Smoke_Test_LGO_NONAdmitted                              Smoke_Test
    Creating a new Account state NY
    Checking Next Button On New Submission For SL           LawyerGuard_SL
    VerifyText                  Underwriter Workbench
    Add Account name on Insured info page
    Enter Territory data on Insured Info Page SL            New York: Remainder of State
    Click on save button
    Add Attorney
    Click on NEXT:Submission Info
    Select broker Contact Source
    Entering Submission_Info Details for SL                 Primary                     12/06/2024
    ClickText                   NEXT:Underwriter Analysis >
    VerifyText                  Underwriting Analysis
    Add Area Of Practice
    Add Details In Underwriter Analysis Tab for SL
    ClickText                   Qualify Submission
    Sleep                       30s
    Validate Header Fields On Compare and Rate quote
    Sleep                       20s
    Click On Bind For SL        Individual broker license
    VerifyText                  Policy Name
    Validate Policy Screen Static Elements
    Verify Policy Screen Dynamic Elements SL
    Click Quote On Policy Page and Select Quote
    Validate Quote Screen Static Elements Admitted
    Validate Quote Screen Dynamic Elements

Verify Policy Page with all tabs, fields and Buttons for Excess
    #TCID=
    #Author=Shraddha
    [Documentation]             Functionality on Insured Info Page
    [Tags]                      Smoke_Test_LGO_NONAdmitted                              Smoke_Test

    Creating a new Account state NY
    Checking Next Button On New Submission For SL           LawyerGuard_SL
    VerifyText                  Underwriter Workbench
    Add Account name on Insured info page
    Enter Territory data on Insured Info Page SL            New York: Remainder of State
    Click on save button
    Add Attorney
    Click on NEXT:Submission Info
    Select broker Contact Source
    Entering Submission_Info Details for SL                 Excess                      12/06/2024
    ClickText                   NEXT:Underwriter Analysis >
    VerifyText                  Underwriting Analysis
    Add Area Of Practice for SL
    Add Details In Underwriter Analysis Tab for SL
    ClickText                   Qualify Submission
    Sleep                       30s
    Add Premium to Excess Fields
    Rate Quote
    Sleep                       30s
    Click On Bind For SL        Individual broker license
    VerifyText                  Policy Name
    Validate Policy Screen Static Elements
    Verify Policy Screen Dynamic Elements SL
    Click Quote On Policy Page and Select Quote
    Validate Quote Screen Static Elements Admitted
    Validate Quote Screen Dynamic Elements