*** Settings ***
Library                         QWeb
Resource                        ../../resources/common.robot
Resource                        ../../PageObjects/PageObjects_Account.robot
Resource                        ../../PageObjects/PageObjects_HomePage.robot
Resource                        ../../PageObjects/PageObjects_Submission.robot
Resource                        ../../PageObjects/PageObjects_InusredInfo.robot
Resource                        ../../PageObjects/PageObjects_SubmissionInit.robot
Resource                        ../../PageObjects/PageObjects_SubmissionInfo.robot
Resource                        ../../PageObjects/PageObjects_CheckEndorsements.robot
Resource                        ../../PageObjects/PageObjects_UnderwrittingAnalysis.robot
Resource                        ../../PageObjects/Surplus_Lines/PageObjects_SL_UnderwriterAnalysis.robot
Resource                        ../../PageObjects/PageObjects_CompareAndRateQuote.robot
Resource                        ../../PageObjects/PageObjects_Quote.robot
Resource                        ../../PageObjects/PageObjects_PolicyPage.robot

Library                         RetryFailed                 global_retries=${retry_count}
Suite Setup                     Setup Browser
Suite Teardown                  CloseAllBrowsers





*** Test Cases ***

Verify tabs after clicking on the Quote name from the quote section For Primary
    #TCID=
    #Author=Shraddha
    [Documentation]             Functionality on Insured Info Page
    [Tags]                      Smoke_Test_LGO_NONAdmitted                              Smoke_Test
    Creating a new Account state NY
    Checking Next Button On New Submission For SL           LawyerGuard_SL
    VerifyText                  Underwriter Workbench
    Add Account name on Insured info page
    Enter Territory data on Insured Info Page SL            New York: Remainder of State
    Click on save button
    Add Attorney
    Click on NEXT:Submission Info
    Select broker Contact Source
    Entering Submission_Info Details for SL                 Primary                     12/06/2024
    ClickText                   NEXT:Underwriter Analysis >
    VerifyText                  Underwriting Analysis
    Sleep                       10s
    Add Area Of Practice for SL
    Sleep                       10s
    Add Details In Underwriter Analysis Tab for SL
    ClickText                   Qualify Submission
    Sleep                       30s
    Validate Header Fields On Compare and Rate quote
    Sleep                       20s
    Click On Quote
    Validate Quote Screen Static Elements Admitted
    Validate Quote Screen Static Elements SL
    Validate Quote Screen Dynamic Elements


Verify the Quote tab on the post bind page For Primary
    #TCID=
    #Author=Shraddha
    [Documentation]             Functionality on Insured Info Page
    [Tags]                      Smoke_Test_LGO_NONAdmitted                              Smoke_Test
    Creating a new Account state NY
    Checking Next Button On New Submission For SL           LawyerGuard_SL
    VerifyText                  Underwriter Workbench
    Add Account name on Insured info page
    Enter Territory data on Insured Info Page SL            New York: Remainder of State
    Click on save button
    Add Attorney
    Click on NEXT:Submission Info
    Select broker Contact Source
    Entering Submission_Info Details for SL                 Primary                     12/06/2024
    ClickText                   NEXT:Underwriter Analysis >
    VerifyText                  Underwriting Analysis
    Add Area Of Practice for SL
    Add Details In Underwriter Analysis Tab for SL
    Sleep                       20s
    ClickText                   Qualify Submission
    Sleep                       30s
    Click On Bind For SL        Individual broker license
    VerifyText                  Policy Name
    #Click Quote On Policy Page and Select Quote
    Sleep                       10s
    ClickElement                //li[@title\='Quote']
    Sleep                       10s
    #ClickElement               (//records-hoverable-link//a)[last()]                   timeout=10s
    ClickText                   ${uniquename}
    Sleep                       10s
    Validate Quote Screen Static Elements Admitted
    Validate Quote Screen Dynamic Elements

Verify tabs after clicking on the Quote name from the quote section For Excess
    #TCID=
    #Author=Shraddha
    [Documentation]             Functionality on Insured Info Page
    [Tags]                      Smoke_Test_LGO_NONAdmitted                              Smoke_Test
    Creating a new Account
    Checking Next Button On New Submission For SL           LawyerGuard_SL
    #Validate LaweyrGuard New submission Fields SL
    VerifyText                  Underwriter Workbench
    Add Account name on Insured info page
    # VerifyInputValue          Contact Record Type         Attorney                    timeout=2s
    Click on save button
    Add Attorney
    Click on NEXT:Submission Info
    Select broker Contact Source
    Entering Submission_Info Details for SL                 Excess                      12/06/2024
    ClickText                   NEXT:Underwriter Analysis >
    VerifyText                  Underwriting Analysis
    Sleep                       20s
    Verify Underwriting Analysis Page Elements for SL Primary
    Validate Attributes for SL
    Add Area Of Practice for SL
    Add Details In Underwriter Analysis Tab for SL
    Sleep                       20s
    ClickText                   Qualify Submission
    Sleep                       40s
    Click On Quote
    Validate Quote Screen Static Elements Admitted
    Validate Quote Screen Static Elements SL
    Validate Quote Screen Dynamic Elements


Verify the Quote tab on the post bind page For Excess
    #TCID=
    #Author=Shraddha
    [Documentation]             Functionality on Insured Info Page
    [Tags]                      Smoke_Test_LGO_NONAdmitted                              Smoke_Test
    Creating a new Account state NY
    Checking Next Button On New Submission For SL           LawyerGuard_SL
    #Validate LaweyrGuard New submission Fields SL
    VerifyText                  Underwriter Workbench
    Add Account name on Insured info page
    # VerifyInputValue          Contact Record Type         Attorney                    timeout=2s
    Enter Territory data on Insured Info Page SL            New York: Remainder of State
    Click on save button
    Add Attorney
    Click on NEXT:Submission Info
    Select broker Contact Source
    Entering Submission_Info Details for SL                 Excess                      12/06/2024
    ClickText                   NEXT:Underwriter Analysis >
    VerifyText                  Underwriting Analysis
    Sleep                       20s
    Verify Underwriting Analysis Page Elements for SL Primary
    Validate Attributes for SL
    Add Area Of Practice for SL
    Add Details In Underwriter Analysis Tab for SL
    Sleep                       10s
    ClickText                   Qualify Submission
    Sleep                       30s
    Click On Bind For SL        Individual broker license
    VerifyText                  Policy Name
    Sleep                       10s
    ClickElement                //li[@title\='Quote']
    Sleep                       10s
    #ClickElement               (//records-hoverable-link//a)[last()]                   timeout=10s
    ClickText                   ${uniquename}
    Sleep                       10s
    Validate Quote Screen Static Elements Admitted
    Validate Quote Screen Dynamic Elements

