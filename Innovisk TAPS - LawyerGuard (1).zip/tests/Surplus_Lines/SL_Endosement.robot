*** Settings ***
Resource                        ../../resources/common.robot
Resource                        ../../PageObjects/PageObjects_Account.robot
Resource                        ../../PageObjects/PageObjects_HomePage.robot
Resource                        ../../PageObjects/PageObjects_Submission.robot
Resource                        ../../PageObjects/PageObjects_InusredInfo.robot
Resource                        ../../PageObjects/PageObjects_SubmissionInit.robot
Resource                        ../../PageObjects/PageObjects_SubmissionInfo.robot
Resource                        ../../PageObjects/PageObjects_CheckEndorsements.robot
Resource                        ../../PageObjects/PageObjects_UnderwrittingAnalysis.robot
Resource                        ../../PageObjects/Surplus_Lines/PageObjects_SL_UnderwriterAnalysis.robot

Library                         RetryFailed                 global_retries=${retry_count}
Suite Setup                     Setup Browser
Suite Teardown                  CloseAllBrowsers


*** Test Cases ***

Verify state related endorsement are visible for given state for LG SL Primary
    # Author = Shraddha
    #TC=108879
    [Documentation]
    [Tags]                      Smoke_Test_LGO_NONAdmitted                              Smoke_Test

    Creating a new Account state NY
    Checking Next Button On New Submission For SL           LawyerGuard_SL
    VerifyText                  Underwriter Workbench
    Add Account name on Insured info page
    Enter Territory data on Insured Info Page SL            New York: Remainder of State
    Click on save button
    Add Attorney
    Click on NEXT:Submission Info
    Select broker Contact Source
    Entering Submission_Info Details for SL                 Primary                     12/06/2024
    ClickText                   NEXT:Underwriter Analysis >
    VerifyText                  Underwriting Analysis
    Add Area Of Practice
    Add Details In Underwriter Analysis Tab for SL
    ClickText                   Qualify Submission
    Sleep                       40s
    ClickElement                //lightning-icon[@title\='Endorsements']
    VerifyText                  Lawyers' Professional Liability Declarations
    VerifyText                  Lawyers Professional Liability Insurance Policy
    VerifyText                  Schedule of Forms and Endorsements
    Check Endorsements According to State                   NY_SL_P

Verify state related endorsement are visible for given state for LG SL Excess 
    # Author = Shraddha
    #TC=108357
    [Documentation]
    [Tags]                      Smoke_Test_LGO_NONAdmitted                              Smoke_Test

    Creating a new Account state NY
    Checking Next Button On New Submission For SL           LawyerGuard_SL
    VerifyText                  Underwriter Workbench
    Add Account name on Insured info page
    Enter Territory data on Insured Info Page SL            New York: Remainder of State
    Click on save button
    Add Attorney
    Click on NEXT:Submission Info
    Select broker Contact Source
    Entering Submission_Info Details for SL                 Excess                      12/06/2024
    ClickText                   NEXT:Underwriter Analysis >
    VerifyText                  Underwriting Analysis
    Add Area Of Practice
    Add Details In Underwriter Analysis Tab for SL
    ClickText                   Qualify Submission
    Sleep                       40s
    ClickElement                //lightning-icon[@title\='Endorsements']
    VerifyText                  Follow Form Excess Liability Declarations
    VerifyText                  Follow Form Excess Liability Policy
    VerifyText                  Schedule Of Underlying Insurance
    VerifyText                  Schedule Of Forms And Endorsements
    VerifyText                  Excess OFAC Notice
    VerifyText                  Notice To Policyholder – Loss Reporting Procedures
    Check Endorsements According to State                   NY_SL_E