*** Settings ***
Library                         QWeb
Library                         QForce
Library                         FakerLibrary
Library                         String
Library                         BuiltIn
Library                         DateTime
Resource                        ../../resources/common.robot
Resource                        ../../PageObjects/PageObjects_Account.robot
Resource                        ../../PageObjects/PageObjects_HomePage.robot
Resource                        ../../PageObjects/PageObjects_Submission.robot
Resource                        ../../PageObjects/PageObjects_InusredInfo.robot
Resource                        ../../PageObjects/PageObjects_SubmissionInit.robot
Resource                        ../../PageObjects/PageObjects_SubmissionInfo.robot
Resource                        ../../PageObjects/PageObjects_CheckEndorsements.robot
Resource                        ../../PageObjects/PageObjects_UnderwrittingAnalysis.robot
Resource                        ../../PageObjects/Surplus_Lines/PageObjects_SL_UnderwriterAnalysis.robot
Resource                        ../../PageObjects/PageObjects_CompareAndRateQuote.robot
Resource                        ../../PageObjects/PageObjects_Quote.robot
Resource                        ../../PageObjects/PageObjects_PolicyPage.robot
Resource                        ../../PageObjects/PageObjects_PolicyPage.robot
Resource                        ../../PageObjects/PageObjects_Quote.robot

Library                         RetryFailed                 global_retries=${retry_count}
Suite Setup                     Setup Browser
Suite Teardown                  CloseAllBrowsers




*** Test Cases ***


Send Email Submission on Primary
    #TCID=
    #Author=Shraddha
    [Documentation]             Functionality on Insured Info Page
    [Tags]                      Smoke_Test_LGO_NONAdmitted                              Smoke_Test
    Creating a new Account state NY
    Checking Next Button On New Submission For SL           LawyerGuard_SL
    VerifyText                  Underwriter Workbench
    Add Account name on Insured info page
    Enter Territory data on Insured Info Page SL            New York: Remainder of State
    Click on save button
    Add Attorney
    Click on NEXT:Submission Info
    Select broker Contact Source
    Entering Submission_Info Details for SL                 Primary                     12/06/2024
    ClickText                   NEXT:Underwriter Analysis >
    VerifyText                  Underwriting Analysis
    Add Area Of Practice
    Sleep                       10s
    Add Details In Underwriter Analysis Tab for SL
    Sleep                       30s
    ClickText                   Qualify Submission
    Sleep                       30s
    Send Mail On Submission Page Primary                    Additional Information Request
    Send Mail On Submission Page Primary                    Admitted Decline and Quote Surplus Transmittal
    Send Mail On Submission Page Primary                    BOR Acknowledgement Midterm
    Send Mail On Submission Page Primary                    BOR Acknowledgement New/Renewal
    Send Mail On Submission Page Primary                    BOR Countermanding
    Send Mail On Submission Page Primary                    Claim Verification
    Send Mail On Submission Page Primary                    Coverage Expired – File Closed Transmittal
    Send Mail On Submission Page Primary                    Declination
    Send Mail On Submission Page Primary                    Duplicate Submission
    Send Mail On Submission Page Primary                    Indication Transmittal
    Send Mail On Submission Page Primary                    Non-Renewal Transmittal
    Send Mail On Submission Page Primary                    Not Quoted - Pricing
    Send Mail On Submission Page Primary                    Quote Transmittal
    Send Mail On Submission Page Primary                    Streamline Proposal Follow Up Transmittal

Send Email Submission on Excess
    #TCID=
    #Author=Shraddha
    [Documentation]             Functionality on Insured Info Page
    [Tags]                      Smoke_Test_LGO_NONAdmitted                              Smoke_Test
    Creating a new Account state NY
    Checking Next Button On New Submission For SL           LawyerGuard_SL
    VerifyText                  Underwriter Workbench
    Add Account name on Insured info page
    Enter Territory data on Insured Info Page SL            New York: Remainder of State
    Click on save button
    Add Attorney
    Click on NEXT:Submission Info
    Select broker Contact Source
    Entering Submission_Info Details for SL                 Excess                      12/06/2024
    ClickText                   NEXT:Underwriter Analysis >
    VerifyText                  Underwriting Analysis
    Sleep                       10s
    Add Area Of Practice for SL
    Sleep                       10s
    Add Details In Underwriter Analysis Tab for SL
    Sleep                       10s
    ClickText                   Qualify Submission
    Sleep                       30s
    Send Mail On Submission Page Excess                     Additional Information Request
    Send Mail On Submission Page Excess                     BOR Acknowledgement Midterm
    Send Mail On Submission Page Excess                     BOR Acknowledgement New/Renewal
    Send Mail On Submission Page Excess                     BOR Countermanding
    Send Mail On Submission Page Excess                     Claim Verification
    Send Mail On Submission Page Excess                     Coverage Expired – File Closed Transmittal
    Send Mail On Submission Page Excess                     Declination
    Send Mail On Submission Page Excess                     Duplicate Submission
    Send Mail On Submission Page Excess                     Non-Renewal Transmittal
    Send Mail On Submission Page Excess                     Not Quoted - Pricing
    Send Mail On Submission Page Excess                     Quote Transmittal

