*** Settings ***
Library                         QWeb
Library                         QForce
#Library                        QVision
Library                         FakerLibrary
Library                         String
Library                         BuiltIn
Library                         DateTime
Resource                        ../../resources/common.robot
Resource                        ../../PageObjects/PageObjects_Account.robot
Resource                        ../../resources/common.robot
Resource                        ../../PageObjects/PageObjects_Account.robot
Resource                        ../../PageObjects/PageObjects_HomePage.robot
Resource                        ../../PageObjects/PageObjects_Submission.robot
Resource                        ../../PageObjects/PageObjects_InusredInfo.robot
Resource                        ../../PageObjects/PageObjects_SubmissionInit.robot
Resource                        ../../PageObjects/PageObjects_SubmissionInfo.robot
Resource                        ../../PageObjects/PageObjects_CheckEndorsements.robot
Resource                        ../../PageObjects/PageObjects_UnderwrittingAnalysis.robot
Resource                        ../../PageObjects/Surplus_Lines/PageObjects_SL_UnderwriterAnalysis.robot
Resource                        ../../PageObjects/PageObjects_CompareAndRateQuote.robot
Resource                        ../../PageObjects/Surplus_Lines/PageObjects_SL_QuoteLetter.robot

Library                         ../../libraries/MailLib.py                              ${tenant_id}                ${client_id_mail}        ${client_secret_mail}



Library                         RetryFailed                 global_retries=${retry_count}
Suite Setup                     Setup Browser
Suite Teardown                  CloseAllBrowsers


*** Test Cases ***

Reading Quote Letter LG SL Primary
    # Author = Amol Gaymukhe
    #TC=
    [Documentation]             QuoteLetter                 Primary
    [Tags]                      Smoke_Test_LGO_NONAdmitted                              Smoke_Test
    Creating an account with a state California
    Checking Next Button On New Submission For SL           LawyerGuard_SL
    VerifyText                  Underwriter Workbench
    Add Account name on Insured info page
    Enter Territory data on Insured Info Page SL            California: Remainder of State
    Click on save button
    Add Attorney
    Click on NEXT:Submission Info
    Select broker Contact Source
    Entering Submission_Info Details for SL                 Primary                     12/06/2024
    ClickText                   NEXT:Underwriter Analysis >
    VerifyText                  Underwriting Analysis
    Add Area Of Practice
    Add Details In Underwriter Analysis Tab for SL
    ClickText                   Qualify Submission
    Sleep                       30s
    Generate Document In Quoted                             Quote Proposal
    Sleep                       10s
    Move to outputdir
    Read PDF Quote Letter Static document data for Primary
    Get Dynamic Data For SL Quote Letter
    Test PDF File               ${Pdate}
    Test PDF File               ${uniqueName}
    Test PDF File               Policy Period: ${Edate} to ${Exdate}
    Test PDF File               ${pdf_premium}
    Test PDF File               $250
    Test PDF File               ${pdf_SurplusTax}
    Test PDF File               ${pdf_Excess_Stamping_Fee}


Quote Letter LG SL Excess 
    # Author = Shraddha
    #TC=108357
    [Documentation]             QuoteLetter                 Excess
    [Tags]                      Smoke_Test_LGO_NONAdmitted                              Smoke_Test

    Creating an account with a state California
    Checking Next Button On New Submission For SL           LawyerGuard_SL
    VerifyText                  Underwriter Workbench
    Add Account name on Insured info page
    Enter Territory data on Insured Info Page SL            California: Remainder of State
    Click on save button
    Add Attorney
    Click on NEXT:Submission Info
    Select broker Contact Source
    Entering Submission_Info Details for SL                 Excess                      12/06/2024
    ClickText                   NEXT:Underwriter Analysis >
    VerifyText                  Underwriting Analysis
    Add Area Of Practice
    Add Details In Underwriter Analysis Tab for SL
    ClickText                   Qualify Submission
    Sleep                       30s
    Scroll                      //html
    Scroll                      //html
    Scroll                      //html
    Scroll                      //html
    Scroll                      //html
    #Verify Excess Quote Data
    VerifyText                  Primary Quote Premium
    VerifyText                  Actual Primary Premium Charged
    VerifyText                  Excess Quota Share
    VerifyText                  Excess Layer Limit
    TypeText                    Actual Primary Premium Charged                          3000000
    TypeText                    //input[contains(@name,'-Excess Layer Limit')]          5000000
    ClickElement                (//lightning-icon[@title\='Save'])
    Sleep                       10s
    Scroll                      //html                      page_up
    Scroll                      //html                      page_up
    Scroll                      //html                      page_up
    Scroll                      //html                      page_up
    Scroll                      //html                      page_up
    Rate Quote
    Sleep                       30s
    RefreshPage
    Generate Document In Quoted                             Quote Proposal
    Log To Console              ------ Document Genearted Successful -------            Quote Proposal
    Move to outputdir
    Read PDF Quote Letter Static data for Excess

    #Converting Date to Propsal Date
    ${CurrentDate}=             Get Current Date
    ${Pdate}=                   Convert Date                ${CurrentDate}              result_format=%B %-d, %Y
    #Converting Eff Date and Exp Date
    ${Eff_D}=                   GetInputValue               (//div[@data-id\='QuoteData']//lightning-input)[1]
    ${Exp_D}=                   GetInputValue               (//div[@data-id\='QuoteData']//lightning-input)[2]
    ${Edate}=                   Convert Date                ${Eff_D}                    result_format=%B %-d, %Y
    ${Exdate}=                  Convert Date                ${Exp_D}                    result_format=%B %-d, %Y

    # ${Excess_SurplusTax}=     GetInputValue               (//div[@data-id\='QuoteData']//lightning-input)[10]
    # ${Excess_Stamping_Fee}=                               GetInputValue               (//div[@data-id\='QuoteData']//lightning-input)[11]
    # ${result}=                Convert To Number           ${Excess_Stamping_Fee}      2
    # ${Ex_ST_One}=             Catenate                    $                           ${Excess_SurplusTax}
    #${Ex_ST_Result}=           Remove String               ${Ex_ST_One}                ${SPACE}
    #${Ex_SF_One}=              Catenate                    $                           ${result}
    # ${Ex_SF_Result}=          Remove String               ${Ex_SF_One}                ${SPACE}

    ${orignal_premium}=         GetText                     (//div[@data-id\='QuoteData']//lightning-input)[6]
    ${pdf_premium}=             Set Variable                ${orignal_premium}
    Set Global Variable         ${pdf_premium}

    ${SurplusTax}=              GetText                     (//div[@data-id\='QuoteData']//lightning-input)[10]
    ${pdf_SurplusTax}=          Set Variable                ${SurplusTax}
    Set Global Variable         ${pdf_SurplusTax}

    ${Excess_Stamping_Fee}=     GetText                     (//div[@data-id\='QuoteData']//lightning-input)[11]
    ${pdf_Excess_Stamping_Fee}=                             Set Variable                ${Excess_Stamping_Fee}
    Set Global Variable         ${pdf_Excess_Stamping_Fee}



    Test PDF File               ${Pdate}
    Test PDF File               ${uniqueName}
    Test PDF File               Policy Period: ${Edate} to ${Exdate}
    Test PDF File               ${pdf_premium}
    Test PDF File               $250
    Test PDF File               ${pdf_SurplusTax}
    Test PDF File               ${pdf_Excess_Stamping_Fee}


    # ${QuotePremium}=          GetText                     //p[@class\='QuoteHeaderPremium slds-align_absolute-center']
    # ${Account}=               GetFieldValue               Account
    #Test PDF File              ${QuotePremium}
    # Test PDF File             ${pdf_policyperiod}
    # Test PDF File             ${fromdate1}
    # Test PDF File             ${todate1}