*** Settings ***
#Resource                       ../../resources/common.robot
Resource                        ../../PageObjects/PageObjects_Account.robot
Resource                        ../../PageObjects/PageObjects_HomePage.robot
Resource                        ../../PageObjects/PageObjects_Submission.robot
Resource                        ../../PageObjects/PageObjects_InusredInfo.robot
Resource                        ../../PageObjects/PageObjects_SubmissionInit.robot
Resource                        ../../PageObjects/PageObjects_SubmissionInfo.robot
Resource                        ../../PageObjects/PageObjects_CheckEndorsements.robot
Resource                        ../../PageObjects/PageObjects_UnderwrittingAnalysis.robot
Resource                        ../../PageObjects/Surplus_Lines/PageObjects_SL_UnderwriterAnalysis.robot
Resource                        ../../PageObjects/PageObjects_CompareAndRateQuote.robot
Resource                        ../../PageObjects/Surplus_Lines/PageObjects_SL_QuoteLetter.robot



Library                         RetryFailed                 global_retries=${retry_count}
Suite Setup                     Setup Browser
Suite Teardown                  CloseAllBrowsers


*** Test Cases ***

Verify Header section of Quote Console For Primary 
    # Author = Shraddha
    #TC=108760
    [Documentation]             Surplus
    [Tags]                      Smoke_Test_LGO_NONAdmitted                              Smoke_Test

    Creating a new Account state NY
    Checking Next Button On New Submission For SL           LawyerGuard_SL
    VerifyText                  Underwriter Workbench
    Add Account name on Insured info page
    Enter Territory data on Insured Info Page SL            New York: Remainder of State
    Click on save button
    Add Attorney
    Click on NEXT:Submission Info
    Select broker Contact Source
    Entering Submission_Info Details for SL                 Primary                     12/06/2024
    ClickText                   NEXT:Underwriter Analysis >
    VerifyText                  Underwriting Analysis
    Add Area Of Practice
    Add Details In Underwriter Analysis Tab for SL
    ClickText                   Qualify Submission
    Sleep                       30s
    Validate Header Fields On Compare and Rate quote
    Generate Document In Quoted                             Quote Proposal
    Generate Document In Quoted                             Streamlined Renewal
    Generate Document In Rated                              Indication
    Generate Document In Rated                              Account Summary
    New Quote Button




Verify Header section of Quote Console: Bulk Rate for Primary   
    # Author = Shraddha
    #TC=108760
    [Documentation]             Surplus
    [Tags]                      Smoke_Test_LGO_NONAdmitted                              Smoke_Test
    Creating a new Account state NY
    Checking Next Button On New Submission For SL           LawyerGuard_SL
    VerifyText                  Underwriter Workbench
    Add Account name on Insured info page
    Enter Territory data on Insured Info Page SL            New York: Remainder of State
    Click on save button
    Add Attorney
    Click on NEXT:Submission Info
    Select broker Contact Source
    Entering Submission_Info Details for SL                 Primary                     12/06/2024
    ClickText                   NEXT:Underwriter Analysis >
    VerifyText                  Underwriting Analysis
    Add Area Of Practice
    Add Details In Underwriter Analysis Tab for SL
    ClickText                   Qualify Submission
    Sleep                       30s
    Verify Bulk Rate


Verify Header section of Quote Console: Internal Referal For Primary
    # Author = Shraddha
    #TC=108760
    [Documentation]             Surplus
    [Tags]                      Smoke_Test_LGO_NONAdmitted                              Smoke_Test
    Creating a new Account state NY
    Checking Next Button On New Submission For SL           LawyerGuard_SL
    VerifyText                  Underwriter Workbench
    Add Account name on Insured info page
    Enter Territory data on Insured Info Page SL            New York: Remainder of State
    Click on save button
    Add Attorney
    Click on NEXT:Submission Info
    Select broker Contact Source
    Entering Submission_Info Details for SL                 Primary                     12/06/2024
    ClickText                   NEXT:Underwriter Analysis >
    VerifyText                  Underwriting Analysis
    Add Area Of Practice
    Add Details In Underwriter Analysis Tab for SL
    ClickText                   Qualify Submission
    Sleep                       30s
    Validate Header Fields On Compare and Rate quote
    Vaidate Refer Functionality Fields
    Add Internal Refer

Verify Header section of Quote Console: External Referal for Primary
    # Author = Shraddha
    #TC=
    [Documentation]             Surplus
    [Tags]                      Smoke_Test_LGO_NONAdmitted                              Smoke_Test
    Creating a new Account state NY
    Checking Next Button On New Submission For SL           LawyerGuard_SL
    VerifyText                  Underwriter Workbench
    Add Account name on Insured info page
    Enter Territory data on Insured Info Page SL            New York: Remainder of State
    Click on save button
    Add Attorney
    Click on NEXT:Submission Info
    Select broker Contact Source
    Entering Submission_Info Details for SL                 Primary                     12/06/2024
    ClickText                   NEXT:Underwriter Analysis >
    VerifyText                  Underwriting Analysis
    Add Area Of Practice
    Add Details In Underwriter Analysis Tab for SL
    ClickText                   Qualify Submission
    Sleep                       30s
    Vaidate Refer Functionality Fields
    Add External Refer

Verify the functionality of Limits And Deductibles section on Quote console for Primary
    # Author = Shraddha
    #TC=
    [Documentation]             Surplus
    [Tags]                      Smoke_Test_LGO_NONAdmitted                              Smoke_Test
    Creating a new Account state NY
    Checking Next Button On New Submission For SL           LawyerGuard_SL
    VerifyText                  Underwriter Workbench
    Add Account name on Insured info page
    Enter Territory data on Insured Info Page SL            New York: Remainder of State
    Click on save button
    Add Attorney
    Click on NEXT:Submission Info
    Select broker Contact Source
    Entering Submission_Info Details for SL                 Primary                     12/06/2024
    ClickText                   NEXT:Underwriter Analysis >
    VerifyText                  Underwriting Analysis
    Add Area Of Practice
    Add Details In Underwriter Analysis Tab for SL
    ClickText                   Qualify Submission
    Sleep                       30s
    Validate Limit and Deductibles for Primary

Verify the main Quote Console Component on screen(in dark colour)below quote console header:Premium seek and Dropdown values for Primary
    # Author = Shraddha
    #TC=
    [Documentation]             Surplus
    [Tags]                      Smoke_Test_LGO_NONAdmitted                              Smoke_Test
    Creating a new Account state NY
    Checking Next Button On New Submission For SL           LawyerGuard_SL
    VerifyText                  Underwriter Workbench
    Add Account name on Insured info page
    Enter Territory data on Insured Info Page SL            New York: Remainder of State
    Click on save button
    Add Attorney
    Click on NEXT:Submission Info
    Select broker Contact Source
    Entering Submission_Info Details for SL                 Primary                     12/06/2024
    ClickText                   NEXT:Underwriter Analysis >
    VerifyText                  Underwriting Analysis
    Add Area Of Practice
    Add Details In Underwriter Analysis Tab for SL
    ClickText                   Qualify Submission
    Sleep                       30s
    Validate Quote Console Header Fields for Primary
    Validate DropDown Values
    Operations on DropDown Values

Verify the functionality of Area Of Practice section on Quote Console 
    # Author = Shraddha
    #TC=
    [Documentation]             Surplus
    [Tags]                      Smoke_Test_LGO_NONAdmitted                              Smoke_Test
    Creating a new Account state NY
    Checking Next Button On New Submission For SL           LawyerGuard_SL
    VerifyText                  Underwriter Workbench
    Add Account name on Insured info page
    Enter Territory data on Insured Info Page SL            New York: Remainder of State
    Click on save button
    Add Attorney
    Click on NEXT:Submission Info
    Select broker Contact Source
    Entering Submission_Info Details for SL                 Primary                     12/06/2024
    ClickText                   NEXT:Underwriter Analysis >
    VerifyText                  Underwriting Analysis
    Add Area Of Practice
    Add Details In Underwriter Analysis Tab for SL
    ClickText                   Qualify Submission
    Sleep                       30s
    VerifyText                  Area of Practice
    VerifyText                  100.0000% Admiralty-Defense (0.470 - 0.970)
    VerifyElement               //div[@data-id\='AreaofPractice']//div/label
    ClickElement                //div[@data-id\='AreaofPractice']//div/label
    #VerifyText                 //div[@data-id\='AreaofPractice']//span[text()\='0.72']
    Log To Console              ------ AOP Completed Successful -------

Verify the functionality of Litigation History section on Quote Console for Primary
    #Author = Shraddha
    #TC=
    [Documentation]             Surplus
    [Tags]                      Smoke_Test_LGO_NONAdmitted                              Smoke_Test
    Creating a new Account state NY
    Checking Next Button On New Submission For SL           LawyerGuard_SL
    VerifyText                  Underwriter Workbench
    Add Account name on Insured info page
    Enter Territory data on Insured Info Page SL            New York: Remainder of State
    Click on save button
    Add Attorney
    Click on NEXT:Submission Info
    Select broker Contact Source
    Entering Submission_Info Details for SL                 Primary                     12/06/2024
    ClickText                   NEXT:Underwriter Analysis >
    VerifyText                  Underwriting Analysis
    Add Area Of Practice
    Add Details In Underwriter Analysis Tab for SL
    ClickText                   Qualify Submission
    Sleep                       30s
    Verify Litigation History on Quote Console


Verify the functionality of Quote Data section on Quote Console for Primary
    #Author = Shraddha
    #TC=
    [Documentation]             Surplus
    [Tags]                      Smoke_Test_LGO_NONAdmitted                              Smoke_Test
    Creating a new Account state NY
    Checking Next Button On New Submission For SL           LawyerGuard_SL
    VerifyText                  Underwriter Workbench
    Add Account name on Insured info page
    Enter Territory data on Insured Info Page SL            New York: Remainder of State
    Click on save button
    Add Attorney
    Click on NEXT:Submission Info
    Select broker Contact Source
    Entering Submission_Info Details for SL                 Primary                     12/06/2024
    ClickText                   NEXT:Underwriter Analysis >
    VerifyText                  Underwriting Analysis
    Add Area Of Practice
    Add Details In Underwriter Analysis Tab for SL
    Add Subjectivities for SL
    Sleep                       30s
    VerifyText                  Effective Date
    VerifyText                  Expiration Date
    VerifyText                  Quote Premium
    VerifyText                  Policy Fee
    VerifyText                  Endorsement Effective Date
    VerifyText                  Transaction Premium
    VerifyText                  Quota Share
    VerifyText                  State Taxes
    VerifyText                  Municipal Taxes
    VerifyText                  Surplus Lines Taxes
    VerifyText                  Stamping Fees
    VerifyText                  Total Premium
    VerifyText                  State Specific Fees
    VerifyText                  Default Commission Percentage
    VerifyText                  Expiring Commission Percentage
    VerifyText                  Commission Percentage
    VerifyCheckbox              Commission Override
    Log To Console              ------ Quote Data Fields Verified Successful -------
    Rate Quote
    Click On Bind For SL        Agency broker license
    VerifyText                  Policy Name

Verify the functionality of Quote Data section on Quote Console for Excess
    #Author = Shraddha
    #TC=
    [Documentation]             Surplus
    [Tags]                      Smoke_Test_LGO_NONAdmitted                              Smoke_Test
    Creating a new Account
    Checking Next Button On New Submission For SL           LawyerGuard_SL
    #Validate LaweyrGuard New submission Fields SL
    VerifyText                  Underwriter Workbench
    Add Account name on Insured info page
    # VerifyInputValue          Contact Record Type         Attorney                    timeout=2s
    Click on save button
    Add Attorney
    Click on NEXT:Submission Info
    Select broker Contact Source
    Entering Submission_Info Details for SL                 Excess                      12/06/2024
    ClickText                   NEXT:Underwriter Analysis >
    VerifyText                  Underwriting Analysis
    Verify Underwriting Analysis Page Elements for SL Primary
    Add Area Of Practice for SL
    Add Details In Underwriter Analysis Tab for SL
    Add Subjectivities for SL
    Sleep                       30s
    Scroll                      //html
    Scroll                      //html
    Scroll                      //html
    Scroll                      //html
    Scroll                      //html
    #Verify Excess Quote Data
    VerifyText                  Primary Quote Premium
    VerifyText                  Actual Primary Premium Charged
    VerifyText                  Excess Quota Share
    VerifyText                  Excess Layer Limit
    TypeText                    Actual Primary Premium Charged                          3000000
    TypeText                    //input[contains(@name,'-Excess Layer Limit')]          5000000
    Log To Console              ------ Excess Quote Data Fields Verified Successful -------
    Scroll                      //html                      page_up
    Scroll                      //html                      page_up
    Scroll                      //html                      page_up
    Scroll                      //html                      page_up
    Scroll                      //html                      page_up
    Rate Quote
    Click On Bind For SL        Individual broker license
    VerifyText                  Policy Name


