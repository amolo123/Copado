*** Settings ***
Library                         QWeb
Library                         QForce
Library                         FakerLibrary
Library                         String
Library                         BuiltIn
Library                         DateTime
#Resource                       ../../resources/common.robot
Resource                        ../../PageObjects/PageObjects_Account.robot
Resource                        ../../PageObjects/PageObjects_HomePage.robot
Resource                        ../../PageObjects/PageObjects_Submission.robot
Resource                        ../../PageObjects/PageObjects_InusredInfo.robot
Resource                        ../../PageObjects/PageObjects_SubmissionInit.robot
Resource                        ../../PageObjects/PageObjects_SubmissionInfo.robot
Resource                        ../../PageObjects/PageObjects_CheckEndorsements.robot
Resource                        ../../PageObjects/PageObjects_UnderwrittingAnalysis.robot
Resource                        ../../PageObjects/Surplus_Lines/PageObjects_SL_UnderwriterAnalysis.robot
Resource                        ../../PageObjects/PageObjects_CompareAndRateQuote.robot
Resource                        ../../PageObjects/Surplus_Lines/PageObjects_SL_QuoteLetter.robot
Resource


Library                         RetryFailed                 global_retries=${retry_count}
Suite Setup                     Setup Browser
Suite Teardown                  CloseAllBrowsers


*** Test Cases ***

Verify the functionality of 'create SL submission' from submission info page of admitted product Primary
    # Author = Shraddha
    #TC=108351
    [Documentation]
    [Tags]                      Smoke_Test_LGO_NONAdmitted                              Smoke_Test

    Creating a new Account
    Validate LaweyrGuard New submission Fields
    VerifyText                  Underwriter Workbench
    Add Account name on Insured info page
    Click on save button
    Add Attorney
    Click on NEXT:Submission Info
    Select broker Contact Source
    Add Details In SubmissionInfo Page
    Transform From Admitted to SL
    Entering Submission_Info Details for SL                 Primary                     12/06/2024
    ClickText                   NEXT:Underwriter Analysis >
    VerifyText                  Underwriting Analysis
    Sleep                       20s
    Add Area Of Practice for SL
    Sleep                       20s
    Add Details In Underwriter Analysis Tab for SL
    Sleep                       20s
    ClickText                   Qualify Submission
    Sleep                       30s
    Sleep                       20s
    Click On Bind For SL        Individual broker license
    VerifyField                 Product Name                LawyerGuard_SL              partial_match=True

Verify Elements
    # Author = Shraddha
    #TC=108351
    [Documentation]
    [Tags]                      Smoke_Test_LGO_NONAdmitted                              Smoke_Test

    Creating a new Account
    Validate LaweyrGuard New submission Fields
    VerifyText                  Underwriter Workbench
    Add Account name on Insured info page
    Click on save button
    Add Attorney
    Click on NEXT:Submission Info
    Select broker Contact Source
    Add Details In SubmissionInfo Page
    Verify Elements on Transform SL Pop Up and Decline

    Creating a new Account
    Validate LaweyrGuard New submission Fields
    VerifyText                  Underwriter Workbench
    Add Account name on Insured info page
    Click on save button
    Add Attorney
    Click on NEXT:Submission Info
    Select broker Contact Source
    Add Details In SubmissionInfo Page
    Verify Elements on Transform SL Pop Up with user selection                          Entertainment/Sports exposure

Verify the functionality of 'create SL submission' from submission info page of admitted product Excess
    # Author = Shraddha
    #TC=108351
    [Documentation]
    [Tags]                      Smoke_Test_LGO_NONAdmitted                              Smoke_Test

    Creating a new Account
    Validate LaweyrGuard New submission Fields
    VerifyText                  Underwriter Workbench
    Add Account name on Insured info page
    Click on save button
    Add Attorney
    Click on NEXT:Submission Info
    Select broker Contact Source
    Add Details In SubmissionInfo Page
    Transform From Admitted to SL
    Sleep                       10s
    Entering Submission_Info Details for SL                 Excess                      12/06/2024
    ClickText                   NEXT:Underwriter Analysis >
    VerifyText                  Underwriting Analysis
    Add Area Of Practice for SL
    Sleep                       20s
    Add Details In Underwriter Analysis Tab for SL
    Sleep                       20s
    ClickText                   Qualify Submission
    Sleep                       30s
    Click On Bind For SL        Individual broker license
    VerifyField                 Product Name                LawyerGuard_SL              partial_match=True



Verify the functionality of 'create SL Excess submission' from Policy page of admitted product
    # Author = Shraddha
    #TC=108351
    [Documentation]
    [Tags]                      Smoke_Test_LGO_NONAdmitted                              Smoke_Test

    Creating a new Account
    Validate LaweyrGuard New submission Fields
    VerifyText                  Underwriter Workbench
    Add Account name on Insured info page
    Click on save button
    Add Attorney
    Click on NEXT:Submission Info
    Select broker Contact Source
    Add Details In SubmissionInfo Page
    ClickText                   NEXT:Underwriter Analysis >
    VerifyText                  Underwriting Analysis
    Add Area Of Practice
    ClickText                   Qualify Submission
    Sleep                       30s
    Click On Bind
    ClickText                   Create SL Excess Submission
    Sleep                       30s
    Entering Submission_Info Details for SL                 Excess                      12/06/2024
    ClickText                   NEXT:Underwriter Analysis >
    VerifyText                  Underwriting Analysis
    Sleep                       20s
    Add Area Of Practice for SL
    Sleep                       20s
    Add Details In Underwriter Analysis Tab for SL
    Sleep                       20s
    ClickText                   Qualify Submission
    Sleep                       30s
    Click On Bind For SL        Individual broker license
    VerifyField                 Product Name                LawyerGuard_SL              partial_match=True

