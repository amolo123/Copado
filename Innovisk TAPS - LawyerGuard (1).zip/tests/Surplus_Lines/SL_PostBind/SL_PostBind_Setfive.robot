*** Settings ***
Library                         QWeb
Library                         QForce
Library                         FakerLibrary
Library                         String
Library                         BuiltIn
Library                         DateTime
Library                         RetryFailed                 global_retries=${retry_count}
Resource                        ../../../resources/common.robot
Resource                        ../../../PageObjects/PageObjects_Account.robot
Resource                        ../../../PageObjects/PageObjects_HomePage.robot
Resource                        ../../../PageObjects/PageObjects_Submission.robot
Resource                        ../../../PageObjects/PageObjects_InusredInfo.robot
Resource                        ../../../PageObjects/PageObjects_SubmissionInit.robot
Resource                        ../../../PageObjects/PageObjects_SubmissionInfo.robot
Resource                        ../../../PageObjects/PageObjects_CheckEndorsements.robot
Resource                        ../../../PageObjects/PageObjects_UnderwrittingAnalysis.robot
Resource                        ../../../PageObjects/Surplus_Lines/PageObjects_SL_UnderwriterAnalysis.robot
Resource                        ../../../PageObjects/PageObjects_CompareAndRateQuote.robot
Resource                        ../../../PageObjects/PageObjects_Quote.robot
Resource                        ../../../PageObjects/PageObjects_PolicyPage.robot
Resource                        ../../../PageObjects/PageObjects_PolicyPage.robot
Resource                        ../../../PageObjects/PageObjects_Quote.robot


Library                         RetryFailed                 global_retries=${retry_count}
Suite Setup                     Setup Browser
Suite Teardown                  CloseAllBrowsers

*** Test Cases ***

Extended Reporting Period - Firm Excess
    #TCID=
    #Author=Shraddha
    [Documentation]             Functionality on Insured Info Page
    [Tags]                      Regression_Test_LGO_NONAdmitted                         Regression_Test

    Creating a new Account state NY
    Checking Next Button On New Submission For SL           LawyerGuard_SL
    VerifyText                  Underwriter Workbench
    Add Account name on Insured info page
    Enter Territory data on Insured Info Page SL            New York: Remainder of State
    Click on save button
    Add Attorney
    Click on NEXT:Submission Info
    Select broker Contact Source
    Entering Submission_Info Details for SL                 Excess                      12/06/2024
    ClickText                   NEXT:Underwriter Analysis >
    VerifyText                  Underwriting Analysis
    Sleep                       10s
    Add Area Of Practice for SL
    Sleep                       10s
    Add Details In Underwriter Analysis Tab for SL
    ClickText                   Qualify Submission
    Sleep                       30s
    Add Premium to Excess Fields
    Rate Quote
    Sleep                       30s
    Click On Bind For SL        Individual broker license
    VerifyText                  Policy Name
    RefreshPage
    Change Policy Functionality                             Midterm Cancellation
    Select Change Midterm Cancellation Input
    Click Bind SL After Amendment
    Change Policy Functionality                             Extended Reporting Period

    #DropDown                   1486:0                      Firm
    DropDown                    ERP Type                    Firm
    #VerifyText                 ERP Type
    ClickText                   Endorsement Effective Date                              timeout=55s
    ${cur_data}=                Get Current Date            result_format=%b %-d, %Y
    ${comp_effective_date}=     Get Current Date            increment=5 day             result_format=%b %-d, %Y
    Log To Console              ${comp_effective_date}
    ${subdate1}=                Get Substring               ${comp_effective_date}      4                           -6
    Log To Console              ${subdate1}
    ClickElement                //a[@title\='Go to next month']
    ClickElement                //span[text()\='${subdate1}']
    ClickText                   Confirm                     anchor=Cancel
    Sleep                       20s
    Click Bind SL After Amendment
    Click Quote On Policy Page
    VerifyText                  Midterm Cancellation
    VerifyText                  Extended Reporting Period

Validate Flat Cancellation for Primary 
    #TCID=
    #Author=Shraddha
    [Documentation]             Functionality on Insured Info Page
    [Tags]                      Regression_Test_LGO_NONAdmitted                         Regression_Test
    Creating a new Account state NY
    Checking Next Button On New Submission For SL           LawyerGuard_SL
    VerifyText                  Underwriter Workbench
    Add Account name on Insured info page
    Enter Territory data on Insured Info Page SL            New York: Remainder of State
    Click on save button
    Add Attorney
    Click on NEXT:Submission Info
    Select broker Contact Source
    Entering Submission_Info Details for SL                 Primary                     12/06/2024
    ClickText                   NEXT:Underwriter Analysis >
    VerifyText                  Underwriting Analysis
    Add Area Of Practice
    Sleep                       10s
    Add Details In Underwriter Analysis Tab for SL
    Sleep                       10s
    ClickText                   Qualify Submission
    Sleep                       30s
    Click On Bind For SL        Individual broker license
    VerifyText                  Policy Name
    Change Policy Functionality                             Flat Cancellation
    Sleep                       10s
    Select flat cancellation Input
    Click Bind SL After Amendment
    Click Quote On Policy Page
    VerifyText                  Flat Cancellation

Validate Flat Cancellation for Excess  
    #TCID=
    #Author=Shraddha
    [Documentation]             Functionality on Insured Info Page
    [Tags]                      Regression_Test_LGO_NONAdmitted                         Regression_Test
    Creating a new Account state NY
    Checking Next Button On New Submission For SL           LawyerGuard_SL
    VerifyText                  Underwriter Workbench
    Add Account name on Insured info page
    Enter Territory data on Insured Info Page SL            New York: Remainder of State
    Click on save button
    Add Attorney
    Click on NEXT:Submission Info
    Select broker Contact Source
    Entering Submission_Info Details for SL                 Excess                      12/06/2024
    ClickText                   NEXT:Underwriter Analysis >
    VerifyText                  Underwriting Analysis
    Add Area Of Practice for SL
    Sleep                       10s
    Add Details In Underwriter Analysis Tab for SL
    Sleep                       10s
    ClickText                   Qualify Submission
    Sleep                       30s
    Add Premium to Excess Fields
    Rate Quote
    Sleep                       30s
    Click On Bind For SL        Individual broker license
    VerifyText                  Policy Name
    Change Policy Functionality                             Flat Cancellation
    Sleep                       10s
    Select flat cancellation Input
    Click Bind SL After Amendment
    Click Quote On Policy Page
    VerifyText                  Flat Cancellation

Reinstatement - Primary
    #TCID=
    #Author=Shraddha
    [Documentation]             Functionality on Insured Info Page
    [Tags]                      Regression_Test_LGO_NONAdmitted                         Regression_Test
    Creating a new Account state NY
    Checking Next Button On New Submission For SL           LawyerGuard_SL
    VerifyText                  Underwriter Workbench
    Add Account name on Insured info page
    Enter Territory data on Insured Info Page SL            New York: Remainder of State
    Click on save button
    Add Attorney
    Click on NEXT:Submission Info
    Select broker Contact Source
    Entering Submission_Info Details for SL                 Primary                     12/06/2024
    ClickText                   NEXT:Underwriter Analysis >
    VerifyText                  Underwriting Analysis
    Add Area Of Practice
    Sleep                       10s
    Add Details In Underwriter Analysis Tab for SL
    Sleep                       10s
    ClickText                   Qualify Submission
    Sleep                       30s
    Click On Bind For SL        Individual broker license
    VerifyText                  Policy Name
    Change Policy Functionality                             Midterm Cancellation
    Select Change Midterm Cancellation Input
    Click Bind SL After Amendment
    Change Policy Functionality                             Reinstatement
    #ClickElement               //div[@class\="slds-form-element__control slds-grow"]
    ClickText                   Endorsement Effective Date                              timeout=55s
    ${cur_data}=                Get Current Date            result_format=%b %-d, %Y
    ${comp_effective_date}=     Get Current Date            increment=5 day             result_format=%b %-d, %Y
    Log To Console              ${comp_effective_date}
    ${subdate1}=                Get Substring               ${comp_effective_date}      4                           -6
    Log To Console              ${subdate1}
    ClickElement                //a[@title\='Go to next month']
    ClickElement                //span[text()\='${subdate1}']
    ClickText                   Confirm                     anchor=Cancel
    Sleep                       20s
    Click Bind SL After Amendment
    Click Quote On Policy Page
    VerifyText                  Midterm Cancellation
    VerifyText                  Reinstatement

Reinstatement - Excess
    #TCID=
    #Author=Shraddha
    [Documentation]             Functionality on Insured Info Page
    [Tags]                      Regression_Test_LGO_NONAdmitted                         Regression_Test
    Creating a new Account state NY
    Checking Next Button On New Submission For SL           LawyerGuard_SL
    VerifyText                  Underwriter Workbench
    Add Account name on Insured info page
    Enter Territory data on Insured Info Page SL            New York: Remainder of State
    Click on save button
    Add Attorney
    Click on NEXT:Submission Info
    Select broker Contact Source
    Entering Submission_Info Details for SL                 Excess                      12/06/2024
    ClickText                   NEXT:Underwriter Analysis >
    VerifyText                  Underwriting Analysis
    Add Area Of Practice for SL
    Sleep                       10s
    Add Details In Underwriter Analysis Tab for SL
    Sleep                       10s
    ClickText                   Qualify Submission
    Sleep                       30s
    Add Premium to Excess Fields
    Rate Quote
    Sleep                       30s
    Click On Bind For SL        Individual broker license
    VerifyText                  Policy Name
    Change Policy Functionality                             Midterm Cancellation
    Select Change Midterm Cancellation Input
    Click Bind SL After Amendment
    Change Policy Functionality                             Reinstatement
    #DropDown                   1486:0                      Firm
    #VerifyText                 ERP Type
    ClickText                   Endorsement Effective Date                              timeout=55s
    ${cur_data}=                Get Current Date            result_format=%b %-d, %Y
    ${comp_effective_date}=     Get Current Date            increment=5 day             result_format=%b %-d, %Y
    Log To Console              ${comp_effective_date}
    ${subdate1}=                Get Substring               ${comp_effective_date}      4                           -6
    Log To Console              ${subdate1}
    ClickElement                //a[@title\='Go to next month']
    ClickElement                //span[text()\='${subdate1}']
    ClickText                   Confirm                     anchor=Cancel
    Sleep                       20s
    Click Bind SL After Amendment
    Click Quote On Policy Page
    VerifyText                  Midterm Cancellation
    VerifyText                  Reinstatement