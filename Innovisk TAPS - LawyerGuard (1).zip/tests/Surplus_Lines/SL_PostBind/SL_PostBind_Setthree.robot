*** Settings ***
Library                         QWeb
Library                         QForce
Library                         FakerLibrary
Library                         String
Library                         BuiltIn
Library                         DateTime
Library                         RetryFailed                 global_retries=${retry_count}
Resource                        ../../../resources/common.robot
Resource                        ../../../PageObjects/PageObjects_Account.robot
Resource                        ../../../PageObjects/PageObjects_HomePage.robot
Resource                        ../../../PageObjects/PageObjects_Submission.robot
Resource                        ../../../PageObjects/PageObjects_InusredInfo.robot
Resource                        ../../../PageObjects/PageObjects_SubmissionInit.robot
Resource                        ../../../PageObjects/PageObjects_SubmissionInfo.robot
Resource                        ../../../PageObjects/PageObjects_CheckEndorsements.robot
Resource                        ../../../PageObjects/PageObjects_UnderwrittingAnalysis.robot
Resource                        ../../../PageObjects/Surplus_Lines/PageObjects_SL_UnderwriterAnalysis.robot
Resource                        ../../../PageObjects/PageObjects_CompareAndRateQuote.robot
Resource                        ../../../PageObjects/PageObjects_Quote.robot
Resource                        ../../../PageObjects/PageObjects_PolicyPage.robot
Resource                        ../../../PageObjects/PageObjects_PolicyPage.robot
Resource                        ../../../PageObjects/PageObjects_Quote.robot


Library                         RetryFailed                 global_retries=${retry_count}
Suite Setup                     Setup Browser
Suite Teardown                  CloseAllBrowsers

*** Test Cases ***

Validate change policy - Address change Excess
    #TCID=
    #Author=Shraddha
    [Documentation]             Functionality on Insured Info Page
    [Tags]                      Regression_Test_LGO_NONAdmitted                         Regression_Test
    Creating a new Account state NY
    Checking Next Button On New Submission For SL           LawyerGuard_SL
    VerifyText                  Underwriter Workbench
    Add Account name on Insured info page
    Enter Territory data on Insured Info Page SL            New York: Remainder of State
    Click on save button
    Add Attorney
    Click on NEXT:Submission Info
    Select broker Contact Source
    Entering Submission_Info Details for SL                 Excess                      12/06/2024
    ClickText                   NEXT:Underwriter Analysis >
    VerifyText                  Underwriting Analysis
    Sleep                       30s
    Add Area Of Practice for SL
    Sleep                       30s
    Add Details In Underwriter Analysis Tab for SL
    ClickText                   Qualify Submission
    Sleep                       30s
    Add Premium to Excess Fields
    Rate Quote
    Sleep                       30s
    Click On Bind For SL        Individual broker license
    VerifyText                  Policy Name
    Sleep                       20s
    Change Policy Functionality                             Address Change
    Select Change Address Input
    ClickText                   Quote
    ClickElement                //a[@data-label\='Quote']
    #VerifyText                 ${uniquename} 2             anchor=Quote Name
    Sleep                       20s
    RefreshPage
    ClickElement                //a[@data-label\='Submissions']
    ClickElement                //a[@data-label\='Quote']
    VerifyText                  ${uniquename} 2             anchor=Quote Name
    VerifyText                  Bound                       anchor=Status
    VerifyText                  Bound                       anchor=3

Extended Reported Period - Name Individual Primary
    #TCID=
    #Author=Shraddha
    [Documentation]             Functionality on Insured Info Page
    [Tags]                      Regression_Test_LGO_NONAdmitted                         Regression_Test
    Creating a new Account state NY
    Checking Next Button On New Submission For SL           LawyerGuard_SL
    VerifyText                  Underwriter Workbench
    Add Account name on Insured info page
    Enter Territory data on Insured Info Page SL            New York: Remainder of State
    Click on save button
    Add Attorney
    Click on NEXT:Submission Info
    Select broker Contact Source
    Entering Submission_Info Details for SL                 Primary                     12/06/2024
    ClickText                   NEXT:Underwriter Analysis >
    VerifyText                  Underwriting Analysis
    Add Area Of Practice
    Sleep                       30s
    Add Details In Underwriter Analysis Tab for SL
    Sleep                       30s
    ClickText                   Qualify Submission
    Sleep                       30s
    Click On Bind For SL        Individual broker license
    VerifyText                  Policy Name
    Change Policy Functionality                             Midterm Cancellation
    Select Change Midterm Cancellation Input
    Click Bind SL After Amendment
    Change Policy Functionality                             Extended Reporting Period
    Select Change ERP date Input
    Click Bind SL After Amendment
    Click Quote On Policy Page
    VerifyText                  Midterm Cancellation
    VerifyText                  Extended Reporting Period

Extended Reported Period - Name Individual Excess
    #TCID=
    #Author=Shraddha
    [Documentation]             Functionality on Insured Info Page
    [Tags]                      Regression_Test_LGO_NONAdmitted                         Regression_Test
    Creating a new Account state NY
    Checking Next Button On New Submission For SL           LawyerGuard_SL
    VerifyText                  Underwriter Workbench
    Add Account name on Insured info page
    Enter Territory data on Insured Info Page SL            New York: Remainder of State
    Click on save button
    Add Attorney
    Click on NEXT:Submission Info
    Select broker Contact Source
    Entering Submission_Info Details for SL                 Excess                      12/06/2024
    ClickText                   NEXT:Underwriter Analysis >
    VerifyText                  Underwriting Analysis
    Add Area Of Practice for SL
    Sleep                       30s
    Add Details In Underwriter Analysis Tab for SL
    Sleep                       30s
    ClickText                   Qualify Submission
    Sleep                       30s
    Add Premium to Excess Fields
    Rate Quote
    Sleep                       30s
    Click On Bind For SL        Individual broker license
    VerifyText                  Policy Name
    Change Policy Functionality                             Midterm Cancellation
    Select Change Midterm Cancellation Input
    Sleep                       10s
    Click Bind SL After Amendment
    Sleep                       10s
    Change Policy Functionality                             Extended Reporting Period
    Select Change ERP date Input
    Sleep                       10s
    Click Bind SL After Amendment
    Sleep                       10s
    Click Quote On Policy Page
    VerifyText                  Midterm Cancellation
    VerifyText                  Extended Reporting Period

Validate Cancel and Replace Primary
    #TCID=
    #Author=Shraddha
    [Documentation]             Functionality on Insured Info Page
    [Tags]                      Regression_Test_LGO_NONAdmitted                         Regression_Test
    Creating a new Account state NY
    Checking Next Button On New Submission For SL           LawyerGuard_SL
    VerifyText                  Underwriter Workbench
    Add Account name on Insured info page
    Enter Territory data on Insured Info Page SL            New York: Remainder of State
    Click on save button
    Add Attorney
    Click on NEXT:Submission Info
    Select broker Contact Source
    Entering Submission_Info Details for SL                 Primary                     12/06/2024
    ClickText                   NEXT:Underwriter Analysis >
    VerifyText                  Underwriting Analysis
    Add Area Of Practice
    Sleep                       10s
    Add Details In Underwriter Analysis Tab for SL
    Sleep                       10s
    ClickText                   Qualify Submission
    Sleep                       30s
    Click On Bind For SL        Individual broker license
    VerifyText                  Policy Name
    Change Policy Functionality                             Cancel & Replace
    Select Change Cancel & Replacement Input
    ClickElement                (//button[@title\='Rating'])[5]
    VerifyText                  Success                     anchor=Rating successfully!
    Sleep                       30s
    ClickElement                (//lightning-icon[@title\='Finalize Quote'])[3]         delay=3s
    Sleep                       30s
    ClickElement                //lightning-icon[@title\='Bind']
    ClickCheckbox               Agency broker license       off
    ClickCheckbox               Individual broker license                               on
    ClickElement                //span[text()\='Select Item 1']
    ClickElement                //button[@title\='Bind']
    VerifyText                  Success                     anchor=Bind quote successfully!
    Sleep                       10s
    Verify Coverage Cancel replace on policy quote

Validate Cancel and Replace Excess
    #TCID=
    #Author=Shraddha
    [Documentation]             Functionality on Insured Info Page
    [Tags]                      Regression_Test_LGO_NONAdmitted                         Regression_Test
    Creating a new Account state NY
    Checking Next Button On New Submission For SL           LawyerGuard_SL
    VerifyText                  Underwriter Workbench
    Add Account name on Insured info page
    Enter Territory data on Insured Info Page SL            New York: Remainder of State
    Click on save button
    Add Attorney
    Click on NEXT:Submission Info
    Select broker Contact Source
    Entering Submission_Info Details for SL                 Excess                      12/06/2024
    ClickText                   NEXT:Underwriter Analysis >
    VerifyText                  Underwriting Analysis
    Add Area Of Practice for SL
    Sleep                       30s
    Add Details In Underwriter Analysis Tab for SL
    Sleep                       30s
    ClickText                   Qualify Submission
    Sleep                       30s
    Add Premium to Excess Fields
    Rate Quote
    Sleep                       30s
    Click On Bind For SL        Individual broker license
    VerifyText                  Policy Name
    Change Policy Functionality                             Cancel & Replace
    Select Change Cancel & Replacement Input
    ClickElement                (//button[@title\='Rating'])[5]
    VerifyText                  Success                     anchor=Rating successfully!
    Sleep                       30s
    ClickElement                (//lightning-icon[@title\='Finalize Quote'])[3]         delay=3s
    Sleep                       30s
    ClickElement                //lightning-icon[@title\='Bind']
    ClickCheckbox               Agency broker license       off
    ClickCheckbox               Individual broker license                               on
    ClickElement                //span[text()\='Select Item 1']
    ClickElement                //button[@title\='Bind']
    VerifyText                  Success                     anchor=Bind quote successfully!
    Sleep                       10s
    Verify Coverage Cancel replace on policy quote
