*** Settings ***
Library                         QWeb
Library                         QForce
Library                         FakerLibrary
Library                         String
Library                         BuiltIn
Library                         DateTime
Library                         RetryFailed                 global_retries=${retry_count}
Resource                        ../../../resources/common.robot
Resource                        ../../../PageObjects/PageObjects_Account.robot
Resource                        ../../../PageObjects/PageObjects_HomePage.robot
Resource                        ../../../PageObjects/PageObjects_Submission.robot
Resource                        ../../../PageObjects/PageObjects_InusredInfo.robot
Resource                        ../../../PageObjects/PageObjects_SubmissionInit.robot
Resource                        ../../../PageObjects/PageObjects_SubmissionInfo.robot
Resource                        ../../../PageObjects/PageObjects_CheckEndorsements.robot
Resource                        ../../../PageObjects/PageObjects_UnderwrittingAnalysis.robot
Resource                        ../../../PageObjects/Surplus_Lines/PageObjects_SL_UnderwriterAnalysis.robot
Resource                        ../../../PageObjects/PageObjects_CompareAndRateQuote.robot
Resource                        ../../../PageObjects/PageObjects_Quote.robot
Resource                        ../../../PageObjects/PageObjects_PolicyPage.robot
Resource                        ../../../PageObjects/PageObjects_PolicyPage.robot
Resource                        ../../../PageObjects/PageObjects_Quote.robot


Library                         RetryFailed                 global_retries=${retry_count}
Suite Setup                     Setup Browser
Suite Teardown                  CloseAllBrowsers

*** Test Cases ***

Verify Change Policy Amendment on Primary SL
    #TCID=
    #Author=Shraddha
    [Documentation]             Functionality on Insured Info Page
    [Tags]                      Regression_Test_LGO_NONAdmitted                         Regression_Test

    Creating a new Account state NY
    Checking Next Button On New Submission For SL           LawyerGuard_SL
    VerifyText                  Underwriter Workbench
    Add Account name on Insured info page
    Enter Territory data on Insured Info Page SL            New York: Remainder of State
    Click on save button
    Add Attorney
    Click on NEXT:Submission Info
    Select broker Contact Source
    Entering Submission_Info Details for SL                 Primary                     12/06/2024
    ClickText                   NEXT:Underwriter Analysis >
    VerifyText                  Underwriting Analysis
    Add Area Of Practice
    Sleep                       20s
    Add Details In Underwriter Analysis Tab for SL
    Sleep                       20s
    ClickText                   Qualify Submission
    Sleep                       30s
    Click On Bind For SL        Individual broker license
    VerifyText                  Policy Name
    Change Policy Functionality                             Amendment
    Select Change Endorsement Input
    Input Data in Predecessor Firm On Underwriter Analysis
    ClickText                   Save
    Sleep                       5s
    ClickText                   Compare & Rate Quotes
    Click On Rate After Amendment
    Sleep                       10s
    Click Bind SL After Amendment
    Sleep                       20s



Verify Change Policy Amendment on Excess SL
    #TCID=
    #Author=Shraddha
    [Documentation]             Functionality on Insured Info Page
    [Tags]                      Regression_Test_LGO_NONAdmitted                         Regression_Test
    Creating a new Account state NY
    Checking Next Button On New Submission For SL           LawyerGuard_SL
    VerifyText                  Underwriter Workbench
    Add Account name on Insured info page
    Enter Territory data on Insured Info Page SL            New York: Remainder of State
    Click on save button
    Add Attorney
    Click on NEXT:Submission Info
    Select broker Contact Source
    Entering Submission_Info Details for SL                 Excess                      12/06/2024
    ClickText                   NEXT:Underwriter Analysis >
    VerifyText                  Underwriting Analysis
    Add Area Of Practice for SL
    Sleep                       20s
    Add Details In Underwriter Analysis Tab for SL
    Sleep                       20s
    ClickText                   Qualify Submission
    Sleep                       30s
    Add Premium to Excess Fields
    Rate Quote
    Sleep                       30s
    Click On Bind For SL        Individual broker license
    VerifyText                  Policy Name
    Change Policy Functionality                             Amendment
    Select Change Endorsement Input
    Input Data in Predecessor Firm On Underwriter Analysis
    ClickText                   Save
    Sleep                       5s
    ClickText                   Compare & Rate Quotes
    Click On Rate After Amendment
    Sleep                       10s
    Click Bind SL After Amendment
    Sleep                       20s


Validate Midterm Cancellation for Primary 
    #TCID=
    #Author=Shraddha
    [Documentation]             Functionality on Insured Info Page
    [Tags]                      Regression_Test_LGO_NONAdmitted                         Regression_Test
    Creating a new Account state NY
    Checking Next Button On New Submission For SL           LawyerGuard_SL
    VerifyText                  Underwriter Workbench
    Add Account name on Insured info page
    Enter Territory data on Insured Info Page SL            New York: Remainder of State
    Click on save button
    Add Attorney
    Click on NEXT:Submission Info
    Select broker Contact Source
    Entering Submission_Info Details for SL                 Primary                     12/06/2024
    ClickText                   NEXT:Underwriter Analysis >
    VerifyText                  Underwriting Analysis
    Sleep                       20s
    Add Area Of Practice
    Sleep                       20s
    Add Details In Underwriter Analysis Tab for SL
    Sleep                       20s
    ClickText                   Qualify Submission
    Sleep                       30s
    Click On Bind For SL        Individual broker license
    VerifyText                  Policy Name
    Change Policy Functionality                             Midterm Cancellation
    Select Change Midterm Cancellation Input
    Click Bind SL After Amendment
    Click Quote On Policy Page
    VerifyText                  Midterm Cancellation

Validate Midterm Cancellation for Excess  
    #TCID=
    #Author=Shraddha
    [Documentation]             Functionality on Insured Info Page
    [Tags]                      Regression_Test_LGO_NONAdmitted                         Regression_Test
    Creating a new Account state NY
    Checking Next Button On New Submission For SL           LawyerGuard_SL
    VerifyText                  Underwriter Workbench
    Add Account name on Insured info page
    Enter Territory data on Insured Info Page SL            New York: Remainder of State
    Click on save button
    Add Attorney
    Click on NEXT:Submission Info
    Select broker Contact Source
    Entering Submission_Info Details for SL                 Excess                      12/06/2024
    ClickText                   NEXT:Underwriter Analysis >
    VerifyText                  Underwriting Analysis
    Sleep                       20s
    Add Area Of Practice for SL
    Sleep                       20s
    Add Details In Underwriter Analysis Tab for SL
    Sleep                       20s
    ClickText                   Qualify Submission
    Sleep                       30s
    Add Premium to Excess Fields
    Rate Quote
    Sleep                       30s
    Click On Bind For SL        Individual broker license
    VerifyText                  Policy Name
    Change Policy Functionality                             Midterm Cancellation
    Select Change Midterm Cancellation Input
    Click Bind SL After Amendment
    Click Quote On Policy Page
    VerifyText                  Midterm Cancellation


Extension -Policy Change document generation, verify dates for Primary
    #TCID=
    #Author=Shraddha
    [Documentation]             Functionality on Insured Info Page
    [Tags]                      Regression_Test_LGO_NONAdmitted                         Regression_Test
    Creating a new Account state NY
    Checking Next Button On New Submission For SL           LawyerGuard_SL
    VerifyText                  Underwriter Workbench
    Add Account name on Insured info page
    Enter Territory data on Insured Info Page SL            New York: Remainder of State
    Click on save button
    Add Attorney
    Click on NEXT:Submission Info
    Select broker Contact Source
    Entering Submission_Info Details for SL                 Primary                     12/06/2024
    ClickText                   NEXT:Underwriter Analysis >
    VerifyText                  Underwriting Analysis
    Sleep                       20s
    Add Area Of Practice
    Sleep                       20s
    Add Details In Underwriter Analysis Tab for SL
    Sleep                       20s
    ClickText                   Qualify Submission
    Sleep                       30s
    Click On Bind For SL        Individual broker license
    VerifyText                  Policy Name
    Change Policy Functionality                             Extension
    Select Change Extension Input
    Click Bind SL After Amendment
    Click Quote On Policy Page
    VerifyText                  Extension

Extension -Policy Change document generation, verify dates for Excess
    #TCID=
    #Author=Shraddha
    [Documentation]             Functionality on Insured Info Page
    [Tags]                      Regression_Test_LGO_NONAdmitted                         Regression_Test
    Creating a new Account state NY
    Checking Next Button On New Submission For SL           LawyerGuard_SL
    VerifyText                  Underwriter Workbench
    Add Account name on Insured info page
    Enter Territory data on Insured Info Page SL            New York: Remainder of State
    Click on save button
    Add Attorney
    Click on NEXT:Submission Info
    Select broker Contact Source
    Entering Submission_Info Details for SL                 Excess                      12/06/2024
    ClickText                   NEXT:Underwriter Analysis >
    VerifyText                  Underwriting Analysis
    Sleep                       20s
    Add Area Of Practice for SL
    Sleep                       20s
    Add Details In Underwriter Analysis Tab for SL
    Sleep                       20s
    ClickText                   Qualify Submission
    Sleep                       30s
    Add Premium to Excess Fields
    Rate Quote
    Sleep                       30s
    Click On Bind For SL        Individual broker license
    VerifyText                  Policy Name
    Change Policy Functionality                             Extension
    Select Change Extension Input
    Click Bind SL After Amendment
    Click Quote On Policy Page
    VerifyText                  Extension