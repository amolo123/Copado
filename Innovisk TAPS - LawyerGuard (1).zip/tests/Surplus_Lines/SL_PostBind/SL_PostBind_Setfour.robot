*** Settings ***
Library                         QWeb
Library                         QForce
Library                         FakerLibrary
Library                         String
Library                         BuiltIn
Library                         DateTime
Library                         RetryFailed                 global_retries=${retry_count}
Resource                        ../../../resources/common.robot
Resource                        ../../../PageObjects/PageObjects_Account.robot
Resource                        ../../../PageObjects/PageObjects_HomePage.robot
Resource                        ../../../PageObjects/PageObjects_Submission.robot
Resource                        ../../../PageObjects/PageObjects_InusredInfo.robot
Resource                        ../../../PageObjects/PageObjects_SubmissionInit.robot
Resource                        ../../../PageObjects/PageObjects_SubmissionInfo.robot
Resource                        ../../../PageObjects/PageObjects_CheckEndorsements.robot
Resource                        ../../../PageObjects/PageObjects_UnderwrittingAnalysis.robot
Resource                        ../../../PageObjects/Surplus_Lines/PageObjects_SL_UnderwriterAnalysis.robot
Resource                        ../../../PageObjects/PageObjects_CompareAndRateQuote.robot
Resource                        ../../../PageObjects/PageObjects_Quote.robot
Resource                        ../../../PageObjects/PageObjects_PolicyPage.robot
Resource                        ../../../PageObjects/PageObjects_PolicyPage.robot
Resource                        ../../../PageObjects/PageObjects_Quote.robot


Library                         RetryFailed                 global_retries=${retry_count}
Suite Setup                     Setup Browser
Suite Teardown                  CloseAllBrowsers

*** Test Cases ***

Extended Reporting Period - Firm Primary
    #TCID=
    #Author=Shraddha
    [Documentation]             Functionality on Insured Info Page
    [Tags]                      Regression_Test_LGO_NONAdmitted                         Regression_Test
    Creating a new Account state NY
    Checking Next Button On New Submission For SL           LawyerGuard_SL
    VerifyText                  Underwriter Workbench
    Add Account name on Insured info page
    Enter Territory data on Insured Info Page SL            New York: Remainder of State
    Click on save button
    Add Attorney
    Click on NEXT:Submission Info
    Select broker Contact Source
    Entering Submission_Info Details for SL                 Primary                     12/06/2024
    ClickText                   NEXT:Underwriter Analysis >
    VerifyText                  Underwriting Analysis
    Add Area Of Practice
    Add Details In Underwriter Analysis Tab for SL
    ClickText                   Qualify Submission
    Sleep                       30s
    Click On Bind For SL        Individual broker license
    VerifyText                  Policy Name
    Change Policy Functionality                             Midterm Cancellation
    Select Change Midterm Cancellation Input
    Click Bind SL After Amendment
    Change Policy Functionality                             Extended Reporting Period
    Select Change ERP date Input
    Click Bind SL After Amendment

Extended Reporting Period - Name Individual Excess
    #TCID=
    #Author=Shraddha
    [Documentation]             Functionality on Insured Info Page
    [Tags]                      Regression_Test_LGO_NONAdmitted                         Regression_Test
    Creating a new Account state NY
    Checking Next Button On New Submission For SL           LawyerGuard_SL
    VerifyText                  Underwriter Workbench
    Add Account name on Insured info page
    Enter Territory data on Insured Info Page SL            New York: Remainder of State
    Click on save button
    Add Attorney
    Click on NEXT:Submission Info
    Select broker Contact Source
    Entering Submission_Info Details for SL                 Excess                      12/06/2024
    ClickText                   NEXT:Underwriter Analysis >
    VerifyText                  Underwriting Analysis
    Add Area Of Practice for SL
    Add Details In Underwriter Analysis Tab for SL
    ClickText                   Qualify Submission
    Sleep                       30s
    Add Premium to Excess Fields
    Rate Quote
    Sleep                       30s
    Click On Bind For SL        Individual broker license
    VerifyText                  Policy Name
    Change Policy Functionality                             Midterm Cancellation
    Select Change Midterm Cancellation Input
    Click Bind SL After Amendment
    Change Policy Functionality                             Extended Reporting Period
    Select Change ERP date Input
    Click Bind SL After Amendment


Create Renewal flow for Primary
    #TCID=
    #Author=Shraddha
    [Documentation]             Functionality on Insured Info Page
    [Tags]                      Regression_Test_LGO_NONAdmitted                         Regression_Test
    Creating an account with a state California
    Checking Next Button On New Submission For SL           LawyerGuard_SL
    VerifyText                  Underwriter Workbench
    Add Account name on Insured info page
    Enter Territory data on Insured Info Page SL            New York: Remainder of State
    Click on save button
    Add Attorney
    Click on NEXT:Submission Info
    Select broker Contact Source
    Entering Submission_Info Details for SL                 Primary                     12/06/2024
    ClickText                   NEXT:Underwriter Analysis >
    VerifyText                  Underwriting Analysis
    Add Area Of Practice
    Add Details In Underwriter Analysis Tab for SL
    ClickText                   Qualify Submission
    Sleep                       30s
    Click On Bind For SL        Individual broker license
    VerifyText                  Policy Name
    Sleep                       10s
    Create a Renewal Flow
    Sleep                       10s
    Click On Bind For SL        Individual broker license
    VerifyText                  Policy Name
    ClickElement                //li[@data-label\='Quote']
    VerifyText                  Renewal

Create Renewal flow for Excess
    #TCID=
    #Author=Shraddha
    [Documentation]             Functionality on Insured Info Page
    [Tags]                      Regression_Test_LGO_NONAdmitted                         Regression_Test
    Creating a new Account state NY
    Checking Next Button On New Submission For SL           LawyerGuard_SL
    VerifyText                  Underwriter Workbench
    Add Account name on Insured info page
    Enter Territory data on Insured Info Page SL            New York: Remainder of State
    Click on save button
    Add Attorney
    Click on NEXT:Submission Info
    Select broker Contact Source
    Entering Submission_Info Details for SL                 Excess                      12/06/2024
    ClickText                   NEXT:Underwriter Analysis >
    VerifyText                  Underwriting Analysis
    Add Area Of Practice for SL
    Add Details In Underwriter Analysis Tab for SL
    ClickText                   Qualify Submission
    Sleep                       30s
    Add Premium to Excess Fields
    Rate Quote
    Sleep                       30s
    Click On Bind For SL        Individual broker license
    VerifyText                  Policy Name
    Sleep                       10s
    Create a Renewal Flow
    Sleep                       10s
    Click On Bind For SL        Individual broker license
    VerifyText                  Policy Name
    ClickElement                //li[@data-label\='Quote']
    VerifyText                  Renewal


Extended Reported Period - Firm Primary
    #TCID=
    #Author=Shraddha
    [Documentation]             Functionality on Insured Info Page
    [Tags]                      Regression_Test_LGO_NONAdmitted                         Regression_Test
    Creating a new Account state NY
    Checking Next Button On New Submission For SL           LawyerGuard_SL
    VerifyText                  Underwriter Workbench
    Add Account name on Insured info page
    Enter Territory data on Insured Info Page SL            New York: Remainder of State
    Click on save button
    Add Attorney
    Click on NEXT:Submission Info
    Select broker Contact Source
    Entering Submission_Info Details for SL                 Primary                     12/06/2024
    ClickText                   NEXT:Underwriter Analysis >
    VerifyText                  Underwriting Analysis
    Add Area Of Practice
    Add Details In Underwriter Analysis Tab for SL
    ClickText                   Qualify Submission
    Sleep                       30s
    Click On Bind For SL        Individual broker license
    VerifyText                  Policy Name
    Change Policy Functionality                             Midterm Cancellation
    Select Change Midterm Cancellation Input
    Click Bind SL After Amendment
    Change Policy Functionality                             Extended Reporting Period
    #ClickElement               //div[@class\="slds-form-element__control slds-grow"]
    #DropDown                   5018:0                      Firm
    DropDown                    ERP Type                    Firm
    ClickText                   Endorsement Effective Date                              timeout=55s
    ${cur_data}=                Get Current Date            result_format=%b %-d, %Y
    ${comp_effective_date}=     Get Current Date            increment=5 day             result_format=%b %-d, %Y
    Log To Console              ${comp_effective_date}
    ${subdate1}=                Get Substring               ${comp_effective_date}      4                           -6
    Log To Console              ${subdate1}
    ClickElement                //a[@title\='Go to next month']
    ClickElement                //span[text()\='${subdate1}']
    ClickText                   Confirm                     anchor=Cancel
    Sleep                       20s
    Click Bind SL After Amendment
    Click Quote On Policy Page
    VerifyText                  Midterm Cancellation
    VerifyText                  Extended Reporting Period


Verify adding multiple endorsements and creating renewal Primary
    #TCID=
    #Author=Shraddha
    [Documentation]             Functionality on Insured Info Page
    [Tags]                      Regression_Test_LGO_NONAdmitted                         Regression_Test
    Creating a new Account state NY
    Checking Next Button On New Submission For SL           LawyerGuard_SL
    VerifyText                  Underwriter Workbench
    Add Account name on Insured info page
    Enter Territory data on Insured Info Page SL            New York: Remainder of State
    Click on save button
    Add Attorney
    Click on NEXT:Submission Info
    Select broker Contact Source
    Entering Submission_Info Details for SL                 Primary                     12/06/2024
    ClickText                   NEXT:Underwriter Analysis >
    VerifyText                  Underwriting Analysis
    Add Area Of Practice
    Add Details In Underwriter Analysis Tab for SL
    ClickText                   Qualify Submission
    Sleep                       30s
    Click On Bind For SL        Individual broker license
    VerifyText                  Policy Name
    Sleep                       10s
    Change Policy Functionality                             Amendment
    Select Change Endorsement Input
    Add Endorsement for SL      Additional Named Insured
    Click On Rate After Amendment
    Sleep                       10s
    Click Bind SL After Amendment
    Change Policy Functionality                             Amendment
    Select Change Endorsement Input
    Add Endorsement for Primary                             Additional Defense Coverage Endorsement
    Click Rate after adding endorsement
    Click Bind SL After Amendment
    Create a Renewal Flow
    Get Default percentage on renewal and Verify matching

Verify adding multiple endorsements and creating renewal Excess
    #TCID=
    #Author=Shraddha
    [Documentation]             Functionality on Insured Info Page
    [Tags]                      Regression_Test_LGO_NONAdmitted                         Regression_Test
    Creating a new Account state NY
    Checking Next Button On New Submission For SL           LawyerGuard_SL
    VerifyText                  Underwriter Workbench
    Add Account name on Insured info page
    Enter Territory data on Insured Info Page SL            New York: Remainder of State
    Click on save button
    Add Attorney
    Click on NEXT:Submission Info
    Select broker Contact Source
    Entering Submission_Info Details for SL                 Excess                      12/06/2024
    ClickText                   NEXT:Underwriter Analysis >
    VerifyText                  Underwriting Analysis
    Add Area Of Practice for SL
    Add Details In Underwriter Analysis Tab for SL
    ClickText                   Qualify Submission
    Sleep                       30s
    Add Premium to Excess Fields
    Rate Quote
    Sleep                       30s
    Click On Bind For SL        Individual broker license
    VerifyText                  Policy Name
    Sleep                       10s
    Change Policy Functionality                             Amendment
    Select Change Endorsement Input
    Add Endorsement for Primary                             Prior Acts Exclusion
    Click On Rate After Amendment
    Click Bind SL After Amendment
    Change Policy Functionality                             Amendment
    Select Change Endorsement Input
    Add Endorsement for Primary                             Specific Entity Exclusion
    Click Rate after adding endorsement
    Click Bind SL After Amendment
    Create a Renewal Flow
    Get Default percentage on renewal and Verify matching
