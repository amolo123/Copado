*** Settings ***
Library                         QWeb
Library                         QForce
Library                         FakerLibrary
Library                         String
Library                         BuiltIn
Library                         DateTime
Library                         RetryFailed                 global_retries=${retry_count}
Resource                        ../../../resources/common.robot
Resource                        ../../../PageObjects/PageObjects_Account.robot
Resource                        ../../../PageObjects/PageObjects_HomePage.robot
Resource                        ../../../PageObjects/PageObjects_Submission.robot
Resource                        ../../../PageObjects/PageObjects_InusredInfo.robot
Resource                        ../../../PageObjects/PageObjects_SubmissionInit.robot
Resource                        ../../../PageObjects/PageObjects_SubmissionInfo.robot
Resource                        ../../../PageObjects/PageObjects_CheckEndorsements.robot
Resource                        ../../../PageObjects/PageObjects_UnderwrittingAnalysis.robot
Resource                        ../../../PageObjects/Surplus_Lines/PageObjects_SL_UnderwriterAnalysis.robot
Resource                        ../../../PageObjects/PageObjects_CompareAndRateQuote.robot
Resource                        ../../../PageObjects/PageObjects_Quote.robot
Resource                        ../../../PageObjects/PageObjects_PolicyPage.robot
Resource                        ../../../PageObjects/PageObjects_PolicyPage.robot
Resource                        ../../../PageObjects/PageObjects_Quote.robot


Library                         RetryFailed                 global_retries=${retry_count}
Suite Setup                     Setup Browser
Suite Teardown                  CloseAllBrowsers

*** Test Cases ***

Validate BOR For Primary
    #TCID=
    #Author=Shraddha
    [Documentation]             Functionality on Insured Info Page
    [Tags]                      Regression_Test_LGO_NONAdmitted                         Regression_Test
    Creating a new Account state NY
    Checking Next Button On New Submission For SL           LawyerGuard_SL
    VerifyText                  Underwriter Workbench
    Add Account name on Insured info page
    Enter Territory data on Insured Info Page SL            New York: Remainder of State
    Click on save button
    Add Attorney
    Click on NEXT:Submission Info
    Select broker Contact Source
    Entering Submission_Info Details for SL                 Primary                     12/06/2024
    ClickText                   NEXT:Underwriter Analysis >
    VerifyText                  Underwriting Analysis
    Add Area Of Practice
    Sleep                       20s
    Add Details In Underwriter Analysis Tab for SL
    Sleep                       10s
    ClickText                   Qualify Submission
    Sleep                       30s
    Click On Bind For SL        Individual broker license
    VerifyText                  Policy Name
    Change Policy Functionality                             Broker of Record (BOR)
    Select BOR Input
    ClickText                   Quote
    ClickElement                //a[@data-label\='Quote']
    #VerifyText                 ${uniquename} 2             anchor=Quote Name
    Sleep                       20s
    RefreshPage
    ClickElement                //a[@data-label\='Submissions']
    ClickElement                //a[@data-label\='Quote']
    VerifyText                  ${uniquename} 2             anchor=Quote Name
    VerifyText                  Bound                       anchor=Status
    VerifyText                  Bound

Validate BOR For Excess
    #TCID=
    #Author=Shraddha
    [Documentation]             Functionality on Insured Info Page
    [Tags]                      Regression_Test_LGO_NONAdmitted                         Regression_Test
    Creating a new Account state NY
    Checking Next Button On New Submission For SL           LawyerGuard_SL
    VerifyText                  Underwriter Workbench
    Add Account name on Insured info page
    Enter Territory data on Insured Info Page SL            New York: Remainder of State
    Click on save button
    Add Attorney
    Click on NEXT:Submission Info
    Select broker Contact Source
    Entering Submission_Info Details for SL                 Excess                      12/06/2024
    ClickText                   NEXT:Underwriter Analysis >
    VerifyText                  Underwriting Analysis
    Add Area Of Practice for SL
    Sleep                       20s
    Add Details In Underwriter Analysis Tab for SL
    Sleep                       20s
    ClickText                   Qualify Submission
    Sleep                       30s
    Add Premium to Excess Fields
    Rate Quote
    Sleep                       30s
    Click On Bind For SL        Individual broker license
    VerifyText                  Policy Name
    Change Policy Functionality                             Broker of Record (BOR)
    Select BOR Input
    ClickText                   Quote
    ClickElement                //a[@data-label\='Quote']
    #VerifyText                 ${uniquename} 2             anchor=Quote Name
    Sleep                       20s
    RefreshPage
    ClickElement                //a[@data-label\='Submissions']
    ClickElement                //a[@data-label\='Quote']
    VerifyText                  ${uniquename} 2             anchor=Quote Name
    VerifyText                  Bound                       anchor=Status
    VerifyText                  Bound

Validate Name Change for Primary
    #TCID=
    #Author=Shraddha
    [Documentation]             Functionality on Insured Info Page
    [Tags]                      Regression_Test_LGO_NONAdmitted                         Regression_Test
    Creating a new Account state NY
    Checking Next Button On New Submission For SL           LawyerGuard_SL
    VerifyText                  Underwriter Workbench
    Add Account name on Insured info page
    Enter Territory data on Insured Info Page SL            New York: Remainder of State
    Click on save button
    Add Attorney
    Click on NEXT:Submission Info
    Select broker Contact Source
    Entering Submission_Info Details for SL                 Primary                     12/06/2024
    ClickText                   NEXT:Underwriter Analysis >
    VerifyText                  Underwriting Analysis
    Add Area Of Practice
    Sleep                       20s
    Add Details In Underwriter Analysis Tab for SL
    Sleep                       20s
    ClickText                   Qualify Submission
    Sleep                       30s
    Click On Bind For SL        Individual broker license
    VerifyText                  Policy Name
    Sleep                       20s
    Change Policy Functionality                             Name Change
    Select Change Name Input
    #Click Quote On Policy Page
    #VerifyText                 Name Change
    #VerifyText                 ${uniquename} 2
    #RefreshPage
    ClickText                   Quote
    ClickElement                //a[@data-label\='Quote']
    #VerifyText                 ${uniquename} 2             anchor=Quote Name
    Sleep                       20s
    RefreshPage
    ClickElement                //a[@data-label\='Submissions']
    ClickElement                //a[@data-label\='Quote']
    VerifyText                  ${uniquename} 2             anchor=Quote Name
    VerifyText                  Bound                       anchor=Status
    VerifyText                  Bound                       anchor=3

Validate Name Change for Excess
    #TCID=
    #Author=Shraddha
    [Documentation]             Functionality on Insured Info Page
    [Tags]                      Regression_Test_LGO_NONAdmitted                         Regression_Test
    Creating a new Account state NY
    Checking Next Button On New Submission For SL           LawyerGuard_SL
    VerifyText                  Underwriter Workbench
    Add Account name on Insured info page
    Enter Territory data on Insured Info Page SL            New York: Remainder of State
    Click on save button
    Add Attorney
    Click on NEXT:Submission Info
    Select broker Contact Source
    Entering Submission_Info Details for SL                 Excess                      12/06/2024
    ClickText                   NEXT:Underwriter Analysis >
    VerifyText                  Underwriting Analysis
    Add Area Of Practice for SL
    Sleep                       20s
    Add Details In Underwriter Analysis Tab for SL
    Sleep                       20s
    ClickText                   Qualify Submission
    Sleep                       30s
    Add Premium to Excess Fields
    Rate Quote
    Sleep                       30s
    Click On Bind For SL        Individual broker license
    VerifyText                  Policy Name
    Sleep                       20s
    Change Policy Functionality                             Name Change
    Select Change Name Input
    #Click Quote On Policy Page
    #VerifyText                 Name Change
    #VerifyText                 ${uniquename} 2
    #RefreshPage
    ClickText                   Quote
    ClickElement                //a[@data-label\='Quote']
    #VerifyText                 ${uniquename} 2             anchor=Quote Name
    Sleep                       20s
    RefreshPage
    ClickElement                //a[@data-label\='Submissions']
    ClickElement                //a[@data-label\='Quote']
    VerifyText                  ${uniquename} 2             anchor=Quote Name
    VerifyText                  Bound                       anchor=Status
    VerifyText                  Bound                       anchor=3

Validate change policy - Address change Primary
    #TCID=
    #Author=Shraddha
    [Documentation]             Functionality on Insured Info Page
    [Tags]                      Regression_Test_LGO_NONAdmitted                         Regression_Test
    Creating a new Account state NY
    Checking Next Button On New Submission For SL           LawyerGuard_SL
    VerifyText                  Underwriter Workbench
    Add Account name on Insured info page
    Enter Territory data on Insured Info Page SL            New York: Remainder of State
    Click on save button
    Add Attorney
    Click on NEXT:Submission Info
    Select broker Contact Source
    Entering Submission_Info Details for SL                 Primary                     12/06/2024
    ClickText                   NEXT:Underwriter Analysis >
    VerifyText                  Underwriting Analysis
    Add Area Of Practice
    Sleep                       20s
    Add Details In Underwriter Analysis Tab for SL
    Sleep                       20s
    ClickText                   Qualify Submission
    Sleep                       30s
    Click On Bind For SL        Individual broker license
    VerifyText                  Policy Name
    Change Policy Functionality                             Address Change
    Select Change Address Input
    ClickText                   Quote
    ClickElement                //a[@data-label\='Quote']
    #VerifyText                 ${uniquename} 2             anchor=Quote Name
    Sleep                       20s
    RefreshPage
    ClickElement                //a[@data-label\='Submissions']
    ClickElement                //a[@data-label\='Quote']
    VerifyText                  ${uniquename} 2             anchor=Quote Name
    VerifyText                  Bound                       anchor=Status
    VerifyText                  Bound                       anchor=3
