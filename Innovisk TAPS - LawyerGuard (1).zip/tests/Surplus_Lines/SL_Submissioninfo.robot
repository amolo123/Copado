*** Settings ***
Resource                        ../../resources/common.robot
Resource                        ../../PageObjects/PageObjects_Account.robot
Resource                        ../../PageObjects/PageObjects_HomePage.robot
Resource                        ../../PageObjects/PageObjects_Submission.robot
Resource                        ../../PageObjects/PageObjects_InusredInfo.robot
Resource                        ../../PageObjects/PageObjects_SubmissionInit.robot
Resource                        ../../PageObjects/PageObjects_SubmissionInfo.robot
Library                         RetryFailed                 global_retries=${retry_count}
Suite Setup                     Setup Browser
Suite Teardown                  CloseAllBrowsers


*** Test Cases ***

Verify the functionality of Submission Info tab for primary
    # Author = Rugveda Nikam
    #TC=108501
    [Documentation]             Entering                    Details in Insured Info Tab
    [Tags]                      Smoke_Test_LGO_NONAdmitted                              Smoke_Test
    Creating a new Account
    Checking Next Button On New Submission For SL           LawyerGuard_SL
    #Validate LaweyrGuard New submission Fields SL
    VerifyText                  Underwriter Workbench
    Add Account name on Insured info page
    # VerifyInputValue          Contact Record Type         Attorney                    timeout=2s
    Click on save button
    Add Attorney
    Click on NEXT:Submission Info
    Validate Submission Init on Submission info page SL     Primary
    Select broker Contact Source
    Validate SubmissionInfo New submission Fields for primary
    Add Details In SubmissionInfo Page for primary
    Verify SubmissionInfo Page Input Details for primary
    Verify Decline Close and Reopen
    ClickText                   NEXT:Underwriter Analysis >

Verify the functionality of Submission Info tab for Excess
    # Author = Rugveda Nikam
    #TC=108520
    [Documentation]             Entering                    Details in Insured Info Tab
    [Tags]                      Smoke_Test_LGO_NONAdmitted                              Smoke_Test

    Creating an account with a state California
    Checking Next Button On New Submission For SL           LawyerGuard_SL
    #Validate LaweyrGuard New submission Fields SL
    VerifyText                  Underwriter Workbench
    Add Account name on Insured info page
    Enter Territory data on Insured Info Page SL            California: Remainder of State
    # VerifyInputValue          Contact Record Type         Attorney                    timeout=2s
    Click on save button
    Add Attorney
    Click on NEXT:Submission Info
    Validate Submission Init on Submission info page SL     Excess
    Select broker Contact Source
    Validate SubmissionInfo New submission Fields for Excess
    Add Details In SubmissionInfo Page for Excess
    Verify SubmissionInfo Page Input Details for Excess
    Verify Decline Close and Reopen
    ClickText                   NEXT:Underwriter Analysis >