*** Settings ***
Library                         QWeb
Library                         QForce
#Library                        QVision
Library                         FakerLibrary
Library                         String
Library                         BuiltIn
Library                         DateTime
Resource                        ../../resources/common.robot
Resource                        ../../PageObjects/PageObjects_Account.robot
Resource                        ../../PageObjects/PageObjects_HomePage.robot
Resource                        ../../PageObjects/PageObjects_Submission.robot
Resource                        ../../PageObjects/PageObjects_InusredInfo.robot

Library                         RetryFailed                 global_retries=${retry_count}
Suite Setup                     Setup Browser
Suite Teardown                  CloseAllBrowsers


*** Test Cases ***


Verify Save Button and Next Submission Info Functionality on Insured Info Page For Primary and Excess
    [Documentation]             Verify Save Button and Next Submission Info Functionality on Insured Info Page For Primary and Excess
    [Tags]                      Smoke_Test_LGO_NONAdmitted                              Smoke_Test


    # Author = Shraddha T Patil
    #TC=107969,107970
    Creating a new Account
    Checking Next Button On New Submission For SL           LawyerGuard_SL
    VerifyText                  Underwriter Workbench
    Validate field on Insured info SL
    Validate Underwriting Comments on Insured info page SL
    Validate Territory data on Insured Info Page SL         New York: Remainder of State
    Add Account name on Insured info page
    Click on save button
    Add Attorney SL             Shraddha                    Patil
    Add Attorney SL             Shraddha                    Kulkarni
    Add Attorney SL             Rugveda                     Nikam
    Add Attorney SL             Rugveda                     Tiwaskar
    Add Attorney SL             Pinki                       Lubana
    #Validate Billing address on Insured info page
    Click on NEXT:Submission Info


Verify Edit and Delete Functionality on the Attorney section for Primary and Excess

    [Documentation]             Verify Edit and Delete Functionality on the Attorney section for Primary and Excess
    [Tags]                      Smoke_Test_LGO_NONAdmitted                              Smoke_Test

    # Author = Shraddha T Patil
    #TC=107971
    Creating a new Account
    Checking Next Button On New Submission For SL           LawyerGuard_SL
    VerifyText                  Underwriter Workbench
    Validate field on Insured info SL
    Validate Underwriting Comments on Insured info page SL
    Validate Territory data on Insured Info Page SL         New York: Remainder of State
    Add Account name on Insured info page
    Click on save button
    Edit and Delete Attroney Details

Verify Cancel Button Functionality on Attorney Pop Up For Primary and Excess
    [Documentation]             Verify Cancel Button Functionality on Attorney Pop Up For Primary and Excess
    [Tags]                      Smoke_Test_LGO_NONAdmitted                              Smoke_Test

    # Author = Shraddha T Patil
    #TC=107974
    Creating a new Account
    Checking Next Button On New Submission For SL           LawyerGuard_SL
    VerifyText                  Underwriter Workbench
    Validate field on Insured info SL
    Validate Underwriting Comments on Insured info page SL
    Validate Territory data on Insured Info Page SL         New York: Remainder of State
    Add Account name on Insured info page
    Click on save button
    ClickText                   New                         partial_match=False
    Validate component of Attroneys Page
    ClickText                   Cancel                      anchor=Save & New



Verify if Territory is required message is shown if territory is blank when New York address is entered
    [Documentation]             Verify if Territory is required message is shown
    [Tags]                      Smoke_Test_LGO_NONAdmitted                              Smoke_Test

    # Author = Shraddha T Patil
    #TC=108412
    #Creating an account with a state NY
    Creating a new Account state NY
    Checking Next Button On New Submission For SL           LawyerGuard_SL
    VerifyText                  Underwriter Workbench
    Validate field on Insured info SL
    Validate Underwriting Comments on Insured info page SL
    #Validate Territory data on Insured Info Page SL        New York: Remainder of State
    Add Account name on Insured info page
    Click on save button SL
