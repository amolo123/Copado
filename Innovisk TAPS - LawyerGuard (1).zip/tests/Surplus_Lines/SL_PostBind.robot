# *** Settings ***
# Library                         QWeb
# Library                         QForce
# Library                         FakerLibrary
# Library                         String
# Library                         BuiltIn
# Library                         DateTime
# Library                         RetryFailed                 global_retries=${retry_count}
# Resource                        ../../resources/common.robot
# Resource                        ../../PageObjects/PageObjects_Account.robot
# Resource                        ../../PageObjects/PageObjects_HomePage.robot
# Resource                        ../../PageObjects/PageObjects_Submission.robot
# Resource                        ../../PageObjects/PageObjects_InusredInfo.robot
# Resource                        ../../PageObjects/PageObjects_SubmissionInit.robot
# Resource                        ../../PageObjects/PageObjects_SubmissionInfo.robot
# Resource                        ../../PageObjects/PageObjects_CheckEndorsements.robot
# Resource                        ../../PageObjects/PageObjects_UnderwrittingAnalysis.robot
# Resource                        ../../PageObjects/Surplus_Lines/PageObjects_SL_UnderwriterAnalysis.robot
# Resource                        ../../PageObjects/PageObjects_CompareAndRateQuote.robot
# Resource                        ../../PageObjects/PageObjects_Quote.robot
# Resource                        ../../PageObjects/PageObjects_PolicyPage.robot
# Resource                        ../../PageObjects/PageObjects_PolicyPage.robot
# Resource                        ../../PageObjects/PageObjects_Quote.robot


# Library                         RetryFailed                 global_retries=${retry_count}
# Suite Setup                     Setup Browser
# Suite Teardown                  CloseAllBrowsers

# *** Test Cases ***

# Verify Change Policy Amendment on Primary SL
#     #TCID=
#     #Author=Shraddha
#     [Documentation]             Functionality on Insured Info Page
#     [Tags]                      SL

#     Creating a new Account state NY
#     Checking Next Button On New Submission For SL           LawyerGuard_SL
#     VerifyText                  Underwriter Workbench
#     Add Account name on Insured info page
#     Enter Territory data on Insured Info Page SL            New York: Remainder of State
#     Click on save button
#     Add Attorney
#     Click on NEXT:Submission Info
#     Select broker Contact Source
#     Entering Submission_Info Details for SL                 Primary                     12/06/2024
#     ClickText                   NEXT:Underwriter Analysis >
#     VerifyText                  Underwriting Analysis
#     Add Area Of Practice
#     Add Details In Underwriter Analysis Tab for SL
#     ClickText                   Qualify Submission
#     Sleep                       30s
#     Click On Bind For SL        Individual broker license
#     VerifyText                  Policy Name
#     Change Policy Functionality                             Amendment
#     Select Change Endorsement Input
#     Input Data in Predecessor Firm On Underwriter Analysis
#     ClickText                   Save
#     Sleep                       5s
#     ClickText                   Compare & Rate Quotes
#     Click On Rate After Amendment
#     Click Bind SL After Amendment
#     Sleep                       20s



# #Verify Change Policy Amendment on Excess SL
#     #TCID=
#     #Author=Shraddha
#     [Documentation]             Functionality on Insured Info Page
#     [Tags]                      SL
#     #Creating a new Account state NY
#     #Checking Next Button On New Submission For SL           LawyerGuard_SL
#     #VerifyText                  Underwriter Workbench
#     #Add Account name on Insured info page
#     #Enter Territory data on Insured Info Page SL            New York: Remainder of State
#     #Click on save button
#     #Add Attorney
#     #Click on NEXT:Submission Info
#     #Select broker Contact Source
#     #Entering Submission_Info Details for SL                 Excess                      12/06/2024
#     #ClickText                   NEXT:Underwriter Analysis >
#     #VerifyText                  Underwriting Analysis
#     #Add Area Of Practice for SL
#     #Add Details In Underwriter Analysis Tab for SL
#     #ClickText                   Qualify Submission
#     #Sleep                       30s
#     #Add Premium to Excess Fields
#     #Rate Quote
#     #Sleep                       30s
#     #Click On Bind For SL        Individual broker license
#     #VerifyText                  Policy Name
#     #Change Policy Functionality                             Amendment
#     #Select Change Endorsement Input
#     #Input Data in Predecessor Firm On Underwriter Analysis
#     #ClickText                   Save
#     #Sleep                       5s
#     #ClickText                   Compare & Rate Quotes
#     #Click On Rate After Amendment
#     #Click Bind SL After Amendment
#     #Sleep                       20s


# #Validate Midterm Cancellation for Primary 
#     #TCID=
#     #Author=Shraddha
#     [Documentation]             Functionality on Insured Info Page
#     [Tags]                      SL
#     Creating a new Account state NY
#     Checking Next Button On New Submission For SL           LawyerGuard_SL
#     VerifyText                  Underwriter Workbench
#     Add Account name on Insured info page
#     Enter Territory data on Insured Info Page SL            New York: Remainder of State
#     Click on save button
#     Add Attorney
#     Click on NEXT:Submission Info
#     Select broker Contact Source
#     Entering Submission_Info Details for SL                 Primary                     12/06/2024
#     ClickText                   NEXT:Underwriter Analysis >
#     VerifyText                  Underwriting Analysis
#     Add Area Of Practice
#     Add Details In Underwriter Analysis Tab for SL
#     ClickText                   Qualify Submission
#     Sleep                       30s
#     Click On Bind For SL        Individual broker license
#     VerifyText                  Policy Name
#     Change Policy Functionality                             Midterm Cancellation
#     Select Change Midterm Cancellation Input
#     Click Bind SL After Amendment
#     Click Quote On Policy Page
#     VerifyText                  Midterm Cancellation

# #Validate Midterm Cancellation for Excess  
#     #TCID=
#     #Author=Shraddha
#     [Documentation]             Functionality on Insured Info Page
#     [Tags]                      SL
#     Creating a new Account state NY
#     Checking Next Button On New Submission For SL           LawyerGuard_SL
#     VerifyText                  Underwriter Workbench
#     Add Account name on Insured info page
#     Enter Territory data on Insured Info Page SL            New York: Remainder of State
#     Click on save button
#     Add Attorney
#     Click on NEXT:Submission Info
#     Select broker Contact Source
#     Entering Submission_Info Details for SL                 Excess                      12/06/2024
#     ClickText                   NEXT:Underwriter Analysis >
#     VerifyText                  Underwriting Analysis
#     Add Area Of Practice for SL
#     Add Details In Underwriter Analysis Tab for SL
#     ClickText                   Qualify Submission
#     Sleep                       30s
#     Add Premium to Excess Fields
#     Rate Quote
#     Sleep                       30s
#     Click On Bind For SL        Individual broker license
#     VerifyText                  Policy Name
#     Change Policy Functionality                             Midterm Cancellation
#     Select Change Midterm Cancellation Input
#     Click Bind SL After Amendment
#     Click Quote On Policy Page
#     VerifyText                  Midterm Cancellation


# #Extension -Policy Change document generation, verify dates for Primary
#     #TCID=
#     #Author=Shraddha
#     [Documentation]             Functionality on Insured Info Page
#     [Tags]                      SL
#     Creating a new Account state NY
#     Checking Next Button On New Submission For SL           LawyerGuard_SL
#     VerifyText                  Underwriter Workbench
#     Add Account name on Insured info page
#     Enter Territory data on Insured Info Page SL            New York: Remainder of State
#     Click on save button
#     Add Attorney
#     Click on NEXT:Submission Info
#     Select broker Contact Source
#     Entering Submission_Info Details for SL                 Primary                     12/06/2024
#     ClickText                   NEXT:Underwriter Analysis >
#     VerifyText                  Underwriting Analysis
#     Add Area Of Practice
#     Add Details In Underwriter Analysis Tab for SL
#     ClickText                   Qualify Submission
#     Sleep                       30s
#     Click On Bind For SL        Individual broker license
#     VerifyText                  Policy Name
#     Change Policy Functionality                             Extension
#     Select Change Extension Input
#     Click Bind SL After Amendment
#     Click Quote On Policy Page
#     VerifyText                  Extension

# #Extension -Policy Change document generation, verify dates for Excess
#     #TCID=
#     #Author=Shraddha
#     [Documentation]             Functionality on Insured Info Page
#     [Tags]                      SL
#     Creating a new Account state NY
#     Checking Next Button On New Submission For SL           LawyerGuard_SL
#     VerifyText                  Underwriter Workbench
#     Add Account name on Insured info page
#     Enter Territory data on Insured Info Page SL            New York: Remainder of State
#     Click on save button
#     Add Attorney
#     Click on NEXT:Submission Info
#     Select broker Contact Source
#     Entering Submission_Info Details for SL                 Excess                      12/06/2024
#     ClickText                   NEXT:Underwriter Analysis >
#     VerifyText                  Underwriting Analysis
#     Add Area Of Practice for SL
#     Add Details In Underwriter Analysis Tab for SL
#     ClickText                   Qualify Submission
#     Sleep                       30s
#     Add Premium to Excess Fields
#     Rate Quote
#     Sleep                       30s
#     Click On Bind For SL        Individual broker license
#     VerifyText                  Policy Name
#     Change Policy Functionality                             Extension
#     Select Change Extension Input
#     Click Bind SL After Amendment
#     Click Quote On Policy Page
#     VerifyText                  Extension

# #Validate BOR For Primary
#     #TCID=
#     #Author=Shraddha
#     [Documentation]             Functionality on Insured Info Page
#     [Tags]                      SL
#     Creating a new Account state NY
#     Checking Next Button On New Submission For SL           LawyerGuard_SL
#     VerifyText                  Underwriter Workbench
#     Add Account name on Insured info page
#     Enter Territory data on Insured Info Page SL            New York: Remainder of State
#     Click on save button
#     Add Attorney
#     Click on NEXT:Submission Info
#     Select broker Contact Source
#     Entering Submission_Info Details for SL                 Primary                     12/06/2024
#     ClickText                   NEXT:Underwriter Analysis >
#     VerifyText                  Underwriting Analysis
#     Add Area Of Practice
#     Add Details In Underwriter Analysis Tab for SL
#     ClickText                   Qualify Submission
#     Sleep                       30s
#     Click On Bind For SL        Individual broker license
#     VerifyText                  Policy Name
#     Change Policy Functionality                             Broker of Record (BOR)
#     Select BOR Input
#     ClickText                   Quote
#     ClickElement                //a[@data-label\='Quote']
#     #VerifyText                 ${uniquename} 2             anchor=Quote Name
#     Sleep                       20s
#     RefreshPage
#     ClickElement                //a[@data-label\='Submissions']
#     ClickElement                //a[@data-label\='Quote']
#     VerifyText                  ${uniquename} 2             anchor=Quote Name
#     VerifyText                  Bound                       anchor=Status
#     VerifyText                  Bound

# #Validate BOR For Excess
#     #TCID=
#     #Author=Shraddha
#     [Documentation]             Functionality on Insured Info Page
#     [Tags]                      SL
#     Creating a new Account state NY
#     Checking Next Button On New Submission For SL           LawyerGuard_SL
#     VerifyText                  Underwriter Workbench
#     Add Account name on Insured info page
#     Enter Territory data on Insured Info Page SL            New York: Remainder of State
#     Click on save button
#     Add Attorney
#     Click on NEXT:Submission Info
#     Select broker Contact Source
#     Entering Submission_Info Details for SL                 Excess                      12/06/2024
#     ClickText                   NEXT:Underwriter Analysis >
#     VerifyText                  Underwriting Analysis
#     Add Area Of Practice for SL
#     Add Details In Underwriter Analysis Tab for SL
#     ClickText                   Qualify Submission
#     Sleep                       30s
#     Add Premium to Excess Fields
#     Rate Quote
#     Sleep                       30s
#     Click On Bind For SL        Individual broker license
#     VerifyText                  Policy Name
#     Change Policy Functionality                             Broker of Record (BOR)
#     Select BOR Input
#     ClickText                   Quote
#     ClickElement                //a[@data-label\='Quote']
#     #VerifyText                 ${uniquename} 2             anchor=Quote Name
#     Sleep                       20s
#     RefreshPage
#     ClickElement                //a[@data-label\='Submissions']
#     ClickElement                //a[@data-label\='Quote']
#     VerifyText                  ${uniquename} 2             anchor=Quote Name
#     VerifyText                  Bound                       anchor=Status
#     VerifyText                  Bound

# #Validate Name Change for Primary
#     #TCID=
#     #Author=Shraddha
#     [Documentation]             Functionality on Insured Info Page
#     [Tags]                      SL
#     Creating a new Account state NY
#     Checking Next Button On New Submission For SL           LawyerGuard_SL
#     VerifyText                  Underwriter Workbench
#     Add Account name on Insured info page
#     Enter Territory data on Insured Info Page SL            New York: Remainder of State
#     Click on save button
#     Add Attorney
#     Click on NEXT:Submission Info
#     Select broker Contact Source
#     Entering Submission_Info Details for SL                 Primary                     12/06/2024
#     ClickText                   NEXT:Underwriter Analysis >
#     VerifyText                  Underwriting Analysis
#     Add Area Of Practice
#     Add Details In Underwriter Analysis Tab for SL
#     ClickText                   Qualify Submission
#     Sleep                       30s
#     Click On Bind For SL        Individual broker license
#     VerifyText                  Policy Name
#     Sleep                       20s
#     Change Policy Functionality                             Name Change
#     Select Change Name Input
#     #Click Quote On Policy Page
#     #VerifyText                 Name Change
#     #VerifyText                 ${uniquename} 2
#     #RefreshPage
#     ClickText                   Quote
#     ClickElement                //a[@data-label\='Quote']
#     #VerifyText                 ${uniquename} 2             anchor=Quote Name
#     Sleep                       20s
#     RefreshPage
#     ClickElement                //a[@data-label\='Submissions']
#     ClickElement                //a[@data-label\='Quote']
#     VerifyText                  ${uniquename} 2             anchor=Quote Name
#     VerifyText                  Bound                       anchor=Status
#     VerifyText                  Bound                       anchor=3

# #Validate Name Change for Excess
#     #TCID=
#     #Author=Shraddha
#     [Documentation]             Functionality on Insured Info Page
#     [Tags]                      SL
#     Creating a new Account state NY
#     Checking Next Button On New Submission For SL           LawyerGuard_SL
#     VerifyText                  Underwriter Workbench
#     Add Account name on Insured info page
#     Enter Territory data on Insured Info Page SL            New York: Remainder of State
#     Click on save button
#     Add Attorney
#     Click on NEXT:Submission Info
#     Select broker Contact Source
#     Entering Submission_Info Details for SL                 Excess                      12/06/2024
#     ClickText                   NEXT:Underwriter Analysis >
#     VerifyText                  Underwriting Analysis
#     Add Area Of Practice for SL
#     Add Details In Underwriter Analysis Tab for SL
#     ClickText                   Qualify Submission
#     Sleep                       30s
#     Add Premium to Excess Fields
#     Rate Quote
#     Sleep                       30s
#     Click On Bind For SL        Individual broker license
#     VerifyText                  Policy Name
#     Sleep                       20s
#     Change Policy Functionality                             Name Change
#     Select Change Name Input
#     #Click Quote On Policy Page
#     #VerifyText                 Name Change
#     #VerifyText                 ${uniquename} 2
#     #RefreshPage
#     ClickText                   Quote
#     ClickElement                //a[@data-label\='Quote']
#     #VerifyText                 ${uniquename} 2             anchor=Quote Name
#     Sleep                       20s
#     RefreshPage
#     ClickElement                //a[@data-label\='Submissions']
#     ClickElement                //a[@data-label\='Quote']
#     VerifyText                  ${uniquename} 2             anchor=Quote Name
#     VerifyText                  Bound                       anchor=Status
#     VerifyText                  Bound                       anchor=3

# #Validate change policy - Address change Primary
#     #TCID=
#     #Author=Shraddha
#     [Documentation]             Functionality on Insured Info Page
#     [Tags]                      SL
#     Creating a new Account state NY
#     Checking Next Button On New Submission For SL           LawyerGuard_SL
#     VerifyText                  Underwriter Workbench
#     Add Account name on Insured info page
#     Enter Territory data on Insured Info Page SL            New York: Remainder of State
#     Click on save button
#     Add Attorney
#     Click on NEXT:Submission Info
#     Select broker Contact Source
#     Entering Submission_Info Details for SL                 Primary                     12/06/2024
#     ClickText                   NEXT:Underwriter Analysis >
#     VerifyText                  Underwriting Analysis
#     Add Area Of Practice
#     Add Details In Underwriter Analysis Tab for SL
#     ClickText                   Qualify Submission
#     Sleep                       30s
#     Click On Bind For SL        Individual broker license
#     VerifyText                  Policy Name
#     Change Policy Functionality                             Address Change
#     Select Change Address Input
#     ClickText                   Quote
#     ClickElement                //a[@data-label\='Quote']
#     #VerifyText                 ${uniquename} 2             anchor=Quote Name
#     Sleep                       20s
#     RefreshPage
#     ClickElement                //a[@data-label\='Submissions']
#     ClickElement                //a[@data-label\='Quote']
#     VerifyText                  ${uniquename} 2             anchor=Quote Name
#     VerifyText                  Bound                       anchor=Status
#     VerifyText                  Bound                       anchor=3

# #Validate change policy - Address change Excess
#     #TCID=
#     #Author=Shraddha
#     [Documentation]             Functionality on Insured Info Page
#     [Tags]                      SL
#     Creating a new Account state NY
#     Checking Next Button On New Submission For SL           LawyerGuard_SL
#     VerifyText                  Underwriter Workbench
#     Add Account name on Insured info page
#     Enter Territory data on Insured Info Page SL            New York: Remainder of State
#     Click on save button
#     Add Attorney
#     Click on NEXT:Submission Info
#     Select broker Contact Source
#     Entering Submission_Info Details for SL                 Excess                      12/06/2024
#     ClickText                   NEXT:Underwriter Analysis >
#     VerifyText                  Underwriting Analysis
#     Add Area Of Practice for SL
#     Add Details In Underwriter Analysis Tab for SL
#     ClickText                   Qualify Submission
#     Sleep                       30s
#     Add Premium to Excess Fields
#     Rate Quote
#     Sleep                       30s
#     Click On Bind For SL        Individual broker license
#     VerifyText                  Policy Name
#     Sleep                       20s
#     Change Policy Functionality                             Address Change
#     Select Change Address Input
#     ClickText                   Quote
#     ClickElement                //a[@data-label\='Quote']
#     #VerifyText                 ${uniquename} 2             anchor=Quote Name
#     Sleep                       20s
#     RefreshPage
#     ClickElement                //a[@data-label\='Submissions']
#     ClickElement                //a[@data-label\='Quote']
#     VerifyText                  ${uniquename} 2             anchor=Quote Name
#     VerifyText                  Bound                       anchor=Status
#     VerifyText                  Bound                       anchor=3

# #Extended Reported Period - Name Individual Primary
#     #TCID=
#     #Author=Shraddha
#     [Documentation]             Functionality on Insured Info Page
#     [Tags]                      SL
#     Creating a new Account state NY
#     Checking Next Button On New Submission For SL           LawyerGuard_SL
#     VerifyText                  Underwriter Workbench
#     Add Account name on Insured info page
#     Enter Territory data on Insured Info Page SL            New York: Remainder of State
#     Click on save button
#     Add Attorney
#     Click on NEXT:Submission Info
#     Select broker Contact Source
#     Entering Submission_Info Details for SL                 Primary                     12/06/2024
#     ClickText                   NEXT:Underwriter Analysis >
#     VerifyText                  Underwriting Analysis
#     Add Area Of Practice
#     Add Details In Underwriter Analysis Tab for SL
#     ClickText                   Qualify Submission
#     Sleep                       30s
#     Click On Bind For SL        Individual broker license
#     VerifyText                  Policy Name
#     Change Policy Functionality                             Midterm Cancellation
#     Select Change Midterm Cancellation Input
#     Click Bind SL After Amendment
#     Change Policy Functionality                             Extended Reporting Period
#     Select Change ERP date Input
#     Click Bind SL After Amendment
#     Click Quote On Policy Page
#     VerifyText                  Midterm Cancellation
#     VerifyText                  Extended Reporting Period

# #Extended Reported Period - Name Individual Excess
#     #TCID=
#     #Author=Shraddha
#     [Documentation]             Functionality on Insured Info Page
#     [Tags]                      SL
#     Creating a new Account state NY
#     Checking Next Button On New Submission For SL           LawyerGuard_SL
#     VerifyText                  Underwriter Workbench
#     Add Account name on Insured info page
#     Enter Territory data on Insured Info Page SL            New York: Remainder of State
#     Click on save button
#     Add Attorney
#     Click on NEXT:Submission Info
#     Select broker Contact Source
#     Entering Submission_Info Details for SL                 Excess                      12/06/2024
#     ClickText                   NEXT:Underwriter Analysis >
#     VerifyText                  Underwriting Analysis
#     Add Area Of Practice for SL
#     Add Details In Underwriter Analysis Tab for SL
#     ClickText                   Qualify Submission
#     Sleep                       30s
#     Add Premium to Excess Fields
#     Rate Quote
#     Sleep                       30s
#     Click On Bind For SL        Individual broker license
#     VerifyText                  Policy Name
#     Change Policy Functionality                             Midterm Cancellation
#     Select Change Midterm Cancellation Input
#     Sleep                       10s
#     Click Bind SL After Amendment
#     Sleep                       10s
#     Change Policy Functionality                             Extended Reporting Period
#     Select Change ERP date Input
#     Sleep                       10s
#     Click Bind SL After Amendment
#     Sleep                       10s
#     Click Quote On Policy Page
#     VerifyText                  Midterm Cancellation
#     VerifyText                  Extended Reporting Period

# #Validate Cancel and Replace Primary
#     #TCID=
#     #Author=Shraddha
#     [Documentation]             Functionality on Insured Info Page
#     [Tags]                      SL
#     Creating a new Account state NY
#     Checking Next Button On New Submission For SL           LawyerGuard_SL
#     VerifyText                  Underwriter Workbench
#     Add Account name on Insured info page
#     Enter Territory data on Insured Info Page SL            New York: Remainder of State
#     Click on save button
#     Add Attorney
#     Click on NEXT:Submission Info
#     Select broker Contact Source
#     Entering Submission_Info Details for SL                 Primary                     12/06/2024
#     ClickText                   NEXT:Underwriter Analysis >
#     VerifyText                  Underwriting Analysis
#     Add Area Of Practice
#     Add Details In Underwriter Analysis Tab for SL
#     ClickText                   Qualify Submission
#     Sleep                       30s
#     Click On Bind For SL        Individual broker license
#     VerifyText                  Policy Name
#     Change Policy Functionality                             Cancel & Replace
#     Select Change Cancel & Replacement Input
#     ClickElement                (//button[@title\='Rating'])[5]
#     VerifyText                  Success                     anchor=Rating successfully!
#     Sleep                       30s
#     ClickElement                (//lightning-icon[@title\='Finalize Quote'])[3]         delay=3s
#     Sleep                       30s
#     ClickElement                //lightning-icon[@title\='Bind']
#     ClickCheckbox               Agency broker license       off
#     ClickCheckbox               Individual broker license                               on
#     ClickElement                //span[text()\='Select Item 1']
#     ClickElement                //button[@title\='Bind']
#     VerifyText                  Success                     anchor=Bind quote successfully!
#     Verify Coverage Cancel replace on policy quote

# #Validate Cancel and Replace Excess
#     #TCID=
#     #Author=Shraddha
#     [Documentation]             Functionality on Insured Info Page
#     [Tags]                      SL
#     Creating a new Account state NY
#     Checking Next Button On New Submission For SL           LawyerGuard_SL
#     VerifyText                  Underwriter Workbench
#     Add Account name on Insured info page
#     Enter Territory data on Insured Info Page SL            New York: Remainder of State
#     Click on save button
#     Add Attorney
#     Click on NEXT:Submission Info
#     Select broker Contact Source
#     Entering Submission_Info Details for SL                 Excess                      12/06/2024
#     ClickText                   NEXT:Underwriter Analysis >
#     VerifyText                  Underwriting Analysis
#     Add Area Of Practice for SL
#     Add Details In Underwriter Analysis Tab for SL
#     ClickText                   Qualify Submission
#     Sleep                       30s
#     Add Premium to Excess Fields
#     Rate Quote
#     Sleep                       30s
#     Click On Bind For SL        Individual broker license
#     VerifyText                  Policy Name
#     Change Policy Functionality                             Cancel & Replace
#     Select Change Cancel & Replacement Input
#     ClickElement                (//button[@title\='Rating'])[5]
#     VerifyText                  Success                     anchor=Rating successfully!
#     Sleep                       30s
#     ClickElement                (//lightning-icon[@title\='Finalize Quote'])[3]         delay=3s
#     Sleep                       30s
#     ClickElement                //lightning-icon[@title\='Bind']
#     ClickCheckbox               Agency broker license       off
#     ClickCheckbox               Individual broker license                               on
#     ClickElement                //span[text()\='Select Item 1']
#     ClickElement                //button[@title\='Bind']
#     VerifyText                  Success                     anchor=Bind quote successfully!
#     Verify Coverage Cancel replace on policy quote

# #Extended Reporting Period - Firm Primary
#     #TCID=
#     #Author=Shraddha
#     [Documentation]             Functionality on Insured Info Page
#     [Tags]                      SL
#     Creating a new Account state NY
#     Checking Next Button On New Submission For SL           LawyerGuard_SL
#     VerifyText                  Underwriter Workbench
#     Add Account name on Insured info page
#     Enter Territory data on Insured Info Page SL            New York: Remainder of State
#     Click on save button
#     Add Attorney
#     Click on NEXT:Submission Info
#     Select broker Contact Source
#     Entering Submission_Info Details for SL                 Primary                     12/06/2024
#     ClickText                   NEXT:Underwriter Analysis >
#     VerifyText                  Underwriting Analysis
#     Add Area Of Practice
#     Add Details In Underwriter Analysis Tab for SL
#     ClickText                   Qualify Submission
#     Sleep                       30s
#     Click On Bind For SL        Individual broker license
#     VerifyText                  Policy Name
#     Change Policy Functionality                             Midterm Cancellation
#     Select Change Midterm Cancellation Input
#     Click Bind SL After Amendment
#     Change Policy Functionality                             Extended Reporting Period
#     Select Change ERP date Input
#     Click Bind SL After Amendment

# #Extended Reporting Period - Name Individual Excess
#     #TCID=
#     #Author=Shraddha
#     [Documentation]             Functionality on Insured Info Page
#     [Tags]                      SL
#     Creating a new Account state NY
#     Checking Next Button On New Submission For SL           LawyerGuard_SL
#     VerifyText                  Underwriter Workbench
#     Add Account name on Insured info page
#     Enter Territory data on Insured Info Page SL            New York: Remainder of State
#     Click on save button
#     Add Attorney
#     Click on NEXT:Submission Info
#     Select broker Contact Source
#     Entering Submission_Info Details for SL                 Excess                      12/06/2024
#     ClickText                   NEXT:Underwriter Analysis >
#     VerifyText                  Underwriting Analysis
#     Add Area Of Practice for SL
#     Add Details In Underwriter Analysis Tab for SL
#     ClickText                   Qualify Submission
#     Sleep                       30s
#     Add Premium to Excess Fields
#     Rate Quote
#     Sleep                       30s
#     Click On Bind For SL        Individual broker license
#     VerifyText                  Policy Name
#     Change Policy Functionality                             Midterm Cancellation
#     Select Change Midterm Cancellation Input
#     Click Bind SL After Amendment
#     Change Policy Functionality                             Extended Reporting Period
#     Select Change ERP date Input
#     Click Bind SL After Amendment


# #Create Renewal flow for Primary
#     #TCID=
#     #Author=Shraddha
#     [Documentation]             Functionality on Insured Info Page
#     [Tags]                      SL
#     Creating a new Account state NY
#     Checking Next Button On New Submission For SL           LawyerGuard_SL
#     VerifyText                  Underwriter Workbench
#     Add Account name on Insured info page
#     Enter Territory data on Insured Info Page SL            New York: Remainder of State
#     Click on save button
#     Add Attorney
#     Click on NEXT:Submission Info
#     Select broker Contact Source
#     Entering Submission_Info Details for SL                 Primary                     12/06/2024
#     ClickText                   NEXT:Underwriter Analysis >
#     VerifyText                  Underwriting Analysis
#     Add Area Of Practice
#     Add Details In Underwriter Analysis Tab for SL
#     ClickText                   Qualify Submission
#     Sleep                       30s
#     Click On Bind For SL        Individual broker license
#     VerifyText                  Policy Name
#     Create a Renewal Flow
#     Sleep                       10s
#     Click On Bind For SL        Individual broker license
#     VerifyText                  Policy Name
#     ClickElement                //li[@data-label\='Quote']
#     VerifyText                  Renewal

# #Create Renewal flow for Excess
#     #TCID=
#     #Author=Shraddha
#     [Documentation]             Functionality on Insured Info Page
#     [Tags]                      SL
#     Creating a new Account state NY
#     Checking Next Button On New Submission For SL           LawyerGuard_SL
#     VerifyText                  Underwriter Workbench
#     Add Account name on Insured info page
#     Enter Territory data on Insured Info Page SL            New York: Remainder of State
#     Click on save button
#     Add Attorney
#     Click on NEXT:Submission Info
#     Select broker Contact Source
#     Entering Submission_Info Details for SL                 Excess                      12/06/2024
#     ClickText                   NEXT:Underwriter Analysis >
#     VerifyText                  Underwriting Analysis
#     Add Area Of Practice for SL
#     Add Details In Underwriter Analysis Tab for SL
#     ClickText                   Qualify Submission
#     Sleep                       30s
#     Add Premium to Excess Fields
#     Rate Quote
#     Sleep                       30s
#     Click On Bind For SL        Individual broker license
#     VerifyText                  Policy Name
#     Create a Renewal Flow
#     Sleep                       10s
#     Click On Bind For SL        Individual broker license
#     VerifyText                  Policy Name
#     ClickElement                //li[@data-label\='Quote']
#     VerifyText                  Renewal


# #Extended Reported Period - Firm Primary
#     #TCID=
#     #Author=Shraddha
#     [Documentation]             Functionality on Insured Info Page
#     [Tags]                      SL
#     Creating a new Account state NY
#     Checking Next Button On New Submission For SL           LawyerGuard_SL
#     VerifyText                  Underwriter Workbench
#     Add Account name on Insured info page
#     Enter Territory data on Insured Info Page SL            New York: Remainder of State
#     Click on save button
#     Add Attorney
#     Click on NEXT:Submission Info
#     Select broker Contact Source
#     Entering Submission_Info Details for SL                 Primary                     12/06/2024
#     ClickText                   NEXT:Underwriter Analysis >
#     VerifyText                  Underwriting Analysis
#     Add Area Of Practice
#     Add Details In Underwriter Analysis Tab for SL
#     ClickText                   Qualify Submission
#     Sleep                       30s
#     Click On Bind For SL        Individual broker license
#     VerifyText                  Policy Name
#     Change Policy Functionality                             Midterm Cancellation
#     Select Change Midterm Cancellation Input
#     Click Bind SL After Amendment
#     Change Policy Functionality                             Extended Reporting Period
#     #ClickElement               //div[@class\="slds-form-element__control slds-grow"]
#     #DropDown                   5018:0                      Firm
#     DropDown                    ERP Type                    Firm
#     ClickText                   Endorsement Effective Date                              timeout=55s
#     ${cur_data}=                Get Current Date            result_format=%b %-d, %Y
#     ${comp_effective_date}=     Get Current Date            increment=5 day             result_format=%b %-d, %Y
#     Log To Console              ${comp_effective_date}
#     ${subdate1}=                Get Substring               ${comp_effective_date}      4                           -6
#     Log To Console              ${subdate1}
#     ClickElement                //a[@title\='Go to next month']
#     ClickElement                //span[text()\='${subdate1}']
#     ClickText                   Confirm                     anchor=Cancel
#     Sleep                       20s
#     Click Bind SL After Amendment
#     Click Quote On Policy Page
#     VerifyText                  Midterm Cancellation
#     VerifyText                  Extended Reporting Period


# #Extended Reporting Period - Firm Excess
#     #TCID=
#     #Author=Shraddha
#     [Documentation]             Functionality on Insured Info Page
#     [Tags]                      SL

#     Creating a new Account state NY
#     Checking Next Button On New Submission For SL           LawyerGuard_SL
#     VerifyText                  Underwriter Workbench
#     Add Account name on Insured info page
#     Enter Territory data on Insured Info Page SL            New York: Remainder of State
#     Click on save button
#     Add Attorney
#     Click on NEXT:Submission Info
#     Select broker Contact Source
#     Entering Submission_Info Details for SL                 Excess                      12/06/2024
#     ClickText                   NEXT:Underwriter Analysis >
#     VerifyText                  Underwriting Analysis
#     Add Area Of Practice for SL
#     Add Details In Underwriter Analysis Tab for SL
#     ClickText                   Qualify Submission
#     Sleep                       30s
#     Add Premium to Excess Fields
#     Rate Quote
#     Sleep                       30s
#     Click On Bind For SL        Individual broker license
#     VerifyText                  Policy Name
#     RefreshPage
#     Change Policy Functionality                             Midterm Cancellation
#     Select Change Midterm Cancellation Input
#     Click Bind SL After Amendment
#     Change Policy Functionality                             Extended Reporting Period

#     #DropDown                   1486:0                      Firm
#     DropDown                    ERP Type                    Firm
#     #VerifyText                  ERP Type
#     ClickText                   Endorsement Effective Date                              timeout=55s
#     ${cur_data}=                Get Current Date            result_format=%b %-d, %Y
#     ${comp_effective_date}=     Get Current Date            increment=5 day             result_format=%b %-d, %Y
#     Log To Console              ${comp_effective_date}
#     ${subdate1}=                Get Substring               ${comp_effective_date}      4                           -6
#     Log To Console              ${subdate1}
#     ClickElement                //a[@title\='Go to next month']
#     ClickElement                //span[text()\='${subdate1}']
#     ClickText                   Confirm                     anchor=Cancel
#     Sleep                       20s
#     Click Bind SL After Amendment
#     Click Quote On Policy Page
#     VerifyText                  Midterm Cancellation
#     VerifyText                  Extended Reporting Period

# #Validate Flat Cancellation for Primary 
#     #TCID=
#     #Author=Shraddha
#     [Documentation]             Functionality on Insured Info Page
#     [Tags]                      SL
#     Creating a new Account state NY
#     Checking Next Button On New Submission For SL           LawyerGuard_SL
#     VerifyText                  Underwriter Workbench
#     Add Account name on Insured info page
#     Enter Territory data on Insured Info Page SL            New York: Remainder of State
#     Click on save button
#     Add Attorney
#     Click on NEXT:Submission Info
#     Select broker Contact Source
#     Entering Submission_Info Details for SL                 Primary                     12/06/2024
#     ClickText                   NEXT:Underwriter Analysis >
#     VerifyText                  Underwriting Analysis
#     Add Area Of Practice
#     Add Details In Underwriter Analysis Tab for SL
#     ClickText                   Qualify Submission
#     Sleep                       30s
#     Click On Bind For SL        Individual broker license
#     VerifyText                  Policy Name
#     Change Policy Functionality                             Flat Cancellation
#     Sleep                       10s
#     Select flat cancellation Input
#     Click Bind SL After Amendment
#     Click Quote On Policy Page
#     VerifyText                  Flat Cancellation

# #Validate Flat Cancellation for Excess  
#     #TCID=
#     #Author=Shraddha
#     [Documentation]             Functionality on Insured Info Page
#     [Tags]                      SL
#     Creating a new Account state NY
#     Checking Next Button On New Submission For SL           LawyerGuard_SL
#     VerifyText                  Underwriter Workbench
#     Add Account name on Insured info page
#     Enter Territory data on Insured Info Page SL            New York: Remainder of State
#     Click on save button
#     Add Attorney
#     Click on NEXT:Submission Info
#     Select broker Contact Source
#     Entering Submission_Info Details for SL                 Excess                      12/06/2024
#     ClickText                   NEXT:Underwriter Analysis >
#     VerifyText                  Underwriting Analysis
#     Add Area Of Practice for SL
#     Add Details In Underwriter Analysis Tab for SL
#     ClickText                   Qualify Submission
#     Sleep                       30s
#     Add Premium to Excess Fields
#     Rate Quote
#     Sleep                       30s
#     Click On Bind For SL        Individual broker license
#     VerifyText                  Policy Name
#     Change Policy Functionality                             Flat Cancellation
#     Sleep                       10s
#     Select flat cancellation Input
#     Click Bind SL After Amendment
#     Click Quote On Policy Page
#     VerifyText                  Flat Cancellation

# #Reinstatement - Primary
#     #TCID=
#     #Author=Shraddha
#     [Documentation]             Functionality on Insured Info Page
#     [Tags]                      SL
#     Creating a new Account state NY
#     Checking Next Button On New Submission For SL           LawyerGuard_SL
#     VerifyText                  Underwriter Workbench
#     Add Account name on Insured info page
#     Enter Territory data on Insured Info Page SL            New York: Remainder of State
#     Click on save button
#     Add Attorney
#     Click on NEXT:Submission Info
#     Select broker Contact Source
#     Entering Submission_Info Details for SL                 Primary                     12/06/2024
#     ClickText                   NEXT:Underwriter Analysis >
#     VerifyText                  Underwriting Analysis
#     Add Area Of Practice
#     Add Details In Underwriter Analysis Tab for SL
#     ClickText                   Qualify Submission
#     Sleep                       30s
#     Click On Bind For SL        Individual broker license
#     VerifyText                  Policy Name
#     Change Policy Functionality                             Midterm Cancellation
#     Select Change Midterm Cancellation Input
#     Click Bind SL After Amendment
#     Change Policy Functionality                             Reinstatement
#     #ClickElement               //div[@class\="slds-form-element__control slds-grow"]
#     ClickText                   Endorsement Effective Date                              timeout=55s
#     ${cur_data}=                Get Current Date            result_format=%b %-d, %Y
#     ${comp_effective_date}=     Get Current Date            increment=5 day             result_format=%b %-d, %Y
#     Log To Console              ${comp_effective_date}
#     ${subdate1}=                Get Substring               ${comp_effective_date}      4                           -6
#     Log To Console              ${subdate1}
#     ClickElement                //a[@title\='Go to next month']
#     ClickElement                //span[text()\='${subdate1}']
#     ClickText                   Confirm                     anchor=Cancel
#     Sleep                       20s
#     Click Bind SL After Amendment
#     Click Quote On Policy Page
#     VerifyText                  Midterm Cancellation
#     VerifyText                  Reinstatement

# #Reinstatement - Excess
#     #TCID=
#     #Author=Shraddha
#     [Documentation]             Functionality on Insured Info Page
#     [Tags]                      SL
#     Creating a new Account state NY
#     Checking Next Button On New Submission For SL           LawyerGuard_SL
#     VerifyText                  Underwriter Workbench
#     Add Account name on Insured info page
#     Enter Territory data on Insured Info Page SL            New York: Remainder of State
#     Click on save button
#     Add Attorney
#     Click on NEXT:Submission Info
#     Select broker Contact Source
#     Entering Submission_Info Details for SL                 Excess                      12/06/2024
#     ClickText                   NEXT:Underwriter Analysis >
#     VerifyText                  Underwriting Analysis
#     Add Area Of Practice for SL
#     Add Details In Underwriter Analysis Tab for SL
#     ClickText                   Qualify Submission
#     Sleep                       30s
#     Add Premium to Excess Fields
#     Rate Quote
#     Sleep                       30s
#     Click On Bind For SL        Individual broker license
#     VerifyText                  Policy Name
#     Change Policy Functionality                             Midterm Cancellation
#     Select Change Midterm Cancellation Input
#     Click Bind SL After Amendment
#     Change Policy Functionality                             Reinstatement
#     #DropDown                   1486:0                      Firm
#     #VerifyText                 ERP Type
#     ClickText                   Endorsement Effective Date                              timeout=55s
#     ${cur_data}=                Get Current Date            result_format=%b %-d, %Y
#     ${comp_effective_date}=     Get Current Date            increment=5 day             result_format=%b %-d, %Y
#     Log To Console              ${comp_effective_date}
#     ${subdate1}=                Get Substring               ${comp_effective_date}      4                           -6
#     Log To Console              ${subdate1}
#     ClickElement                //a[@title\='Go to next month']
#     ClickElement                //span[text()\='${subdate1}']
#     ClickText                   Confirm                     anchor=Cancel
#     Sleep                       20s
#     Click Bind SL After Amendment
#     Click Quote On Policy Page
#     VerifyText                  Midterm Cancellation
#     VerifyText                  Reinstatement
