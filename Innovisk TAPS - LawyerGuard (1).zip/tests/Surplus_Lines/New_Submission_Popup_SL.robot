*** Settings ***
Library                         QWeb
Library                         QForce
#Library                        QVision
Library                         FakerLibrary
Library                         String
Library                         BuiltIn
Library                         DateTime
Resource                        ../../resources/common.robot
Resource                        ../../PageObjects/PageObjects_Account.robot
Resource                        ../../PageObjects/PageObjects_HomePage.robot
Resource                        ../../PageObjects/PageObjects_Submission.robot
Resource                        ../../PageObjects/PageObjects_InusredInfo.robot

Library                         RetryFailed                 global_retries=${retry_count}
Suite Setup                     Setup Browser
Suite Teardown                  CloseAllBrowsers


*** Test Cases ***

Check the functionality of Cancel button on New Submission Pop Up.
    [Documentation]             Check the functionality of Cancel button on New Submission Pop Up.
    [Tags]                      Smoke_Test_LGO_NONAdmitted                              Smoke_Test


    # Author = Shraddha T Patil
    #TC=107899,107898

    Creating a new Account
    Checking Cancel Button On New Submission For SL         LawyerGuard_SL


Check the functionality of Next Button on New Submission Pop-Up
    [Documentation]             Check the functionality of Next Button on New Submission Pop-Up
    [Tags]                      Smoke_Test_LGO_NONAdmitted                              Smoke_Test


    # Author = Shraddha T Patil
    #TC=107965
    Creating a new Account
    Checking Next Button On New Submission For SL           LawyerGuard_SL



