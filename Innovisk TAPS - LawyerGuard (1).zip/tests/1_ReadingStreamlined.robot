*** Settings ***
Library                         QWeb
Library                         QForce
#Library                        QVision
Library                         FakerLibrary
Library                         String
Library                         BuiltIn
Library                         DateTime
Resource                        ../resources/common.robot
Resource                        ../resources/ReadPDF.robot
Resource                        ../PageObjects/PageObjects_Account.robot
Resource                        ../PageObjects/PageObjects_HomePage.robot
Resource                        ../PageObjects/PageObjects_Submission.robot
Resource                        ../PageObjects/PageObjects_InusredInfo.robot
Resource                        ../PageObjects/PageObjects_SubmissionInit.robot
Resource                        ../PageObjects/PageObjects_SubmissionInfo.robot
Resource                        ../PageObjects/PageObjects_UnderwrittingAnalysis.robot
Resource                        ../PageObjects/PageObjects_CompareAndRateQuote.robot
Resource                        ../PageObjects/PageObjects_PDFRead.robot
Resource                        ../resources/PageSelection.robot
Resource                        ../PageObjects/Surplus_Lines/PageObjects_SL_UnderwriterAnalysis.robot

Library                         RetryFailed                 global_retries=${retry_count}

Suite Setup                     Setup Browser
Suite Teardown                  CloseAllBrowsers


*** Test Cases ***

Verify Quote Proposal and Streamlined Renewal and Indication Document
    #Author=Amol Gaymukhe
    [Documentation]             Verify Indication document
    [Tags]                      Smoke_Test_LGO_Admitted     Smoke_Test
    Creating a new Account
    Validate LaweyrGuard New submission Fields
    VerifyText                  Underwriter Workbench
    Add Account name on Insured info page
    # VerifyInputValue          Contact Record Type         Attorney                    timeout=2s
    Click on save button
    Add Attorney
    Click on NEXT:Submission Info
    Select broker Contact Source
    Add Details In SubmissionInfo Page
    ClickText                   NEXT:Underwriter Analysis >
    VerifyText                  Underwriting Analysis
    Sleep                       20s
    Add Area Of Practice
    ClickText                   Qualify Submission
    Sleep                       30s
    #Validate Header Fields On Compare and Rate quote
    RefreshPage
    Generate Document In Quoted                             Quote Proposal
    Sleep                       15s
    Move to outputdir
    Sleep                       10s
    Read PDF Quote Letter Static Document
    Read PDF Quote Letter Dynamic Document
    Sleep                       30s
    Generate Document In Quoted                             Streamlined Renewal
    Sleep                       15s
    Move to outputdir
    Read PDF Streamlined Renewal Static Document
    Read PDF StreamlinedRenewal Dynamic Document
    Sleep                       30s
    Generate Document In Rated                              Indication
    Sleep                       15s
    Move to outputdir
    Read PDF Indication Static Document
    Read PDF Indication Dynamic Document
    Sleep                       30s
    Generate Document In Rated                              Account Summary
    Sleep                       15s
    Get WORD document and attach it to log
    Read Word Account Summary Static Document
    Read Word Account Summary Dynamic Document
