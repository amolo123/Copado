*** Settings ***
Resource                        ../resources/common.robot
Resource                        ../PageObjects/PageObjects_Account.robot
Resource                        ../PageObjects/PageObjects_HomePage.robot
Resource                        ../PageObjects/PageObjects_Submission.robot
Library                         RetryFailed                 global_retries=${retry_count}
Suite Setup                     Setup Browser
Suite Teardown                  CloseAllBrowsers



*** Test Cases ***

Validate Creation of Business Account : Save and New Button 
    # Author = Amol
    #TC=93877
    [Documentation]             Save and New Of the Created Account
    [Tags]                      Smoke_Test_LGO_Admitted     Smoke_Test
    Creating a new Account with Save and new


Validate Creation of Business Account : Cancel Button 
    # Author = Amol
    #TC=93879
    [Documentation]             Save and New Of the Created Account
    [Tags]                      Smoke_Test_LGO_Admitted     Smoke_Test
    Creation of Account Cancel

Validate when check box for "Mailing same as billing address" is checked - Mailing and Billing address are same on the Details tab after saving the account info    
    # Author = Amol
    #TC=93885
    [Documentation]             Save and New Of the Created Account
    [Tags]                      Smoke_Test_LGO_Admitted     Smoke_Test
    Creating a new Account
    Verify Account Created Fields


Validate the Buttons acc - Follow, Edit, Delete 
    # Author = Amol
    #TC=93951
    [Tags]                      Smoke_Test_LGO_Admitted     Smoke_Test

    Follow Edit and Delete Account Click


Validate Creation of Business Account : Save Button 
    # Author = Amol
    #TC=93876
    [Documentation]             Creating an Account and Verifying
    [Tags]                      Smoke_Test_LGO_Admitted     Smoke_Test
    #Validate Account Elements
    Creating a new Account
    Verify Account Created Fields
    #Delete Account Click

Validate Editing the Details Tab after the Account Creation 
    # Author = Amol
    #TC=93878
    [Documentation]             Editing Of the Created Account
    [Tags]                      Smoke_Test_LGO_Admitted     Smoke_Test
    Creating a new Account
    Editing the Account

