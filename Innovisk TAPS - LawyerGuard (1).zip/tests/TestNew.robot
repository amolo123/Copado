*** Settings ***
Resource                 ../resources/common.robot
Documentation            New test suite
Library                  QWeb
Library                  ../libraries/MailLib.py     ${tenant_id}                ${client_id_mail}           ${client_secret_mail}
Library                  String
Library                  QForce
Library                  ${CURDIR}/../libraries/graph.py
Resource                 ${CURDIR}/../resources/graph.resource
#Library                 RetryFailed                 global_retries=2


*** Test Cases ***
Try it out
    Log To Console       Skip This As Pass

#     ${messages}=         get_last_mail               QA.Testing.Inbox@innovisk.global                        #QA.Testing.Inbox@innovisk.global
#     ${messages2}=        get_all_mail                Copado.Tester1@jisc.ac.uk
#     ${links}=            get_mail_links              Copado.Tester1@jisc.ac.uk
#     send_mail_message    QA.Testing.Inbox@innovisk.global                        CRT Robot                   QA.Testing.Inbox@innovisk.global                     Copado Tester1              CRT Send Mail Test 1    Body text with link <a href\="https://www.google.com">google</a> and more
#     Log to Console       ${messages}
#     Log to Console       ${messages2}
#     Log to Console       ${links}


# Check Email Content
#     ${body}=             Get Email Content           ${client_id_mail}           ${client_secret_mail}       ${tenant_id}             QA.Testing.Inbox@innovisk.global                        CRT Send Mail Test 1
#     Evaluate             "${body}" == "${email_body}"
#     Log To Console       ${body}
#     Should Contain       ${body}                     text with link