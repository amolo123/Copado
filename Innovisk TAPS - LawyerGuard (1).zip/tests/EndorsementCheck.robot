*** Settings ***
Resource                        ../resources/common.robot
Resource                        ../PageObjects/PageObjects_Account.robot
Resource                        ../PageObjects/PageObjects_HomePage.robot
Resource                        ../PageObjects/PageObjects_Submission.robot
Resource                        ../PageObjects/PageObjects_InusredInfo.robot
Resource                        ../PageObjects/PageObjects_SubmissionInit.robot
Resource                        ../PageObjects/PageObjects_SubmissionInfo.robot
Resource                        ../PageObjects/PageObjects_UnderwrittingAnalysis.robot
Resource                        ../PageObjects/PageObjects_CheckEndorsements.robot
Library                         RetryFailed                 global_retries=${retry_count}
Suite Setup                     Setup Browser
Suite Teardown                  CloseAllBrowsers


#Variables                      Statevariables.py


*** Test Cases ***

Validate endorsements and Endosement picker 
    # Author = Amol Gaymukhe
    #TC=93946
    [Documentation]             Entering                    Details in Insured Info Tab
    [Tags]                      Smoke_Test_LGO_Admitted     Smoke_Test

    Creating a new Account
    Validate LaweyrGuard New submission Fields
    VerifyText                  Underwriter Workbench
    Add Account name on Insured info page
    Click on save button
    Add Attorney
    Click on NEXT:Submission Info
    Select broker Contact Source
    Add Details In SubmissionInfo Page
    ClickText                   NEXT:Underwriter Analysis >
    VerifyText                  Underwriting Analysis
    Add Area Of Practice
    ClickText                   Qualify Submission
    Sleep                       30s
    ClickElement                //lightning-icon[@title\='Endorsements']
    # For VA Dont change#########
    Check Endorsements According to State                   VA

    # # For Other states### Can update and add#########

    Select State                Kansas

    Check Endorsements According to State                   KS

    Select State                New York

    Check Endorsements According to State                   NY

    Select State                Florida

    Check Endorsements According to State                   FL


    Select State                California

    Check Endorsements According to State                   CA

    Select State                Connecticut

    Check Endorsements According to State                   CT

    # For any other State################



