*** Settings ***
Library                         QWeb
Library                         QForce
#Library                        QVision
Library                         FakerLibrary
Library                         String
Library                         BuiltIn
Library                         DateTime
Resource                        ../resources/common.robot
Resource                        ../PageObjects/PageObjects_Account.robot
Resource                        ../PageObjects/PageObjects_HomePage.robot
Resource                        ../PageObjects/PageObjects_Submission.robot
Resource                        ../PageObjects/PageObjects_InusredInfo.robot
Library                         RetryFailed                 global_retries=${retry_count}
Suite Setup                     Setup Browser
Suite Teardown                  CloseAllBrowsers


*** Test Cases ***

Verify Save Button and Next Submission Info Functionality on Insured Info Page 
    [Documentation]             Functionality on Insured Info Page
    [Tags]                      Smoke_Test_LGO_Admitted     Smoke_Test

    # Author = Vighanesh Surve
    #TC=93926
    Creating a new Account
    Validate LaweyrGuard New submission Fields
    VerifyText                  Underwriter Workbench
    Validate field on Insured info
    Validate Underwriting Comments on Insured info page
    Validate Territory data on Insured Info Page
    Add Account name on Insured info page
    Click on save button
    Add Attorney
    #Validate Billing address on Insured info page
    Click on NEXT:Submission Info

Validate Label on Attorneys Page
    [Documentation]             Label on Attorneys Page
    [Tags]                      Smoke_Test_LGO_Admitted     Smoke_Test

    # Author = Vighanesh Surve
    #TC=93926

    Creating a new Account
    Validate LaweyrGuard New submission Fields
    VerifyText                  Underwriter Workbench
    Add Account name on Insured info page
    ClickText                   New                         partial_match=False
    Validate component of Attroneys Page

Verify New Button Functionality on the Attorney Section 

    [Documentation]             Functionality on the Attorney Section
    [Tags]                      Smoke_Test_LGO_Admitted     Smoke_Test

    # Author = Vighanesh Surve
    #TC=93927 , 93928 , 93931 , 93931 , 93933
    Creating a new Account
    Validate LaweyrGuard New submission Fields
    VerifyText                  Underwriter Workbench
    Add Account name on Insured info page
    Edit and Delete Attroney Details
