*** Settings ***
Resource                        ../resources/common.robot
Resource                        ../PageObjects/PageObjects_Account.robot
Resource                        ../PageObjects/PageObjects_HomePage.robot
Resource                        ../PageObjects/PageObjects_Submission.robot
Resource                        ../PageObjects/PageObjects_InusredInfo.robot
Library                         RetryFailed                 global_retries=${retry_count}
Suite Setup                     Setup Browser
Suite Teardown                  CloseAllBrowsers


*** Test Cases ***
Validate Record Type and Product on the New Submission Pop Up 
    [Documentation]             Product on the New Submission Pop Up
    [Tags]                      Smoke_Test_LGO_Admitted     Smoke_Test
    # Author = Vighanesh Surve
    #TC=93865

    Creating a new Account
    Validate LaweyrGuard New submission Fields
    VerifyText                  Underwriter Workbench
    # Add Account name on Insured info page
    # Click on save button
    # PickList                  Province                    Colorado
    # TypeText                  Street                      1102 Village view drive
    # TypeText                  City                        thurman
    # TypeText                  PostalCode                  77182
    # Click on save button



Check the functionality of Cancel button on New Submission Pop Up.    
    # Author = Amol
    # TC= 93868
    [Documentation]             Validating Submision Popup Fields
    [Tags]                      Smoke_Test_LGO_Admitted     Smoke_Test
    Checking Cancel Button On New Submission


Check the functionality of Next Button on New Submission Pop-Up 
    # Author = Amol
    # TC= 93869
    [Documentation]             Validating Submision Popup Fields
    [Tags]                      Smoke_Test_LGO_Admitted     Smoke_Test
    Validate LaweyrGuard New submission Fields
    VerifyText                  Underwriter Workbench