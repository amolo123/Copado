*** Settings ***
Library                         QForce
#Library                        QVision
Library                         FakerLibrary
Library                         String
Library                         BuiltIn
Library                         DateTime
Library                         RetryFailed                 global_retries=${retry_count}
Resource                        ../resources/common.robot
Resource                        ../PageObjects/PageObjects_Account.robot
Resource                        ../PageObjects/PageObjects_HomePage.robot
Resource                        ../PageObjects/PageObjects_Submission.robot
Resource                        ../PageObjects/PageObjects_InusredInfo.robot
Resource                        ../PageObjects/PageObjects_SubmissionInit.robot
Resource                        ../PageObjects/PageObjects_SubmissionInfo.robot
Resource                        ../PageObjects/PageObjects_UnderwrittingAnalysis.robot
Resource                        ../PageObjects/PageObjects_CompareAndRateQuote.robot
Suite Setup                     Setup Browser
Suite Teardown                  CloseAllBrowsers



*** Test Cases ***

Verify Email Functionality
    # #Author=Amol Gaymukhe
    # [Documentation]             Functionality on Insured Info Page
    # [Tags]                      Account                     regression                smoke
    Log To Console    Skip This As Pass
    # Creating a new Account
    # Validate LaweyrGuard New submission Fields
    # VerifyText                  Underwriter Workbench
    # Add Account name on Insured info page
    # # VerifyInputValue          Contact Record Type         Attorney                  timeout=2s
    # Click on save button
    # Add Attorney
    # Click on NEXT:Submission Info
    # Select broker Contact Source
    # Add Details In SubmissionInfo Page
    # ClickText                   NEXT:Underwriter Analysis >
    # VerifyText                  Underwriting Analysis
    # Add Area Of Practice
    # ClickText                   Qualify Submission
    # Sleep                       30s
    # ClickText                   Send Mail
    # VerifyText                  Generate Email Template

    # DropDown                    Select a Template:          [[14]]
    # VerifyText                  Send To Email Address:      delay=25s                 timeout=10s
    # PressKey                    CC:                         {CONTROL + A + DELETE}
    # PressKey                    BCC:                        {CONTROL + A + DELETE}
    # ClickText                   Send                        anchor=Cancel