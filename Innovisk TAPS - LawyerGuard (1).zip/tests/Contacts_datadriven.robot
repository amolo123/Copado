*** Settings ***
Resource                      ../resources/common.robot
Resource                      ../PageObjects/PageObjects_Account.robot
Resource                      ../PageObjects/PageObjects_HomePage.robot
Resource                      ../PageObjects/PageObjects_Submission.robot
Library                       RetryFailed                 global_retries=${retry_count}
Suite Setup                   Run Keywords                Setup Browser               Creating an Excel Test
Suite Teardown                CloseAllBrowsers
Library                       DataDriver                  file=${CURDIR}/../resources/compareImport.csv         #include=tagtoinclude                               exclude=tagtoexclude
Test Template                 Iterate CSV File

*** Test Cases ***
Upload File     ${Status}                   ${Attorney Last Name}       ${Attorney First Name}    ${Hire Date M/D/Y}      ${Expiring Annual Hours Worked}                         ${Current Annual Hours Worked}                 ${Annual Hours}          ${Admitted to Bar - State}               ${Admitted to BarMDY}    ${Position}    ${Additional comments}    ${Salesforce id}



*** Keywords ***
Creating an Excel Test
    #Author=Amol

    Home
    Creating a new Account
    Sleep                     20s
    ClickText                 Accounts
    VerifyText                Recently Viewed             anchor=span
    VerifyText                Recently Viewed             anchor=span
    #${uniquename1}=          GetText                     (//span[@data-cell-type\="lstOutputLookup"])[1]
    #ClickText                ${uniquename1}
    ClickElement              //a[contains(@href, '/lightning/r/')][1]
    ClickText                 Attorney Import
    UseModal                  On
    UploadFile                Upload Files                ${CURDIR}/../resources/ImportA.csv
    ClickText                 Yes                         delay=3s
    sleep                     30s
    ClickText                 Contacts                    anchor=Notes                delay=3s
    ClickElement              //a//span[text()\='View All']                           delay=2s
    UseTable                  Email

    # Repeat Keyword          5 times                     Scroll                      dt-outer-container        bottom                  tag=div                     timeout=2
    # Repeat Keyword          5 times                     Scroll                      dt-outer-container        Top                     tag=div                     timeout=2
    Set Suite Variable        ${rowno}                    2
Iterate CSV File
    [Arguments]               ${Status}                   ${Attorney Last Name}       ${Attorney First Name}    ${Hire Date M/D/Y}      ${Expiring Annual Hours Worked}                         ${Current Annual Hours Worked}                 ${Annual Hours}          ${Admitted to Bar - State}               ${Admitted to BarMDY}    ${Position}    ${Additional comments}    ${Salesforce id}
    ${rand_var}=              Set Variable                ${rowno}
    ${rowno}=                 Evaluate                    ${rowno}+1
    Set Suite Variable        ${rowno}

    #${rowno}=                Set Variable                27
    # IF                      "${rand_var}"=="27"
    #                         ScrollText                  Ayesha
    # ELSE IF                 "${rand_var}"=="35"
    #                         ScrollText                  Rosita
    # ELSE IF                 "${rand_var}"=="47"
    #                         ScrollText                  Athar
    # END

    Scroll Text               ${Attorney Last Name}
    VerifyTable               r${rand_var}/c?Contact Name                             Open ${Attorney First Name} ${Attorney Last Name} Preview
    VerifyTable               r${rand_var}/c?Status       ${Status}
