*** Settings ***
Library                         QWeb
Library                         QForce
Library                         FakerLibrary
Library                         String
Library                         BuiltIn
Library                         DateTime
Library                         RetryFailed                 global_retries=${retry_count}
Resource                        ../resources/common.robot
Resource                        ../PageObjects/PageObjects_Account.robot
Resource                        ../PageObjects/PageObjects_HomePage.robot
Resource                        ../PageObjects/PageObjects_Submission.robot
Resource                        ../PageObjects/PageObjects_InusredInfo.robot
Resource                        ../PageObjects/PageObjects_SubmissionInit.robot
Resource                        ../PageObjects/PageObjects_SubmissionInfo.robot
Resource                        ../PageObjects/PageObjects_UnderwrittingAnalysis.robot
Resource                        ../PageObjects/PageObjects_CompareAndRateQuote.robot
Resource                        ../PageObjects/PageObjects_PolicyPage.robot
Resource                        ../PageObjects/PageObjects_Quote.robot

Suite Setup                     Setup Browser
Suite Teardown                  CloseAllBrowsers




*** Test Cases ***

Verify Policy Page with all tabs, fields and Buttons.
    #TCID=94406
    #Author=Amol Gaymukhe
    [Documentation]             Functionality on Insured Info Page
    [Tags]                      Smoke_Test_LGO_Admitted     Smoke_Test

    Creating a new Account
    Validate LaweyrGuard New submission Fields
    VerifyText                  Underwriter Workbench
    Add Account name on Insured info page
    Click on save button
    Add Attorney
    Click on NEXT:Submission Info
    Select broker Contact Source
    Add Details In SubmissionInfo Page
    ClickText                   NEXT:Underwriter Analysis >
    VerifyText                  Underwriting Analysis
    Add Area Of Practice
    Sleep                       20s
    ClickText                   Qualify Submission
    Sleep                       30s
    RefreshPage
    Validate Header Fields On Compare and Rate quote
    Click On Bind
    Validate Policy Screen Static Elements
    Validate Policy Screen Dynamic Elements
    Click Quote On Policy Page and Select Quote
    Validate Quote Screen Static Elements Admitted
    Validate Quote Screen Dynamic Elements