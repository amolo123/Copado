*** Settings ***
Library                         QWeb
Library                         QForce
Library                         String
Library                         FakerLibrary
Library                         Collections
Library                         DateTime
Library                         Process
Library                         OperatingSystem
Library                         ../libraries/read_docx.py




*** Variables ***
# IMPORTANT: Please read the readme.txt to understand needed variables and how to handle them!!
${BROWSER}                      chrome
#${username}                    pace.delivery1@qentinel.com.demonew
#${login_url}                   https://qentinel--demonew.my.salesforce.com/            # Salesforce instance. NOTE: Should be overwritten in CRT variables
${home_url}                     ${login_url}/lightning/page/home
${broker_contact}               Automation LGO

*** Keywords ***
Setup Browser
    # Setting search order is not really needed here, but given as an example
    # if you need to use multiple libraries containing keywords with duplicate names
    Set Library Search Order    QForce                      QWeb
    Open Browser                about:blank                 ${BROWSER}                  #prefs="autofill.profile_enabled":false, "autofill.credit_card_enabled":false
    SetConfig                   LineBreak                   ${EMPTY}                    #\ue000
    Evaluate                    random.seed()               random                      # initialize random generator
    SetConfig                   DefaultTimeout              30s                         #sometimes salesforce is slow
    # adds a delay of 0.3 between keywords. This is helpful in cloud with limited resources.
    #SetConfig                  Delay                       0.3

End suite
    Close All Browsers


Login
    [Documentation]             Login to Salesforce instance
    GoTo                        ${login_url}
    TypeText                    Username                    ${username}                 delay=1
    TypeText                    Password                    ${password}
    ClickText                   Log In
    # We'll check if variable ${secret} is given. If yes, fill the MFA dialog.
    # If not, MFA is not expected.
    # ${secret} is ${None} unless specifically given.
    # ${MFA_needed}=            Run Keyword And Return Status                           Should Not Be Equal         ${None}                ${secret}
    # Run Keyword If            ${MFA_needed}               Fill MFA

    Sleep                       5s
    ${MFA_Text_One}=            IsText                      Use the authenticator app on your mobile device to generate a verification code.
    IF                          "${MFA_Text_One}" == "True"
        ${MFA_needed}=          Run Keyword And Return Status                           Should Not Be Equal         ${None}                ${secret}
        Run Keyword If          ${MFA_needed}               Fill MFA
        Log To Console          Login using MFA
    END



Fill MFA
    ${mfa_code}=                GetOTP                      ${username}                 ${secret}                   ${login_url}
    TypeSecret                  Verification Code           ${mfa_code}
    ClickText                   Verify


Home
    [Documentation]             Navigate to homepage, login if needed
    GoTo                        ${home_url}
    ${login_status} =           IsText                      To access this page, you have to log in to Salesforce.                         2
    Run Keyword If              ${login_status}             Login
    ClickText                   Home
    VerifyTitle                 Home | Salesforce

Click on save button
    ClickText                   Save
    VerifyText                  Success                     anchor=Account updated

Click on save button SL
    ClickText                   Save
    VerifyText                  Territory is required for this state                    anchor=Warning

Click on NEXT:Submission Info
    ClickText                   NEXT:Submission Info >




Get WORD document and attach it to log
    [Documentation]             This keyword will read the downloaded document
    ...                         Will store it in a suite variable ${read_doc}
    ...                         And will attach it to the execution log
    Sleep                       10s

    IF                          "${EXECDIR}"=="/home/executor/execution"
    # normal test run environment
        ${downloads_folder}=    Set Variable                /home/executor/Downloads
    ELSE                        # Live Testing environment
        ${downloads_folder}=    Set Variable                /home/services/Downloads
    END
    Wait Until Keyword Succeeds                             30 sec                      2 sec                       Directory Should Exist    ${downloads_folder}
    @{list_files}               List Files In Directory     ${downloads_folder}         *.docx
    #@{list_files}              List Files In Directory     ${OUTPUT_DIR}               *.docx
    Log To Console              ${list_files}[0]
    Move File                   ${downloads_folder}/${list_files}[0]                    ${OUTPUT_DIR}
    Sleep                       2s
    #File Should Exist          ${downloads_folder}/${list_files}[0]
    #read Docx File             ${downloads_folder}/${list_files}[0]
    Log To Console              ${OUTPUT_DIR}/${list_files}[0]
    ${read_doc}=                read docx file              ${OUTPUT_DIR}/${list_files}[0]
    Log To Console              ${read_doc}
    #${testdoc}=                Get File                    ${OUTPUT_DIR}/${list_files}[0]
    # Attach file to log
    #Copy File                  ${downloads_folder}${list_files}[1]                     ${OUTPUT DIR}
    Set Suite Variable          ${read_doc}

    # Example of custom keyword with robot fw syntax
    # VerifyStage
    #                           [Documentation]             Verifies that stage given in ${text} is at ${selected} state; either selected (true) or not selected (false)
    #                           [Arguments]                 ${text}                     ${selected}=true
    #                           VerifyElement               //a[@title\="${text}" and (@aria-checked\="${selected}" or @aria-selected\="${selected}")]


    # NoData
    #                           VerifyNoText                ${data}                     timeout=3                   delay=2


    # DeleteAccounts
    #                           [Documentation]             RunBlock to remove all data until it doesn't exist anymore
    #                           ClickText                   ${data}
    #                           ClickText                   Delete
    #                           VerifyText                  Are you sure you want to delete this account?
    #                           ClickText                   Delete                      2
    #                           VerifyText                  Undo
    #                           VerifyNoText                Undo
    #                           ClickText                   Accounts                    partial_match=False


    # DeleteLeads
    #                           [Documentation]             RunBlock to remove all data until it doesn't exist anymore
    #                           ClickText                   ${data}
    #                           ClickText                   Delete
    #                           VerifyText                  Are you sure you want to delete this lead?
    #                           ClickText                   Delete                      2
    #                           VerifyText                  Undo
    #                           VerifyNoText                Undo
    #                           ClickText                   Leads                       partial_match=False

Expand Subjectivities
    #Author=Amol
    [Documentation]             Expand Subjectivities
    ${subjectivity_flag}=       GetAttribute                //span[@title\='Subjectivities']//ancestor::button      aria-expanded
    Log To Console              ${subjectivity_flag}

    IF                          '${subjectivity_flag}' == 'false'
        ClickElement            //span[text()\='Subjectivities']//parent::button
    ELSE
        Log To Console          Subjectivities Accordian already Opened
    END