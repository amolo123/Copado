*** Settings ***
Library                  QVision
Library                  QForce
Library                  String
Library                  FakerLibrary
Library                  Collections
Library                  DateTime
Library                  Process
Library                  OperatingSystem

*** Variables ***


*** Keywords ***
Select PDF Page 2 for account summary
    [Documentation]      Selects The Page Of The PDF
    [Tags]               PDF Page
    [Arguments]          ${anchor_Q}
    #Author=Amol Gaymukhe
    QVision.ClickText    1                        below=12              #right=10
    Sleep                3s

Select PDF Page 3 for account summary
    [Documentation]      Selects The Page Of The PDF
    [Tags]               PDF Page
    [Arguments]          ${anchor_Q}
    #Author=Amol Gaymukhe
    QVision.ClickText    2                        below=12              #right=10
    Sleep                3s

Select PDF Page 4 for account summary
    [Documentation]      Selects The Page Of The PDF
    [Tags]               PDF Page
    [Arguments]          ${anchor_Q}
    #Author=Amol Gaymukhe
    QVision.ClickText    3                        below=8               #right=10
    Sleep                3s

Select PDF Page 5 for account summary
    [Documentation]      Selects The Page Of The PDF
    [Tags]               PDF Page
    [Arguments]          ${anchor_Q}
    #Author=Amol Gaymukhe
    QVision.ClickText    4                        below=12              #right=10
    Sleep                3s

Select PDF Page 6 for account summary
    [Documentation]      Selects The Page Of The PDF
    [Tags]               PDF Page
    [Arguments]          ${anchor_Q}
    #Author=Amol Gaymukhe      
    PageDown
    QVision.ClickText    5                        below=18            
    Sleep                3s
