*** Settings ***
Library                  QVision
Library                  QForce
Library                  String
Library                  FakerLibrary
Library                  Collections
Library                  DateTime
Library                  Process
Library                  OperatingSystem

*** Variables ***


*** Keywords ***

Select PDF Page 2
    [Documentation]      Selects The Page Of The PDF
    [Tags]               PDF Page
    [Arguments]          ${anchor_Q}
    #Author=Amol Gaymukhe
    QVision.ClickText    1                  anchor=${anchor_Q}    below=12     #right=10
    Sleep                15s




Select PDF Page 3
    [Documentation]      Selects The Page Of The PDF
    [Tags]               PDF Page
    [Arguments]          ${anchor_Q}

    #Author=Amol Gaymukhe
    QVision.ClickText    2                  anchor=${anchor_Q}    below=10     #left=10
    Sleep                15s



Select PDF Page 4
    [Documentation]      Selects The Page Of The PDF
    [Tags]               PDF Page
    [Arguments]          ${anchor_Q}

    #Author=Amol Gaymukhe
    QVision.ClickText    3                  anchor=${anchor_Q}    below=10     #left=10
    Sleep                15s


Select PDF Page 5
    [Documentation]      Selects The Page Of The PDF
    [Tags]               PDF Page
    [Arguments]          ${anchor_Q}

    #Author=Amol Gaymukhe
    QVision.ClickText    3                  anchor=${anchor_Q}    below=100    #left=10
    Sleep                15s

Select PDF Page 6
    [Documentation]      Selects The Page Of The PDF
    [Tags]               PDF Page
    [Arguments]          ${anchor_Q}

    #Author=Amol Gaymukhe
    QVision.ClickText    6                  anchor=${anchor_Q}    below=100    #left=10
    Sleep                15s


Select PDF Page 2 for indication
    [Documentation]      Selects The Page Of The PDF
    [Tags]               PDF Page
    [Arguments]          ${anchor_Q}
    #Author=Amol Gaymukhe
    QVision.ClickText    1                  anchor=LawyerGuard    below=20     #right=10
    Sleep                3s


Click on full Screen button
    [Documentation]      Scroll to next page

    QWeb.ClickText       Account Summary
    QWeb.ClickText       Fullscreen

Scroll page
    [Arguments]          ${TextToScroll}
    QWeb.ScrollTo        ${TextToScroll}

         

