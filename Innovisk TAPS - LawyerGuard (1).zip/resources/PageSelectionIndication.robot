*** Settings ***
Library                  QVision
Library                  QForce
Library                  String
Library                  FakerLibrary
Library                  Collections
Library                  DateTime
Library                  Process
Library                  OperatingSystem

*** Variables ***


*** Keywords ***
Select PDF Page 2 for indication
    [Documentation]      Selects The Page Of The PDF
    [Tags]               PDF Page
    [Arguments]          ${anchor_Q}
    #Author=Amol Gaymukhe
    QVision.ClickText    1                        anchor=LawyerGuard    below=20     #right=10
    Sleep                3s
