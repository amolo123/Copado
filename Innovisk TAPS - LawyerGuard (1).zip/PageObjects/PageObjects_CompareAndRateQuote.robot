*** Settings ***
Library                         QWeb
Library                         QForce
#Library                        QVision
Library                         FakerLibrary
Library                         String
Library                         BuiltIn
Library                         DateTime
Library                         QImage
Library                         CopadoAI
Library                         Screenshot
Resource                        ../resources/common.robot
Resource                        ../PageObjects/PageObjects_Account.robot

Library                         ../libraries/MailLib.py     ${tenant_id}                ${client_id_mail}           ${client_secret_mail}

Library                         ${CURDIR}/../libraries/graph.py
Resource                        ${CURDIR}/../resources/graph.resource



*** Keywords ***

Validate Header Fields On Compare and Rate quote
    #Author=Amol
    [Documentation]             Validating Fields on Compare and Rate quote
    [Tags]                      Validating

    VerifyElement               //button[@title\='Scroll to Top']
    VerifyElement               //button[@title\='Scroll to Bottom']
    VerifyElement               //button[@title\='Scroll to Left']
    VerifyElement               //button[@title\='Scroll to Right']
    VerifyText                  Bulk Rate
    VerifyText                  Justification
    VerifyText                  Generate Document
    VerifyText                  Refer
    VerifyText                  New Quote

    ClickElement                //button[@title\='Scroll to Bottom']
    ClickElement                //button[@title\='Scroll to Top']
    ClickElement                //button[@title\='Scroll to Right']
    ClickElement                //button[@title\='Scroll to Left']
    ${orignal_premium}=         GetText                     (//div[@data-id\='QuoteData']//lightning-input)[8]
    ${premiumonquote}=          Set Variable                ${orignal_premium}
    Set Global Variable         ${premiumonquote}
    Log To Console              ------Header Fields Validated Successfully-------



Verify SRP Value
    #Author=Amol
    [Documentation]             Validating SRP Flow
    [Tags]                      SRP
    VerifyText                  Schedule Rating Plan        timeout=20s
    ClickElement                //input[contains(@name,'-Firm History / Qualifications / Expertise')]
    PressKey                    //input[contains(@name,'-Firm History / Qualifications / Expertise')]               {CONTROL + A + DELETE}
    TypeText                    //input[contains(@name,'-Firm History / Qualifications / Expertise')]               0.025
    Log To Console              ------SRP Values input Successfully-------

    ClickElement                (//lightning-icon[@icon-name\='utility:save'])[1]       timeout=5s
    VerifyText                  Success                     anchor=Update records successfully!
    ClickElement                (//button[@title\='Rating'])[1]
    VerifyText                  Success                     anchor=Rating successfully!                             timeout=55s
    Sleep                       30s
    ClickElement                //lightning-icon[@title\='Finalize Quote']              delay=2s
    #VerifyText                 Warning                     anchor=Rating successfully!
    VerifyText                  Warning                     anchor=Please select justification reason.              timeout=55s
    Log To Console              ------Rating and Finalize Warning message Validated-------

    ClickText                   Justification
    UseModal                    On
    UseTable                    Schedule Rating Plan Characteristics
    ClickCell                   r1c3                        index=1
    DropDown                    //select                    Newly established firm      anchor=1
    ClickElement                //button[@title\='Close']
    Log To Console              ------ Justification Added Successfully-------

    ClickElement                (//button[@title\='Rating'])[1]
    VerifyText                  Success                     anchor=Rating successfully!                             timeout=45s
    ClickElement                //lightning-icon[@title\='Finalize Quote']
    VerifyText                  Success                     anchor=Finalize quote successfully!                     timeout=45s
    Log To Console              ------ SRP Was Successful -------



Verify Bulk Rate
    #Author=Amol
    [Documentation]             Validating Bulk Flow
    [Tags]                      Bulkrate
    ClickElement                //button[@title\='Clone Quote']
    ClickElement                //button[@title\='Clone Quote']                         delay=5s
    ClickText                   Bulk Rate
    ClickElement                //span[text()\='Select All']
    ClickText                   Bulk Rate Selected Quotes
    Log To Console              ------ Bulk Rate Was Successful -------


Generate Document In Quoted 
    #Author=Amol
    [Documentation]             Generating Document
    [Tags]                      Doc
    [Arguments]                 ${document_name}
    ClickElement                (//button[@title\='Rating'])[1]
    VerifyText                  Success                     anchor=Rating successfully!                             timeout=60s              partial_match=false
    Sleep                       20s
    #Getting PDF variables for Policy period
    ${orignal_premium}=         GetText                     (//div[@data-id\='QuoteData']//lightning-input)[8]
    ${pdf_premium}=             Set Variable                ${orignal_premium}
    Set Global Variable         ${pdf_premium}
    Log To Console              ${pdf_premium}
    ${state_taxes}=             GetText                     (//div[@data-id\='QuoteData']//lightning-input)[6]
    ${pdf_statetaxes}=          Set Variable                ${state_taxes}
    Set Global Variable         ${pdf_statetaxes}
    ${fromdate}=                GetInputValue               (//div[@data-id\='QuoteData']//lightning-input)[1]
    ${todate}=                  GetInputValue               (//div[@data-id\='QuoteData']//lightning-input)[2]
    Log To Console              ${fromdate}
    Log To Console              ${todate}
    ${fromdate1}=               Convert Date                ${fromdate}                 result_format=%B %-d, %Y
    ${todate1}=                 Convert Date                ${todate}                   result_format=%B %-d, %Y
    ${pdf_policyperiod}=        Set Variable                ${fromdate1} to ${todate1}
    Set Global Variable         ${pdf_policyperiod}
    Set Global Variable         ${fromdate1}
    Set Global Variable         ${todate1}
    ClickElement                //lightning-icon[@title\='Finalize Quote']              delay=2s
    VerifyText                  Success                     anchor=Finalize quote successfully!                     timeout=120s             partial_match=false
    Sleep                       25s
    ClickText                   Generate Document
    Sleep                       3s
    ClickElement                //button[@name\='Document Type']                        delay=2s
    ClickText                   ${document_name}
    ClickText                   Generate                    anchor=Cancel
    VerifyText                  Success                     anchor=Document generated successfully!                 timeout=60s              partial_match=false
    Sleep                       25s
    Log To Console              ------ Document Genearted Successful -------


Generate Document In Quoted after Renewal
    #Author=Amol
    [Documentation]             Generating Document
    [Tags]                      Doc
    [Arguments]                 ${document_name}
    ClickElement                (//button[@title\='Rating'])[3]
    VerifyText                  Success                     anchor=Rating successfully!                             timeout=55s

    #Getting PDF variables for Policy period
    ${orignal_premium}=         GetText                     (//div[@data-id\='QuoteData']//lightning-input)[19]
    ${pdf_premium}=             Set Variable                ${orignal_premium}
    Set Global Variable         ${pdf_premium}

    ${state_taxes}=             GetText                     (//div[@data-id\='QuoteData']//lightning-input)[17]
    ${pdf_statetaxes}=          Set Variable                ${state_taxes}
    Set Global Variable         ${pdf_statetaxes}

    ${fromdate}=                GetInputValue               (//div[@data-id\='QuoteData']//lightning-input)[12]
    ${todate}=                  GetInputValue               (//div[@data-id\='QuoteData']//lightning-input)[13]
    Log To Console              ${fromdate}
    Log To Console              ${todate}
    ${fromdate1}=               Convert Date                ${fromdate}                 result_format=%B %-d, %Y
    ${todate1}=                 Convert Date                ${todate}                   result_format=%B %-d, %Y

    ${pdf_policyperiod}=        Set Variable                ${fromdate1} to ${todate1}
    Set Global Variable         ${pdf_policyperiod}

    ClickElement                //lightning-icon[@title\='Finalize Quote']              delay=2s
    VerifyText                  Success                     anchor=Finalize quote successfully!                     timeout=55s
    ClickText                   Generate Document
    ClickElement                //button[@name\='Document Type']                        delay=2s
    ClickText                   ${document_name}
    ClickText                   Generate                    anchor=Cancel
    VerifyText                  Success                     anchor=Document generated successfully!                 timeout=55s
    Log To Console              ------ Document Genearted Successful -------


Generate Document In Rated 
    #Author=Amol
    [Documentation]             Generating Document
    [Tags]                      Doc
    [Arguments]                 ${document_name}
    ClickElement                (//button[@title\='Rating'])[1]
    VerifyText                  Success                     anchor=Rating successfully!                             timeout=55s              partial_match=false
    ClickText                   Generate Document           delay=2s
    ClickElement                //button[@name\='Document Type']                        delay=2s
    ClickText                   ${document_name}
    ClickText                   Generate                    anchor=Cancel
    VerifyText                  Success                     anchor=Document generated successfully!                 timeout=55s


    ${orignal_premium}=         GetText                     (//div[@data-id\='QuoteData']//lightning-input)[8]
    ${pdf_premium}=             Set Variable                ${orignal_premium}
    Set Global Variable         ${pdf_premium}
    ${state_taxes}=             GetText                     (//div[@data-id\='QuoteData']//lightning-input)[6]
    ${pdf_statetaxes}=          Set Variable                ${state_taxes}
    Set Global Variable         ${pdf_statetaxes}

    ${fromdate}=                GetInputValue               (//div[@data-id\='QuoteData']//lightning-input)[1]
    ${todate}=                  GetInputValue               (//div[@data-id\='QuoteData']//lightning-input)[2]
    Log To Console              ${fromdate}
    Log To Console              ${todate}
    ${fromdate1}=               Convert Date                ${fromdate}                 result_format=%B %-d, %Y
    ${todate1}=                 Convert Date                ${todate}                   result_format=%B %-d, %Y
    ${fromdate2}=               Convert Date                ${fromdate}                 result_format=%m/%d/%Y
    ${todate2}=                 Convert Date                ${todate}                   result_format=%m/%d/%Y
    ${pdf_policyperiod}=        Set Variable                ${fromdate1} to ${todate1}
    ${pdf_policyperiod2}=       Set Variable                ${fromdate2} - ${todate2}
    ${pdf_policyperiod3}=       Set Variable                ${fromdate1} To: ${todate1}
    Set Global Variable         ${pdf_policyperiod}
    Set Global Variable         ${pdf_policyperiod2}
    Set Global Variable         ${pdf_policyperiod3}
    Set Global Variable         ${todate2}
    Set Global Variable         ${fromdate2}
    Log To Console              ------ Document Genearted Successfully -------


Generate Document In Rated After Renewal 
    #Author=Amol
    [Documentation]             Generating Document
    [Tags]                      Doc
    [Arguments]                 ${document_name}
    ClickElement                (//button[@title\='Rating'])[3]
    VerifyText                  Success                     anchor=Rating successfully!                             timeout=55s
    ClickText                   Generate Document           delay=2s
    ClickElement                //button[@name\='Document Type']                        delay=2s
    ClickText                   ${document_name}
    ClickText                   Generate                    anchor=Cancel
    VerifyText                  Success                     anchor=Document generated successfully!                 timeout=55s


    ${orignal_premium}=         GetText                     (//div[@data-id\='QuoteData']//lightning-input)[19]
    ${pdf_premium}=             Set Variable                ${orignal_premium}
    Set Global Variable         ${pdf_premium}
    ${state_taxes}=             GetText                     (//div[@data-id\='QuoteData']//lightning-input)[17]
    ${pdf_statetaxes}=          Set Variable                ${state_taxes}
    Set Global Variable         ${pdf_statetaxes}

    ${fromdate}=                GetInputValue               (//div[@data-id\='QuoteData']//lightning-input)[12]
    ${todate}=                  GetInputValue               (//div[@data-id\='QuoteData']//lightning-input)[13]
    Log To Console              ${fromdate}
    Log To Console              ${todate}
    ${fromdate1}=               Convert Date                ${fromdate}                 result_format=%B %-d, %Y
    ${todate1}=                 Convert Date                ${todate}                   result_format=%B %-d, %Y
    ${fromdate2}=               Convert Date                ${fromdate}                 result_format=%m/%d/%Y
    ${todate2}=                 Convert Date                ${todate}                   result_format=%m/%d/%Y
    ${pdf_policyperiod}=        Set Variable                ${fromdate1} to ${todate1}
    ${pdf_policyperiod2}=       Set Variable                ${fromdate2} - ${todate2}
    Set Global Variable         ${pdf_policyperiod}
    Set Global Variable         ${pdf_policyperiod2}

    Log To Console              ------ Document Genearted Successfully -------


New Quote Button
    #Author=Amol
    [Documentation]             New quote button
    [Tags]                      new quote
    ClickText                   New Quote
    VerifyText                  Success                     anchor=Rate Successfully    timeout=45s
    Log To Console              ------ New Quote Created Successfully -------


Click On Save
    #Author=Amol
    [Documentation]             New quote button
    [Tags]                      new quote
    ClickElement                //lightning-icon[@title\='Save']


Vaidate Refer Functionality Fields
    #Author=Amol
    [Documentation]             Refer Button
    [Tags]                      Refer

    ClickText                   Refer
    Log To Console              ------ Refer Clicked Successful -------

    UseModal                    On
    #Verify refer type dropdown values
    ${refer_type}=              GetPickList                 Refer Type
    @{my_refer_type}=           Create List                 --None--                    External                    Internal
    Log To Console              ${refer_type}
    Log To Console              ${my_refer_type}
    Lists Should Be Equal       ${refer_type}               ${my_refer_type}            ignore_order=false
    Log To Console              ------ Refer Type Picklist Valided Successful -------

    #Verify refer date
    ${refer_date}=              GetInputValue               //input[@name\='Referral_Date__c']
    ${cur_date}=                Get Current Date            result_format=%b %-d, %Y
    Log To Console              ${cur_date}
    Log To Console              ${cur_date}

    IF                          "${refer_date}"=="${cur_date}"
        Log To Console          Success
    ELSE
        Fail
    END
    Log To Console              ------ Refer Date Checked and Valided Successful -------

    VerifyElement               //span[text()\='Available']/parent::*
    VerifyText                  Comments
    Log To Console              ------ Refer Completed Successful -------

Add Internal Refer
    #Author=Amol
    [Documentation]             Internal Referal
    [Tags]                      Internal
    PickList                    Refer Type                  Internal
    #MultiPickList              Referral Reason             Collections                 action=Move selection to Chosen
    MultiPickList               Referral Reason             Collections                 action=Move to Chosen

    Typetext                    Comments                    Testing Comments
    ClickElement                //input[@placeholder\='Search People...']
    ComboBox                    Search People...            Shraddha Patil
    #ClickElement               (//ul[@aria-label\='Recent People']/li[@role\='presentation'])[1]
    ClickText                   Ok                          anchor=Cancel
    VerifyText                  Success                     anchor=Your request is submitted successfully.          delay=2s
    Log To Console              ------ Internal Refer Completed Successful -------

Add External Refer
    #Author=Amol
    [Documentation]             External Referal
    [Tags]                      Internal

    PickList                    Refer Type                  External
    #MultiPickList              Referral Reason             Backdating                  action=Move selection to Chosen
    MultiPickList               Referral Reason             Backdating                  action=Move to Chosen
    Typetext                    Comments                    Testing Comments
    #ClickElement               //input[@placeholder\='Search People...']
    #ClickElement               (//ul[@aria-label\='Recent People']/li[@role\='presentation'])[2]
    ClickText                   Ok                          anchor=Cancel
    VerifyText                  Success                     anchor=Your request is submitted successfully.          delay=2s
    Log To Console              ------ External Refer Completed Successful -------



Generate Streamlined Renewal document
    #Author=Amol
    [Documentation]             Generate Quote letter
    [Tags]                      Streamlined Renewal document
    ClickElement                //lightning-icon[@title\='Finalize Quote']
    VerifyText                  Success                     anchor=Finalize quote successfully!
    Sleep                       3s
    ClickText                   Generate Document           anchor=Justification
    UseModal                    On
    ClickElement                //button[@name\='Document Type']
    ClickText                   Streamlined Renewal
    ClickText                   Generate                    anchor=Cancel
    VerifyText                  Success                     anchor=Document generated successfully!
    Log To Console              ------ Stramlined REnewal Completed Successful -------




Validate Limit and Deductibles
    #Author=Amol
    [Documentation]             Limits and Deductibles
    [Tags]                      lim                         smoke
    VerifyText                  Limits and Deductibles
    VerifyText                  Defense Option
    VerifyText                  Per Claim Limit
    VerifyText                  Aggregate Limit
    VerifyText                  Separate Defense Limit
    VerifyText                  Deductible Type
    VerifyText                  Per Claim Deductible
    VerifyText                  Aggregate Deductible
    VerifyText                  Data Breach Limit
    VerifyText                  Data Breach Deductible
    Log To Console              ------ Limit and Deductible Fields Verified Successful -------


    #Verifying                  Defence option dropdown

    VerifyElement               (//div[@data-id\='LimitsandDeductibles']//div/label)[1]
    ClickElement                (//div[@data-id\='LimitsandDeductibles']//div/label)[1]
    VerifyElement               //lightning-base-combobox-item[@data-value\='Defense Expenses Within Limit']
    VerifyElement               //lightning-base-combobox-item[@data-value\='Defense Expenses Outside Limit']
    VerifyElement               //lightning-base-combobox-item[@data-value\='Defense Expenses Within Limit with Additional Defense Limit']
    ClickElement                (//div[@data-id\='LimitsandDeductibles']//div/label)[1]
    Log To Console              ------ Defence Dropdown Verified Successful -------

    #Verifying                  Per claim limit

    VerifyElement               (//div[@data-id\='LimitsandDeductibles']//div/label)[2]
    ClickElement                (//div[@data-id\='LimitsandDeductibles']//div/label)[2]
    VerifyElement               //lightning-base-combobox-item[@data-value\='100,000']
    VerifyElement               //lightning-base-combobox-item[@data-value\='250,000']
    VerifyElement               //lightning-base-combobox-item[@data-value\='500,000']
    VerifyElement               //lightning-base-combobox-item[@data-value\='1,000,000']
    VerifyElement               //lightning-base-combobox-item[@data-value\='2,000,000']
    VerifyElement               //lightning-base-combobox-item[@data-value\='3,000,000']
    VerifyElement               //lightning-base-combobox-item[@data-value\='4,000,000']
    VerifyElement               //lightning-base-combobox-item[@data-value\='5,000,000']
    VerifyElement               //lightning-base-combobox-item[@data-value\='6,000,000']
    VerifyElement               //lightning-base-combobox-item[@data-value\='7,000,000']
    VerifyElement               //lightning-base-combobox-item[@data-value\='7,500,000']
    VerifyElement               //lightning-base-combobox-item[@data-value\='8,000,000']
    VerifyElement               //lightning-base-combobox-item[@data-value\='9,000,000']
    VerifyElement               //lightning-base-combobox-item[@data-value\='10,000,000']
    ClickElement                (//div[@data-id\='LimitsandDeductibles']//div/label)[2]
    Log To Console              ------ Per claim Dropdown Verified Successful -------


    #Verifying                  Aggregate Limit
    VerifyElement               (//div[@data-id\='LimitsandDeductibles']//div/label)[3]
    ClickElement                (//div[@data-id\='LimitsandDeductibles']//div/label)[3]
    VerifyElement               //lightning-base-combobox-item[@data-value\='1,000,000']
    VerifyElement               //lightning-base-combobox-item[@data-value\='2,000,000']
    VerifyElement               //lightning-base-combobox-item[@data-value\='3,000,000']
    ClickElement                (//div[@data-id\='LimitsandDeductibles']//div/label)[3]
    Log To Console              ------ Aggregate Limit Dropdown Verified Successful -------


    #Verifying                  Seperate defense limit
    VerifyElement               (//div[@data-id\='LimitsandDeductibles']//div/label)[4]
    ClickElement                (//div[@data-id\='LimitsandDeductibles']//div/label)[4]
    VerifyElement               //lightning-base-combobox-item[@data-value\='0']
    ClickElement                (//div[@data-id\='LimitsandDeductibles']//div/label)[4]
    Log To Console              ------ Seperate defense limit Dropdown Verified Successful -------


    #Verifying                  Deductible type
    VerifyElement               (//div[@data-id\='LimitsandDeductibles']//div/label)[5]
    ClickElement                (//div[@data-id\='LimitsandDeductibles']//div/label)[5]
    VerifyElement               //lightning-base-combobox-item[@data-value\='Damages and Defense Expenses']
    VerifyElement               //lightning-base-combobox-item[@data-value\='Damages Only']
    ClickElement                (//div[@data-id\='LimitsandDeductibles']//div/label)[5]
    Log To Console              ------ Deductible type Dropdown Verified Successful -------

    #Verifying                  Per Claim Deductible
    VerifyElement               (//div[@data-id\='LimitsandDeductibles']//div/label)[6]
    ClickElement                (//div[@data-id\='LimitsandDeductibles']//div/label)[6]
    VerifyElement               //lightning-base-combobox-item[@data-value\='1,000']
    VerifyElement               //lightning-base-combobox-item[@data-value\='2,000']
    VerifyElement               //lightning-base-combobox-item[@data-value\='2,500']
    VerifyElement               //lightning-base-combobox-item[@data-value\='3,000']
    VerifyElement               //lightning-base-combobox-item[@data-value\='4,000']
    VerifyElement               //lightning-base-combobox-item[@data-value\='5,000']
    VerifyElement               //lightning-base-combobox-item[@data-value\='7,500']
    VerifyElement               //lightning-base-combobox-item[@data-value\='10,000']
    VerifyElement               //lightning-base-combobox-item[@data-value\='15,000']
    VerifyElement               //lightning-base-combobox-item[@data-value\='20,000']
    VerifyElement               //lightning-base-combobox-item[@data-value\='25,000']
    VerifyElement               //lightning-base-combobox-item[@data-value\='35,000']
    VerifyElement               //lightning-base-combobox-item[@data-value\='50,000']
    VerifyElement               //lightning-base-combobox-item[@data-value\='75,000']
    VerifyElement               //lightning-base-combobox-item[@data-value\='100,000']
    VerifyElement               //lightning-base-combobox-item[@data-value\='150,000']
    VerifyElement               //lightning-base-combobox-item[@data-value\='200,000']
    VerifyElement               //lightning-base-combobox-item[@data-value\='250,000']
    VerifyElement               //lightning-base-combobox-item[@data-value\='500,000']
    ClickElement                (//div[@data-id\='LimitsandDeductibles']//div/label)[6]
    Log To Console              ------ Per Claim Deductible Dropdown Verified Successful -------


    #Verifying                  Aggregate Deductible
    VerifyElement               (//div[@data-id\='LimitsandDeductibles']//div/label)[7]
    ClickElement                (//div[@data-id\='LimitsandDeductibles']//div/label)[7]
    VerifyElement               //lightning-base-combobox-item[@data-value\='1 time']
    VerifyElement               //lightning-base-combobox-item[@data-value\='2 times']
    VerifyElement               //lightning-base-combobox-item[@data-value\='3 times']
    VerifyElement               //lightning-base-combobox-item[@data-value\='None']
    ClickElement                (//div[@data-id\='LimitsandDeductibles']//div/label)[7]
    Log To Console              ------ Aggregate Deductible Dropdown Verified Successful -------

    #Verifying                  Data Breach Limit
    VerifyElement               (//div[@data-id\='LimitsandDeductibles']//div/label)[8]
    ClickElement                (//div[@data-id\='LimitsandDeductibles']//div/label)[8]
    VerifyElement               //lightning-base-combobox-item[@data-value\='0']
    VerifyElement               //lightning-base-combobox-item[@data-value\='250,000']
    ClickElement                (//div[@data-id\='LimitsandDeductibles']//div/label)[8]
    Log To Console              ------ Data Breach Limit Dropdown Verified Successful -------

    #Verifying                  Data Breach deductible
    VerifyElement               (//div[@data-id\='LimitsandDeductibles']//div/label)[9]
    ClickElement                (//div[@data-id\='LimitsandDeductibles']//div/label)[9]
    VerifyElement               //lightning-base-combobox-item[@data-value\='0']
    ClickElement                (//div[@data-id\='LimitsandDeductibles']//div/label)[9]
    Log To Console              ------ Data Breach deductible Dropdown Verified Successful -------


    ${orignal_premium}=         GetText                     (//c-quote-comparison-lawyer-guard-item-lwc//lightning-formatted-number)[1]
    Log To Console              ${orignal_premium}
    #Set Global Variable        ${orignal_premium}

    ClickElement                (//div[@data-id\='LimitsandDeductibles']//div/label)[2]
    ClickElement                //lightning-base-combobox-item[@data-value\='4,000,000']
    ClickElement                (//div[@data-id\='LimitsandDeductibles']//div/label)[6]
    ClickElement                //lightning-base-combobox-item[@data-value\='25,000']
    ClickElement                (//div[@data-id\='LimitsandDeductibles']//div/label)[3]
    ClickElement                //lightning-base-combobox-item[@data-value\='2,000,000']

    ClickElement                (//button[@title\='Rating'])[1]
    VerifyText                  Success                     anchor=Rating successfully!                             delay=15s


    ${changed_premium}=         GetText                     (//c-quote-comparison-lawyer-guard-item-lwc//lightning-formatted-number)[1]      delay=3s
    Log To Console              ${changed_premium}


    IF                          "${orignal_premium}"=="${changed_premium}"
        Fail
    ELSE
        Log To Console          Premium changed successfully
    END
    Log To Console              ------ Limit and Deductibles Functionality Verified Successful -------



Validate Quote Console Header Fields
    #Author=Amol
    [Documentation]             Quote Console Header
    [Tags]                      quote                       smoke

    VerifyElement               //a[@class\='quoteName']/b
    ${quote_name}=              GetText                     //a[@class\='quoteName']/b
    ${uniquename1}=             Set Variable                ${uniquename} 1
    Log To Console              ${uniquename1}
    IF                          "${quote_name}"=="${uniquename1}"
        Log To Console          Success
    ELSE
        Fail
    END
    Log To Console              ------ Quote Name Validated Successful -------

    VerifyElement               (//p/lightning-formatted-number)[1]
    VerifyElement               (//lightning-badge)[1]      #Quote Status
    VerifyElement               (//button[@title\='Rating'])[1]
    VerifyElement               //button[@title\='Clone Quote']
    VerifyElement               //lightning-icon[@title\='Premium Seek']
    VerifyElement               (//lightning-icon[@title\='Save'])[1]
    VerifyElement               //lightning-icon[@title\='Finalize Quote']
    VerifyElement               //lightning-icon[@title\='Referral']
    VerifyElement               //lightning-icon[@title\='Endorsements']
    VerifyElement               //span[text()\='Show menu']/parent::*                   #DropDown
    Log To Console              ------ Header Fields Validated Successful -------

Validate Premium Seek
    #Author=Amol
    [Documentation]             Premium Seek
    [Tags]                      premiumseek                 smoke

    ClickElement                //input[contains(@name,'-Firm History / Qualifications / Expertise')]
    PressKey                    //input[contains(@name,'-Firm History / Qualifications / Expertise')]               {CONTROL + A + DELETE}
    TypeText                    //input[contains(@name,'-Firm History / Qualifications / Expertise')]               0.025
    ClickElement                (//lightning-icon[@icon-name\='utility:save'])[1]       timeout=5s
    # ClickElement              (//button[@title\='Rating'])[1]
    # VerifyText                Success                     anchor=Rating successfully!                             delay=15s

    ${orignal_premium}=         GetText                     (//c-quote-comparison-lawyer-guard-item-lwc//lightning-formatted-number)[1]
    Log To Console              ${orignal_premium}

    ClickElement                //lightning-icon[@title\='Premium Seek']
    TypeText                    //input[@name\='targetPremium']                         3000
    ClickText                   Seek Premium
    ClickElement                //button[@title\='Primary action' and @type\='button' and text()\='Seek Premium']
    VerifyText                  Warning Message
    ${indicative_premium}=      GetText                     //span[text()\='Indicative Premium']/parent::*/parent::*//input
    Log To Console              ${indicative_premium}
    ClickText                   Save and Rate
    VerifyText                  Success                     anchor=Rating successfully!                             delay=5s                 timeout=45s
    Log To Console              ------ Save and Rate is Successful -------
    ${changed_premium}=         GetText                     (//c-quote-comparison-lawyer-guard-item-lwc//lightning-formatted-number)[1]      delay=3s
    Log To Console              ${changed_premium}

    IF                          "${orignal_premium}"=="${changed_premium}"
        Fail
    ELSE
        Log To Console          Premium changed successfully
    END

    ClickElement                //button[@title\='Clone Quote']
    ClickElement                (//button[@title\='Rating'])[3]
    VerifyText                  Success                     anchor=Rating successfully!                             timeout=45s
    Log To Console              ------ Clone Quote and Rating is Successful -------
    ClickElement                (//lightning-icon[@icon-name\='utility:save'])[1]       timeout=5s
    ClickElement                (//lightning-icon[@title\='Finalize Quote'])[2]
    VerifyText                  Success                     anchor=Finalize quote successfully!                     timeout=45s
    Log To Console              ------ Premium Seek Validated Successful -------



Validate DropDown Values
    #Author=Amol
    [Documentation]             DropDown Values
    [Tags]                      smoke                       regression
    ClickElement                (//span[text()\='Show menu']/parent::* )                #DropDown
    VerifyText                  Close Quote
    VerifyText                  Factor Summary
    VerifyText                  Attorney Roster
    VerifyText                  Apply to All - Factors
    VerifyText                  Apply to All - Commission
    ClickElement                (//span[text()\='Show menu']/parent::* )
    Log To Console              ------ Dropdown Values Validated Successful -------

Operations on DropDown Values
    #Author=Amol
    [Documentation]             DropDown Values
    [Tags]                      smoke                       regression
    ClickElement                //button[@title\='Clone Quote']
    ClickElement                (//span[text()\='Show menu']/parent::* )                #DropDown
    ClickText                   Factor Summary
    UseTable                    Current Value
    ClickElement                //button[@title\='Close']

    ClickElement                (//span[text()\='Show menu']/parent::* )                delay=2s
    ClickText                   Attorney Roster
    UseTable                    Hire Date
    ClickElement                //button[@title\='Close']

    ClickElement                (//span[text()\='Show menu']/parent::* )                delay=2s
    ClickText                   Apply to All - Factors
    UseTable                    Quote Name
    ClickText                   Apply to All Factors to Selected Quotes

    ClickElement                (//span[text()\='Show menu']/parent::* )                delay=2s
    ClickText                   Apply to All - Commission

    ClickElement                (//span[text()\='Show menu']/parent::*)                 #DropDown
    ClickText                   Close Quote
    PickList                    Closed Reason               No activity
    ClickText                   Yes                         anchor=No
    Log To Console              ------ Dropdown Values Operations Completed Successful -------


Verify Expand All Collapse All Fields
    #Author=Amol
    [Documentation]             Expand All Collapse All
    [Tags]                      smoke                       regression
    VerifyText                  State :
    VerifyText                  Min/Max (SRP) :
    VerifyText                  Expand All
    VerifyText                  Collapse All
    VerifyText                  Limits and Deductibles
    VerifyText                  Area of Practice
    VerifyText                  Litigation History
    VerifyText                  Credit/Debit Information
    ClickText                   Collapse All
    ClickText                   Expand All
    Log To Console              ------ Expand All Collapse All Completed Successful -------


Verify Area Of Practice section on Quote Console 
    #Author=Amol
    [Documentation]             Quote console Area of Practice section
    [Tags]                      smoke                       regression
    VerifyText                  Area of Practice
    VerifyText                  100.0000% Admiralty-Defense
    VerifyElement               //div[@data-id\='AreaofPractice']//div/label
    ClickElement                //div[@data-id\='AreaofPractice']//div/label
    #VerifyText                 //div[@data-id\='AreaofPractice']//span[text()\='0.72']
    ${aop1}=                    GetInputValue               //div[@data-id\='AreaofPractice']//input
    Log To Console              ${aop1}
    IF                          "${aop1}"=="0.72"
        Log To Console          passed
    ELSE
        Fail
    END
    Log To Console              ------ AOP Completed Successful -------


Verify Litigation History on Quote Console 
    #Author=Amol
    [Documentation]             Quote console Area of Practice section
    [Tags]                      smoke                       regression
    VerifyText                  Litigation History
    VerifyText                  Test Claim ( - )
    VerifyElement               //div[@data-id\='LitigationHistory']//div/label
    ClickElement                //div[@data-id\='LitigationHistory']//div/label
    VerifyText                  //div[@data-id\='LitigationHistory']//span[text()\='1']
    Log To Console              ------ Litigation History Verification Completed Successful -------


Validate Credit Debit Fields
    #Author=Amol
    [Documentation]             Credit and Debit Fields
    [Tags]                      smoke                       regression
    VerifyText                  Credit/Debit Information
    VerifyText                  Loss Prevention/Risk Management
    VerifyText                  Schedule Rating Plan
    VerifyText                  Career Coverage
    VerifyText                  Worldwide Coverage
    VerifyText                  Title Agent Endorsement
    VerifyText                  Client Type Factor
    VerifyText                  Endorsements/Miscellaneous Credits/Debits
    VerifyText                  Loyalty Credit
    VerifyText                  DRI Factor

    VerifyText                  Conflicts of Interest / Docket Control Systems
    VerifyText                  Client Intake / Screening / File Opening Procedures
    VerifyText                  Oversight / Peer Review / Internal Communication Systems
    VerifyText                  Office Policies and Procedures / Firm Management / Billing Practices

    VerifyText                  Firm History / Qualifications / Expertise
    VerifyText                  Firm Financial Condition / Growth Plans / Compensation Structure
    VerifyText                  Unusual Liability Exposures / Office Sharing / Other Office Locations
    VerifyText                  Client Involvements and Dependency / Number and Types of Clients
    VerifyText                  Severity Exposure / Average Case Value / Size of Transactions
    VerifyText                  Frequency Exposure / Number of Cases / Transactions Handled
    VerifyText                  Firm Structure / Depth of Practice Groups / Staffing
    VerifyText                  Disciplinary Action/ Criminal Convictions

    VerifyText                  Level of Coverage
    VerifyText                  Individuals - All Other
    VerifyText                  Individuals - High Net Worth (>$10M assets)
    VerifyText                  Small Private Companies (<$100M revenues)
    VerifyText                  Large Private Companies (>$100M revenues)
    VerifyText                  Small Public Companies (<$100M revenues)
    VerifyText                  Large Public Companies (>$100M revenues)
    VerifyText                  Government or Public Institutions
    VerifyText                  Non Profit Organizations or Charities

    VerifyText                  Other
    VerifyText                  Amended Exclusions for Large Firms
    VerifyText                  Title Agency As Named Insured
    VerifyText                  Continuing Professional Education Credit
    VerifyText                  Pro Bono Credit
    VerifyText                  Years Continuously Insured for Professional Liability
    VerifyText                  DRI Factor
    Log To Console              ------ Credit Debit Fields Verified Successful -------



Verify Credit Debit Fields and Functionality
    #Author=Amol
    [Documentation]             Credit and Debit Fields
    [Tags]                      smoke                       regression
    VerifyElement               (//div[@data-id\='Credit/DebitInformation']//div/label)[1]
    ClickElement                (//div[@data-id\='Credit/DebitInformation']//div/label)[1]
    VerifyElement               //lightning-base-combobox-item[@data-value\='1.05']
    ClickElement                //lightning-base-combobox-item[@data-value\='1.05']

    VerifyElement               (//div[@data-id\='Credit/DebitInformation']//div/label)[2]
    ClickElement                (//div[@data-id\='Credit/DebitInformation']//div/label)[2]
    VerifyElement               //lightning-base-combobox-item[@data-value\='0.95']
    ClickElement                //lightning-base-combobox-item[@data-value\='0.95']

    VerifyElement               (//div[@data-id\='Credit/DebitInformation']//div/label)[3]
    ClickElement                (//div[@data-id\='Credit/DebitInformation']//div/label)[3]
    VerifyElement               //lightning-base-combobox-item[@data-value\='1.05']
    ClickElement                //lightning-base-combobox-item[@data-value\='1.05']

    VerifyElement               (//div[@data-id\='Credit/DebitInformation']//div/label)[4]
    ClickElement                (//div[@data-id\='Credit/DebitInformation']//div/label)[4]
    VerifyElement               //lightning-base-combobox-item[@data-value\='1.05']
    ClickElement                //lightning-base-combobox-item[@data-value\='1.05']

    #input values
    ClickElement                (//div[@data-id\='Credit/DebitInformation']//div/label)[5]
    PressKey                    (//div[@data-id\='Credit/DebitInformation']//div//input)[1]                         {CONTROL + A + DELETE}
    TypeText                    (//div[@data-id\='Credit/DebitInformation']//div//input)[1]                         0.025


    ClickElement                (//div[@data-id\='Credit/DebitInformation']//div/label)[6]
    PressKey                    (//div[@data-id\='Credit/DebitInformation']//div//input)[2]                         {CONTROL + A + DELETE}
    TypeText                    (//div[@data-id\='Credit/DebitInformation']//div//input)[2]                         0.100


    ClickElement                (//div[@data-id\='Credit/DebitInformation']//div/label)[7]
    PressKey                    (//div[@data-id\='Credit/DebitInformation']//div//input)[3]                         {CONTROL + A + DELETE}
    TypeText                    (//div[@data-id\='Credit/DebitInformation']//div//input)[3]                         0.100

    ClickElement                (//div[@data-id\='Credit/DebitInformation']//div/label)[8]
    PressKey                    (//div[@data-id\='Credit/DebitInformation']//div//input)[4]                         {CONTROL + A + DELETE}
    TypeText                    (//div[@data-id\='Credit/DebitInformation']//div//input)[4]                         0.100

    ClickElement                (//div[@data-id\='Credit/DebitInformation']//div/label)[9]
    PressKey                    (//div[@data-id\='Credit/DebitInformation']//div//input)[5]                         {CONTROL + A + DELETE}
    TypeText                    (//div[@data-id\='Credit/DebitInformation']//div//input)[5]                         0.100

    ClickElement                (//div[@data-id\='Credit/DebitInformation']//div/label)[10]
    PressKey                    (//div[@data-id\='Credit/DebitInformation']//div//input)[6]                         {CONTROL + A + DELETE}
    TypeText                    (//div[@data-id\='Credit/DebitInformation']//div//input)[6]                         0.100

    ClickElement                (//div[@data-id\='Credit/DebitInformation']//div/label)[11]
    PressKey                    (//div[@data-id\='Credit/DebitInformation']//div//input)[7]                         {CONTROL + A + DELETE}
    TypeText                    (//div[@data-id\='Credit/DebitInformation']//div//input)[7]                         0.025

    ClickElement                (//div[@data-id\='Credit/DebitInformation']//div/label)[12]
    PressKey                    (//div[@data-id\='Credit/DebitInformation']//div//input)[8]                         {CONTROL + A + DELETE}
    TypeText                    (//div[@data-id\='Credit/DebitInformation']//div//input)[8]                         0.025

    #DRI Factor
    ClickElement                (//div[@data-id\='Credit/DebitInformation']//div/label)[12]
    PressKey                    (//div[@data-id\='Credit/DebitInformation']//div//input)[9]                         {CONTROL + A + DELETE}
    TypeText                    (//div[@data-id\='Credit/DebitInformation']//div//input)[9]                         0.85

    ${orignal_premium}=         GetText                     (//c-quote-comparison-lawyer-guard-item-lwc//lightning-formatted-number)[1]
    Log To Console              ${orignal_premium}

    ClickElement                (//button[@title\='Rating'])[1]
    VerifyText                  Success                     anchor=Rating successfully!                             delay=10s                timeout=45s
    Sleep                       10s
    ${changed_premium}=         GetText                     (//c-quote-comparison-lawyer-guard-item-lwc//lightning-formatted-number)[1]      delay=3s
    Log To Console              ${changed_premium}

    IF                          "${orignal_premium}"=="${changed_premium}"
        Fail
    ELSE
        Log To Console          Premium changed successfully
    END
    Log To Console              ------ Credit Debit Functionality Verified Successful -------


Validate Quote Data Fields 
    #Author=Amol
    [Documentation]             Quote data fields
    [Tags]                      smoke                       regression
    VerifyText                  Effective Date
    VerifyText                  Expiration Date
    VerifyText                  Quote Premium
    VerifyText                  Endorsement Effective Date
    VerifyText                  Transaction Premium
    VerifyText                  State Taxes
    VerifyText                  Municipal Taxes
    VerifyText                  Total Premium
    VerifyText                  Default Commission Percentage
    VerifyText                  Expiring Commission Percentage
    VerifyText                  Commission Percentage
    VerifyCheckbox              Commission Override
    Log To Console              ------ Quote Data Fields Verified Successful -------

Edit Quote data Fields and verify rating 
    #Author=Amol
    [Documentation]             Quote data fields
    [Tags]                      smoke                       regression

    ClickElement                (//div[@data-id\='QuoteData']//lightning-input)[1]
    PressKey                    (//div[@data-id\='QuoteData']//lightning-input)[1]      {CONTROL + A + DELETE}
    TypeText                    (//div[@data-id\='QuoteData']//lightning-input)[1]      3/7/2024                    delay=3s
    #TypeText                   Comments                    123/45/                     delay=1s
    # ${dt}=                    Set Variable                3/7/2024
    # Log To Console            ${dt}

    ClickElement                (//div[@data-id\='QuoteData']//lightning-input)[2]
    PressKey                    (//div[@data-id\='QuoteData']//lightning-input)[2]      {CONTROL + A + DELETE}
    TypeText                    (//div[@data-id\='QuoteData']//lightning-input)[2]      3/7/2025

    ClickElement                (//div[@data-id\='QuoteData']//lightning-input)[3]
    PressKey                    (//div[@data-id\='QuoteData']//lightning-input)[3]      {CONTROL + A + DELETE}
    TypeText                    (//div[@data-id\='QuoteData']//lightning-input)[3]      4000

    VerifyAttribute             (//div[@data-id\='QuoteData']//lightning-input)[4]      variant                     label-hidden
    VerifyAttribute             (//div[@data-id\='QuoteData']//lightning-input)[5]      variant                     label-hidden


    ClickElement                (//div[@data-id\='QuoteData']//lightning-input)[6]
    PressKey                    (//div[@data-id\='QuoteData']//lightning-input)[6]      {CONTROL + A + DELETE}
    TypeText                    (//div[@data-id\='QuoteData']//lightning-input)[6]      6000

    ClickElement                (//div[@data-id\='QuoteData']//lightning-input)[7]
    PressKey                    (//div[@data-id\='QuoteData']//lightning-input)[7]      {CONTROL + A + DELETE}
    TypeText                    (//div[@data-id\='QuoteData']//lightning-input)[7]      1200

    VerifyAttribute             (//div[@data-id\='QuoteData']//lightning-input)[8]      variant                     label-hidden
    VerifyAttribute             (//div[@data-id\='QuoteData']//lightning-input)[9]      variant                     label-hidden
    VerifyAttribute             (//div[@data-id\='QuoteData']//lightning-input)[10]     variant                     label-hidden

    ClickElement                (//div[@data-id\='QuoteData']//lightning-input)[11]
    PressKey                    (//div[@data-id\='QuoteData']//lightning-input)[11]     {CONTROL + A + DELETE}
    TypeText                    (//div[@data-id\='QuoteData']//lightning-input)[11]     5.5

    ClickElement                (//button[@title\='Rating'])[1]
    VerifyText                  Success                     anchor=Rating successfully!                             partial_match=false      timeout=45s
    Log To Console              ------ Edit Quote Data Fields operations Verified Successful -------

Edit Limit Fields and verify rating
    #Author=Amol
    [Documentation]             Quote data fields
    [Tags]                      smoke                       regression

    ${orignal_premium}=         GetText                     //c-quote-comparison-lawyer-guard-item-lwc//lightning-formatted-number
    Log To Console              ${orignal_premium}

    ClickElement                (//div[@data-id\='LimitsandDeductibles']//lightning-combobox)[2]
    ClickElement                //lightning-base-combobox-item[@data-value\='2,000,000']

    Sleep                       2s
    ClickElement                (//div[@data-id\='LimitsandDeductibles']//lightning-combobox)[3]
    ClickElement                //lightning-base-combobox-item[@data-value\='3,000,000']

    ClickElement                (//button[@title\='Rating'])[1]
    VerifyText                  Success                     anchor=Rating successfully!                             timeout=45s
    Sleep                       45s
    ${changed_premium}=         GetText                     //c-quote-comparison-lawyer-guard-item-lwc//lightning-formatted-number           delay=3s
    Sleep                       30s
    Log To Console              ${changed_premium}

    IF                          "${orignal_premium}"=="${changed_premium}"
        Fail
    ELSE
        Log To Console          Premium changed successfully
    END


Edit Limit Fields and verify rating after amendment
    #Author=Amol
    [Documentation]             Quote data fields
    [Tags]                      smoke                       regression

    ${orignal_premium}=         GetText                     (//c-quote-comparison-lawyer-guard-item-lwc//lightning-formatted-number)[3]
    Log To Console              ${orignal_premium}
    ClickElement                (//div[@data-id\='LimitsandDeductibles']//lightning-combobox)[11]
    ClickElement                //lightning-base-combobox-item[@data-value\='2,000,000']

    Sleep                       2s
    ClickElement                (//div[@data-id\='LimitsandDeductibles']//lightning-combobox)[12]
    ClickElement                //lightning-base-combobox-item[@data-value\='3,000,000']

    ClickElement                (//button[@title\='Rating'])[3]
    VerifyText                  Success                     anchor=Rating successfully!                             timeout=120s             partial_match=false
    ${changed_premium}=         GetText                     (//c-quote-comparison-lawyer-guard-item-lwc//lightning-formatted-number)[3]      delay=3s
    Log To Console              ${changed_premium}
    IF                          "${orignal_premium}"=="${changed_premium}"
        Fail
    ELSE
        Log To Console          Premium changed successfully
    END

Edit Limit and Verify Rating on first quote
    #Author=Amol
    [Documentation]             Quote data fields
    [Tags]                      smoke                       regression

    RefreshPage
    ${orignal_premium}=         GetText                     //c-quote-comparison-lawyer-guard-item-lwc//lightning-formatted-number
    Log To Console              ${orignal_premium}

    ClickElement                ((//c-quote-comparison-lawyer-guard-item-lwc)[last()]//div[@data-id\='LimitsandDeductibles']//lightning-combobox)[2]
    ClickElement                //lightning-base-combobox-item[@data-value\='6,000,000']

    ClickElement                ((//c-quote-comparison-lawyer-guard-item-lwc)[last()]//div[@data-id\='LimitsandDeductibles']//lightning-combobox)[3]
    ClickElement                //lightning-base-combobox-item[@data-value\='2,000,000']

    ClickElement                (//button[@title\='Rating'])[1]
    VerifyText                  Success                     anchor=Rating successfully!                             timeout=45s
    Sleep                       45s
    ${changed_premium}=         GetText                     //c-quote-comparison-lawyer-guard-item-lwc//lightning-formatted-number           delay=3s
    Log To Console              ${changed_premium}
    Sleep                       20s
    IF                          "${orignal_premium}"=="${changed_premium}"
        Fail
    ELSE
        Log To Console          Premium changed successfully
    END

Edit Limit Fields and verify rating after Cancel Replace
    #Author=Amol
    [Documentation]             Quote data fields
    [Tags]                      smoke                       regression

    ${orignal_premium}=         GetText                     (//c-quote-comparison-lawyer-guard-item-lwc//lightning-formatted-number)[5]
    Log To Console              ${orignal_premium}

    ClickElement                ((//c-quote-comparison-lawyer-guard-item-lwc)[3]//div[@data-id\='LimitsandDeductibles']//lightning-combobox)[2]
    ClickElement                //lightning-base-combobox-item[@data-value\='2,000,000']

    ClickElement                ((//c-quote-comparison-lawyer-guard-item-lwc)[3]//div[@data-id\='LimitsandDeductibles']//lightning-combobox)[3]
    ClickElement                //lightning-base-combobox-item[@data-value\='2,000,000']

    # ClickElement              (//div[@data-id\='LimitsandDeductibles']//lightning-combobox)[12]
    # ClickElement              //lightning-base-combobox-item[@data-value\='2,000,000']

    ClickElement                (//button[@title\='Rating'])[5]
    VerifyText                  Success                     anchor=Rating successfully!                             timeout=60s
    Sleep                       45s
    ${changed_premium}=         GetText                     (//c-quote-comparison-lawyer-guard-item-lwc//lightning-formatted-number)[5]      delay=3s
    Log To Console              ${changed_premium}
    IF                          "${orignal_premium}"=="${changed_premium}"
        Fail
    ELSE
        Log To Console          Premium changed successfully
    END


Click On Bind
    #Author=Amol
    [Documentation]             Bind
    [Tags]                      smoke                       regression
    Sleep                       60s
    ClickElement                //lightning-icon[@title\='Finalize Quote']              delay=2s
    VerifyText                  Success                     anchor=Finalize quote successfully!                     timeout=120s             partial_match=false
    Sleep                       60s
    ClickElement                //lightning-icon[@title\='Bind']//span[@class\='slds-assistive-text']
    VerifyText                  Bind Quote
    Sleep                       10s
    ClickElement                //button[@title\='Bind']
    #Sleep                      45s
    # RefreshPage
    # ${Sanction_one}=          IsText                      The record has failed the Sanction check and is requested for confirmation. You will be notified once the review is done. In case of any help please contact with System Admin.    timeout=30s
    # IF                        "${Sanction_one}" == "True"
    #                           ClickText                   ${uniqueName}               anchor=Account
    #                           VerifyText                  Details                     timeout=30s
    #                           ClickElement                //*[@title\="Sanction"]

    # END
    VerifyText                  Success                     anchor=Bind quote successfully!                         timeout=45s              partial_match=false
    Log To Console              --------------Bind Successfull----------------
    Sleep                       15s
Click On Bind After Amendment
    #Author=Amol
    [Documentation]             Bind
    [Tags]                      smoke                       regression

    Sleep                       60s
    ClickElement                (//lightning-icon[@title\='Finalize Quote'])[4]         delay=2s
    VerifyText                  Success                     anchor=Finalize quote successfully!                     timeout=120s             partial_match=false
    Sleep                       60s
    ClickElement                //lightning-icon[@title\='Bind']//span[@class\='slds-assistive-text']
    VerifyText                  Bind Quote
    Sleep                       10s
    ClickElement                //button[@title\='Bind']
    VerifyText                  Success                     anchor=Bind quote successfully!                         partial_match=false
    Log To Console              --------------Bind Successfull after amendment----------------
Click On Bind After Amendment multiple
    #Author=Amol
    [Documentation]             Bind
    [Tags]                      smoke                       regression

    Sleep                       60s
    ClickElement                (//lightning-icon[@title\='Finalize Quote'])[2]         delay=2s
    VerifyText                  Success                     anchor=Finalize quote successfully!                     timeout=120s             partial_match=false
    Sleep                       60s
    ClickElement                //lightning-icon[@title\='Bind']//span[@class\='slds-assistive-text']
    VerifyText                  Bind Quote
    Sleep                       10s
    ClickElement                //button[@title\='Bind']
    VerifyText                  Success                     anchor=Bind quote successfully!                         partial_match=false
    Log To Console              --------------Bind Successfull after amendment----------------


Click On Bind After Cancel Replace Correction
    #Author=Amol
    [Documentation]             Bind
    [Tags]                      smoke                       regression
    ClickElement                (//lightning-icon[@title\='Finalize Quote'])[3]         delay=2s
    VerifyText                  Success                     anchor=Finalize quote successfully!                     timeout=120s             partial_match=false
    Sleep                       10s
    ClickElement                //lightning-icon[@title\='Bind']//span[@class\='slds-assistive-text']
    VerifyText                  Bind Quote
    Sleep                       10s
    ClickCheckbox               Agency broker license       off
    ClickCheckbox               Individual broker license                               on
    ClickElement                //span[text()\='Select Item 1']
    ClickElement                //button[@title\='Bind']
    VerifyText                  Success                     anchor=Bind quote successfully!
    Sleep                       30s
    Log To Console              --------------Bind Successfull after Cancel and Replace----------------
    
 Click On Bind After Cancel Replace Correction for admitted
    #Author=Shraddha
    [Documentation]             Bind
    [Tags]                      smoke                       Regression

    ClickElement                (//lightning-icon[@title\='Finalize Quote'])[3]         delay=2s
    VerifyText                  Success                     anchor=Finalize quote successfully!                     timeout=120s             partial_match=false
    Sleep                       10s
    ClickElement                //lightning-icon[@title\='Bind']//span[@class\='slds-assistive-text']
    VerifyText                  Bind Quote
    Sleep                       10s
    ClickElement                //button[@title\='Bind']
    VerifyText                  Success                     anchor=Bind quote successfully!
    Sleep                       30s
    Log To Console              --------------Bind Successfull after Cancel and Replace----------------


Click On Quote 
    #Author=Amol
    [Documentation]             Bind
    [Tags]                      smoke                       regression
    ClickElement                //a[@class\='quoteName']

Click On Goal Seek
    #Author=Amol
    [Documentation]             Bind
    [Tags]                      smoke                       regression
    ClickElement                //span[text()\='Premium Seek']



Validate GOAL Seek Fields
    #Author=Amol
    [Documentation]             Bind
    [Tags]                      smoke                       regression
    VerifyAll                   Premium Seek, Current Premium, Target Premium, State, State Cap, Current Score (*SRP)
    VerifyText                  Seek Premium
    VerifyAll                   Firm History / Qualifications / Expertise(-0.250 - 0.250)
    VerifyAll                   Firm Financial Condition / Growth Plans / Compensation Structure(-0.250 - 0.250), Indicative Premium, Save and Rate, Ignore and Return
    VerifyAll                   Client Involvements and Dependency / Number and Types of Clients(-0.250 - 0.250), Severity Exposure / Average Case Value / Size of Transactions(-0.250 - 0.250)

Enter Data On Schedule Rating For Goal Seek
    #Author=Amol
    [Documentation]             Bind
    [Tags]                      smoke                       regression
    ClickElement                (//div[@data-id\='Credit/DebitInformation']//input)[1]
    TypeText                    (//div[@data-id\='Credit/DebitInformation']//input)[1]                              0.025
    ClickElement                (//div[@data-id\='Credit/DebitInformation']//input)[2]
    TypeText                    (//div[@data-id\='Credit/DebitInformation']//input)[2]                              0.025
    ClickElement                (//div[@data-id\='Credit/DebitInformation']//input)[3]
    TypeText                    (//div[@data-id\='Credit/DebitInformation']//input)[3]                              0.025


Goal Seek Operation
    #Author=Amol
    [Documentation]             Bind
    [Tags]                      smoke                       regression

    ${Value1}=                  GetInputValue               //td[text()\='Firm History / Qualifications / Expertise(-0.250 - 0.250)']//parent::*//lightning-input
    Log To Console              ${Value1}
    ${Value2}=                  GetInputValue               //td[text()\='Firm Financial Condition / Growth Plans / Compensation Structure(-0.250 - 0.250)']//parent::*//lightning-input
    Log To Console              ${Value2}
    IF                          '${Value1}' == '0.025' and '${Value2}' == '0.025'
        Log To Console          Value Pass
    ELSE
        Fail
    END

    ${Value3}=                  GetInputValue               //label[text()\='Current Premium']//parent::*/parent::*/parent::*//input
    ${Value4}=                  Remove String               ${Value3}                   ,                           $
    ${fin_value3}=              Evaluate                    ${Value4}+2
    Typetext                    //input[@name\='targetPremium']                         ${fin_value3}
    ClickText                   Seek Premium
    Sleep                       5s
    ${target_value}=            GetInputValue               //input[@name\='targetPremium']
    ${seek_value}=              GetInputValue               (//span[text()\='Indicative Premium']//parent::div/following::div//input)[1]
    Log To Console              ${target_value}
    Log To Console              ${seek_value}
    IF                          '${target_value}' == '${seek_value}'
        Log To Console          Value Pass
    ELSE
        Fail
    END
    ClickText                   Save and Rate
    VerifyText                  Success                     anchor=Rating successfully!                             timeout=95s              partial_match=false

    Sleep                       45s
    ${final_prem}=              GetText                     (//p/lightning-formatted-number)[1]
    Log To Console              ${final_prem}
    Log To Console              ${target_value}
    Click On Rate

    IF                          '${final_prem}' == '${target_value}.00'
        Log To Console          Value Pass
    ELSE
        Fail
    END

Click On Rate 
    #Author=Amol
    [Documentation]             Bind
    [Tags]                      smoke                       regression
    ClickElement                (//button[@title\='Rating'])[1]
    VerifyText                  Success                     anchor=Rating successfully!                             timeout=45s              partial_match=false


Click On Rate After Amendment
    #Author=Amol
    [Documentation]             Bind
    [Tags]                      smoke                       regression
    ClickElement                (//button[@title\='Rating'])[3]
    VerifyText                  Success                     anchor=Rating successfully!                             timeout=55s              partial_match=false


Send Mail On Submission Page
    #Author=Amol
    [Documentation]             Sending Mail From Submission Page
    [Tags]                      Validating
    [Arguments]                 ${Mailtype}
    ClickText                   Send Mail
    UseModal                    On
    ClickElement                //select

    # #ClickText                Binder Transmittal

    IF                          "${Mailtype}"=="Additional Information Request"
        DropDown                Select a Template:          [[1]]
    ELSE IF                     "${Mailtype}"=="BOR Acknowledgement Midterm"
        DropDown                Select a Template:          [[2]]
    ELSE IF                     "${Mailtype}"=="BOR Acknowledgement New/Renewal"
        DropDown                Select a Template:          [[3]]
    ELSE IF                     "${Mailtype}"=="BOR Countermanding"
        DropDown                Select a Template:          [[4]]
    ELSE IF                     "${Mailtype}"=="Claim Verification"
        DropDown                Select a Template:          [[5]]
    ELSE IF                     "${Mailtype}"=="Coverage Expired – File Closed Transmittal"
        DropDown                Select a Template:          [[6]]
    ELSE IF                     "${Mailtype}"=="Declination"
        DropDown                Select a Template:          [[7]]
    ELSE IF                     "${Mailtype}"=="Duplicate Submission"
        DropDown                Select a Template:          [[8]]
    ELSE IF                     "${Mailtype}"=="Indication Transmittal"
        DropDown                Select a Template:          [[9]]
    ELSE IF                     "${Mailtype}"=="LG Firm Changes"
        DropDown                Select a Template:          [[10]]
    ELSE IF                     "${Mailtype}"=="Non-Renewal Transmittal"
        DropDown                Select a Template:          [[11]]
    ELSE IF                     "${Mailtype}"=="Not Quoted - Pricing"
        DropDown                Select a Template:          [[12]]
    ELSE IF                     "${Mailtype}"=="Quote Transmittal"
        DropDown                Select a Template:          [[13]]
    ELSE IF                     "${Mailtype}"=="Streamline Proposal Follow Up Transmittal"
        DropDown                Select a Template:          [[14]]
    END
    ${subjectline}=             GetInputValue               Subject:                    timeout=45s
    Log To Console              ${subjectline}
    Set Global Variable         ${subjectline}
    ClickText                   Send                        anchor=Cancel
    Sleep                       40s
    ${body}=                    Get Email Content           ${client_id_mail}           ${client_secret_mail}       ${tenant_id}             QA.Testing.Inbox@innovisk.global              ${subjectline}
    Log To Console              ${body}
    Set Global Variable         ${body}


Verify Email Contains same limit and deductibles
    #Author=Amol
    [Documentation]             Verifying Email with Limits and Deductibles
    [Tags]                      Validating
    Should Contain              ${body}                     Limit of Liability: Each Claim ($1000000), Aggregate ($1000000), Limit Type (Defense Expenses Within Limit). Deductible: Each Claim ($1000), Aggregate (None), Deductible Type (Damages and Defense Expenses). This would be approximately




Select Endorsements
    #Author=Amol
    [Documentation]             Verifying Email with Limits and Deductibles
    [Tags]                      Validating
    ClickElement                //lightning-icon[@title\='Endorsements']
    ClickElement                //div[text()\='ALFA Endorsement']/parent::td/parent::tr//button
    Sleep                       3s
    ClickElement                //div[text()\='Additional Named Insured']/parent::td/parent::tr//button
    ClickText                   Return Quote Process
    Log To Console              --------Endorsements Selected Successfully----------

Generate Document Account Summary 
    #Author=Amol
    [Arguments]                 ${document_name}
    ClickText                   Generate Document           delay=2s
    ClickElement                //button[@name\='Document Type']                        delay=2s
    ClickText                   ${document_name}
    ClickText                   Generate                    anchor=Cancel
    VerifyText                  Success                     anchor=Document generated successfully!                 timeout=45s





Send Non Quoted Transmittal Mail And Check limits 
    #Author=Amol
    [Documentation]             Sending Mail From Policy Page
    [Tags]                      Validating
    ClickText                   Send Mail
    UseModal                    On
    ClickElement                //select                    timeout=30s
    DropDown                    Select a Template:          [[12]]                      timeout=30s
    ${emailbody}=               GetInputValue               //div[@data-placeholder\='Reinput email template']      timeout=30s
    Log To Console              ${emailbody}
    Should Contain              ${emailbody}                Limit of Liability: Each Claim ($2000000), Aggregate ($3000000), Limit Type (Defense Expenses Within Limit). Deductible: Each Claim ($1000), Aggregate (None), Deductible Type (Damages and Defense Expenses).
    ClickText                   Cancel                      anchor=Send
    #RefreshPage
    # Should Contain            ${emailbody}                Answer the following question on the supplement
    # Should Contain            ${emailbody}                Amend the Area of Practice grid to equal 100%


Get Default percentage on renewal and Verify matching
    ${defprem_compa}=           GetInputValue               //input[contains(@name, 'Default Commission Percentage')]
    Log To Console              ${defprem_compa}
    IF                          "${defprem_compa}" == "15.0000"
        Log To Console          Success
    ELSE
        Fail
    END




Commision Overridde check   
    #Author=Amol
    [Documentation]             Override Check
    [Tags]                      Validating

    ClickElement                (//div[@data-id\='QuoteData']//input)[last()]
    TypeText                    (//div[@data-id\='QuoteData']//input)[last()]           12.000



Get all the Read PDF details in Quoted
    #Getting PDF variables for Policy period
    ${orignal_premium}=         GetText                     (//div[@data-id\='QuoteData']//lightning-input)[8]
    ${pdf_premium}=             Set Variable                ${orignal_premium}
    Set Global Variable         ${pdf_premium}

    ${state_taxes}=             GetText                     (//div[@data-id\='QuoteData']//lightning-input)[6]
    ${pdf_statetaxes}=          Set Variable                ${state_taxes}
    Set Global Variable         ${pdf_statetaxes}

    ${fromdate}=                GetInputValue               (//div[@data-id\='QuoteData']//lightning-input)[1]
    ${todate}=                  GetInputValue               (//div[@data-id\='QuoteData']//lightning-input)[2]
    Log To Console              ${fromdate}
    Log To Console              ${todate}
    ${fromdate1}=               Convert Date                ${fromdate}                 result_format=%B %-d, %Y
    ${todate1}=                 Convert Date                ${todate}                   result_format=%B %-d, %Y

    ${pdf_policyperiod}=        Set Variable                ${fromdate1} to ${todate1}
    Set Global Variable         ${pdf_policyperiod}
    Set Global Variable         ${fromdate1}
    Set Global Variable         ${todate1}

Get all the Read PDF details in Rated 

    ${orignal_premium}=         GetText                     (//div[@data-id\='QuoteData']//lightning-input)[8]
    ${pdf_premium}=             Set Variable                ${orignal_premium}
    Set Global Variable         ${pdf_premium}
    ${state_taxes}=             GetText                     (//div[@data-id\='QuoteData']//lightning-input)[6]
    ${pdf_statetaxes}=          Set Variable                ${state_taxes}
    Set Global Variable         ${pdf_statetaxes}

    ${fromdate}=                GetInputValue               (//div[@data-id\='QuoteData']//lightning-input)[1]
    ${todate}=                  GetInputValue               (//div[@data-id\='QuoteData']//lightning-input)[2]
    Log To Console              ${fromdate}
    Log To Console              ${todate}
    ${fromdate1}=               Convert Date                ${fromdate}                 result_format=%B %-d, %Y
    ${todate1}=                 Convert Date                ${todate}                   result_format=%B %-d, %Y
    ${fromdate2}=               Convert Date                ${fromdate}                 result_format=%m/%d/%Y
    ${todate2}=                 Convert Date                ${todate}                   result_format=%m/%d/%Y
    ${pdf_policyperiod}=        Set Variable                ${fromdate1} to ${todate1}
    ${pdf_policyperiod2}=       Set Variable                ${fromdate2} - ${todate2}
    ${pdf_policyperiod3}=       Set Variable                ${fromdate1} To: ${todate1}
    Set Global Variable         ${pdf_policyperiod}
    Set Global Variable         ${pdf_policyperiod2}
    Set Global Variable         ${pdf_policyperiod3}
    Set Global Variable         ${todate2}
    Set Global Variable         ${fromdate2}


Get all the Read PDF details in Quoted after Renewal 

    #Getting PDF variables for Policy period
    ${orignal_premium}=         GetText                     (//div[@data-id\='QuoteData']//lightning-input)[19]
    ${pdf_premium}=             Set Variable                ${orignal_premium}
    Set Global Variable         ${pdf_premium}

    ${state_taxes}=             GetText                     (//div[@data-id\='QuoteData']//lightning-input)[17]
    ${pdf_statetaxes}=          Set Variable                ${state_taxes}
    Set Global Variable         ${pdf_statetaxes}

    ${fromdate}=                GetInputValue               (//div[@data-id\='QuoteData']//lightning-input)[12]
    ${todate}=                  GetInputValue               (//div[@data-id\='QuoteData']//lightning-input)[13]
    Log To Console              ${fromdate}
    Log To Console              ${todate}
    ${fromdate1}=               Convert Date                ${fromdate}                 result_format=%B %-d, %Y
    ${todate1}=                 Convert Date                ${todate}                   result_format=%B %-d, %Y

    ${pdf_policyperiod}=        Set Variable                ${fromdate1} to ${todate1}
    Set Global Variable         ${pdf_policyperiod}


Get all the Read PDF details in Rated after Renewal
    ${orignal_premium}=         GetText                     (//div[@data-id\='QuoteData']//lightning-input)[19]
    ${pdf_premium}=             Set Variable                ${orignal_premium}
    Set Global Variable         ${pdf_premium}
    ${state_taxes}=             GetText                     (//div[@data-id\='QuoteData']//lightning-input)[17]
    ${pdf_statetaxes}=          Set Variable                ${state_taxes}
    Set Global Variable         ${pdf_statetaxes}

    ${fromdate}=                GetInputValue               (//div[@data-id\='QuoteData']//lightning-input)[12]
    ${todate}=                  GetInputValue               (//div[@data-id\='QuoteData']//lightning-input)[13]
    Log To Console              ${fromdate}
    Log To Console              ${todate}
    ${fromdate1}=               Convert Date                ${fromdate}                 result_format=%B %-d, %Y
    ${todate1}=                 Convert Date                ${todate}                   result_format=%B %-d, %Y
    ${fromdate2}=               Convert Date                ${fromdate}                 result_format=%m/%d/%Y
    ${todate2}=                 Convert Date                ${todate}                   result_format=%m/%d/%Y
    ${pdf_policyperiod}=        Set Variable                ${fromdate1} to ${todate1}
    ${pdf_policyperiod2}=       Set Variable                ${fromdate2} - ${todate2}
    Set Global Variable         ${pdf_policyperiod}
    Set Global Variable         ${pdf_policyperiod2}

Rate Quote
    [Documentation]             Rate Quote and wait for component to load

    RefreshPage
    Sleep                       30s
    ClickElement                (//button[@title\='Rating'])[1]
    VerifyText                  Rating successfully!        timeout=120s                partial_match=false


Click On Bind For SL
    [Documentation]             Bind
    [Tags]                      smoke                       regression
    [Arguments]                 ${arg1}
    ClickElement                //lightning-icon[@title\='Finalize Quote']              delay=2s
    VerifyText                  Success                     anchor=Finalize quote successfully!                     timeout=120s             partial_match=false
    Sleep                       30s
    ClickElement                //lightning-icon[@title\='Bind']
    #IF                         "${arg1}" == "Individual broker license"
    ClickCheckbox               Agency broker license       off
    ClickCheckbox               Individual broker license                               on
    ClickElement                //span[text()\='Select Item 1']
    ClickElement                //button[@title\='Bind']
    VerifyText                  Success                     anchor=Bind quote successfully!                         timeout=45s
    Log To Console              --------------Bind Successfull----------------
    Sleep                       15s
    # ELSE IF                   "${arg1}" == "Agency broker license"
    #                           ClickCheckbox               Agency broker license       on
    # ClickElement              //span[text()\='Select Item 1']
    #                           ClickElement                //button[@title\='Bind']
    # VerifyText                Success                     anchor=Bind quote successfully!                         timeout=45s
    # Log To Console            --------------Bind Successfull----------------
    #                           Sleep                       15s

    #END


Validate Limit and Deductibles for Primary
    #Author=Shraddha
    [Documentation]             Limits and Deductibles
    [Tags]                      lim                         smoke
    VerifyText                  Limits and Deductibles
    VerifyText                  Defense Option
    VerifyText                  Per Claim Limit
    VerifyText                  Aggregate Limit
    VerifyText                  Separate Defense Limit
    VerifyText                  Deductible Type
    VerifyText                  Per Claim Deductible
    VerifyText                  Aggregate Deductible
    Log To Console              ------ Limit and Deductible Fields Verified Successful -------



    #Verifying                  Per claim limit

    VerifyElement               (//div[@data-id\='LimitsandDeductibles']//div/label)[2]
    ClickElement                (//div[@data-id\='LimitsandDeductibles']//div/label)[2]
    VerifyElement               //lightning-base-combobox-item[@data-value\='500,000']
    VerifyElement               //lightning-base-combobox-item[@data-value\='1,000,000']
    VerifyElement               //lightning-base-combobox-item[@data-value\='2,000,000']
    VerifyElement               //lightning-base-combobox-item[@data-value\='3,000,000']
    VerifyElement               //lightning-base-combobox-item[@data-value\='4,000,000']
    VerifyElement               //lightning-base-combobox-item[@data-value\='5,000,000']
    VerifyElement               //lightning-base-combobox-item[@data-value\='6,000,000']
    VerifyElement               //lightning-base-combobox-item[@data-value\='7,000,000']
    VerifyElement               //lightning-base-combobox-item[@data-value\='7,500,000']
    VerifyElement               //lightning-base-combobox-item[@data-value\='8,000,000']
    VerifyElement               //lightning-base-combobox-item[@data-value\='9,000,000']
    VerifyElement               //lightning-base-combobox-item[@data-value\='10,000,000']
    ClickElement                (//div[@data-id\='LimitsandDeductibles']//div/label)[2]
    Log To Console              ------ Per claim Dropdown Verified Successful -------


    #Verifying                  Aggregate Limit
    VerifyElement               (//div[@data-id\='LimitsandDeductibles']//div/label)[3]
    ClickElement                (//div[@data-id\='LimitsandDeductibles']//div/label)[3]
    VerifyElement               //lightning-base-combobox-item[@data-value\='1,000,000']
    VerifyElement               //lightning-base-combobox-item[@data-value\='2,000,000']
    VerifyElement               //lightning-base-combobox-item[@data-value\='3,000,000']
    ClickElement                (//div[@data-id\='LimitsandDeductibles']//div/label)[3]
    Log To Console              ------ Aggregate Limit Dropdown Verified Successful -------



    #Verifying                  Deductible type
    VerifyElement               (//div[@data-id\='LimitsandDeductibles']//div/label)[5]
    ClickElement                (//div[@data-id\='LimitsandDeductibles']//div/label)[5]
    VerifyElement               //lightning-base-combobox-item[@data-value\='Damages and Defense Expenses']
    VerifyElement               //lightning-base-combobox-item[@data-value\='Damages Only']
    VerifyElement               //lightning-base-combobox-item[@data-value\='50% Max Expense Offset']
    ClickElement                (//div[@data-id\='LimitsandDeductibles']//div/label)[5]
    Log To Console              ------ Deductible type Dropdown Verified Successful -------

    #Verifying                  Per Claim Deductible
    VerifyElement               (//div[@data-id\='LimitsandDeductibles']//div/label)[6]
    ClickElement                (//div[@data-id\='LimitsandDeductibles']//div/label)[6]
    VerifyElement               //lightning-base-combobox-item[@data-value\='10,000']
    VerifyElement               //lightning-base-combobox-item[@data-value\='15,000']
    VerifyElement               //lightning-base-combobox-item[@data-value\='20,000']
    VerifyElement               //lightning-base-combobox-item[@data-value\='25,000']
    VerifyElement               //lightning-base-combobox-item[@data-value\='50,000']
    VerifyElement               //lightning-base-combobox-item[@data-value\='75,000']
    VerifyElement               //lightning-base-combobox-item[@data-value\='100,000']
    VerifyElement               //lightning-base-combobox-item[@data-value\='150,000']
    VerifyElement               //lightning-base-combobox-item[@data-value\='200,000']
    VerifyElement               //lightning-base-combobox-item[@data-value\='250,000']
    VerifyElement               //lightning-base-combobox-item[@data-value\='500,000']
    ClickElement                (//div[@data-id\='LimitsandDeductibles']//div/label)[6]
    Log To Console              ------ Per Claim Deductible Dropdown Verified Successful -------


    #Verifying                  Aggregate Deductible
    VerifyElement               (//div[@data-id\='LimitsandDeductibles']//div/label)[7]
    ClickElement                (//div[@data-id\='LimitsandDeductibles']//div/label)[7]
    VerifyElement               //lightning-base-combobox-item[@data-value\='1 time']
    VerifyElement               //lightning-base-combobox-item[@data-value\='2 times']
    VerifyElement               //lightning-base-combobox-item[@data-value\='3 times']
    VerifyElement               //lightning-base-combobox-item[@data-value\='None']
    ClickElement                (//div[@data-id\='LimitsandDeductibles']//div/label)[7]
    Log To Console              ------ Aggregate Deductible Dropdown Verified Successful -------




    ${orignal_premium}=         GetText                     (//c-quote-comparison-lawyer-guard-item-lwc//lightning-formatted-number)[1]
    Log To Console              ${orignal_premium}
    #Set Global Variable        ${orignal_premium}

    ClickElement                (//div[@data-id\='LimitsandDeductibles']//div/label)[2]
    ClickElement                //lightning-base-combobox-item[@data-value\='4,000,000']
    ClickElement                (//div[@data-id\='LimitsandDeductibles']//div/label)[6]
    ClickElement                //lightning-base-combobox-item[@data-value\='25,000']
    ClickElement                (//div[@data-id\='LimitsandDeductibles']//div/label)[3]
    ClickElement                //lightning-base-combobox-item[@data-value\='2,000,000']

    ClickElement                (//button[@title\='Rating'])[1]
    VerifyText                  Success                     anchor=Rating successfully!                             delay=15s


    ${changed_premium}=         GetText                     (//c-quote-comparison-lawyer-guard-item-lwc//lightning-formatted-number)[1]      delay=3s
    Log To Console              ${changed_premium}

Validate Quote Console Header Fields for Primary
    #Author=Amol
    [Documentation]             Quote Console Header
    [Tags]                      quote                       smoke

    VerifyElement               //a[@class\='quoteName']/b
    ${quote_name}=              GetText                     //a[@class\='quoteName']/b
    ${uniquename1}=             Set Variable                ${uniquename} 1
    Log To Console              ${uniquename1}
    IF                          "${quote_name}"=="${uniquename1}"
        Log To Console          Success
    ELSE
        Fail
    END
    Log To Console              ------ Quote Name Validated Successful -------

    VerifyElement               (//p/lightning-formatted-number)[1]
    VerifyElement               (//lightning-badge)[1]      #Quote Status
    VerifyElement               (//button[@title\='Rating'])[1]
    VerifyElement               //button[@title\='Clone Quote']
    VerifyElement               (//lightning-icon[@title\='Save'])[1]
    VerifyElement               //lightning-icon[@title\='Finalize Quote']
    VerifyElement               //lightning-icon[@title\='Referral']
    VerifyElement               //lightning-icon[@title\='Endorsements']
    VerifyElement               //span[text()\='Show menu']/parent::*                   #DropDown
    Log To Console              ------ Header Fields Validated Successful -------

Click Bind SL After Amendment
    #Author=Amol
    [Documentation]             Quote Console Header
    [Tags]                      quote                       smoke

    ClickElement                (//lightning-icon[@title\='Finalize Quote'])[2]         delay=2s
    VerifyText                  Success                     anchor=Finalize quote successfully!                     timeout=120s             partial_match=false
    Sleep                       30s                         30s
    ClickElement                //lightning-icon[@title\='Bind']
    ClickCheckbox               Agency broker license       off
    ClickCheckbox               Individual broker license                               on
    ClickElement                //span[text()\='Select Item 1']
    ClickElement                //button[@title\='Bind']
    VerifyText                  Success                     anchor=Bind quote successfully!                         timeout=45s


Send Mail On Submission Page Excess
    #Author=Amol
    [Documentation]             Sending Mail From Submission Page
    [Tags]                      Validating
    [Arguments]                 ${Mailtype}
    ClickText                   Send Mail
    UseModal                    On
    ClickElement                //select

    # #ClickText                Binder Transmittal
    IF                          "${Mailtype}"=="Additional Information Request"
        DropDown                Select a Template:          [[1]]
    ELSE IF                     "${Mailtype}"=="BOR Acknowledgement Midterm"
        DropDown                Select a Template:          [[2]]
    ELSE IF                     "${Mailtype}"=="BOR Acknowledgement New/Renewal"
        DropDown                Select a Template:          [[3]]
    ELSE IF                     "${Mailtype}"=="BOR Countermanding"
        DropDown                Select a Template:          [[4]]
    ELSE IF                     "${Mailtype}"=="Claim Verification"
        DropDown                Select a Template:          [[5]]
    ELSE IF                     "${Mailtype}"=="Coverage Expired – File Closed Transmittal"
        DropDown                Select a Template:          [[6]]
    ELSE IF                     "${Mailtype}"=="Declination"
        DropDown                Select a Template:          [[7]]
    ELSE IF                     "${Mailtype}"=="Duplicate Submission"
        DropDown                Select a Template:          [[8]]
    ELSE IF                     "${Mailtype}"=="Non-Renewal Transmittal"
        DropDown                Select a Template:          [[9]]
    ELSE IF                     "${Mailtype}"=="Not Quoted - Pricing"
        DropDown                Select a Template:          [[10]]
    ELSE IF                     "${Mailtype}"=="Quote Transmittal"
        DropDown                Select a Template:          [[11]]
    END
    ${subjectline}=             GetInputValue               Subject:                    timeout=45s
    Log To Console              ${subjectline}
    Set Global Variable         ${subjectline}
    ClickText                   Send                        anchor=Cancel
    Sleep                       40s
    ${body}=                    Get Email Content           ${client_id_mail}           ${client_secret_mail}       ${tenant_id}             QA.Testing.Inbox@innovisk.global              ${subjectline}
    #Log To Console             ${body}
    Set Global Variable         ${body}

Send Mail On Submission Page Primary
    #Author=Amol
    [Documentation]             Sending Mail From Submission Page
    [Tags]                      Validating
    [Arguments]                 ${Mailtype}
    ClickText                   Send Mail
    UseModal                    On
    ClickElement                //select

    # #ClickText                Binder Transmittal
    IF                          "${Mailtype}"=="Additional Information Request"
        DropDown                Select a Template:          [[1]]
    ELSE IF                     "${Mailtype}"=="Admitted Decline and Quote Surplus Transmittal"
        DropDown                Select a Template:          [[2]]
    ELSE IF                     "${Mailtype}"=="BOR Acknowledgement Midterm"
        DropDown                Select a Template:          [[3]]
    ELSE IF                     "${Mailtype}"=="BOR Acknowledgement New/Renewal"
        DropDown                Select a Template:          [[4]]
    ELSE IF                     "${Mailtype}"=="BOR Countermanding"
        DropDown                Select a Template:          [[5]]
    ELSE IF                     "${Mailtype}"=="Claim Verification"
        DropDown                Select a Template:          [[6]]
    ELSE IF                     "${Mailtype}"=="Coverage Expired – File Closed Transmittal"
        DropDown                Select a Template:          [[7]]
    ELSE IF                     "${Mailtype}"=="Declination"
        DropDown                Select a Template:          [[8]]
    ELSE IF                     "${Mailtype}"=="Duplicate Submission"
        DropDown                Select a Template:          [[9]]
    ELSE IF                     "${Mailtype}"=="Indication Transmittal"
        DropDown                Select a Template:          [[10]]
    ELSE IF                     "${Mailtype}"=="Non-Renewal Transmittal"
        DropDown                Select a Template:          [[11]]
    ELSE IF                     "${Mailtype}"=="Not Quoted - Pricing"
        DropDown                Select a Template:          [[12]]
    ELSE IF                     "${Mailtype}"=="Quote Transmittal"
        DropDown                Select a Template:          [[13]]
    ELSE IF                     "${Mailtype}"=="Streamline Proposal Follow Up Transmittal"
        DropDown                Select a Template:          [[14]]
    END
    ${subjectline}=             GetInputValue               Subject:                    timeout=45s
    Log To Console              ${subjectline}
    Set Global Variable         ${subjectline}
    ClickText                   Send                        anchor=Cancel
    Sleep                       40s
    ${body}=                    Get Email Content           ${client_id_mail}           ${client_secret_mail}       ${tenant_id}             QA.Testing.Inbox@innovisk.global              ${subjectline}
    #Log To Console             ${body}
    Set Global Variable         ${body}

Add Premium to Excess Fields
    #Author=Amol
    [Documentation]             Add Premium to Excess Fields
    [Tags]                      Excess Fields

    Scroll                      //html
    Scroll                      //html
    Scroll                      //html
    Scroll                      //html
    Scroll                      //html
    #Verify Excess Quote Data
    VerifyText                  Primary Quote Premium
    VerifyText                  Actual Primary Premium Charged
    VerifyText                  Excess Quota Share
    VerifyText                  Excess Layer Limit
    TypeText                    Actual Primary Premium Charged                          3000000
    TypeText                    //input[contains(@name,'-Excess Layer Limit')]          5000000
    ClickElement                (//lightning-icon[@title\='Save'])
    Sleep                       10s
    Scroll                      //html                      page_up
    Scroll                      //html                      page_up
    Scroll                      //html                      page_up
    Scroll                      //html                      page_up
    Scroll                      //html                      page_up


Add Endorsement
    [Documentation]             Add Endorsement
    [Arguments]                 ${Form_Name}

    ClickElement                (//lightning-icon[@title\='Endorsements' and @icon-name\='standard:contact_list'])[2]
    ClickElement                //input[@name\='enter-search']
    TypeText                    Search for Endorsements     ${Form_Name}
    Sleep                       5s
    ClickElement                (//table//tbody//tr//td/button)[1]
    ClickElement                //table//tbody//tr//lightning-button-icon//button[@title\="Edit"]
    ClickElement                (//table/tbody//tr)[4]
    TypeText                    Additional Insured(s) Name                              Test One
    ClickElement                //button[text()\="Save"]
    ClickText                   Return Quote Process

Click Rate after adding endorsement
    [Documentation]             Clicking on Rate button

    VerifyText                  Rate                        timeout=30
    RefreshPage
    Sleep                       5s
    ClickElement                (//button[@title\="Rating"])[3]
    VerifyText                  Success                     anchor=Rating sucessfully!                              timeout=45s


Check Image comparison - PreBind
    #Author=shraddha Patil
    [Documentation]             Check Image comparison
    [Arguments]                 ${imageno}                  ${doctype_}                 ${province_check}
    ${image1}=                  LogScreenshot

    IF                          "${doctype_}" == "Admitted_Quote"

        IF                      "${province_check}"=="Arizona"
            ${BASE_IMAGE_PATH}=                             Set Variable                ${CURDIR}/../images/quote/AZ
            Log To Console      ${BASE_IMAGE_PATH}
        ELSE IF                 "${province_check}"=="California"
            ${BASE_IMAGE_PATH}=                             Set Variable                ${CURDIR}/../images/quote/CA
            Log To Console      ${BASE_IMAGE_PATH}
        ELSE IF                 "${province_check}"=="Texas"
            ${BASE_IMAGE_PATH}=                             Set Variable                ${CURDIR}/../images/quote/TX
            Log To Console      ${BASE_IMAGE_PATH}
        ELSE IF                 "${province_check}"=="Oregon"
            ${BASE_IMAGE_PATH}=                             Set Variable                ${CURDIR}/../images/quote/OR
            Log To Console      ${BASE_IMAGE_PATH}
        ELSE IF                 "${province_check}"=="Alaska"
            ${BASE_IMAGE_PATH}=                             Set Variable                ${CURDIR}/../images/quote/AK
            Log To Console      ${BASE_IMAGE_PATH}
        END

        CompareImages           ${image1}                   quote${imageno}.png         tolerance=${tolerance}

    ELSE IF                     "${doctype_}" == "Quote_SL"

        IF                      "${province_check}"=="Arizona"
            ${BASE_IMAGE_PATH}=                             Set Variable                ${CURDIR}/../images/quoteSL/AZ
            Log To Console      ${BASE_IMAGE_PATH}
        ELSE IF                 "${province_check}"=="California"
            ${BASE_IMAGE_PATH}=                             Set Variable                ${CURDIR}/../images/quoteSL/CA
            Log To Console      ${BASE_IMAGE_PATH}
        ELSE IF                 "${province_check}"=="Texas"
            ${BASE_IMAGE_PATH}=                             Set Variable                ${CURDIR}/../images/quoteSL/TX
            Log To Console      ${BASE_IMAGE_PATH}
        ELSE IF                 "${province_check}"=="Oregon"
            ${BASE_IMAGE_PATH}=                             Set Variable                ${CURDIR}/../images/quoteSL/OR
            Log To Console      ${BASE_IMAGE_PATH}
        ELSE IF                 "${province_check}"=="Alaska"
            ${BASE_IMAGE_PATH}=                             Set Variable                ${CURDIR}/../images/quoteSL/AK
            Log To Console      ${BASE_IMAGE_PATH}
        END

        CompareImages           ${image1}                   quote${imageno}.png         tolerance=${tolerance}

    ELSE IF                     "${doctype_}" == "Account_Summary"

        IF                      "${province_check}"=="Arizona"
            ${BASE_IMAGE_PATH}=                             Set Variable                ${CURDIR}/../images/AccountSummary/AZ
            Log To Console      ${BASE_IMAGE_PATH}
        ELSE IF                 "${province_check}"=="California"
            ${BASE_IMAGE_PATH}=                             Set Variable                ${CURDIR}/../images/AccountSummary/CA
            Log To Console      ${BASE_IMAGE_PATH}
        ELSE IF                 "${province_check}"=="Texas"
            ${BASE_IMAGE_PATH}=                             Set Variable                ${CURDIR}/../images/AccountSummary/TX
            Log To Console      ${BASE_IMAGE_PATH}
        ELSE IF                 "${province_check}"=="Oregon"
            ${BASE_IMAGE_PATH}=                             Set Variable                ${CURDIR}/../images/AccountSummary/OR
            Log To Console      ${BASE_IMAGE_PATH}
        ELSE IF                 "${province_check}"=="Alaska"
            ${BASE_IMAGE_PATH}=                             Set Variable                ${CURDIR}/../images/AccountSummary/AK
            Log To Console      ${BASE_IMAGE_PATH}
        END

        CompareImages           ${image1}                   Account_Summary${imageno}.png                           tolerance=${tolerance}

    ELSE IF                     "${doctype_}" == "accountsummarysl"

        IF                      "${province_check}"=="Alaska"
            ${BASE_IMAGE_PATH}=                             Set Variable                ${CURDIR}/../images/accountsummarysl/AK
            Log To Console      ${BASE_IMAGE_PATH}
        ELSE IF                 "${province_check}"=="Arizona"
            ${BASE_IMAGE_PATH}=                             Set Variable                ${CURDIR}/../images/accountsummarysl/AZ
            Log To Console      ${BASE_IMAGE_PATH}
        ELSE IF                 "${province_check}"=="California"
            ${BASE_IMAGE_PATH}=                             Set Variable                ${CURDIR}/../images/accountsummarysl/CA
            Log To Console      ${BASE_IMAGE_PATH}
        ELSE IF                 "${province_check}"=="New York"
            ${BASE_IMAGE_PATH}=                             Set Variable                ${CURDIR}/../images/accountsummarysl/NY
            Log To Console      ${BASE_IMAGE_PATH}
        ELSE IF                 "${province_check}"=="Texas"
            ${BASE_IMAGE_PATH}=                             Set Variable                ${CURDIR}/../images/accountsummarysl/TX
            Log To Console      ${BASE_IMAGE_PATH}
        END

        CompareImages           ${image1}                   accountsummarysl${imageno}.png                          tolerance=${tolerance}


    ELSE IF                     "${doctype_}" == "Indication"

        IF                      "${province_check}"=="Arizona"
            ${BASE_IMAGE_PATH}=                             Set Variable                ${CURDIR}/../images/indication/AZ
            Log To Console      ${BASE_IMAGE_PATH}
        ELSE IF                 "${province_check}"=="California"
            ${BASE_IMAGE_PATH}=                             Set Variable                ${CURDIR}/../images/indication/CA
            Log To Console      ${BASE_IMAGE_PATH}
        ELSE IF                 "${province_check}"=="Texas"
            ${BASE_IMAGE_PATH}=                             Set Variable                ${CURDIR}/../images/indication/TX
            Log To Console      ${BASE_IMAGE_PATH}
        ELSE IF                 "${province_check}"=="Oregon"
            ${BASE_IMAGE_PATH}=                             Set Variable                ${CURDIR}/../images/indication/OR
            Log To Console      ${BASE_IMAGE_PATH}
        ELSE IF                 "${province_check}"=="Alaska"
            ${BASE_IMAGE_PATH}=                             Set Variable                ${CURDIR}/../images/indication/AK
            Log To Console      ${BASE_IMAGE_PATH}
        END

        CompareImages           ${image1}                   indication${imageno}.png    tolerance=${tolerance}


    ELSE IF                     "${doctype_}" == "StreamlineRW"

        IF                      "${province_check}"=="Arizona"
            ${BASE_IMAGE_PATH}=                             Set Variable                ${CURDIR}/../images/StreamlineRW/AZ
            Log To Console      ${BASE_IMAGE_PATH}
        ELSE IF                 "${province_check}"=="California"
            ${BASE_IMAGE_PATH}=                             Set Variable                ${CURDIR}/../images/StreamlineRW/CA
            Log To Console      ${BASE_IMAGE_PATH}
        ELSE IF                 "${province_check}"=="Texas"
            ${BASE_IMAGE_PATH}=                             Set Variable                ${CURDIR}/../images/StreamlineRW/TX
            Log To Console      ${BASE_IMAGE_PATH}
        ELSE IF                 "${province_check}"=="Oregon"
            ${BASE_IMAGE_PATH}=                             Set Variable                ${CURDIR}/../images/StreamlineRW/OR
            Log To Console      ${BASE_IMAGE_PATH}
        ELSE IF                 "${province_check}"=="Alaska"
            ${BASE_IMAGE_PATH}=                             Set Variable                ${CURDIR}/../images/StreamlineRW/AK
            Log To Console      ${BASE_IMAGE_PATH}
        END

        CompareImages           ${image1}                   streamline${imageno}.png    tolerance=${tolerance}

    ELSE IF                     "${doctype_}" == "StreamlineRWSL"

        IF                      "${province_check}"=="Arizona"
            ${BASE_IMAGE_PATH}=                             Set Variable                ${CURDIR}/../images/StreamlineRWSL/AZ
            Log To Console      ${BASE_IMAGE_PATH}
        ELSE IF                 "${province_check}"=="California"
            ${BASE_IMAGE_PATH}=                             Set Variable                ${CURDIR}/../images/StreamlineRWSL/CA
            Log To Console      ${BASE_IMAGE_PATH}
        ELSE IF                 "${province_check}"=="Texas"
            ${BASE_IMAGE_PATH}=                             Set Variable                ${CURDIR}/../images/StreamlineRWSL/TX
            Log To Console      ${BASE_IMAGE_PATH}
        ELSE IF                 "${province_check}"=="New York"
            ${BASE_IMAGE_PATH}=                             Set Variable                ${CURDIR}/../images/StreamlineRWSL/NY
            Log To Console      ${BASE_IMAGE_PATH}
        ELSE IF                 "${province_check}"=="Alaska"
            ${BASE_IMAGE_PATH}=                             Set Variable                ${CURDIR}/../images/StreamlineRWSL/AK
            Log To Console      ${BASE_IMAGE_PATH}
        END

        CompareImages           ${image1}                   streamline${imageno}.png    tolerance=${tolerance}
    END


Check Image comparison - PreBind - Account Summary
    #Author=shraddha Patil
    [Documentation]             Check Image comparison
    [Arguments]                 ${imageno}                  ${doctype_}                 ${province_check}           ${tolerance_a}
    ${image1}=                  LogScreenshot

    IF                          "${doctype_}" == "accountsummary"

        IF                      "${province_check}"=="Arizona"
            ${BASE_IMAGE_PATH}=                             Set Variable                ${CURDIR}/../images/accountsummary/AZ
            Log To Console      ${BASE_IMAGE_PATH}
        ELSE IF                 "${province_check}"=="California"
            ${BASE_IMAGE_PATH}=                             Set Variable                ${CURDIR}/../images/accountsummary/CA
            Log To Console      ${BASE_IMAGE_PATH}
        ELSE IF                 "${province_check}"=="Texas"
            ${BASE_IMAGE_PATH}=                             Set Variable                ${CURDIR}/../images/accountsummary/TX
            Log To Console      ${BASE_IMAGE_PATH}
        ELSE IF                 "${province_check}"=="Oregon"
            ${BASE_IMAGE_PATH}=                             Set Variable                ${CURDIR}/../images/accountsummary/OR
            Log To Console      ${BASE_IMAGE_PATH}
        ELSE IF                 "${province_check}"=="Alaska"
            ${BASE_IMAGE_PATH}=                             Set Variable                ${CURDIR}/../images/accountsummary/AK
            Log To Console      ${BASE_IMAGE_PATH}
        END

        CompareImages           ${image1}                   accountsummary${imageno}.png                            tolerance=${tolerance_a}

    ELSE IF                     "${doctype_}" == "accountsummarysl"

        IF                      "${province_check}"=="Alaska"
            ${BASE_IMAGE_PATH}=                             Set Variable                ${CURDIR}/../images/accountsummarysl/AK
            Log To Console      ${BASE_IMAGE_PATH}
        ELSE IF                 "${province_check}"=="Arizona"
            ${BASE_IMAGE_PATH}=                             Set Variable                ${CURDIR}/../images/accountsummarysl/AZ
            Log To Console      ${BASE_IMAGE_PATH}
        ELSE IF                 "${province_check}"=="California"
            ${BASE_IMAGE_PATH}=                             Set Variable                ${CURDIR}/../images/accountsummarysl/CA
            Log To Console      ${BASE_IMAGE_PATH}
        ELSE IF                 "${province_check}"=="New York"
            ${BASE_IMAGE_PATH}=                             Set Variable                ${CURDIR}/../images/accountsummarysl/NY
            Log To Console      ${BASE_IMAGE_PATH}
        ELSE IF                 "${province_check}"=="Texas"
            ${BASE_IMAGE_PATH}=                             Set Variable                ${CURDIR}/../images/accountsummarysl/TX
            Log To Console      ${BASE_IMAGE_PATH}
        END

        CompareImages           ${image1}                   accountsummarysl${imageno}.png                          tolerance=${tolerance_a}


    END

Add Endorsement for SL 
    [Documentation]             Add Endorsement
    [Arguments]                 ${Form_Name}

    ClickElement                (//lightning-icon[@title\='Endorsements' and @icon-name\='standard:contact_list'])[2]
    ClickElement                //input[@name\='enter-search']
    TypeText                    Search for Endorsements     ${Form_Name}
    Sleep                       5s
    ClickElement                (//table//tbody//tr//td/button)[1]
    ClickElement                //table//tbody//tr//lightning-button-icon//button[@title\="Edit"]
    ClickElement                ((//table/tbody//tr)[4]//td)[2]
    TypeText                    Additional Named Insured    Test One
    ClickElement                //button[text()\="Save"]
    ClickText                   Return Quote Process

Add Endorsement for Primary 
    [Documentation]             Add Endorsement
    [Arguments]                 ${Form_Name}

    ClickElement                (//lightning-icon[@title\='Endorsements' and @icon-name\='standard:contact_list'])[2]
    ClickElement                //input[@name\='enter-search']
    TypeText                    Search for Endorsements     ${Form_Name}
    Sleep                       5s
    ClickElement                (//table//tbody//tr//td/button)[1]
    #ClickElement               //table//tbody//tr//lightning-button-icon//button[@title\="Edit"]
    ClickElement                ((//table/tbody//tr)[4]//td)[2]
    ClickText                   Return Quote Process



Check Image comparison for Quote letter
    #Author=Amol Gaymukhe
    [Documentation]             Verify Indication document
    [Tags]                      Smoke_Test_LGO_Admitted     Smoke_Test
    [Arguments]                 ${imageno}
    ${image1}=                  LogScreenshot

    IF                          "${province_check}"=="Arizona"
        ${BASE_IMAGE_PATH}=     Set Variable                ${CURDIR}/../images/quote/AZ
    ELSE IF                     "${province_check}"=="California"
        ${BASE_IMAGE_PATH}=     Set Variable                ${CURDIR}/../images/quote/CA
    ELSE IF                     "${province_check}"=="Texas"
        ${BASE_IMAGE_PATH}=     Set Variable                ${CURDIR}/../images/quote/TX
    ELSE IF                     "${province_check}"=="Oregon"
        ${BASE_IMAGE_PATH}=     Set Variable                ${CURDIR}/../images/quote/OR
    ELSE IF                     "${province_check}"=="Alaska"
        ${BASE_IMAGE_PATH}=     Set Variable                ${CURDIR}/../images/quote/AK
    END

    CompareImages               ${image1}                   quote${imageno}.png         tolerance=${tolerance}



Check Image comparison for Quote letter SL
    #Author=Amol Gaymukhe
    [Documentation]             Verify Indication document
    [Tags]                      Smoke_Test_LGO_Admitted     Smoke_Test
    [Arguments]                 ${imageno}
    ${image1}=                  LogScreenshot

    IF                          "${province_check}"=="Arizona"
        ${BASE_IMAGE_PATH}=     Set Variable                ${CURDIR}/../images/quoteSL/AZ

    ELSE IF                     "${province_check}"=="California"
        ${BASE_IMAGE_PATH}=     Set Variable                ${CURDIR}/../images/quoteSL/CA
    ELSE IF                     "${province_check}"=="Texas"
        ${BASE_IMAGE_PATH}=     Set Variable                ${CURDIR}/../images/quoteSL/TX
    ELSE IF                     "${province_check}"=="Oregon"
        ${BASE_IMAGE_PATH}=     Set Variable                ${CURDIR}/../images/quoteSL/OR
    ELSE IF                     "${province_check}"=="Alaska"
        ${BASE_IMAGE_PATH}=     Set Variable                ${CURDIR}/../images/quoteSL/A
    END
    CompareImages               ${image1}                   quote${imageno}.png         tolerance=${tolerance}


Get Dynamic Data For SL Quote Letter
    #Author=Amol Gaymukhe
    [Documentation]             Verify Indication document
    [Tags]                      Smoke_Test_LGO_Admitted     Smoke_Test
    #Converting Date to Propsal Date
    ${CurrentDate}=             Get Current Date
    ${Pdate}=                   Convert Date                ${CurrentDate}              result_format=%B %-d, %Y
    Set Global Variable         ${Pdate}
    #Converting Eff Date and Exp Date
    ${Eff_D}=                   GetInputValue               (//div[@data-id\='QuoteData']//lightning-input)[1]
    ${Exp_D}=                   GetInputValue               (//div[@data-id\='QuoteData']//lightning-input)[2]
    ${Edate}=                   Convert Date                ${Eff_D}                    result_format=%B %-d, %Y
    ${Exdate}=                  Convert Date                ${Exp_D}                    result_format=%B %-d, %Y
    Set Global Variable         ${Edate}
    Set Global Variable         ${Exdate}

    ${SurplusTax}=              GetText                     (//div[@data-id\='QuoteData']//lightning-input)[10]
    ${pdf_SurplusTax}=          Set Variable                ${SurplusTax}
    Set Global Variable         ${pdf_SurplusTax}

    ${orignal_premium}=         GetText                     (//div[@data-id\='QuoteData']//lightning-input)[6]
    ${pdf_premium}=             Set Variable                ${orignal_premium}
    Set Global Variable         ${pdf_premium}

    ${Excess_Stamping_Fee}=     GetText                     (//div[@data-id\='QuoteData']//lightning-input)[11]
    ${pdf_Excess_Stamping_Fee}=                             Set Variable                ${Excess_Stamping_Fee}
    Set Global Variable         ${pdf_Excess_Stamping_Fee}

