*** Settings ***
Library                      QWeb
Library                      QForce
Library                      FakerLibrary
Library                      String
Library                      BuiltIn
Library                      DateTime
Resource                     ../resources/common.robot
Resource                     ../PageObjects/PageObjects_InusredInfo.robot

*** Variables ***
${broker_contact}            Automation LGO
${underwriter}               COPADO-LGO Automation-User

*** Keywords ***


Validate Submission Init on Submission info page 
    #Author=Amol Gaymukhe

    VerifyText               Select Account and Product
    VerifyText               Account Name
    VerifyInputValue         Account Name                ${uniqueName}
    VerifyText               *Product
    VerifyText               LawyerGuard
    VerifyText               Broker Contact

    VerifyPicklist           *Relationship Type          --None--
    VerifyPicklist           *Relationship Type          Broker
    VerifyPicklist           *Relationship Type          Sub-Producer

    VerifyText               Primary Broker?
    #VerifyCheckboxStatus    Checked                     disabled                    anchor= Primary Broker?

    VerifyText               Underwriter
    VerifyText               Received Date
    #validation Pending
    VerifyText               Effective Date
    #validation Pending
    VerifyText               Expiration Date
    #validation Pending
    VerifyText               Submission Init Form

    Log To Console           ----- Submission Init Values Validated Successfully -----

Select broker Contact Source
    #Author=Amol Gaymukhe

    UseModal                 On
    Select Broker Contact    ${broker_contact}           ${underwriter}
    Sleep                    15s

Select Broker Contact
    [Documentation]          Used to select the Broker on the Submission Init Form
    [Arguments]              ${broker}                   ${underwriter}
    #Author=Amol Gaymukhe
    Sleep                    5s
    UseModal                 On
    VerifyText               Submission Init Form
    LogScreenshot
    ClickElement             //label[text()\='Broker Contact']/following-sibling::div//input
    TypeText                 //label[text()\='Broker Contact']/following-sibling::div//input                     ${broker}
    Sleep                    3s
    ClickElement             //label[text()\='Broker Contact']/following-sibling::div//span[contains(text(),'${broker}')]
    # QVision.ClickText      ${broker}                   index=2

    Log To Console           ----- Broker Contact Selected                           Successfully -----
    # ClickElement           //label[text()\='Underwriter']//following-sibling::div//input
    # TypeText               //label[text()\='Underwriter']//following-sibling::div//input                       ${underwriter}
    # Sleep                  4s
    # ClickElement           (//label[text()\='Underwriter']//following-sibling::div//ul/li)[1]
    # #ClickElement          //label[text()\='Underwriter']/following-sibling::div//span[contains(text(),'${underwriter}')]
    Sleep                    5s
    ClickText                Next                        anchor=Cancel


Verify Date 
    #Author=Amol Gaymukhe
    [Documentation]          Used to select the Broker on the Submission Init Form
    Sleep                    5s
    UseModal                 On

    ${received_date}=        GetInputValue               //input[@name\='Received_Date__c']
    ${rdate}=                Remove String               ${received_date}            ,
    Log To Console           ${rdate}


    ${effective_date}=       GetInputValue               //input[@name\='Effective_Date__c']

    ${expiration_Date}=      GetInputValue               //input[@name\='Expiration_Date__c']

    Log To Console           ${received_date}            ${effective_date}           ${expiration_Date}

    ${cur_data}=             Get Current Date            increment=-1 day            result_format=%b %-d, %Y
    Log To Console           ${cur_data}

    Log To Console           ----- Dates On Submission Init Forms Validated Successfully -----
Validate Submission Init on Submission info page SL 
    #Author=Shraddha
    [Arguments]              ${Attachment_Point__c}

    UseModal                 on
    VerifyText               Select Account and Product
    VerifyText               Account Name
    #VerifyInputValue        Account Name                ${uniqueName}
    VerifyElement            //div[@class\="slds-form-element__control"]             anchor= Account Name
    VerifyText               *Product
    #VerifyText              LawyerGuard_SL
    VerifyElement            //input[@data-value\='LawyerGuard_SL']
    VerifyText               Layer
    ClickText                Primary                     anchor=Layer
    VerifyText               Excess                      anchor=Layer
    Clicktext                ${Attachment_Point__c}
    VerifyText               Broker Contact

    VerifyPicklist           *Relationship Type          --None--
    VerifyPicklist           *Relationship Type          Broker
    VerifyPicklist           *Relationship Type          Sub-Producer

    VerifyText               Primary Broker?
    #VerifyCheckboxStatus    Checked                     disabled                    anchor= Primary Broker?

    VerifyText               Underwriter
    VerifyText               Received Date
    #validation Pending
    VerifyText               Effective Date
    #validation Pending
    VerifyText               Expiration Date
    #validation Pending
    VerifyText               Submission Init Form

    Log To Console           ----- Submission Init Values Validated Successfully -----

Validate Submission Init on Submission info page SL Excess 
    #Author=Shraddha
    [Arguments]              ${Attachment_Point__c}

    UseModal                 on
    VerifyText               Select Account and Product
    VerifyText               Account Name
    #VerifyInputValue        Account Name                ${uniqueName}
    VerifyText               *Product
    #VerifyText              LawyerGuard_SL
    VerifyElement            //input[@data-value\='LawyerGuard_SL']
    VerifyElement            //div[@class\="slds-form-element__control"]             anchor= Account Name
    VerifyText               Layer
    ClickText                Primary                     anchor=Layer
    VerifyText               Excess                      anchor=Layer
    Clicktext                Excess
    VerifyText               Broker Contact

    VerifyPicklist           *Relationship Type          --None--
    VerifyPicklist           *Relationship Type          Broker
    VerifyPicklist           *Relationship Type          Sub-Producer

    VerifyText               Primary Broker?
    #VerifyCheckboxStatus    Checked                     disabled                    anchor= Primary Broker?

    VerifyText               Underwriter
    VerifyText               Received Date
    #validation Pending
    VerifyText               Effective Date
    #validation Pending
    VerifyText               Expiration Date
    #validation Pending
    VerifyText               Submission Init Form

    Log To Console           ----- Submission Init Values Validated Successfully -----







