*** Settings ***
Library                         QWeb
Library                         QForce
#Library                        QVision
Library                         FakerLibrary
Library                         String
Library                         BuiltIn
Library                         DateTime

Resource                        ../../resources/ReadPDF.robot


*** Keywords ***

Read PDF Quote Letter Static document data for Primary
    #Author=Amol Gaymukhe
    [Documentation]             Read PDF Quote Letter Static data for Primary
    [Tags]                      Reading data
    #ClickElement               //home/f/QuoteProposal.py
    Import Variables            ${CURDIR}/QuoteProposalSL.py
    Test PDF File               Quote Proposal
    ${AllPDFtext}=              GetPdfText
    #Log To Console              ${AllPDFtext}

    # Reading first page Content
    FOR                         ${index}                    IN RANGE                    10
        Log                     ${index}                    # 0-9
        ${rownum}=              Evaluate                    ${index}+1
        ${bannercheck}=         Set Variable                Quote.bannertext${rownum}
        # Log To Console        ${${bannercheck}}
        Should Contain          ${AllPDFtext}               ${${bannercheck}}
        #Test PDF File          ${${bannercheck}}
    END

    # Reading second page Content Quotation Section
    FOR                         ${index}                    IN RANGE                    9
        Log                     ${index}                    # 0-9
        ${rownum}=              Evaluate                    ${index}+1
        ${quotationcheck}=      Set Variable                Quote.quotationtext${rownum}
        # Log To Console        ${${quotationcheck}}
        Should Contain          ${AllPDFtext}               ${${quotationcheck}}
        # Test PDF File         ${${quotationcheck}}
    END

    #Reading third page Content Endorsement Section
    FOR                         ${index}                    IN RANGE                    15
        Log                     ${index}                    # 0-9
        ${rownum}=              Evaluate                    ${index}+1
        ${Endorsementcheck}=    Set Variable                Quote.endorsementtext${rownum}
        Log To Console          ${${Endorsementcheck}}
        Should Contain          ${AllPDFtext}               ${${Endorsementcheck}}
        Test PDF File           ${${Endorsementcheck}}
    END

    # Reading fourth page Content Binding Instruction Page Section
    FOR                         ${index}                    IN RANGE                    9
        Log                     ${index}                    # 0-9
        ${rownum}=              Evaluate                    ${index}+1
        ${BindingInstructionCheck}=                         Set Variable                Quote.bindingInstructiontext${rownum}
        # Log To Console        ${${BindingInstructionCheck}}
        Should Contain          ${AllPDFtext}               ${${BindingInstructionCheck}}
        # Test PDF File         ${${BindingInstructionCheck}}
    END

    #Reading fourth page Content BillingOptionCheck Page Section
    FOR                         ${index}                    IN RANGE                    12
        Log                     ${index}                    # 0-9
        ${rownum}=              Evaluate                    ${index}+1
        ${BillingOptionCheck}=                              Set Variable                Quote.billingoptiontext${rownum}
        Log To Console          ${${BillingOptionCheck}}
        Should Contain          ${AllPDFtext}               ${${BillingOptionCheck}}
        Test PDF File           ${${BillingOptionCheck}}
    END

    # Reading fourth page Content CoverageFeature Page Section
    FOR                         ${index}                    IN RANGE                    30
        Log                     ${index}                    # 0-9
        ${rownum}=              Evaluate                    ${index}+1
        ${CoverageFeatureCheck}=                            Set Variable                Quote.CoverageFeaturetext${rownum}
        # Log To Console        ${${CoverageFeatureCheck}}
        Should Contain          ${AllPDFtext}               ${${CoverageFeatureCheck}}
        # Test PDF File         ${${CoverageFeatureCheck}}
    END
    # Test PDF File             ${Quote.banner}
    # Test PDF File             ${Quote.CoverageFeaturetext5}
    # ${AllPDFtext}=            GetPdfText
    # Log To Console            ${AllPDFtext}
    Log To Console              ----------Static Quote Data Validated-------------------


Read PDF Quote Letter Static data for Primary

    [Documentation]             Read PDF Quote Letter Static data for Primary

    #Static Data - SL
    Test PDF File               Lawyerguard will be responsible for all Surplus Lines requirements and will pay any taxes
    Test PDF File               associated with this policy directly to the governing Surplus Lines body in the state of risk. You
    Test PDF File               confirm that you will email all necessary Surplus Lines documentation with desired coverage
    Test PDF File               option to be bound per this quotation to qa.testing.inbox@innovisk.global. Below are links to
    Test PDF File               each required document for your reference.
    Test PDF File               Notice of Excess Lines Placement
    Test PDF File               Affidavit by Producing Broker


    #Static Data - Common
    #Banner
    Test PDF File               Quote Proposal
    Test PDF File               LawyerGuard Surplus Lines thanks you for the opportunity to quote this account.
    Test PDF File               Questions? The LawyerGuard team is here to help!
    Test PDF File               WHY LawyerGuard®
    Test PDF File               LawyerGuard® is an insurance and risk management program for lawyers, with an
    Test PDF File               underwriting staff with over 200 years of combined experience. Since 1989, LawyerGuard®
    Test PDF File               has insured attorneys across the country. We underwrite defense,
    Test PDF File               general practice, and
    Test PDF File               specialist boutique firms on a primary and excess basis.
    Test PDF File               Underwritten by leading global providers
    Test PDF File               of specialty insurance,
    Test PDF File               attorneys with individually tailored coverages and risk management support to fit the needs of
    Test PDF File               each firm.

    #Quotation

    Test PDF File               Carrier: Certain Underwriters at Lloyd’s,
    Test PDF File               London AM Best:
    Test PDF File               A
    Test PDF File               XV
    Test PDF File               Participation: 100
    Test PDF File               Lawyers Professional Liability – Claims Made
    Test PDF File               Commission: See Billing Options Section
    Test PDF File               The Underwriters have been approved by the state’s Department of Insurance as an eligible surplus
    Test PDF File               lines insurer, but the policy is not covered by any Insurance Guaranty Fund.



    #Endorsement

    Test PDF File               FORMS TO BE USED:
    Test PDF File               Applicable to all quotes
    Test PDF File               Form Number
    Test PDF File               RM 0823
    Test PDF File               LG LPL SL DEC 02 24
    Test PDF File               LG LPL SL 01 02 24
    Test PDF File               LG LPL SL POL 02 24
    Test PDF File               Appendix A
    Test PDF File               Form Title
    Test PDF File               Risk Management Program Notice
    Test PDF File               Lawyers Professional Liability Policy - Declarations
    Test PDF File               Schedule of Forms and Endorsements
    Test PDF File               Lawyers Professional Liability Insurance Policy
    Test PDF File               Appendix A
    Test PDF File               THIS QUOTATION SHOULD NOT BE CONSTRUED AS A LEGAL INTERPRETATION OR
    Test PDF File               DESCRIPTION OF THE COVERAGE AFFORDED. THE SPECIFIC CONTRACT SHOULD BE
    Test PDF File               CONSULTED FOR THE EXACT DETAILS ON THE COVERAGE AND EXCLUSIONS


    #Binding Instructions
    Test PDF File               This quote is valid until
    Test PDF File               and does not necessarily provide the terms and conditions
    Test PDF File               requested in your submission.
    Test PDF File               After this date, the pricing, terms, and conditions are subject to
    Test PDF File               change. We will not be responsible for consequences that may arise from any delay or failure
    Test PDF File               Compensation: As the program
    Test PDF File               percentage of the insurance premium paid and covers the services we provide the carrier. We
    Test PDF File               may also receive a payment based upon the profitability of the business placed with this
    Test PDF File               carrier under the binding authority.

    #bindingInstructiontext12='per the instructions entitled “Billing Options” below.'

    #Billing Options
    Test PDF File               BILLING INSTRUCTIONS
    Test PDF File               Name of Account
    Test PDF File               Underwriter
    Test PDF File               Phone Number
    Test PDF File               Agency Billing:
    Test PDF File               Full annual premium due immediately upon receipt of invoice.
    Test PDF File               Remit payment
    Test PDF File               in full less commission of 12.00%
    Test PDF File               For billing questions please contact: Finance@Innovisk.com
    Test PDF File               Sincerely,
    Test PDF File               Marc Favata
    Test PDF File               Vice President

    #Coverage Features
    Test PDF File               COVERAGE FEATURES
    Test PDF File               Punitive Damages covered if insurable under applicable law.
    Test PDF File               50% Reduced Deductible for settlement of claim within 30 days after mediation (subject to
    Test PDF File               $25,000 max)
    Test PDF File               Crisis Event Coverage $20,000; Deductible does not apply
    Test PDF File               Pre-Claim Assistance
    Test PDF File               50% “Soft” Hammer
    Test PDF File               Pro Bono Services; Deductible does not apply
    Test PDF File               Malicious Prosecution included within Personal Injury
    Test PDF File               Loss of Earnings Coverage ($500/$15,000/$50,000); Deductible does not apply
    Test PDF File               Disciplinary Proceedings $30,000; Deductible does not apply
    Test PDF File               Broad Definition of Professional Services, as Lawyer, Arbitrator, Mediator, Lobbyist, Notary
    Test PDF File               Public, Title Agent, Administrator, Executor, Trustee, Publisher, Bar Board Member Expert
    Test PDF File               Witness, etc.
    Test PDF File               Independent Contractors/Of Counsels covered
    Test PDF File               Tail Options: 1, 2, 3, 5 years
    Test PDF File               Retirement Tail after 3 years with Insurer and no minimum age requirement, with option to
    Test PDF File               purchase for $2,000 per Attorney, if less than 3 years
    Test PDF File               Free Death/Disability Tail
    Test PDF File               Worldwide Territory
    Test PDF File               Spouse/Domestic Partner Coverage
    Test PDF File               Subpoena Assistance Coverage up to $25,000
    Test PDF File               Definition of Damages includes pre-judgment and post-judgment interest
    Test PDF File               Allowable equity interest in a client up to 10%
    Test PDF File               LawyerGuard policy holders received a variety of free risk management tools through Attorneys
    Test PDF File               Risk Management, including hot-line
    Test PDF File               Programs.
    Test PDF File               The above summary is a limited summation of the coverages available under the LawyerGuard policy,
    Test PDF File               which is available upon request. Refer to the actual insurance policy and all endorsements for a
    Test PDF File               complete description of all policy coverage, terms, limits and conditions.
    Test PDF File               www.LawyerGuard.com



Read PDF Quote Letter Static data for Excess

    [Documentation]             Read PDF Quote Letter Static data for Excess

    #Static Data - SL
    Test PDF File               Quote Proposal
    Test PDF File               LG is a Surplus Lines product.
    Test PDF File               Lawyerguard will be responsible for all Surplus Lines
    Test PDF File               requirements and will pay any taxes associated with this policy directly to the governing
    Test PDF File               Surplus Lines body in the state of risk.




    #Static Data - Common
    #Banner
    Test PDF File               Quote Proposal
    Test PDF File               LawyerGuard Surplus Lines thanks you for the opportunity to quote this account.
    Test PDF File               Questions? The LawyerGuard team is here to help!
    Test PDF File               WHY LawyerGuard®
    Test PDF File               LawyerGuard® is an insurance and risk management program for lawyers, with an
    Test PDF File               underwriting staff with over 200 years of combined experience. Since 1989, LawyerGuard® has
    Test PDF File               insured attorneys across the country.
    Test PDF File               We underwrite defense, general practice, and specialist
    Test PDF File               boutique firms on a primary and excess basis.
    Test PDF File               Underwritten by leading global providers of specialty
    Test PDF File               LawyerGuard® offers multiple options for law firms of up to 50 attorneys with
    Test PDF File               individually tailored coverages and risk management support to fit the needs of each firm.

    #Quotation
    Test PDF File               Carrier: Certain Underwriters at Lloyd’s,
    Test PDF File               London AM Best:
    Test PDF File               A
    Test PDF File               XV
    Test PDF File               Excess Lawyers Professional Liability
    Test PDF File               Policy Period:
    Test PDF File               Retroactive Date:
    Test PDF File               Premium Summary
    Test PDF File               Excess Coverage Summary
    Test PDF File               Commission: See Billing Options Section
    Test PDF File               The Underwriters have been approved by the state’s Department of Insurance as an eligible surplus
    Test PDF File               lines insurer, but the policy is not covered by any Insurance Guaranty Fund.

    #Endorsement
    Test PDF File               FORMS TO BE USED:
    Test PDF File               Applicable to all quotes
    Test PDF File               Form Number
    Test PDF File               RM 052024
    Test PDF File               LRP 01 05 24
    Test PDF File               LGXS 14 05 24
    Test PDF File               LGXS DEC 05 24
    Test PDF File               LGXS 13 05 24
    Test PDF File               LawyerGuard
    Test PDF File               Appendix A
    Test PDF File               Appendix B
    Test PDF File               Form Title
    Test PDF File               Risk Management Program Notice
    Test PDF File               Notice To Policyholder Loss Reporting Procedures
    Test PDF File               Excess Follow Form Policy Declarations
    Test PDF File               Excess Follow Form Liability Policy
    Test PDF File               Schedule of Underlying Insurance
    Test PDF File               Excess OFAC Notice
    Test PDF File               Appendix A
    Test PDF File               Appendix B
    Test PDF File               THIS QUOTATION SHOULD NOT BE CONSTRUED AS A LEGAL INTERPRETATION OR
    Test PDF File               DESCRIPTION OF THE COVERAGE AFFORDED. THE SPECIFIC CONTRACT SHOULD BE
    Test PDF File               CONSULTED FOR THE EXACT DETAILS ON THE COVERAGE AND EXCLUSIONS

    #Binding Instructions
    Test PDF File               This quote is valid until
    Test PDF File               and does not necessarily provide the terms and
    Test PDF File               conditions requested in your submission.
    Test PDF File               After this date,
    Test PDF File               the pricing,
    Test PDF File               terms, and conditions are
    Test PDF File               subject to change. We will not be responsible for consequences that may arise from any delay
    Test PDF File               or failure by you to respond to us by
    Test PDF File               Compensation:
    Test PDF File               As the program manager of the quoted
    Test PDF File               carrier in this proposal,
    Test PDF File               we receive
    Test PDF File               remuneration from the carrier for the tasks we provide the carrier.
    Test PDF File               Our remuneration is a
    Test PDF File               percentage of the insurance premium paid and covers the services we provide the carrier. We
    Test PDF File               may also receive a payment based upon the profitability of the business placed with this
    Test PDF File               carrier under the binding authority.

    #bindingInstructiontext12='per the instructions entitled “Billing Options” below.'


    #Billing Options
    Test PDF File               BILLING INSTRUCTIONS
    Test PDF File               Name of Account
    Test PDF File               Underwriter
    Test PDF File               Phone Number
    Test PDF File               Agency Billing:
    Test PDF File               Full annual premium due immediately upon receipt of invoice.
    Test PDF File               Remit payment
    Test PDF File               in full less commission of 12.00%
    Test PDF File               For billing questions please contact: Finance@Innovisk.com
    Test PDF File               Sincerely,
    Test PDF File               Marc Favata
    Test PDF File               Vice President
