class Quote:
    ip = '123.4.5.6'
    user = 'robot'
    roles = ['admin', 'user']

#Static Data
#Banner
    bannertext1='Quote Proposal'
    bannertext2='LawyerGuard Surplus Lines thanks you for the opportunity to quote this account.'
    bannertext3='Questions? The LawyerGuard team is here to help!'
    bannertext4='WHY LawyerGuard®'
    bannertext5='underwriting staff with over 200 years of combined experience. Since 1989, LawyerGuard®'
    bannertext6='has insured attorneys across the country. We underwrite defense,'
    bannertext7='specialist boutique firms on a primary and excess basis.'
    bannertext8='Underwritten by leading global providers'
    bannertext9='attorneys with individually tailored coverages and risk management support to fit the needs of'
    bannertext10='each firm.'

#Quotation
    quotationtext1='Carrier: Certain Underwriters at Lloyd’s,'
    quotationtext2='London AM Best:'
    quotationtext3='A'
    quotationtext4='XV'
    quotationtext5='Participation: 100'
    quotationtext6='Lawyers Professional Liability – Claims Made'
    quotationtext7='Commission: See Billing Options Section'
    quotationtext8='The Underwriters have been approved by the state’s Department of Insurance as an eligible surplus'
    quotationtext9='lines insurer, but the policy is not covered by any Insurance Guaranty Fund.'
    
#Endorsement
    
    endorsementtext1='FORMS TO BE USED:'
    endorsementtext2='Applicable to all quotes'
    endorsementtext3='Form Number'
    endorsementtext4='RM 0823'
    endorsementtext5='LG LPL SL DEC 02 24'
    endorsementtext6='LG LPL SL 01 02 24'
    endorsementtext7='LG LPL SL POL 02 24'
    endorsementtext8='Appendix A'
    endorsementtext9='Form Title'
    endorsementtext10='Risk Management Program Notice'
    endorsementtext11='Lawyers Professional Liability Policy - Declarations'
    endorsementtext12='Schedule of Forms and Endorsements'
    endorsementtext13='Lawyers Professional Liability Insurance Policy'
    endorsementtext14='Appendix A'
    endorsementtext15='CONSULTED FOR THE EXACT DETAILS ON THE COVERAGE AND EXCLUSIONS'
    
#Binding Instructions    
    bindingInstructiontext1='This quote is valid until'
    bindingInstructiontext2='and does not necessarily provide the terms and conditions'
    bindingInstructiontext3='requested in your submission.'
    bindingInstructiontext4='After this date, the pricing, terms, and conditions are subject to'
    bindingInstructiontext5='change. We will not be responsible for consequences that may arise from'
    bindingInstructiontext6='Compensation: As the program' 
    bindingInstructiontext7='percentage of the insurance premium paid and covers the services we provide the carrier. We'
    bindingInstructiontext8='may also receive a payment based upon the profitability of the business placed with this'
    bindingInstructiontext9='carrier under the binding authority.'



#Billing Options   
    billingoptiontext1='BILLING INSTRUCTIONS'
    billingoptiontext2='Name of Account'
    billingoptiontext3='Underwriter'
    billingoptiontext4='Phone Number'
    billingoptiontext5='Agency Billing:'
    billingoptiontext6='Full annual premium due immediately upon receipt of invoice.'
    billingoptiontext7='Remit payment'
    billingoptiontext8='in full less commission of 12.00%'
    billingoptiontext9='For billing questions please contact: Finance@Innovisk.com'
    billingoptiontext10='Sincerely,'
    billingoptiontext11='Marc Favata'
    billingoptiontext12='Vice President'
    
#Coverage Features   
    CoverageFeaturetext1='COVERAGE FEATURES'
    CoverageFeaturetext2='Punitive Damages covered if insurable under applicable law.'
    CoverageFeaturetext3='50% Reduced Deductible for settlement of claim within 30 days after mediation (subject to'
    CoverageFeaturetext4='$25,000 max)'
    CoverageFeaturetext5='Crisis Event Coverage $20,000; Deductible does not apply'
    CoverageFeaturetext6='Pre-Claim Assistance'
    CoverageFeaturetext7='50% “Soft” Hammer'
    CoverageFeaturetext8='Pro Bono Services; Deductible does not apply'
    CoverageFeaturetext9='Malicious Prosecution included within Personal Injury'
    CoverageFeaturetext10='Loss of Earnings Coverage ($500/$15,000/$50,000); Deductible does not apply'
    CoverageFeaturetext11='Disciplinary Proceedings $30,000; Deductible does not apply'
    CoverageFeaturetext12='Broad Definition of Professional Services, as Lawyer, Arbitrator, Mediator, Lobbyist, Notary'
    CoverageFeaturetext13='Public, Title Agent, Administrator, Executor, Trustee, Publisher, Bar Board Member Expert'
    CoverageFeaturetext14='Witness, etc.'
    CoverageFeaturetext15='Independent Contractors/Of Counsels covered'
    CoverageFeaturetext16='Tail Options: 1, 2, 3, 5 years'
    CoverageFeaturetext17='Retirement Tail after 3 years with Insurer and no minimum age requirement, with option to'
    CoverageFeaturetext18='purchase for $2,000 per Attorney, if less than 3 years'
    CoverageFeaturetext19='Free Death/Disability Tail'
    CoverageFeaturetext20='Worldwide Territory'
    CoverageFeaturetext21='Spouse/Domestic Partner Coverage'
    CoverageFeaturetext22='Subpoena Assistance Coverage up to $25,000'
    CoverageFeaturetext23='Definition of Damages includes pre-judgment and post-judgment interest'
    CoverageFeaturetext24='Allowable equity interest in a client up to 10%'
    CoverageFeaturetext25='LawyerGuard policy holders received a variety of free risk management tools through Attorneys'
    CoverageFeaturetext26='Programs.'
    CoverageFeaturetext27='The above summary is a limited summation of the coverages available under the LawyerGuard policy,'
    CoverageFeaturetext28='which is available upon request. Refer to the actual insurance policy and all endorsements for a'
    CoverageFeaturetext29='complete description of all policy coverage, terms, limits and conditions.'
    CoverageFeaturetext30='www.LawyerGuard.com'
   






    

