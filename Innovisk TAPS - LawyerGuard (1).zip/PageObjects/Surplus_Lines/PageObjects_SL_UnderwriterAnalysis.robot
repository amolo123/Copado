*** Settings ***
Library                      QWeb
Library                      QForce
#Library                     QVision
Library                      FakerLibrary
Library                      String
Library                      BuiltIn
Library                      DateTime
Resource                     ../../resources/common.robot
Resource                     ../PageObjects_SubmissionInfo.robot

Library                      ../../libraries/MailLib.py                              ${tenant_id}         ${client_id_mail}        ${client_secret_mail}

Library                      ${CURDIR}/../../libraries/graph.py
Resource                     ${CURDIR}/../../resources/graph.resource


*** Keywords ***

Validate Attributes for SL
    #Author=Rugveda Nikam
    [tags]                   Underwriting


    VerifyAttribute          //label[text()\='Total Defense AOP%']/parent::div//input                     type                     text
    VerifyAttribute          //span[text()\='Individuals - All Other']/parent::*//input                   max                      100
    VerifyAttribute          //span[text()\='Individuals - High Net Worth (>$10M assets)']/parent::*//input                        max    100
    VerifyAttribute          //span[text()\='Small Private Companies (<$100M revenues)']/parent::*//input                          max    100
    VerifyAttribute          //span[text()\='Large Private Companies (>$100M revenues)']/parent::*//input                          max    100
    VerifyAttribute          //span[text()\='Small Public Companies (<$100M revenues)']/parent::*//input                           max    100
    VerifyAttribute          //span[text()\='Large Public Companies (>$100M revenues)']/parent::*//input                           max    100
    VerifyAttribute          //span[text()\='Government or Public Institutions']/parent::*//input         max                      100
    VerifyAttribute          //span[text()\='Non Profit Organizations or Charities']/parent::*//input     max                      100
    VerifyAttribute          //span[text()\='Other']/parent::*//input                max                  100
    #                        VerifyAttribute             (//span[text()\='Y']/parent::*/parent::span/input)[1]                     part    radio
    #                        VerifyAttribute             (//span[text()='N']/parent::*/parent::span/input)[1]                      part    radio
    #                        VerifyAttribute             (//span[text()\='Y']/parent::*/parent::span/input)[2]                     part    radio
    #                        VerifyAttribute             (//span[text()\='N']/parent::*/parent::span/input)[2]                     part    radio
    VerifyCheckbox           //span[text()\='Bar Complaints/Disciplinary Actions']/parent::*/parent::*
    VerifyCheckbox           //span[text()\='Claims/Suits']/parent::*/parent::*
    VerifyAttribute          //label[text()\='Loss Ratio']/parent::*//input          type                 text

    Log To Console           ------Attributes Validated Successfully-------

*** Keywords ***
 Verify Underwriting Analysis Page Elements for SL Primary
    #Author=Rugveda Nikam
    [Documentation]          Add Primary
    [Tags]                   add SL AOP Primary
    VerifyText               Total Percentage:
    VerifyText               Area of Practice
    VerifyText               Total Defense AOP%
    VerifyText               Individuals - All Other
    VerifyText               Individuals - High Net Worth (>$10M assets)
    VerifyText               Small Private Companies (<$100M revenues)
    VerifyText               Large Private Companies (>$100M revenues)
    VerifyText               Small Public Companies (<$100M revenues)
    VerifyText               Large Public Companies (>$100M revenues)
    VerifyText               Government or Public Institutions
    VerifyText               Non Profit Organizations or Charities
    VerifyText               Other
    VerifyText               Coverage Gaps
    VerifyText               Declined/Cancelled/Non-Renewed
    VerifyText               Predecessor Firms
    VerifyText               Litigation History
    VerifyText               Bar Complaints/Disciplinary Actions
    VerifyText               Claims/Suits
    VerifyText               Loss Ratio
    VerifyText               Subjectivities
    VerifyText               Underwriting Comments (if applicable):
    Log To Console           ------Page Elements Validated Successfully-------

*** Keywords ***
 Add Area Of Practice for SL
    #Author=Rugveda Nikam
    [Documentation]          Add AOP SL
    [Tags]                   add SL AOP
    ClickElement             (//button[@title\='Add Area of Practice'])
    UseModal                 On
    VerifyText               Area of Practice Description                            timeout=10s
    TypeText                 Admiralty-Defense           100
    ClickText                (//button[text()\='Add'])
    Sleep                    3s
    Log To Console           ------Area Of Practice Added Successfully-------

*** Keywords ***

Add Details In Underwriter Analysis Tab for SL
    #Author=Rugveda Nikam
    [Documentation]          Add AOP SL
    [Tags]                   Underwriting
    Add UW
    Scroll                   //html
    Scroll                   //html
    ClickText                Y                           anchor=Coverage Gaps
    ClickText                Y                           anchor=Declined/Cancelled/Non-Renewed
    TypeText                 Predecessor Firms           Test Info 123
    VerifyText               Litigation History
    ClickElement             (//span[text()\='Litigation History']//ancestor::lightning-accordion-section//button)[3]
    #ClickElement            //button[@title\='']/parent::lightning-button-icon
    TypeText                 Enter Claim Matter          Test Claim
    ClickElement             //button[@name\='Severity']
    ClickText                Minimal
    TypeText                 Number of Lawyers           2
    ClickText                Bar Complaints/Disciplinary Actions
    ClickText                Claims/Suits
    TypeText                 Losses                      2
    TypeText                 Loss Ratio                  3

Add Subjectivities for SL 
    #Author=Amol Gaymukhe
    [Documentation]          Add Subjectivity
    [Tags]                   add

    Expand Subjectivities
    ClickElement             //button[@title\='Add Subjectivities']
    UseModal                 On
    VerifyText               Subjectivities
    ClickElement             //th[@data-label\='Amend the Area of Practice grid to equal 100%']/parent::tr/td
    ClickElement             //th[@data-label\='Claim Supplement']/parent::tr/td
    ClickText                Add                         partial_match=False
    TypeText                 Comments                    Test Data
    ClickText                Save                        anchor=Qualify Submission
    ClickText                Qualify Submission          anchor=Save
    VerifyText               Quote Console               timeout=55s
    Log To Console           ------Details Added Successfully-------

Add Litigation History On Underwriter Analysis Page for SL
    #Author=Rugveda Nikam
    [Documentation]          Add Litigation History
    [Tags]                   add
    VerifyText               Litigation History
    ClickElement             (//span[text()\='Litigation History']//ancestor::lightning-accordion-section//button)[3]
    #ClickElement            //button[@title\='']/parent::lightning-button-icon
    TypeText                 Enter Claim Matter          Test Claim
    ClickElement             //button[@name\='Severity']
    ClickText                Minimal
    TypeText                 Number of Lawyers           2
    ClickText                Bar Complaints/Disciplinary Actions
    ClickText                Claims/Suits
    TypeText                 Losses                      2
    TypeText                 Loss Ratio                  3
    ClickElement             (//button[@title\='Save'])                              anchor=Litigation History
    Log To Console           ------Litigation History added Successfully-------




Verify Litigation History after Renewal for SL
    ClickText                Underwriting Analysis
    ${lit_history}=          GetInputValue               //input[@name\='Enter Claim Matter']
    Log To Console           ${lit_history}
    IF                       '${lit_history}' == 'Test Claim'
        Log To Console       Success.....Litigation History after renewal verified
    ELSE
        Fail
    END

Add Subjectivity On Underwriter Analysis Page for SL
    #Author=Rugveda Nikam
    [Documentation]          Add Subjectivity
    [Tags]                   add

    ClickElement             //button[@title\='Add Subjectivities']
    UseModal                 On
    ClickElement             (//table//span[@part\='indicator'])[1]
    ClickElement             (//table//span[@part\='indicator'])[2]
    ClickElement             (//table//span[@part\='indicator'])[3]
    Sleep                    2s
    ClickElement             //button[@title\='Add']
    Log To Console           ------ Subjectivity Added Successfully ------



Add Closed Subjectivity On Underwriter Analysis Page for SL
    #Author=Rugveda Nikam
    [Documentation]          Add Subjectivity
    [Tags]                   add

    ClickElement             //button[@title\='Add Subjectivities']
    UseModal                 On
    ClickElement             (//table//span[@part\='indicator'])[4]
    ClickElement             (//table//span[@part\='indicator'])[5]
    ClickElement             (//table//span[@part\='indicator'])[6]

    ClickElement             //button[@title\='Add']

    UseModal                 Off
    Sleep                    4s
    ScrollTo                 (//label[text()\='Status'])[6]/parent::div
    ClickElement             (//label[text()\='Status'])[4]/parent::div

    ClickElement             (//span[@title\='Completed'])[1]

    ClickElement             (//label[text()\='Status'])[5]/parent::div
    ClickElement             (//span[@title\='Completed'])[2]

    ClickElement             (//label[text()\='Status'])[6]/parent::div
    ClickElement             (//span[@title\='Completed'])[3]


Input Data in Predecessor Firm On Underwriter Analysis SL
    #Author=Rugveda Nikam
    [Documentation]          Underwriting Analysis
    [Tags]                   add
    ClickText                Underwriting Analysis
    Sleep                    5s
    TypeText                 Predecessor Firm            Test Predecessor Data
    Log To Console           --------Input predecessor data successfull-----
