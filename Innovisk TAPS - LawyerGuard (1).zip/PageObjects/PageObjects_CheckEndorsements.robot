*** Settings ***
Library                 QWeb
Library                 QForce
#Library                QVision
Library                 FakerLibrary
Library                 String
Library                 BuiltIn
Library                 DateTime
Resource                ../resources/common.robot



*** Keywords ***

Check Endorsements According to State
    #Author=Amol Gaymukhe
    [Documentation]     Check the Endorsements for different states
    [Arguments]         ${state}

    #ClickElement       //lightning-icon[@title\='Endorsements']
    Import Variables    ${CURDIR}/Statevariables.py                    ${state}
    Log To Console      ${CURDIR}

    FOR                 ${index}                    IN RANGE           ${amountEndorsements}
        Log             ${index}                    # 0-9
        ${rownum}=      Evaluate                    ${index}+1

        Log To Console                              ${list}[${index}]
        UseTable        Endorsement Name
        ${text}=        GetCellText                 r${rownum}c2
        Log To Console                              ${text}
        IF              "${list}[${index}]"=="${text}"
            Log To Console                          Success
        ELSE
            FAIL
        END
    END


Select State
    [Documentation]     Select State
    [Arguments]         ${select_state}

    ClickText           Return Quote Process
    ClickElement        //a[@data-value\='Insured Info']
    VerifyTexts         Province
    PickList            Province                    ${select_state}
    ClickText           Save
    ClickElement        //span[text()\='Compare & Rate Quotes']
    ClickElement        //lightning-icon[@title\='Endorsements']
