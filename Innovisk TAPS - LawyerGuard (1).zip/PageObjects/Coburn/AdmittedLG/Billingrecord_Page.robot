*** Settings ***
Library                         QWeb
Library                         QForce
Library                         FakerLibrary
Library                         String
Library                         BuiltIn
Library                         DateTime

Resource                        ../../../resources/ReadPDF.robot

*** Variables ***
${broker_contact_coburn}        Suppressed Copado Broker

*** Keywords ***

Open Billing Record
    [Documentation]             Open Billing Record
    [Arguments]                 ${QuoteType}

    ClickText                   Billing                     anchor=Details
    UseTable                    Billing Record ID
    ClickText                   BR-                         anchor=${QuoteType}

    # Open Billing Record for Cancal and Replace
    #                           [Documentation]             Open Billing Record
    #                           [Arguments]                 ${QuoteType}

    #                           ClickText                   Billing                anchor=Details
    #                           UseTable                    Billing Record ID
    #                           ClickText                   BR-                    anchor=Generated

Check Non-Premium Billing Record is not created

    [Documentation]             Check Non-Premium Billing Record is not created

    ClickText                   Billing                     anchor=Details
    UseTable                    Billing Record ID
    VerifyNoText                Admendment                  anchor=Quote Type

Download Invoice
    [Documentation]             Download Invoice

    ClickText                   Download Invoice
    VerifyText                  Document has been downloaded sucessfully!          anchor=Success              timeout=60s

Get Details for Billing Record document validation

    [Documentation]             Get Details Billing Record validation

    ${PolicyName}=              GetFieldValue               Policy Name
    Log To Console              ${PolicyName}
    Set Global Variable         ${PolicyName}

    ${Policy_Number}=           GetFieldValue               Policy Number
    Log To Console              ${Policy_Number}
    Set Global Variable         ${Policy_Number}


Navigate to policy Page from Billing record page
    [Documentation]             Navigate to policy Page from Billing record page

    ${policy_number}=           GetFieldValue               Policy Number
    Log To Console              ${Policy_Number}
    ${policy_name}=             GetFieldValue               Policy

    IF                          "$policy_number"=="${EMPTY}" and "$policy_name"=="${EMPTY}"
        Fail
    ELSE
        Log To Console          Success Pass
    END

Verify Content on billing record PDF

    [Documentation]             Verify elements on billing record PDF
    [Arguments]                 ${QuoteType}                ${InsuredName}

    ${Invoice_No}=              GetFieldValue               Invoice No.
    ${Invoice_No}=              Convert To String           ${Invoice_No}
    Log To Console              ${Invoice_No}

    # Test PDF File             ${Invoice_No}
    Test PDF File               ${InsuredName}

    IF                          "${QuoteType}" == "New Business"


        Test PDF File           ${policy_number}
        Test PDF File           New Busines

    ELSE IF                     "${QuoteType}" == "Admendment"

        Test PDF File           ${policy_number}
        Test PDF File           New Busines
    ELSE IF                     "${QuoteType}" == "Flat Cancellation"

        Test PDF File           ${policy_number}
        Test PDF File           Flat Cancellation

    ELSE IF                     "${QuoteType}" == "Midterm Cancellation"

        Test PDF File           ${policy_number}
        Test PDF File           Midterm
        Test PDF File           Cancellation

    ELSE IF                     "${QuoteType}" == "Reinstatement"

        Test PDF File           ${policy_number}
        Test PDF File           Reinstatement

    ELSE IF                     "${QuoteType}" == "Renewal"

        Test PDF File           ${policy_number}
        Test PDF File           Renewal

    ELSE IF                     "${QuoteType}" == "Renewal"

        Test PDF File           ${policy_number}
        Test PDF File           Renewal
    END

    #Static Content

    Test PDF File               Sold To:
    Test PDF File               Bill To:
    # Test PDF File             Policy '#'
    Test PDF File               Total Due:
    # Test PDF File             Invoice "#:"
    Test PDF File               Invoice Date:
    Test PDF File               Due Date:
    # Test PDF File             Endorsement "#"

    Test PDF File               Payment Options:
    Test PDF File               Wire/ACH Remittances
    Test PDF File               or
    Test PDF File               Make Checks Payable to:

    Test PDF File               Bank Name:
    Test PDF File               JP Morgan
    Test PDF File               FEI Premium Trust
    Test PDF File               Account Name:
    Test PDF File               FEI Premium Trust
    # Test PDF File             Lockbox "# 880752"
    # Test PDF File             Routing "#"
    Test PDF File               021000021
    Test PDF File               PO BOX 29650
    # Test PDF File             Account "#"
    Test PDF File               599962787
    Test PDF File               PO BOX 29650
    Test PDF File               Swift Code
    Test PDF File               CHASUS33
    Test PDF File               Phoenix, AZ, 85038-9560

    Test PDF File               For Non-US remittance, please use both Account Number and Swift Code

    Test PDF File               Transaction Type
    Test PDF File               Eff Date:
    Test PDF File               Exp Date:
    Test PDF File               Line Code
    Test PDF File               Trans Date
    Test PDF File               Gross Amount
    Test PDF File               Commission %
    Test PDF File               Broker Commission
    Test PDF File               Net Amount
    Test PDF File               Premium
    Test PDF File               Totals:
    Test PDF File               For Billing Questions,
    Test PDF File               please E-mail:
    Test PDF File               Finance@innovisk.com

Verify Static fields On Billing Record Page

    [Documentation]             Verify feilds on billing record page
    [Tags]                      Billing record fields

    VerifyText                  Billing Record
    VerifyText                  Download Invoice
    #VerifyText                  Under Review
    VerifyText                  Delete
    VerifyText                  Unpaid
    VerifyText                  Partially paid
    VerifyText                  Fully paid
    VerifyText                  Overpaid
    VerifyText                  Overpayment in Error
    VerifyText                  Details
    VerifyText                  History
    VerifyText                  Related Records
    VerifyText                  Gross Amounts
    VerifyText                  Gross Premium
    VerifyText                  TRIA Premium
    VerifyText                  Policy Fees
    VerifyText                  State Stamping Fee
    VerifyText                  Surplus Line Tax
    VerifyText                  State Specific Fees
    VerifyText                  State Tax
    VerifyText                  Total Gross Amount
    VerifyText                  Commissions
    VerifyText                  Broker Commission %
    VerifyText                  Gross Premium Broker Amount
    VerifyText                  TRIA Premium Broker Amount
    VerifyText                  Total Commission
    VerifyText                  Net Amounts
    VerifyText                  Net Amount
    VerifyText                  Net TRIA Premium
    VerifyText                  Total Net Amount
    VerifyText                  Payments Info
    VerifyText                  Original Amount Due
    VerifyText                  Amount Paid
    VerifyText                  Amount Outstanding
    VerifyText                  Payment Status
    VerifyText                  % Paid
    VerifyText                  Invoice Details
    VerifyText                  Invoice No.
    VerifyText                  Invoice Status
    VerifyText                  Invoice Date
    VerifyText                  Status Change Reason
    VerifyText                  Due Date
    VerifyText                  Carrier Name
    VerifyText                  Policy Info
    VerifyText                  Policy
    VerifyText                  Policy Number
    VerifyText                  Quote
    VerifyText                  Quote Type
    VerifyText                  Quote Number
    VerifyText                  Endorsement ref
    VerifyText                  Policy Effective Date
    VerifyText                  Policy Expiry Date
    VerifyText                  Quote Endorsement Effective Date
    VerifyText                  Insured Name
    VerifyText                  LOB
    VerifyText                  Product
    VerifyText                  Underwriter
    VerifyText                  Broker Contact
    VerifyText                  Billing Agency
    VerifyText                  Billing Agency Contacts
    Scroll                      //html
    VerifyText                  All Billing Records Related To Policy
    UseTable                    Billing Record ID
    VerifyText                  Billing Record ID
    VerifyText                  Invoice No.
    VerifyText                  Payment Status
    VerifyText                  Invoice Status
    VerifyText                  Quote Number
    VerifyText                  Quote Type
    VerifyText                  Invoice Date
    VerifyText                  Amount Outstanding
    VerifyText                  System Info
    VerifyText                  Created By
    VerifyText                  Invoice Document Azure Id
    VerifyText                  Owner
    VerifyText                  Last Modified By
    VerifyText                  Currency

Validate Dynamic feilds on Billing Record

    [Documentation]             Validate Dynamic feilds on Billing Record
    [Arguments]                 ${PolicyNumber_BR}          ${QuoteName_Bill}      ${uniqueNameB}              ${broker_contact_coburn}    ${UniqueLOB}    ${BillingAgency}    ${UniqueProduct}

    ${cur_date}                 Get Current date            increment=1 day        result_format=%-m/%-d/%Y
    ${effective_Date}           Get Current date            increment=5 day        result_format=%-m/%-d/%Y
    ${Expiration_Date}          Get Current date            increment=370 day      result_format=%-m/%-d/%Y

    VerifyField                 Invoice Date                ${cur_date}
    VerifyField                 Due Date                    ${effective_Date}
    VerifyField                 Policy Effective Date       ${effective_Date}
    VerifyField                 Quote Effective Date        ${effective_Date}
    VerifyField                 Policy Expiry Date          ${Expiration_Date}
    VerifyField                 Quote Expiry Date           ${Expiration_Date}
    #VerifyField                Policy Number               ${PolicyNumber_BR}
    #VerifyField                Quote                       ${QuoteName_Bill}
    ClickFieldValue             Quote
    ${QuoteName_Bill}=          GetFieldValue               Quote Name             #//td[@data-label\='Quote Number']//a
    ${QuoteName_Bill2}=         Remove String               ${QuoteName_Bill}      1
    ${QuoteName_Bill3}=         Convert To String           ${QuoteName_Bill2}
    Set Global Variable         ${QuoteName_Bill3}
    ClickFieldValue             Policy
    Open Billing Record         NB
    ${getName}=                 GetFieldValue               Insured Name
    Set Global Variable         ${getName}
    ${getName1}=                Remove String               ${getName}             Open                        Preview
    ${getName2}=                Convert To String           ${getName1}
    Log To Console              ${getName2}
    # IF                        "$getName2" == "$QuoteName_Bill3"
    #                           Log To Console              Success
    # ELSE
    #                           Fail
    # END

    ClickFieldValue             Quote
    ${PolicyBR}=                GetFieldValue               Policy
    Set Global Variable         ${PolicyBR}
    ClickFieldValue             Policy
    Open Billing Record         NB
    ${policy_name}              GetFieldValue               Policy
    IF                          "$policy_name"=="$PolicyBR"
        Fail
    ELSE
        Log To Console          Success Pass
    END
    #VerifyField                Policy                      ${policy_name}
    #VerifyText                 Insured Name                ${uniqueNameB}
    ${UniqueProduct}            GetFieldValue               Product
    IF                          "$UniqueProduct"=="LawyerGuard"
        Fail
    ELSE
        Log To Console          Success Pass
    END
    ${UniqueLOB}                GetFieldValue               LOB
    IF                          "$UniqueLOB"=="LawyerGuard"
        Fail
    ELSE
        Log To Console          Success Pass
    END
    ${broker_contact_coburn}    GetFieldValue               Automation LGO
    ${BillingAgency}            GetFieldValue               CALIFORNIA INS CO


Get data to Validate on Billing Record
    [Documentation]             Get data to Validate on Billing Record

    ClickText                   Details
    VerifyField                 Policy Status               Bound
    ClickText                   Quote
    UseTable                    Quote Name
    ${QN}=                      GetCellText                 r1c3
    ClickText                   ${QN}                       anchor=Quote Number
    VerifyText                  Quote Premium               timeout=15s

    ${PolicyNumber_BR}=         GetFieldValue               Policy Number          #//td[@data-label\='Policy Number']//a
    Set Global Variable         ${PolicyNumber_BR}

    ${PolicyBR}=                GetFieldValue               Policy
    Set Global Variable         ${PolicyBR}


    ${QuoteName_Bill}=          GetFieldValue               Quote Name             #//td[@data-label\='Quote Number']//a
    Set Global Variable         ${QuoteName_Bill}



    #${EXPolicyNumber_BR}=      GetFieldValue               Excess Policy Number
    # Set Global Variable       ${EXPolicyNumber_BR}

    ClickFieldValue             Policy
    VerifyText                  Policy Type

