*** Settings ***
Library               QWeb
Library               QForce
#Library              QVision
Library               FakerLibrary
Resource              ../resources/common.robot



*** Keywords ***
Verify All HomePage Elemets
    # Author = Amol
    [tags]            All
    Home
    VerifyText        Accounts
    VerifyText        Contacts
    VerifyText        Reports
    VerifyText        Submissions
    VerifyText        Policies
    VerifyText        Reports
    VerifyText        New Submission
    VerifyText        Existing Submission
    VerifyText        Post Bind Endorsement
    Log To Console    ---- Homepge Elements Verified ----


App Launcher
    # Author = Amol
    [tags]            smoke

    # ClickElement    //button[@class\='slds-button slds-show']
    ClickElement      //span[text()\='App Launcher']