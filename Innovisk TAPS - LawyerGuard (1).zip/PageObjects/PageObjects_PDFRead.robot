*** Settings ***
Library                         QWeb
Library                         QForce
#Library                        QVision
Library                         FakerLibrary
Library                         String
Library                         BuiltIn
Library                         DateTime
Resource                        ../resources/common.robot
Resource                        ../resources/ReadPDF.robot
Resource                        ../PageObjects/PageObjects_Account.robot
Resource                        ../PageObjects/PageObjects_SubmissionInfo.robot
Resource                        ../PageObjects/PageObjects_SubmissionInit.robot
Resource                        ../PageObjects/PageObjects_CompareAndRateQuote.robot



*** Keywords ***
Read PDF Quote Letter Static Document
    #Author=Amol Gaymukhe
    [Documentation]             Read Static data of Quote Letter
    [Tags]                      smoke                       regression
    #ClickElement               //home/f/QuoteProposal.py
    Import Variables            ${CURDIR}/QuoteProposal.py
    Test PDF File               Quote Proposal
    ${AllPDFtext}=              GetPdfText
    #Log To Console             ${AllPDFtext}

    # Reading first page Content
    FOR                         ${index}                    IN RANGE                    6
        Log                     ${index}                    # 0-9
        ${rownum}=              Evaluate                    ${index}+1
        ${bannercheck}=         Set Variable                Quote.bannertext${rownum}
         Log To Console        ${${bannercheck}}
        Should Contain          ${AllPDFtext}               ${${bannercheck}}
        #Test PDF File          ${${bannercheck}}
    END

    # Reading second page Content Quotation Section
    FOR                         ${index}                    IN RANGE                    2
        Log                     ${index}                    # 0-9
        ${rownum}=              Evaluate                    ${index}+1
        ${quotationcheck}=      Set Variable                Quote.quotationtext${rownum}
        # Log To Console        ${${quotationcheck}}
        Should Contain          ${AllPDFtext}               ${${quotationcheck}}
        # Test PDF File         ${${quotationcheck}}
    END

    # Reading third page Content Endorsement Section
    #FOR                        ${index}                    IN RANGE                    19
    #Log                        ${index}                    # 0-9
    #${rownum}=                 Evaluate                    ${index}+1
    #${Endorsementcheck}=       Set Variable                Quote.endorsementtext${rownum}
    # Log To Console            ${${Endorsementcheck}}
    #Should Contain             ${AllPDFtext}               ${${Endorsementcheck}}
    # Test PDF File             ${${Endorsementcheck}}
    #END

    # Reading fourth page Content Binding Instruction Page Section
    FOR                         ${index}                    IN RANGE                    9
        Log                     ${index}                    # 0-9
        ${rownum}=              Evaluate                    ${index}+1
        ${BindingInstructionCheck}=                         Set Variable                Quote.bindingInstructiontext${rownum}
        # Log To Console        ${${BindingInstructionCheck}}
        Should Contain          ${AllPDFtext}               ${${BindingInstructionCheck}}
        # Test PDF File         ${${BindingInstructionCheck}}
    END

    # Reading fourth page Content BillingOptionCheck Page Section
    #FOR                        ${index}                    IN RANGE                    13
    #Log                        ${index}                    # 0-9
    #${rownum}=                 Evaluate                    ${index}+1
    #${BillingOptionCheck}=     Set Variable                Quote.billingoptiontext${rownum}
    # Log To Console            ${${BillingOptionCheck}}
    #Should Contain             ${AllPDFtext}               ${${BillingOptionCheck}}
    # Test PDF File             ${${BillingOptionCheck}}
    #END
    # Reading fourth page Content CoverageFeature Page Section
    FOR                         ${index}                    IN RANGE                    40
        Log                     ${index}                    # 0-9
        ${rownum}=              Evaluate                    ${index}+1
        ${CoverageFeatureCheck}=                            Set Variable                Quote.CoverageFeaturetext${rownum}
        # Log To Console        ${${CoverageFeatureCheck}}
        Should Contain          ${AllPDFtext}               ${${CoverageFeatureCheck}}
        # Test PDF File         ${${CoverageFeatureCheck}}
    END
    # Test PDF File             ${Quote.banner}
    # Test PDF File             ${Quote.CoverageFeaturetext5}
    # ${AllPDFtext}=            GetPdfText
    # Log To Console            ${AllPDFtext}
    Log To Console              ----------Static Quote Data Validated-------------------

Read PDF Quote Letter Dynamic Document
    #Author=Amol Gaymukhe
    [Documentation]             Read Static data of Quote Letter
    [Tags]                      smoke                       regression
    # #ClickElement             //home/f/QuoteProposal.py
    # Import Variables          /home/services/suite//PageObjects/QuoteProposal.py
    # Test PDF File             Quote Proposal
    ${AllPDFtext}=              GetPdfText
    Log To Console              ${AllPDFtext}
    Test PDF File               Regarding:
    Test PDF File               ${pdf_insuredname}
    Test PDF File               Date of Proposal:
    ${date}=                    Get Current Date            result_format=%B %-d, %Y
    Test PDF File               ${date}
    Test PDF File               Underwriter:
    Test PDF File               ${pdf_underwriter}
    #Test PDF File              qateam1@innovisk.com
    # Log To Console            ${pdf_brokername}
    # Test PDF File             ${pdf_brokername}
    Test PDF File               Premium
    Test PDF File               ${pdf_premium}
    Test PDF File               Taxes
    Test PDF File               ${pdf_statetaxes}
    Log To Console              Policy Period: ${pdf_policyperiod}
    Test PDF File               Policy Period: ${pdf_policyperiod}

    Log To Console              ----------Dynamic Quote Data Validated-------------------


Read PDF Streamlined Renewal Static Document
    #Author=Amol Gaymukhe
    [Documentation]             Read Static data of Quote Letter
    [Tags]                      smoke                       regression
    #ClickElement               //home/f/QuoteProposal.py
    # Import Variables          ${CURDIR}/StreamlinedRenewal.py
    Test PDF File               Renewal Proposal – Streamlined
    Test PDF File               The following quotation is a Streamlined Proposal based on current rates and forms for VA, for
    Test PDF File               1 Attorney(s) and 0 Of Counsel/Independent Contractor(s).
    Test PDF File               Lawyers Professional Liability – Claims Made & Reported
    Log To Console              ----------Static Data Validated------------
    Log To Console              ----------Static Streamlined Renewal Data Validated-------------------

Read PDF StreamlinedRenewal Dynamic Document
    #Author=Amol Gaymukhe
    [Documentation]             Read Static data of Quote Letter
    [Tags]                      smoke                       regression
    # #ClickElement             //home/f/QuoteProposal.py
    # Import Variables          /home/services/suite//PageObjects/QuoteProposal.py
    # ${AllPDFtext}=            GetPdfText
    # Log To Console            ${AllPDFtext}
    Test PDF File               Renewal Proposal – Streamlined
    Test PDF File               Regarding:
    Test PDF File               ${pdf_insuredname}
    Test PDF File               Date:
    # Log To Console            ${pdf_dateofproposal}
    # Test PDF File             ${pdf_dateofproposal}
    Test PDF File               Contact:
    Test PDF File               ${pdf_underwriter}
    #Test PDF File              qateam1@innovisk.com
    #Test PDF File              ${pdf_brokername}
    Test PDF File               Premium
    Test PDF File               ${pdf_premium}
    Test PDF File               Taxes
    Test PDF File               ${pdf_statetaxes}
    # Log To Console            Policy Period: ${pdf_policyperiod}
    Test PDF File               Policy Period:
    Test PDF File               ${pdf_policyperiod}
    Log To Console              ----------Dynamic Streamlined Renewal Data Validated-------------------



Read PDF Indication Static Document
    [Documentation]             Read Static data of Indication
    [Tags]                      smoke                       regression
    # Test PDF File             Ballpark Estimate
    Test PDF File               Questions? The LawyerGuard team is here to help!
    Test PDF File               Based on the information received, we are interested in pursuing this account further;
    Test PDF File               however, we do not have enough information to consider formal terms. The following is a
    Test PDF File               non-binding ballpark estimate which is based on the current rates and forms for the State of
    Test PDF File               VA
    #Test PDF File              For consideration of a formal proposal, we will need the following additional information (click
    #Test PDF File              on the corresponding link below to access the document):
    #Test PDF File              Please visit our website LawyerGuard.com for our Coverage Features.

    # ${AllPDFtext}=            GetPdfText
    # Log To Console            ${AllPDFtext}
    Log To Console              ----------Static Indication Data Validated-------------------

Read PDF Indication Dynamic Document
    [Documentation]             Read Static data of Indication
    [Tags]                      smoke                       regression
    # ${AllPDFtext}=            GetPdfText
    # Log To Console            ${AllPDFtext}
    Test PDF File               Regarding:
    Test PDF File               ${pdf_insuredname}
    Test PDF File               Date of Estimate:
    # Log To Console            ${pdf_dateofproposal}
    #Test PDF File               ${pdf_dateofproposal}
    Test PDF File               Underwriter:
    Test PDF File               ${pdf_underwriter}
    # Test PDF File             qateam1@innovisk.com
    #Test PDF File               ${pdf_brokername}
    Test PDF File               Premium
    Test PDF File               ${pdf_premium}
    Test PDF File               Taxes
    Test PDF File               ${pdf_statetaxes}
    # Log To Console            Policy Period: ${pdf_policyperiod}
    Test PDF File               Policy Period:
    Test PDF File               ${pdf_policyperiod}
    Log To Console              ----------Dynamic Data Validated------------


Read Word Account Summary Static Document
    [Documentation]             Read Static data of Indication
    [Tags]                      smoke                       regression

    Should Contain              ${read_doc}                 Account Summary - ${pdf_insuredname}
    Should Contain              ${read_doc}                 SECTION 1 - INSURED INFORMATION
    Should Contain              ${read_doc}                 Letterhead Included:
    Should Contain              ${read_doc}                 Website:
    Should Contain              ${read_doc}                 Territory:
    Should Contain              ${read_doc}                 Street:
    Should Contain              ${read_doc}                 County:
    Should Contain              ${read_doc}                 City:
    Should Contain              ${read_doc}                 State:
    Should Contain              ${read_doc}                 City:
    Should Contain              ${read_doc}                 ATTORNEY INFORMATION
    Should Contain              ${read_doc}                 Underwriting Comments (if applicable):
    Should Contain              ${read_doc}                 New/Renewal:
    Should Contain              ${read_doc}                 Current Carrier:
    Should Contain              ${read_doc}                 Established Date:
    Should Contain              ${read_doc}                 Policy Period:
    Should Contain              ${read_doc}                 Retroactive Date:
    Should Contain              ${read_doc}                 Date Application Signed:
    Should Contain              ${read_doc}                 Signed & dated within
    Should Contain              ${read_doc}                 60/90 (N/R) days:
    Should Contain              ${read_doc}                 Expiring Revenue/Atty:
    Should Contain              ${read_doc}                 Current Revenue/Atty:
    Should Contain              ${read_doc}                 25% Client Revenue:
    Should Contain              ${read_doc}                 Officer/Director/Ownership in Client(s):
    Should Contain              ${read_doc}                 DRI Status:
    Should Contain              ${read_doc}                 Career Coverage:
    Should Contain              ${read_doc}                 AREAS OF PRACTICE
    Should Contain              ${read_doc}                 Practice Type
    Should Contain              ${read_doc}                 INSURANCE HISTORY

    Log To Console              ----------Static Data Validated------------


Read Word Account Summary Dynamic Document
    [Documentation]             Read Static data of Indication
    [Tags]                      smoke                       regression

    Should Contain              ${read_doc}                 ${pdf_insuredname}
    Should Contain              ${read_doc}                 VA
    Should Contain              ${read_doc}                 New Business
    Log To Console              ${pdf_policyperiod2}
    Should Contain              ${read_doc}                 ${pdf_policyperiod2}
    Should Contain              ${read_doc}                 ${pdf_premium}
    #Should Contain              ${read_doc}                 ${pdf_dateofproposal2}

    Log To Console              ----------Dynamic Data Validated------------


