*** Settings ***
Library                         OperatingSystem
Library                         DateTime
Library                         Collections
Library                         QVision
Library                         String
Library                         QForce
Library                         QWeb



*** Keywords ***
Get Latest Downloaded Docx File

    #Set Global Variable        ${DOWNLOAD_DIR}             /home/services/Downloads
    ${HOME}=                    Get Environment Variable    HOME
    ${DOWNLOAD_DIR}=            Set Variable                ${HOME}/Downloads
    Set Global Variable         ${DOWNLOAD_DIR}

    Log                         Checking folder: ${DOWNLOAD_DIR}
    Sleep                       30s
    Directory Should Exist      ${DOWNLOAD_DIR}

    Sleep                       30s
    ${files}=                   List Files In Directory     ${DOWNLOAD_DIR}             *.docx
    Log Many                    ${files}
    Should Not Be Empty         ${files}                    No .docx files found in ${DOWNLOAD_DIR}

    ${latest_file}=             Set Variable                NONE
    ${latest_time}=             Set Variable                0
    Set Global Variable         ${latest_file}

    FOR                         ${file}                     IN                          @{files}
        ${path}=                Set Variable                ${DOWNLOAD_DIR}${/}${file}
        ${modified_str}=        Get Modified Time           ${path}
        ${modified}=            Convert Date                ${modified_str}             result_format=epoch
        Run Keyword If          ${modified} > ${latest_time}                            Set Variable           ${latest_time}    ${modified}
        Run Keyword If          ${modified} > ${latest_time}                            Set Variable           ${latest_file}    ${path}
    END

    Should Not Be Empty         ${latest_file}              Could not find the latest .docx file in ${DOWNLOAD_DIR}
    Sleep                       15s
    # [Return]                  ${latest_file}

Upload file
    [Documentation]             Keyword for uploading files, using the project structure (${CURDIR}/resources)
    #[Arguments]                ${file_name}

    Set Library Search Order    QVision                     QWeb                        QForce
    sleep                       3s

    ${file_path}=               Convert To String           ${DOWNLOAD_DIR}
    @{folders}                  Split String                ${file_path}                separator=/

    FOR                         ${folder}                   IN                          @{folders}
        IF                      '${folder}' != ''
            DoubleClick         ${folder}
        END
    END

    DoubleClick                 ${latest_file}
    Set Library Search Order    QWeb                        QForce
    Run Keyword                 Return To Root Directory
    #VerifyElement              //*[text()\="Download"]     timeout=120s


Return To Root Directory
    [Documentation]             Navigates back to the root directory after upload
    DoubleClick                 /
    Sleep                       1s


Upload and Download file
    ClickElement                //*[text()\="Download"]     timeout=120s


Open new window and convert to PDF

    Sleep                       30s
    RefreshPage
    Sleep                       30s
    Run Keyword                 Get Latest Downloaded Docx File
    OpenWindow
    SwitchWindow                2
    GoTo                        https://smallpdf.com/pdf-to-word
    #GoTo                       https://www.ilovepdf.com/word_to_pdf
    ClickElement                //*[text()\="Choose Files"]
    Run Keyword                 Upload file
    Run Keyword                 Upload and Download file
    CloseWindow
    SwitchWindow                1
    Sleep                       5s
    RefreshPage


Open word document in online Word

    Log                         opening Acoount summary docuemnt in online word
    Sleep                       15s
    RefreshPage
    Run Keyword                 Get Latest Downloaded Docx File
    OpenWindow
    SwitchWindow                2
    #GoTo                       https://jumpshare.com/viewer/word
    GoTo                        https://word.cloud.microsoft/
    QWeb.ClickText              Upload a file
    QWeb.TypeText               Email                       innoviskcopado@gmail.com
    QWeb.Clicktext              Next
    QWeb.Clicktext              Use your password
    QWeb.TypeText               Password                    Vindati@123
    QWeb.Clicktext              Next
    ${stay}=                    QWeb.IsText                 Stay signed in?             timeout=30s
    IF                          "${stay}" == "True"

        QWeb.ClickText          No

    END
    RefreshPage
    Sleep                       30s
    ${PSA}=                     QWeb.IsText                 Please wait a few minutes and then sign in again to access your documents.
    IF                          "${PSA}" == "True"

        QWeb.ClickText          Go back

    END

    QWeb.VerifyText             Upload a file               timeout=60s
    QWeb.ClickText              Upload a file
    Sleep                       30s
    Run Keyword                 Upload file
    Sleep                       60s
    VerifyText                  Format Painter              timeout=120s