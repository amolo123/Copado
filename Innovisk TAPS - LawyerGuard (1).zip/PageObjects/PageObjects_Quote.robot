*** Settings ***
Library                    QWeb
Library                    QForce
#Library                   QVision
Library                    FakerLibrary
Library                    String
Library                    BuiltIn
Library                    DateTime
Resource                   ../resources/common.robot
Resource                   ../PageObjects/PageObjects_Account.robot
Resource                   ../PageObjects/PageObjects_CompareAndRateQuote.robot


*** Keywords ***

Validate Quote Screen Static Elements Admitted
    #Author=Amol
    [Documentation]        Validating Quote Screen Elements
    [Tags]                 Validating

    VerifyText             Quote Name
    VerifyText             Quote Number
    VerifyText             Submission Name
    VerifyText             Account Name
    VerifyText             Transaction Policy Fee
    VerifyText             Municipal Taxes
    VerifyText             Non-Surplus Line Taxes
    VerifyText             Quote Premium
    VerifyText             Total Premium
    VerifyText             Transaction Premium
    VerifyText             Transaction Taxes
    VerifyText             Earned Premium Factor
    VerifyText             Unearned Premium Factor
    VerifyText             Endorsement number
    VerifyText             Named Individual ERP Type
    VerifyText             Quote Currency
    VerifyText             Status
    VerifyText             Rating Status
    VerifyText             Approval Status
    VerifyText             Close Date
    VerifyText             Closed Reason
    VerifyText             Policy
    VerifyText             Policy Number
    VerifyText             Pay Plan
    VerifyText             Net Revenue
    VerifyText             State Taxes

Validate Quote Screen Static Elements SL 
    #Author=Amol
    [Documentation]        Validating Quote Screen Elements
    [Tags]                 SL


    VerifyText             Primary Quote Premium
    VerifyText             Actual Primary Premium Charged
    VerifyText             Attachment Point
    VerifyText             Excess Quota Share
    VerifyText             Attachment Point Limit
    #VerifyText            Excess Unshared Quota Share Premium
    VerifyText             Excess Layer Limit


    VerifyText             Effective Date
    VerifyText             Expiry Date
    VerifyText             Endorsement Effective Date
    VerifyText             Accounting Date
    VerifyText             Overall UW Codes
    VerifyText             Data Breach Premium
    VerifyText             UW Reason
    VerifyText             LPL Premium
    VerifyText             Broker
    VerifyText             Broker Email
    VerifyText             Gross Commission
    VerifyText             Default Commission Percentage
    VerifyText             Commission %
    VerifyText             Commission
    VerifyText             Created By
    VerifyText             Last Modified By
    VerifyText             Azure ID
    VerifyText             Last Modified By
    VerifyText             Generate Quote Document

    VerifyText             Additional Interests
    VerifyText             Approvals
    VerifyText             Referral Reasons
    VerifyText             Endorsement Change Summary
    VerifyText             G Trac
    VerifyNoText           Excess Unshared Quota Share Premium


Validate Quote Screen Dynamic Elements
    #Author=Amol
    [Documentation]        Validating Dynamic Elements
    [Tags]                 Validating

    VerifyField            Quote Name                  ${uniqueName} 1
    ${getName}=            GetText                     //records-record-layout-item[@field-label\='Submission Name']//div/a
    IF                     "${getName}" == "${uniqueName}"
        Log To Console     Success
    ELSE
        Fail
    END
    #VerifyField           Submission Name             Open ${uniqueName} Preview
    VerifyField            Rating Status               Clear
    ${cur_date}=           Get Current Date            increment=5 day             result_format=%-m/%-d/%Y
    ${xpiration_Date}=     Get Current Date            increment=370 day           result_format=%-m/%-d/%Y
    VerifyField            Effective Date              ${cur_date}
    VerifyField            Expiry Date                 ${xpiration_Date}
    VerifyField            Quote Currency                    USD - U.S. Dollar
    ${Broker}=             GetFieldValue               Broker
    Log To Console         ${Broker}
    Set Global Variable    ${Broker}
    #VerifyField           Broker                      Automation LGO
    #VerifyField           Broker Email                qa.testing.inbox@innovisk.global
    ${Broker_email}=       GetFieldValue               Broker Email
    Log To Console         ${Broker_email}
    Set Global Variable    ${Broker_email}
    IF                     "$Broker"== "Open Automation LGO Preview" and "$Broker_email"== "qa.testing.inbox@innovisk.global"
        Fail
    ELSE
        Log To Console     Success Pass
    END



