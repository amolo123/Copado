*** Settings ***
Library                         QWeb
Library                         QForce
#Library                        QVision
Library                         FakerLibrary
Library                         String
Library                         BuiltIn
Library                         DateTime
Resource                        ../resources/common.robot
Resource                        PageObjects_Account.robot
Resource                        PageObjects_InusredInfo.robot




*** Keywords ***

Validate SubmissionInfo New submission Fields
    #Author=Amol
    [tags]                      submission

    VerifyText                  Account Name                anchor=Account Name         partial_match=False
    VerifyText                  Type
    VerifyText                  Product
    VerifyText                  Workflow Status
    VerifyText                  Auto Renewal
    VerifyText                  Closed Reason
    VerifyText                  Expiring Premium
    VerifyText                  Expiring Attorneys
    VerifyText                  Current Carrier
    VerifyText                  Policy Number
    VerifyText                  Current Revenue
    VerifyText                  Expiring Revenue
    VerifyText                  Signed & dated within 60/90 (N/R) day
    VerifyText                  25% Client Revenue
    VerifyText                  Effective Date
    VerifyText                  Received Date
    VerifyText                  Expiration Date
    VerifyText                  Quote Due Date
    VerifyText                  Retroactive Date
    VerifyText                  Established Date (Year Only)
    VerifyText                  Date Application Signed
    VerifyText                  Retroactive Date Inception(RDI)
    VerifyText                  Conflicts of Interest
    VerifyText                  Suits for Fees
    VerifyText                  Docket Control
    VerifyText                  SFF Preventive Measures
    VerifyText                  Engagement Letters
    VerifyText                  Broker Account
    VerifyText                  Broker ID
    VerifyText                  Broker Name
    VerifyText                  Primary Broker?
    VerifyText                  Relationship Type
    VerifyText                  New                         anchor=Broker Account
    VerifyElement               (//button[text()\='New'])
    VerifyText                  Underwriting Comments (if applicable):
    VerifyText                  Clone & Close
    VerifyText                  Decline
    VerifyText                  Close
    VerifyText                  Create SL Submission
    Log To Console              ----- Submission Info Fileds Validated Successfully -----

    # Verifying Picklist Values

    ${WorkflowStatus_value}=    GetPicklist                 Workflow Status
    Log To Console              ${WorkflowStatus_value}
    @{workflow_expected}=       Create List                 Additional Information Requested                        Audit                  Auto-Renewal             Bound                   Declined               Indication Released                 Initial Review                           Non-Renewed                 Not Quoted                  Not Quoted - Duplicate      Not Sold      Quote Referred        Quote Released        Received                    Renewal In Process          Underwriter Review      Not Quoted - Excess Opportunity
    Log To Console              ${workflow_expected}
    Lists Should Be Equal       ${WorkflowStatus_value}     ${workflow_expected}        ignore_order=True


    ${Closedreason_value}=      GetPicklist                 Closed Reason
    Log To Console              ${Closedreason_value}
    @{Closedreason_expected}=                               Create List                 Alternate Carrier Quote     Broker Of Record       Commission               Coverage Deal Breaker                          Duplicate submission                Firm Dissolved                           Lack of Lead Time           Loyalty                     No Response                 Non-Renewal Sent                    Not Quoted - Additional Info Requested            Not Quoted - Firm Dissolved            Not Quoted - Indication Provided    Not Wanted    Other    Premium    Price / Coverage (Broker Lost)    Price / Coverage (Broker Placed Elsewhere)    Service    Withdrawn
    Log To Console              ${Closedreason_expected}
    Lists Should Be Equal       ${Closedreason_value}       ${Closedreason_expected}    ignore_order=True
    Log To Console              ----- Picklist Values Validated Successfully -----


Verify SubmissionInfo Page Input Details
    #Author=Amol Gaymukhe
    #VerifyInputValue           Account Name                anchor=Account Name         partial_match=False
    [Documentation]             Add the details
    ${ipval}=                   GetText                     //label[text()\='Account Name']/parent::c-generate-element-lwc/div//a
    Log To Console              ${ipval}
    ${name3}=                   Set Variable                ${uniqueName}
    Log To Console              ${name3}
    #IF                         "$ipval"=="$name3"
    #                           Log To Console              Success
    # ELSE
    #                           Fail                        Assertion Failed
    #END
    Log Screenshot
    Log To Console              ----- Name Validated Successfully -----
    ${product}=                 GetText                     //label[text()\='Product']/parent::c-generate-element-lwc/div//a
    Log To Console              ${product}

    IF                          "${product}"=="LawyerGuard"
        Log To Console          Success
    ELSE
        Fail                    Assertion Failed
    END
    Log Screenshot
    Log To Console              ----- Product Validated Successfully -----
    ${workflowstatus}=          GetText                     //button[@name\='Workflow_Status__c']

    IF                          "${workflowstatus}"=="Select"
        Log To Console          Success
    ELSE
        Fail                    Assertion Failed
    END
    Log Screenshot
    Log To Console              ----- Work Flow Status Validated Successfully -----
    ${type}=                    GetText                     //button[@name\='Type']
    IF                          "${type}"=="New Business"
        Log To Console          Success
    ELSE
        Fail                    Assertion Failed
    END
    Log Screenshot
    Log To Console              ----- Type Validated Successfully -----

    #Verify Dates
    ${received_date}=           GetInputValue               //input[@name\='Received_Date__c']
    Log To Console              ${received_date}
    ${rdate}=                   Convert Date                ${received_date}            date_format=%b %d, %Y
    Log To Console              ${rdate}
    ${pdf_dateofproposal}=      Convert Date                ${rdate}                    result_format=%B %-d, %Y
    ${pdf_dateofproposal2}=     Convert Date                ${rdate}                    result_format=%m/%d/%Y
    Log To Console              ${pdf_dateofproposal}
    Set Global Variable         ${pdf_dateofproposal}
    Set Global Variable         ${pdf_dateofproposal2}

    ${effective_date}=          GetInputValue               //input[@name\='Effective_Date__c']

    ${expiration_Date}=         GetInputValue               //input[@name\='Expiration_Date__c']


    ${cur_data}=                Get Current Date            result_format=%b %-d, %Y
    ${comp_effective_date}=     Get Current Date            increment=5 day             result_format=%b %-d, %Y
    ${comp_xpiration_Date}=     Get Current Date            increment=370 day           result_format=%b %-d, %Y


    IF                          "${received_date}"== "${cur_data}" and "${effective_date}"=="${comp_effective_date}" and "${expiration_Date}"=="${comp_xpiration_Date}"
        Log To Console          Success
    ELSE
        Fail
    END
    Log To Console              ----- Received date, Efective data, Expiration date     Validated Successfully -----

    #Verify Broker
    UseTable                    Broker                      Name
    ${Broker_name}=             GetCellText                 r2/c?Broker Name
    ${primary_broker}=          GetCellText                 r2/c?Primary Broker?
    ${relationship_type}=       GetCellText                 r2/c?Relationship Type

    Log To Console              ${primary_broker}           ${Broker_name}              ${relationship_type}
    ${pdf_brokername}=          Set Variable                ${Broker_name}
    Set Global Variable         ${pdf_brokername}

    IF                          "${Broker_name}"=="${EMPTY}" and "${primary_broker}"=="${EMPTY}" and "${relationship_type}"=="${EMPTY}"
        Fail
    ELSE
        Log To Console          Success
    END
    Log To Console              ----- Broker date, Primary Broker, Relationship Type    Validated Successfully -----

Add UW 
    [Documentation]             Add UW when it is blank

    ${underwriter_exists}=      IsElement                   //label[text()\='Underwriter']/parent::*//input

    IF                          '${underwriter_exists}'=='True'
        ClickElement            //label[text()\='Underwriter']/parent::c-generate-element-lwc//input
        TypeText                //label[text()\='Underwriter']/parent::c-generate-element-lwc//input                Copado-LGO Automation-user
        Sleep                   4s
        ClickElement            (//label[text()\='Underwriter']/parent::c-generate-element-lwc//li)[1]
    END
Add Details In SubmissionInfo Page
    #Author-Amol Gaymukhe
    [Documentation]             Add the details

    Sleep                       5s
    Add UW
    TypeText                    Expiring Attorneys          2
    TypeText                    Expiring Premium            2000
    TypeText                    Current Carrier             LGO
    #ClickText                  LGO One LLC
    TypeText                    Current Revenue             2000
    VerifyCheckboxValue         25% Client Revenue          off
    VerifyCheckboxValue         Signed & dated within 60/90 (N/R) day                   off
    VerifyCheckboxValue         Officer/Director/ Ownership in Client(s)                off
    VerifyCheckboxValue         Retroactive Date Inception(RDI)                         off
    TypeText                    Underwriting Comments (if applicable):                  Test Comments
    Scroll                      //html                      page_up
    Scroll                      //html                      page_up
    Scroll                      //html                      page_up
    ${pdf_underwriter}=         GetText                     //label[text()\='Underwriter']/parent::c-generate-element-lwc//a/span
    Set Global Variable         ${pdf_underwriter}
    ClickText                   NA
    ClickText                   Move to Selected            parent=LIGHTNING-BUTTON-ICON
    ClickText                   Save
    VerifyText                  Success
    Sleep                       5s
    Log To Console              ----- Submission Info Input Details Added Successfully -----


Verify Decline Close and Reopen
    #Author=Amol Gaymukhe
    [Documentation]             Decline
    ClickText                   Decline
    #VerifyText                 Declination Reason(s)
    #VerifyText                 Decline Current Submission
    #VerifyText                 Keep Current Submission
    MultiPickList               Declination Reason(s)       Accepts equity in lieu of fees                          action=Move to
    MultiPickList               Declination Reason(s)       Attorney(s) in practice for less than 3 years           action=Move to
    MultiPickList               Declination Reason(s)       Banking/Financial Institutions – High % /Conflict / Declared Bankrupt/Insolvent/Receivership            action=Move to
    MultiPickList               Declination Reason(s)       Bankruptcy – Large Clientele / Case Values              action=Move to
    #MultiPickList              Declination Reason(s)       Bar Complaints              ac                          action=Move to
    TypeText                    Comment                     Random Comment
    ClickText                   Next
    ScrollTo                    Send                        anchor=Cancel
    ClickText                   Send                        anchor=Cancel               delay=2s                    partial_match=false
    Log To Console              ----- Decline Done Successfully -----
    ClickText                   Reopen
    Sleep                       3s
    ClickElement                //button[text()\='Close']
    Log To Console              ----- Close Done Successfully -----
    ClickElement                //button[@name\='progress']
    ClickText                   Commission
    TypeText                    Comment                     Random Comment
    ClickText                   Yes                         partial_match=false
    Sleep                       3s
    ClickText                   Reopen
    Sleep                       5s
    Log To Console              ----- Reopen Done Successfully -----



Check WorkFlow Status Indication Release 
    #Author=Amol Gaymukhe
    ${workflow_status}=         GetAttribute                //label[text()\='Workflow Status']/parent::div//button                         data-value
    Log To Console              ${workflow_status}
    IF                          '${workflow_status}' == 'Indication Released'
        Log To Console          Sucess
    ELSE
        Fail
    END
    ClickText                   NEXT:Underwriter Analysis >


Check WorkFlow Status Quote Release
    ClickText                   Submission Info
    Sleep                       10s
    ${workflow_status2}=        GetAttribute                //label[text()\='Workflow Status']/parent::div//button                         data-value
    Log To Console              ${workflow_status2}
    IF                          '${workflow_status2}' == 'Quote Released'
        Log To Console          Sucess
    ELSE
        Fail
    END

Check WorkFlow Status Initial Review 

    Sleep                       10s
    ${workflow_status2}=        GetAttribute                //label[text()\='Workflow Status']/parent::div//button                         data-value
    Log To Console              ${workflow_status2}
    IF                          '${workflow_status2}' == 'Initial Review'
        Log To Console          Sucess
    ELSE
        Fail
    END


Check WorkFlow Additional Information Requested 

    Sleep                       10s
    ${workflow_status2}=        GetAttribute                //label[text()\='Workflow Status']/parent::div//button                         data-value
    Log To Console              ${workflow_status2}
    IF                          '${workflow_status2}' == 'Additional Information Requested'
        Log To Console          Sucess
    ELSE
        Fail
    END




Validate SubmissionInfo New submission Fields for primary
    #Author=Rugveda Nikam
    [tags]                      submission

    VerifyText                  Account Name                anchor=Account Name         partial_match=False
    VerifyText                  Type
    VerifyText                  Product
    VerifyText                  Workflow Status
    VerifyText                  Auto Renewal
    VerifyText                  Closed Reason
    VerifyText                  Expiring Premium
    VerifyText                  Expiring Attorneys
    VerifyText                  Current Carrier
    VerifyText                  Policy Number
    VerifyText                  Current Revenue
    VerifyText                  Expiring Revenue
    VerifyText                  Signed & dated within 60/90 (N/R) day
    VerifyText                  25% Client Revenue
    VerifyText                  Layer
    VerifyText                  Primary Carrier
    VerifyText                  Effective Date
    VerifyText                  Received Date
    VerifyText                  Expiration Date
    VerifyText                  Quote Due Date
    VerifyText                  Excess Retrodate
    VerifyText                  Retroactive Date
    VerifyText                  Established Date (Year Only)
    VerifyText                  Date Application Signed
    VerifyText                  Retroactive Date Inception(RDI)
    VerifyText                  Conflicts of Interest
    VerifyText                  Suits for Fees
    VerifyText                  Docket Control
    VerifyText                  SFF Preventive Measures
    VerifyText                  Engagement Letters
    VerifyText                  Broker Account
    VerifyText                  Broker ID
    VerifyText                  Broker Name
    VerifyText                  Primary Broker?
    VerifyText                  Relationship Type
    VerifyText                  New                         anchor=Broker Account
    VerifyElement               (//button[text()\='New'])
    VerifyText                  Underwriting Comments (if applicable):
    VerifyText                  Clone & Close
    VerifyText                  Decline
    VerifyText                  Close
    Log To Console              ----- Submission Info Fileds Validated Successfully -----

    # Verifying Picklist Values

    ${WorkflowStatus_value}=    GetPicklist                 Workflow Status
    Log To Console              ${WorkflowStatus_value}
    @{workflow_expected}=       Create List                 Additional Information Requested                        Audit                  Auto-Renewal             Bound                   Declined               Indication Released                 Initial Review                           Non-Renewed                 Not Quoted                  Not Quoted - Duplicate      Not Sold      Quote Referred        Quote Released        Received                    Renewal In Process          Underwriter Review      Not Quoted - Excess Opportunity
    Log To Console              ${workflow_expected}
    Lists Should Be Equal       ${WorkflowStatus_value}     ${workflow_expected}        ignore_order=True


    ${Closedreason_value}=      GetPicklist                 Closed Reason
    Log To Console              ${Closedreason_value}
    @{Closedreason_expected}=                               Create List                 Alternate Carrier Quote     Broker Of Record       Commission               Coverage Deal Breaker                          Duplicate submission                Firm Dissolved                           Lack of Lead Time           Loyalty                     No Response                 Non-Renewal Sent                    Not Quoted - Additional Info Requested            Not Quoted - Firm Dissolved            Not Quoted - Indication Provided    Not Wanted    Other    Premium    Price / Coverage (Broker Lost)    Price / Coverage (Broker Placed Elsewhere)    Service    Withdrawn
    Log To Console              ${Closedreason_expected}
    Lists Should Be Equal       ${Closedreason_value}       ${Closedreason_expected}    ignore_order=True
    Log To Console              ----- Picklist Values Validated Successfully -----


Verify SubmissionInfo Page Input Details for primary
    #Author=Rugveda Nikam
    #VerifyInputValue           Account Name                anchor=Account Name         partial_match=False
    [Documentation]             Add the details
    ${ipval}=                   GetText                     //label[text()\='Account Name']/parent::c-generate-element-lwc/div//a
    Log To Console              ${ipval}
    ${name3}=                   Set Variable                ${uniqueName}
    Log To Console              ${name3}
    IF                          "${ipval}"=="${name3}"
        Log To Console          Success
    ELSE
        Fail                    Assertion Failed
    END
    Log Screenshot
    Log To Console              ----- Name Validated Successfully -----
    ${product}=                 GetText                     //label[text()\='Product']/parent::c-generate-element-lwc/div//a
    Log To Console              ${product}

    IF                          "${product}"=="LawyerGuard_SL"
        Log To Console          Success
    ELSE
        Fail                    Assertion Failed
    END
    Log Screenshot
    Log To Console              ----- Product Validated Successfully -----
    ${workflowstatus}=          GetText                     //button[@name\='Workflow_Status__c']

    IF                          "${workflowstatus}"=="Select"
        Log To Console          Success
    ELSE
        Fail                    Assertion Failed
    END
    Log Screenshot
    Log To Console              ----- Work Flow Status Validated Successfully -----
    ${type}=                    GetText                     //button[@name\='Type']
    IF                          "${type}"=="New Business"
        Log To Console          Success
    ELSE
        Fail                    Assertion Failed
    END
    Log Screenshot
    Log To Console              ----- Type Validated Successfully -----

    #Verify Dates
    ${received_date}=           GetInputValue               //input[@name\='Received_Date__c']
    Log To Console              ${received_date}
    ${rdate}=                   Convert Date                ${received_date}            date_format=%b %d, %Y
    Log To Console              ${rdate}
    ${pdf_dateofproposal}=      Convert Date                ${rdate}                    result_format=%B %-d, %Y
    ${pdf_dateofproposal2}=     Convert Date                ${rdate}                    result_format=%m/%d/%Y
    Log To Console              ${pdf_dateofproposal}
    Set Global Variable         ${pdf_dateofproposal}
    Set Global Variable         ${pdf_dateofproposal2}

    ${effective_date}=          GetInputValue               //input[@name\='Effective_Date__c']

    ${expiration_Date}=         GetInputValue               //input[@name\='Expiration_Date__c']


    ${cur_data}=                Get Current Date            result_format=%b %-d, %Y
    ${comp_effective_date}=     Get Current Date            increment=5 day             result_format=%b %-d, %Y
    ${comp_xpiration_Date}=     Get Current Date            increment=370 day           result_format=%b %-d, %Y


    IF                          "${received_date}"== "${cur_data}" and "${effective_date}"=="${comp_effective_date}" and "${expiration_Date}"=="${comp_xpiration_Date}"
        Log To Console          Success
    ELSE
        Fail
    END
    Log To Console              ----- Received date, Efective data, Expiration date     Validated Successfully -----

    #Verify Broker
    UseTable                    Broker                      Name
    ${Broker_name}=             GetCellText                 r2/c?Broker Name
    ${primary_broker}=          GetCellText                 r2/c?Primary Broker?
    ${relationship_type}=       GetCellText                 r2/c?Relationship Type

    Log To Console              ${primary_broker}           ${Broker_name}              ${relationship_type}
    ${pdf_brokername}=          Set Variable                ${Broker_name}
    Set Global Variable         ${pdf_brokername}

    IF                          "${Broker_name}"=="${EMPTY}" and "${primary_broker}"=="${EMPTY}" and "${relationship_type}"=="${EMPTY}"
        Fail
    ELSE
        Log To Console          Success
    END
    Log To Console              ----- Broker date, Primary Broker, Relationship Type    Validated Successfully -----


Add Details In SubmissionInfo Page for primary
    #Author-Rugveda Nikam
    [Documentation]             Add the details
    TypeText                    Expiring Attorneys          2
    TypeText                    Expiring Premium            2000
    TypeText                    Current Carrier             LGO
    TypeText                    Primary Carrier             Lawyerguard
    #ClickText                  LGO One LLC
    TypeText                    Current Revenue             2000
    VerifyCheckboxValue         25% Client Revenue          off
    VerifyCheckboxValue         Signed & dated within 60/90 (N/R) day                   off
    VerifyCheckboxValue         Officer/Director/ Ownership in Client(s)                off
    VerifyCheckboxValue         Retroactive Date Inception(RDI)                         off
    TypeText                    Underwriting Comments (if applicable):                  Test Comments

    ${pdf_underwriter}=         GetText                    //label[text()\='Comments']/parent::*//div
    Set Global Variable         ${pdf_underwriter}              
    Log To Console              ----- Submission Info Input Details Added Successfully -----

Validate SubmissionInfo New submission Fields for Excess
    #Author=Rugveda Nikam
    [tags]                      submission

    VerifyText                  Account Name                anchor=Account Name         partial_match=False
    VerifyText                  Type
    VerifyText                  Product
    VerifyText                  Workflow Status
    VerifyText                  Auto Renewal
    VerifyText                  Closed Reason
    VerifyText                  Expiring Premium
    VerifyText                  Expiring Attorneys
    VerifyText                  Current Carrier
    VerifyText                  Policy Number
    VerifyText                  Current Revenue
    VerifyText                  Expiring Revenue
    VerifyText                  Signed & dated within 60/90 (N/R) day
    VerifyText                  25% Client Revenue
    VerifyText                  Layer
    VerifyText                  Primary Carrier
    VerifyText                  Effective Date
    VerifyText                  Received Date
    VerifyText                  Expiration Date
    VerifyText                  Quote Due Date
    VerifyText                  Excess Retrodate
    VerifyText                  Retroactive Date
    VerifyText                  Established Date (Year Only)
    VerifyText                  Date Application Signed
    VerifyText                  Retroactive Date Inception(RDI)
    VerifyText                  Conflicts of Interest
    VerifyText                  Suits for Fees
    VerifyText                  Docket Control
    VerifyText                  SFF Preventive Measures
    VerifyText                  Engagement Letters
    VerifyText                  Broker Account
    VerifyText                  Broker ID
    VerifyText                  Broker Name
    VerifyText                  Primary Broker?
    VerifyText                  Relationship Type
    VerifyText                  New                         anchor=Broker Account
    VerifyElement               (//button[text()\='New'])
    VerifyText                  Underwriting Comments (if applicable):
    VerifyText                  Clone & Close
    VerifyText                  Decline
    VerifyText                  Close
    Log To Console              ----- Submission Info Fileds Validated Successfully -----

    # Verifying Picklist Values

    ${WorkflowStatus_value}=    GetPicklist                 Workflow Status
    Log To Console              ${WorkflowStatus_value}
    @{workflow_expected}=       Create List                 Additional Information Requested                        Audit                  Auto-Renewal             Bound                   Declined               Indication Released                 Initial Review                           Non-Renewed                 Not Quoted                  Not Quoted - Duplicate      Not Sold      Quote Referred        Quote Released        Received                    Renewal In Process          Underwriter Review      Not Quoted - Excess Opportunity
    Log To Console              ${workflow_expected}
    Lists Should Be Equal       ${WorkflowStatus_value}     ${workflow_expected}        ignore_order=True


    ${Closedreason_value}=      GetPicklist                 Closed Reason
    Log To Console              ${Closedreason_value}
    @{Closedreason_expected}=                               Create List                 Alternate Carrier Quote     Broker Of Record       Commission               Coverage Deal Breaker                          Duplicate submission                Firm Dissolved                           Lack of Lead Time           Loyalty                     No Response                 Non-Renewal Sent                    Not Quoted - Additional Info Requested            Not Quoted - Firm Dissolved            Not Quoted - Indication Provided    Not Wanted    Other    Premium    Price / Coverage (Broker Lost)    Price / Coverage (Broker Placed Elsewhere)    Service    Withdrawn
    Log To Console              ${Closedreason_expected}
    Lists Should Be Equal       ${Closedreason_value}       ${Closedreason_expected}    ignore_order=True
    Log To Console              ----- Picklist Values Validated Successfully -----


Verify SubmissionInfo Page Input Details for Excess
    #Author=Rugveda Nikam
    #VerifyInputValue           Account Name                anchor=Account Name         partial_match=False
    [Documentation]             Add the details
    ${ipval}=                   GetText                     //label[text()\='Account Name']/parent::c-generate-element-lwc/div//a
    Log To Console              ${ipval}
    ${name3}=                   Set Variable                ${uniqueName}
    Log To Console              ${name3}
    IF                          "${ipval}"=="${name3}"
        Log To Console          Success
    ELSE
        Fail                    Assertion Failed
    END
    Log Screenshot
    Log To Console              ----- Name Validated Successfully -----
    ${product}=                 GetText                     //label[text()\='Product']/parent::c-generate-element-lwc/div//a
    Log To Console              ${product}

    IF                          "${product}"=="LawyerGuard_SL"
        Log To Console          Success
    ELSE
        Fail                    Assertion Failed
    END
    Log Screenshot
    Log To Console              ----- Product Validated Successfully -----
    ${workflowstatus}=          GetText                     //button[@name\='Workflow_Status__c']

    IF                          "${workflowstatus}"=="Select"
        Log To Console          Success
    ELSE
        Fail                    Assertion Failed
    END
    Log Screenshot
    Log To Console              ----- Work Flow Status Validated Successfully -----
    ${type}=                    GetText                     //button[@name\='Type']
    IF                          "${type}"=="New Business"
        Log To Console          Success
    ELSE
        Fail                    Assertion Failed
    END
    Log Screenshot
    Log To Console              ----- Type Validated Successfully -----

    #Verify Dates
    ${received_date}=           GetInputValue               //input[@name\='Received_Date__c']
    Log To Console              ${received_date}
    ${rdate}=                   Convert Date                ${received_date}            date_format=%b %d, %Y
    Log To Console              ${rdate}
    ${pdf_dateofproposal}=      Convert Date                ${rdate}                    result_format=%B %-d, %Y
    ${pdf_dateofproposal2}=     Convert Date                ${rdate}                    result_format=%m/%d/%Y
    Log To Console              ${pdf_dateofproposal}
    Set Global Variable         ${pdf_dateofproposal}
    Set Global Variable         ${pdf_dateofproposal2}

    ${effective_date}=          GetInputValue               //input[@name\='Effective_Date__c']

    ${expiration_Date}=         GetInputValue               //input[@name\='Expiration_Date__c']


    ${cur_data}=                Get Current Date            result_format=%b %-d, %Y
    ${comp_effective_date}=     Get Current Date            increment=5 day             result_format=%b %-d, %Y
    ${comp_xpiration_Date}=     Get Current Date            increment=370 day           result_format=%b %-d, %Y


    IF                          "${received_date}"== "${cur_data}" and "${effective_date}"=="${comp_effective_date}" and "${expiration_Date}"=="${comp_xpiration_Date}"
        Log To Console          Success
    ELSE
        Fail
    END
    Log To Console              ----- Received date, Efective data, Expiration date     Validated Successfully -----

    #Verify Broker
    UseTable                    Broker                      Name
    ${Broker_name}=             GetCellText                 r2/c?Broker Name
    ${primary_broker}=          GetCellText                 r2/c?Primary Broker?
    ${relationship_type}=       GetCellText                 r2/c?Relationship Type

    Log To Console              ${primary_broker}           ${Broker_name}              ${relationship_type}
    ${pdf_brokername}=          Set Variable                ${Broker_name}
    Set Global Variable         ${pdf_brokername}

    IF                          "${Broker_name}"=="${EMPTY}" and "${primary_broker}"=="${EMPTY}" and "${relationship_type}"=="${EMPTY}"
        Fail
    ELSE
        Log To Console          Success
    END
    Log To Console              ----- Broker date, Primary Broker, Relationship Type    Validated Successfully -----


Add Details In SubmissionInfo Page for Excess
    #Author-Rugveda Nikam
    [Documentation]             Add the details
    Add UW
    TypeText                    Expiring Attorneys          2
    TypeText                    Expiring Premium            2000
    TypeText                    Current Carrier             LGO
    TypeText                    Primary Carrier             Lawyerguard
    TypeText                    Excess Retrodate            12/08/2024
    #ClickText                  LGO One LLC
    TypeText                    Current Revenue             2000
    VerifyCheckboxValue         25% Client Revenue          off
    VerifyCheckboxValue         Signed & dated within 60/90 (N/R) day                   off
    VerifyCheckboxValue         Officer/Director/ Ownership in Client(s)                off
    VerifyCheckboxValue         Retroactive Date Inception(RDI)                         off
    TypeText                    Underwriting Comments (if applicable):                  Test Comments

    ${pdf_underwriter}=         GetText                     //label[text()\='Underwriter']/parent::c-generate-element-lwc//a/span
    Set Global Variable         ${pdf_underwriter}

    Log To Console              ----- Submission Info Input Details Added Successfully -----


Entering Submission_Info Details for SL 
    [Documentation]             Entering Submission_Info Details for SL
    [Arguments]                 ${Layer}                    ${Date}

    Add UW

    IF                          '${Layer}' == 'Primary'
        PickList                Layer                       ${Layer}
        #ClickText              Save

    ELSE IF                     '${Layer}' == 'Excess'

        PickList                Layer                       ${Layer}
        TypeText                Excess Retrodate            ${Date}
        #ClickText              Save

    END
    Sleep                       10s
    #ClickText                  NA
    # ClickText                 Move to Selected            parent=LIGHTNING-BUTTON-ICON
    ClickText                   Save
    VerifyText                  Success
    Sleep                       5s
    Log To Console              ----- Submission Info Input Details Added Successfully -----



Transform From Admitted to SL
    Scroll                      //html                      page_up
    Scroll                      //html                      page_up
    Scroll                      //html                      page_up
    Scroll                      //html                      page_up
    VerifyText                  Create SL Submission
    ClickText                   Create SL Submission
    ClickElement                //input[@value\='Keep Current Submission']

    ClickText                   Confirm
    VerifyText                  Record created successfully!                            anchor=Success              timeout=120s


Verify Elements on Transform SL Pop Up and Decline
    Scroll                      //html                      page_up
    Scroll                      //html                      page_up
    Scroll                      //html                      page_up
    Scroll                      //html                      page_up
    VerifyText                  Create SL Submission

    ClickText                   Create SL Submission

    VerifyText                  Please Select Option
    VerifyText                  Decline Current Submission
    VerifyText                  Keep Current Submission
    MultiPickList               Declination Reason(s)       Accepts equity in lieu of fees                          action=Move to
    MultiPickList               Declination Reason(s)       Attorney(s) in practice for less than 3 years           action=Move to
    MultiPickList               Declination Reason(s)       Banking/Financial Institutions – High % /Conflict / Declared Bankrupt/Insolvent/Receivership            action=Move to
    MultiPickList               Declination Reason(s)       Bankruptcy – Large Clientele / Case Values              action=Move to
    MultiPickList               Declination Reason(s)       Bar Complaints              action=Move to
    MultiPickList               Declination Reason(s)       Cannabis                    action=Move to
    MultiPickList               Declination Reason(s)       Collection – high % /Less than satisfactory controls in place                  action=Move to
    MultiPickList               Declination Reason(s)       Conflict of Interest Exposure                           action=Move to
    MultiPickList               Declination Reason(s)       Criminal – Focus is High Stakes White Collar Litigation                        action=Move to
    MultiPickList               Declination Reason(s)       Disciplinary Action(s)/Reprimand(s) – Frequency/Nature of Allegations          action=Move to
    MultiPickList               Declination Reason(s)       Domestic Marital Assets – High Values                   action=Move to
    MultiPickList               Declination Reason(s)       Entertainment/Sports exposure                           action=Move to
    MultiPickList               Declination Reason(s)       Environmental – High Values/Types of Services           action=Move to
    MultiPickList               Declination Reason(s)       Excess submission           action=Move to
    MultiPickList               Declination Reason(s)       Fee Suits – Excessive       action=Move to
    MultiPickList               Declination Reason(s)       Financial Institutions      action=Move to
    MultiPickList               Declination Reason(s)       Firm Size                   action=Move to
    MultiPickList               Declination Reason(s)       Firm Structure – excessive Independent Contractor(s) /Of Counsel(s) to Attorney(s) Ratio                action=Move to
    MultiPickList               Declination Reason(s)       Firm Structure - High Support Staff to Attorney Ratio                          action=Move to
    MultiPickList               Declination Reason(s)       Firm Structure – Joint Venture Relationship             action=Move to
    MultiPickList               Declination Reason(s)       High % gross billings with one client                   action=Move to
    MultiPickList               Declination Reason(s)       High Profile Clients / Cases                            action=Move to
    MultiPickList               Declination Reason(s)       Immigration Practice with investor related services     action=Move to
    MultiPickList               Declination Reason(s)       International Exposure      action=Move to
    MultiPickList               Declination Reason(s)       Investment Counseling/Money Management                  action=Move to
    MultiPickList               Declination Reason(s)       Loss Experience             action=Move to
    #MultiPickList              Declination Reason(s)       Mergers & Acquisitions      action=Move to
    #MultiPickList              Declination Reason(s)       Mergers/Acquisitions – High %/High Values               action=Move to
    MultiPickList               Declination Reason(s)       Not a market for the following states: Alaska or Oregon                        action=Move to
    MultiPickList               Declination Reason(s)       Oil & Gas Mining            action=Move to
    MultiPickList               Declination Reason(s)       Other                       action=Move to
    MultiPickList               Declination Reason(s)       Part-Time Practice          action=Move to
    MultiPickList               Declination Reason(s)       Patent                      action=Move to
    MultiPickList               Declination Reason(s)       Plaintiff – High Case Load Per Attorney                 action=Move to
    MultiPickList               Declination Reason(s)       Plaintiff – high exposure Class Action/Mass Tort        action=Move to
    MultiPickList               Declination Reason(s)       Plaintiff – High Values     action=Move to
    MultiPickList               Declination Reason(s)       Probate/Wills/Estate – High Values                      action=Move to
    MultiPickList               Declination Reason(s)       Real Estate – High % of Development, Limited Partnership, Syndication and/or REITS                      action=Move to
    MultiPickList               Declination Reason(s)       Real Estate – High Number of Transactions/High Values                          action=Move to
    MultiPickList               Declination Reason(s)       Revenues – High per attorney which is indicative of higher values              action=Move to
    MultiPickList               Declination Reason(s)       Risk Management/Internal Procedures – % of engagement letters usage            action=Move to
    MultiPickList               Declination Reason(s)       Securities/Bonds – High %/High Values                   action=Move to
    MultiPickList               Declination Reason(s)       Securities – Initial or Secondary Public Offerings      action=Move to
    MultiPickList               Declination Reason(s)       Solo with no back-up attorney                           action=Move to
    MultiPickList               Declination Reason(s)       Title Agency – % of revenue is higher than revenue for law firm                action=Move to
    MultiPickList               Declination Reason(s)       Wills, Estate Planning, Trusts, Probate                 action=Move to
    MultiPickList               Declination Reason(s)       Attorney(s) in practice for less than 3 years           action=Move to
    ClickText                   Cancel                      anchor=Confirm
    VerifyText                  Create SL Submission        timeout=30s



Verify Elements on Transform SL Pop Up with user selection
    [Arguments]                 ${reason}
    Scroll                      //html                      page_up
    Scroll                      //html                      page_up
    Scroll                      //html                      page_up
    Scroll                      //html                      page_up
    VerifyText                  Create SL Submission        timeout=30s
    ClickText                   Create SL Submission
    MultiPickList               Declination Reason(s)       ${reason}                   action=Move to
    TypeText                    Comment                     LG Testing
    ClickElement                //input[@value\='Decline Current Submission']
    ClickText                   Confirm                     anchor=cancel
    VerifyText                  Declination Email Template                              timeout=30s
    ClickText                   Send                        partial_match=False
    VerifyText                  Record created successfully!                            anchor=Success              timeout=30s






