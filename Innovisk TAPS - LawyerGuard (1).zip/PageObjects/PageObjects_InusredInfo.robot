*** Settings ***
Library                         QWeb
Library                         QForce
#Library                        QVision
Library                         FakerLibrary
Library                         String
Library                         BuiltIn
Library                         DateTime
Resource                        ../resources/common.robot
Resource                        ../PageObjects/PageObjects_Account.robot



*** Keywords ***
Validate field on Insured info
    #Author= Vighanesh
    [tags]                      InsuredInfo

    UseModal                    On
    VerifyText                  Account Name
    VerifyText                  County
    VerifyText                  Number Of Attorneys
    VerifyText                  Ratable Attorneys
    Verifytext                  Staff
    VerifyText                  If solo, Back-Up Attorney
    VerifyText                  Yes
    ClickText                   Yes
    ClickText                   Yes
    VerifyText                  No
    ClickText                   No                          partial_match=False
    ClickText                   No                          partial_match=False
    VerifyText                  N/A
    ClickText                   N/A
    VerifyAttribute             //span[text()\='Yes']/parent::label/parent::span/parent::div/parent::fieldset/parent::lightning-radio-group                            type                        radio
    VerifyAttribute             //span[text()\='No']/parent::label/parent::span/parent::div/parent::fieldset/parent::lightning-radio-group                             type                        radio
    VerifyAttribute             //span[text()\='N/A']/parent::label/parent::span/parent::div/parent::fieldset/parent::lightning-radio-group                            type                        radio

    VerifyCheckbox              Office or Staff Sharing     disable
    ClickCheckbox               Office or Staff Sharing     off

    VerifyCheckbox              Letterhead Included         disable
    ClickCheckbox               Letterhead Included         on

    ClickCheckbox               Letterhead Included         off
    VerifyCheckbox              Additional Location(s)      disable

    ClickCheckbox               Additional Location(s)      on
    ClickCheckbox               Additional Location(s)      off

    Log To Console              ----- Insured Info Page Elements Varified Successfully -----

Validate Underwriting Comments on Insured info page
    #Author= Vighanesh
    [tags]                      InsuredInfo

    ClickText                   Underwriting Comments (if applicable):
    ClickText                   Underwriting Comments (if applicable):
    ${rev}=                     Generate Random String      6                           123456789
    Set Global Variable         ${rev}
    TypeText                    //*[@name\="inputUC"]       ${rev}

    Log To Console              ----- Underwritting Comments Verified Successfully -----
Validate Territory data on Insured Info Page
    #Author= Vighanesh
    [tags]                      InsuredInfo

    VerifyText                  Territory
    VerifyPicklist              Territory
    ${Territory_value}=         GetPicklist                 Territory
    Log To Console              ${Territory_value}
    @{Territory_list}=          Create List                 Alabama: Entire State       Alaska: Entire State        Arizona: Entire State    Arkansas: Entire State    California: Los Angeles County                          California: Orange County                               California: Alameda, Contra Costa, Sacramento, San Diego, San Francisco, Santa Clara Counties               California: Fresno, Marin, Riverside, San Bernardino, San Mateo, Santa Barbara, Ventura Counties            California: Remainder of State                          Colorado: Entire State                         Connecticut: Entire State                               Delaware: Entire State                         District of Columbia    Florida: Brevard, Hillsborough, Indian River, Martin, Orange, Pinellas, St. Lucie, Seminole, Volusia counties                     Florida: Broward, Dade, Palm Beach counties           Florida: Remainder of State                            Georgia: Cobb, DeKalb, Fulton, Gwinnett counties        Georgia: Remainder of State                        Hawaii: Entire State    Idaho: Entire State         Illinois: Cook, Madison, St. Clair counties             Illinois: Remainder of State                            Indiana: Entire State       Iowa: Entire State          Kansas: Entire State        Kentucky: Entire State                          Louisiana: Entire State                             Maine: Entire State         Maryland: Entire State      Massachusetts: Remainder of State                       Massachusetts: Suffolk, Norfolk, Middlesex counties    Michigan: Entire State      Minnesota: Entire State     Mississippi: Entire State                         Missouri: Remainder of State                       Missouri: St. Louis, St. Louis City, Jackson, Johnson counties                     Montana: Entire State    Nebraska: Entire State    Nevada: Entire State    New Hampshire: Entire State    New Jersey: Bergen, Camden, Essex, Union counties    New Jersey: Remainder of State    New Mexico: Entire State    New York: Bronx, Kings, New York, Queens, Richmond counties    New York: Remainder of State    North Carolina: Entire State    North Dakota: Entire State    Ohio: Entire State    Oklahoma: Entire State    Oregon: Entire State    Pennsylvania: Philadelphia County    Pennsylvania: Remainder of State    Rhode Island: Entire State    South Carolina: Entire State    South Dakota: Entire State    Tennessee: Entire State    Texas: Brazoria, Chambers, Fort Bend, Galveston, Jefferson, Starr counties    Texas: Cameron, Hidalgo, Nueces, Orange, San Patricio, Willacy counties    Texas: Harris, Houston counties    Texas: Remainder of State    Utah: Entire State    Vermont: Entire State    Virginia: Entire State    Washington: Entire State    West Virginia: Entire State    Wisconsin: Entire State    Wyoming: Entire State
    Log To Console              ${Territory_list}
    Lists Should Be Equal       ${Territory_value}          ${Territory_list}           ignore_order=true
    Log To Console              ----- Teritory Data Verified Successfully -----

Add Account name on Insured info page 
    #Author= Vighanesh NEW
    [tags]                      InsuredInfo

    VerifyText                  Insured Info                timeout=120s
    ClickElement                (//input[@placeholder\="Search..."])[1]
    ${Account_Name_create}=     Remove String               ${uniqueName}               1                           2                        3                         4                           5                           6                           7                           8                           9                         0
    Log To Console              ${uniqueName}
    TypeText                    Search...                   ${uniqueName}
    ClickText                   ${uniqueName}
    ${province_check}=          GetAttribute            //label[text()\='Province']/parent::div//input             data-value                delay=5s
    Log To Console              ${province_check}
    Set Global Variable         ${province_check}
    #ClickElement               (//li[@role\='presentation']/span)[1]
    Log To Console              ----- Insured Info page Add Account Verified Successfully -----



Validate component of Attroneys Page

    VerifyText                  Salutation
    VerifyText                  Name
    VerifyText                  Contact Record Type
    VerifyText                  Attorney                    anchor=Contact Record Type
    VerifyText                  First Name
    VerifyText                  Middle Name
    VerifyText                  Last Name
    VerifyText                  Suffix
    VerifyText                  Account Name
    VerifyText                  Date of Hire
    VerifyText                  Annual Hours Worked
    VerifyText                  Employment Status
    VerifyPicklist              Employment Status
    ${employment_Status}=       GetPicklist                 Employment Status
    Log To Console              ${employment_Status}
    @{employment_Status_List}=                              Create List                 --None--                    Full-Time                Part-Time                 Contractor                  Of Counsel
    Log To Console              ${employment_Status_List}
    Lists Should Be Equal       ${employment_Status}        ${employment_Status_List}                               ignore_order=false

    # PickList                  Employment Status           --None--
    # PickList                  Employment Status           Full-Time
    # PickList                  Employment Status           Part-Time
    # PickList                  Employment Status           Contractor
    # PickList                  Employment Status           Of Counsel

    VerifyText                  Annual Hours Worked
    UseModal                    on

    ${Status}=                  GetPicklist                 Status                      partial_match=False
    Log To Console              ${Status}
    @{Status_List}=             Create List                 --None--                    Departed                    New                      Active
    Log To Console              ${Status_List}
    Lists Should Be Equal       ${Status}                   ${Status_List}              ignore_order=true
    UseModal                    off

    VerifyText                  Admitted State
    VerifyPicklist              Admitted State
    ${Admitted_State}=          GetPicklist                 Admitted State              #//*[@name\='Admitted_State__c']
    Log To Console              ${Admitted_State}

    @{AdmittedState_List}=      Create List                 --None--                    AK                          AL                       AR                        AZ                          CA                          CO                          CT                          DC                          DE                        FL                          GA                        GU                      HI                          IA                          ID                          IL                          IN                          KS                      KY                     LA                          MA                          MD                       ME                    MI                      MN                        MO                         MS                     MT                        NC                          ND                          NE                        NH                         NJ                          NM                          NV                          NY                       OH                        OK                      OR                          PA                          PR                          RI                          SC                          SD                          TN                          TX                          UT                    VA                        VT                      WA                          WI                          WV                          WY
    Log To Console              ${AdmittedState_List}
    Lists Should Be Equal       ${Admitted_State}           ${AdmittedState_List}       ignore_order=true

    Log To Console              ----- Attorney Page Components Successfully -----

Edit and Delete Attroney Details

    #Attroney NO 1
    ClickText                   New                         partial_match=False
    PickList                    Salutation                  Mr.
    ${FirstName} =              FakerLibrary.First Name
    Set Suite Variable          ${FirstName}
    TypeText                    First Name                  ${FirstName}
    ${LastName} =               FakerLibrary.Last Name
    Set Suite Variable          ${LastName}
    TypeText                    Last Name                   ${LastName}
    VerifyText                  Admitted Date               anchor=Employment Status
    ClickElement                //*[@name\='Admitted_Date__c']
    TypeText                    Admitted Date               Feb 12, 2023
    #ClickCell                  r2c4
    PickList                    Admitted State              DE
    VerifyText                  Date of Hire
    ClickElement                //*[@name\='Date_of_Hire__c']
    TypeText                    Date of Hire                Feb 12, 2023
    #ClickCell                  r6c4
    ClickText                   Save                        anchor=Admitted State
    #Sleep                      20sec
    Log To Console              ----- Added First Attorney -----
    #Attroney NO 2
    ClickText                   New                         partial_match=False
    PickList                    Salutation                  Mr.
    ${FirstName} =              FakerLibrary.First Name
    Set Suite Variable          ${FirstName}
    TypeText                    First Name                  ${FirstName}
    ${LastName} =               FakerLibrary.Last Name
    Set Suite Variable          ${LastName}
    TypeText                    Last Name                   ${LastName}
    VerifyText                  Admitted Date               anchor=Employment Status
    ClickElement                //*[@name\='Admitted_Date__c']
    TypeText                    Admitted Date               Jan 3, 2022
    #ClickCell                  r2c4
    PickList                    Admitted State              DE
    VerifyText                  Date of Hire
    ClickElement                //*[@name\='Date_of_Hire__c']
    TypeText                    Date of Hire                Apr 13, 2022
    #ClickCell                  r6c4
    ClickText                   Save                        anchor=Admitted State
    #Sleep                      20sec
    Log To Console              ----- Added Second Attorney -----

    #UseTable                   Sort by:First NameSorted: NoneShow actions
    #ClickCell                  r1c6                        anchor=Status
    #ClickIcon                  r1c6
    ClickElement                (//lightning-button-menu[@class\='slds-dropdown-trigger slds-dropdown-trigger_click'])[last()]
    ClickElement                (//lightning-button-menu[@class\='slds-dropdown-trigger slds-dropdown-trigger_click'])[last()]
    Sleep                       6s
    ClickElement                //span[text()\='Delete']/parent::a
    Sleep                       2s
    Log To Console              ----- Deleted Attorney Successfully -----

    UseTable                    First Name

    ClickElement                (//lightning-button-menu[@class\='slds-dropdown-trigger slds-dropdown-trigger_click'])[last()]
    ClickElement                //span[text()\='Edit']/parent::a

    ${MiddleName} =             FakerLibrary.Name Female
    Set Suite Variable          ${MiddleName}
    TypeText                    Middle Name                 ${MiddleName}
    ${Suffix} =                 FakerLibrary.Suffix
    Set Suite Variable          ${Suffix}
    TypeText                    Suffix                      ${Suffix}
    ClickText                   Save                        anchor=Admitted State
    Log To Console              ----- Edited Attorney Successfully -----



Add Attorney
    ClickElement                //button[text()\='New']
    UseModal                    On
    PickList                    Salutation                  Mr.
    ${random_No}=               Generate Random String      length=2
    ${name1}=                   Name Male
    ${FirstName}                First Name
    ${LastName}                 Last Name
    Set Global Variable         ${name1}
    ${uniqueNameOne}=           Set Variable                ${FirstName}${random_No}
    ${uniqueName_Last}=         Set Variable                ${LastName}${random_No}

    Set Global Variable         ${uniqueNameOne}
    Log To Console              ${uniqueNameOne}

    Set Global Variable         ${uniqueName_Last}
    Log To Console              ${uniqueName_Last}

    TypeText                    First Name                  ${uniqueNameOne}
    TypeText                    Last Name                   ${uniqueName_Last}
    TypeText                    Date of Hire                Feb 4, 2023
    ClickText                   Save                        anchor=Save & New           partial_match=False         timeout=10s
    UseModal                    Off
    #ClickText                  Save                        anchor=Save & New           partial_match=False         timeout=10s
    ClickText                   Save                        partial_match=False         anchor=NEXT:Submission Info >
 Add Static Attorney 
    ClickElement                //button[text()\='New']
    PickList                    Salutation                  Mrs.
    TypeText                    First Name                  Rugveda
    TypeText                    Last Name                   Nikam
    TypeText                    Date of Hire                Feb 4, 2023
    TypeText                    Admitted Date               May 5, 2025
    ClickText                   Save                        anchor=Save & New           partial_match=False         timeout=10s
    # #ClickText                Save                        anchor=Save & New           partial_match=False         timeout=10s
    ClickText                   Save                        partial_match=False         anchor=NEXT:Submission Info >
    Log To Console              ----- Attorney Added Successfully -----
Add Attorney SL

    [Arguments]                 ${Firstname}                ${Lastname}
    ClickElement                //button[text()\='New']
    UseModal                    On
    PickList                    Salutation                  Mr.
    TypeText                    First Name                  ${Firstname}
    TypeText                    Last Name                   ${Lastname}
    TypeText                    Date of Hire                Feb 4, 2023
    ClickText                   Save                        anchor=Save & New           partial_match=False         timeout=10s
    UseModal                    Off
    #ClickText                  Save                        anchor=Save & New           partial_match=False         timeout=10s
    ClickText                   Save                        partial_match=False         anchor=NEXT:Submission Info >

    # ClickElement              //button[text()\='New']
    # PickList                  Salutation                  Mr.
    # TypeText                  First Name                  Melissa
    # TypeText                  Last Name                   Guann
    # TypeText                  Date of Hire                Feb 4, 2023
    # ClickText                 Save                        anchor=Save & New           partial_match=False         timeout=10s
    # #ClickText                Save                        anchor=Save & New           partial_match=False         timeout=10s
    # ClickText                 Save                        partial_match=False         anchor=NEXT:Submission Info >
    Log To Console              ----- Attorney Added Successfully -----
Remove Pin Code and Check Broker input page

    ClickElement                //input[@name\='postalCode']
    PressKey                    //input[@name\='postalCode']                            {CONTROL + A + DELETE}
    ClickText                   NEXT:Submission Info >
    VerifyText                  Submission Init Form

Validate field on Insured info SL
    #Author= Shraddha
    [tags]                      InsuredInfo

    UseModal                    On
    VerifyText                  Account Name
    VerifyText                  County
    VerifyText                  Number Of Attorneys
    # VerifyText                Ratable Attorneys
    Verifytext                  Staff


    VerifyCheckbox              Office or Staff Sharing     disable
    ClickCheckbox               Office or Staff Sharing     off

    VerifyCheckbox              Letterhead Included         disable
    ClickCheckbox               Letterhead Included         on

    ClickCheckbox               Letterhead Included         off
    VerifyCheckbox              Additional Location(s)      disable

    ClickCheckbox               Additional Location(s)      on
    ClickCheckbox               Additional Location(s)      off

    Log To Console              ----- Insured Info Page Elements Varified Successfully -----


Validate Underwriting Comments on Insured info page SL
    #Author= Shraddha
    [tags]                      InsuredInfo

    ClickText                   Underwriting Comments (if applicable):
    ClickText                   Underwriting Comments (if applicable):
    ${rev}=                     Generate Random String      6                           123456789
    Set Global Variable         ${rev}
    TypeText                    //*[@name\="inputUC"]       ${rev}

    Log To Console              ----- Underwritting Comments Verified Successfully -----


Validate Territory data on Insured Info Page SL
    #Author= Shraddha
    [tags]                      InsuredInfo
    [Arguments]                 ${Territory}

    VerifyText                  Territory
    VerifyPicklist              Territory
    ${Territory_value}=         GetPicklist                 Territory
    Log To Console              ${Territory_value}
    @{Territory_list}=          Create List                 Alabama: Entire State       Alaska: Entire State        Arizona: Entire State    Arkansas: Entire State    California: Los Angeles County                          California: Orange County                               California: Alameda, Contra Costa, Sacramento, San Diego, San Francisco, Santa Clara Counties               California: Fresno, Marin, Riverside, San Bernardino, San Mateo, Santa Barbara, Ventura Counties            California: Remainder of State                          Colorado: Entire State                         Connecticut: Entire State                               Delaware: Entire State                         District of Columbia    Florida: Brevard, Hillsborough, Indian River, Martin, Orange, Pinellas, St. Lucie, Seminole, Volusia counties                     Florida: Broward, Dade, Palm Beach counties           Florida: Remainder of State                            Georgia: Cobb, DeKalb, Fulton, Gwinnett counties        Georgia: Remainder of State                        Hawaii: Entire State    Idaho: Entire State         Illinois: Cook, Madison, St. Clair counties             Illinois: Remainder of State                            Indiana: Entire State       Iowa: Entire State          Kansas: Entire State        Kentucky: Entire State                          Louisiana: Entire State                             Maine: Entire State         Maryland: Entire State      Massachusetts: Remainder of State                       Massachusetts: Suffolk, Norfolk, Middlesex counties    Michigan: Entire State      Minnesota: Entire State     Mississippi: Entire State                         Missouri: Remainder of State                       Missouri: St. Louis, St. Louis City, Jackson, Johnson counties                     Montana: Entire State    Nebraska: Entire State    Nevada: Entire State    New Hampshire: Entire State    New Jersey: Bergen, Camden, Essex, Union counties    New Jersey: Remainder of State    New Mexico: Entire State    New York: Bronx, Kings, New York, Queens, Richmond counties    New York: Remainder of State    North Carolina: Entire State    North Dakota: Entire State    Ohio: Entire State    Oklahoma: Entire State    Oregon: Entire State    Pennsylvania: Philadelphia County    Pennsylvania: Remainder of State    Rhode Island: Entire State    South Carolina: Entire State    South Dakota: Entire State    Tennessee: Entire State    Texas: Brazoria, Chambers, Fort Bend, Galveston, Jefferson, Starr counties    Texas: Cameron, Hidalgo, Nueces, Orange, San Patricio, Willacy counties    Texas: Harris, Houston counties    Texas: Remainder of State    Utah: Entire State    Vermont: Entire State    Virginia: Entire State    Washington: Entire State    West Virginia: Entire State    Wisconsin: Entire State    Wyoming: Entire State
    Log To Console              ${Territory_list}
    Lists Should Be Equal       ${Territory_value}          ${Territory_list}           ignore_order=true
    Log To Console              ----- Teritory Data Verified Successfully -----

    PickList                    Territory                   ${Territory}

Enter Territory data on Insured Info Page SL

    #Author= Shraddha
    [tags]                      InsuredInfo
    [Arguments]                 ${Territory}

    VerifyText                  Territory
    PickList                    Territory                   ${Territory}
