class TestEnv:
    ip = '123.4.5.6'
    user = 'robot'
    roles = ['admin', 'user']


#AOP = {'amounts':'65', 'list' : ["Administrative","Admiralty-Plaintiff","Anti-trust / Trade Regulation","Appellate","Arbitration / Mediation","Aviation","Bankruptcy","BI/PI Defendant General Liability","BI/PI Defendant Medical Malpractice","BI/PI Defendant Other","BI/PI Defendant Products Liability","BI/PI Plaintiffs General Liability","BI/PI Plaintiffs Medical Malpractice","BI/PI Plaintiffs Other","BI/PI Plaintiffs Products Liability","Civil Rights / Discrimination","Collection / Repossession","Commercial Law","Communication / FCC","Construction / Building Contracts","Consumer Claims","Copyright / Trademark","Corp-General","Corporate Form","Criminal","Domestic Relations","Eminent Domain","Employee Benefits / ERISA","Entertainment / Sports","Environmental","Environmental Litigation","Foreign","Health Care","Immigration / Naturalization","Insurance Coverage","Investment Counseling / Money Management","Labor Law - Union","Labor Litigation - Defense","Labor Litigation - Management","Labor Litigation - Plaintiff","Litigation-General-Defense","Litigation-General-Plaintiff","Mergers & Acquisitions","Municipal / Government - Zoning","Municipal / Governmental - Other","Oil / Gas / Minerals","Patent","Probate / Wills / Estates","Public Utilities","Real Estate - Commercial","Real Estate - Escrow Agent","Real Estate - Residential","Real Estate - Syndication Development","Real Estate - Title Work","School Law","Securities / Bonds / Secured Transactions / Loans","Social Security Law","Taxation Corporate - Opinions","Taxation Corporation - Prep","Taxation-Individual","Water Rights Law","Workers Compensation - Defense","Workers Compensation - Plaintiff"]}    
AOP = {'amounts':'65', 'list' : ["Administrative","Admiralty-Defense","Admiralty-Plaintiff","Anti-trust / Trade Regulation","Appellate","Arbitration / Mediation","Aviation","Banking / Financial Institutions","Bankruptcy","BI/PI Defendant General Liability","BI/PI Defendant Medical Malpractice","BI/PI Defendant Other","BI/PI Defendant Products Liability","BI/PI Plaintiffs General Liability","BI/PI Plaintiffs Medical Malpractice","BI/PI Plaintiffs Other","BI/PI Plaintiffs Products Liability","Civil Rights / Discrimination","Collection / Repossession","Commercial Law","Communication / FCC","Construction / Building Contracts","Consumer Claims","Copyright / Trademark","Corp-General","Corporate Form","Criminal","Domestic Relations","Eminent Domain","Employee Benefits / ERISA","Entertainment / Sports","Environmental","Environmental Litigation","Foreign","Health Care","Immigration / Naturalization","Insurance Coverage","Investment Counseling / Money Management","Labor Law - Union","Labor Litigation - Defense","Labor Litigation - Management","Labor Litigation - Plaintiff","Litigation-General-Defense","Litigation-General-Plaintiff","Mergers & Acquisitions","Municipal / Government - Zoning","Municipal / Governmental - Other","Oil / Gas / Minerals","Patent","Probate / Wills / Estates","Public Utilities","Real Estate - Commercial","Real Estate - Escrow Agent","Real Estate - Residential","Real Estate - Syndication Development","Real Estate - Title Work","School Law","Securities / Bonds / Secured Transactions / Loans","Social Security Law","Taxation Corporate - Opinions","Taxation Corporation - Prep","Taxation-Individual","Water Rights Law","Workers Compensation - Defense","Workers Compensation - Plaintiff"]}    

AOP_Primary = {'amounts': '65', 'list':[
        "Administrative",
        "Admiralty-Defense",
        "Admiralty-Plaintiff",
        "Anti-trust / Trade Regulation",
        "Appellate",
        "Arbitration / Mediation",
        "Aviation",
        "Banking / Financial Institutions",
        "Bankruptcy",
        "BI/PI Defendant General Liability",
        "BI/PI Defendant Medical Malpractice",
        "BI/PI Defendant Other",
        "BI/PI Defendant Products Liability",
        "BI/PI Plaintiffs General Liability",
        "BI/PI Plaintiffs Medical Malpractice",
        "BI/PI Plaintiffs Other",
        "BI/PI Plaintiffs Products Liability",
        "Civil Rights / Discrimination",
        "Collection / Repossession",
        "Commercial Law",
        "Communication / FCC",
        "Construction / Building Contracts",
        "Consumer Claims",
        "Copyright / Trademark",
        "Corp-General",
        "Corporate Form",
        "Criminal",
        "Domestic Relations",
        "Eminent Domain",
        "Employee Benefits / ERISA",
        "Entertainment / Sports",
        "Environmental",
        "Environmental Litigation",
        "Foreign",
        "Health Care",
        "Immigration / Naturalization",
        "Insurance Coverage",
        "Investment Counseling / Money Management",
        "Labor Law - Union",
        "Labor Litigation - Defense",
        "Labor Litigation - Management",
        "Labor Litigation - Plaintiff",
        "Litigation-General-Defense",
        "Litigation-General-Plaintiff",
        "Mergers & Acquisitions",
        "Municipal / Government - Zoning",
        "Municipal / Governmental - Other",
        "Oil / Gas / Minerals",
        "Other",
        "Probate / Wills / Estates",
        "Public Utilities",
        "Real Estate - Commercial",
        "Real Estate - Escrow Agent",
        "Real Estate - Residential",
        "Real Estate - Syndication Development",
        "Real Estate - Title Work",
        "School Law",
        "Securities / Bonds / Secured Transactions / Loans",
        "Social Security Law",
        "Taxation Corporate - Opinions",
        "Taxation Corporation - Prep",
        "Taxation-Individual",
        "Water Rights Law",
        "Workers Compensation - Defense",
        "Workers Compensation - Plaintiff"
    ]
}
   

AOP_Excess = {
    'amounts': '65',
    'list': [
        "Administrative",
        "Anti-trust / Trade Regulation",
        "Appellate",
        "Arbitration / Mediation",
        "Aviation",
        "Banking / Financial Institutions",
        "Bankruptcy",
        "BI/PI Defendant General Liability",
        "BI/PI Defendant Medical Malpractice",
        "BI/PI Defendant Other",
        "BI/PI Defendant Products Liability",
        "BI/PI Plaintiffs General Liability",
        "BI/PI Plaintiffs Medical Malpractice",
        "BI/PI Plaintiffs Other",
        "BI/PI Plaintiffs Products Liability",
        "Civil Rights / Discrimination",
        "Collection / Repossession",
        "Commercial Law",
        "Communication / FCC",
        "Construction / Building Contracts",
        "Consumer Claims",
        "Copyright / Trademark",
        "Corp-General",
        "Corporate Form",
        "Criminal",
        "Domestic Relations",
        "Eminent Domain",
        "Employee Benefits / ERISA",
        "Entertainment / Sports",
        "Environmental",
        "Environmental Litigation",
        "Foreign",
        "Health Care",
        "Immigration / Naturalization",
        "Insurance Coverage",
        "Investment Counseling / Money Management",
        "Labor Law - Union",
        "Labor Litigation - Defense",
        "Labor Litigation - Management",
        "Labor Litigation - Plaintiff",
        "Litigation-General-Defense",
        "Litigation-General-Plaintiff",
        "Mergers & Acquisitions",
        "Municipal / Government - Zoning",
        "Municipal / Governmental - Other",
        "Oil / Gas / Minerals",
        "Other",
        "Probate / Wills / Estates",
        "Public Utilities",
        "Real Estate - Commercial",
        "Real Estate - Escrow Agent",
        "Real Estate - Residential",
        "Real Estate - Syndication Development",
        "Real Estate - Title Work",
        "School Law",
        "Securities / Bonds / Secured Transactions / Loans",
        "Social Security Law",
        "Taxation Corporate - Opinions",
        "Taxation Corporation - Prep",
        "Taxation-Individual",
        "Water Rights Law",
        "Workers Compensation - Defense",
        "Workers Compensation - Plaintiff",
        "Admiralty-Defense",
        "Admiralty-Plaintiff"
    ]
}
# my_var = 'Hello World'
# my_list = ["Apple", "Banana", "Cherry"]
# my_dict = {'name': 'John', 'age': 36}

# VA = {'scalar': 'Scalar variable',
#               'LIST__list': ['List','variable']}

VA = {'amountEndorsements':'55','list':["Additional Defense Coverage Endorsement","Additional Named Insured","Additional Named Insured with Scheduled Retro Date","Aggregate Deductible Endorsement","ALFA Endorsement","ALFA Extended Reporting Period","Amend Directors and Officers Capacity","Amend Equity Threshold Exclusion","Amended Bodily Injury Exclusion","Amended Settlement Endorsement","Career Coverage Endorsement (Attorney)","Claims Expenses In Addition To The Limits Endorsement","Claims Made Period Limitation","Class Action Sublimit of Liability","Damages Only Deductible Endorsement","Damages Only Deductible – Claim Expenses","Data Breach Coverage Endorsement","Data Breach Exclusion","Delete Independent Contractor Endorsement","Delete Predecessor Firm Endorsement","Delete Title Agent Endorsement","Director, Officer, Manager Exclusion","Fee Collection and Dispute Endorsement","Handling of Funds Exclusion","Internet Legal Services Exclusion","Management Committee","Manuscript Endorsement","Named Individual Extended Reporting Period","Office or Staff Sharing Exclusion","Optional Extended Reporting Period","Prior Knowledge Date","Professional Services Entity Exclusion","Professional Services Extension","Public Officials Endorsement","Punitive Damages Exclusion","Quota Share Endorsement","Reduced Limits for Specified Person or Entity","Reduced Limits for Specified Services","Reduced Settlement Deductible","Service of Suit","Service of Suit","Social Engineering Damages Exclusion","Social Engineering Exclusion","Social Engineering Sublimit","Specific Claim or Matter Exclusion","Specified Client, Contract, or Project Limit","Specified Person or Entity Endorsement","Specified Person or Entity Exclusion","Specified Person or Entity with Limited Prior Acts Endorsement","Specified Predecessor Firm Exclusion","Specified Services Exclusion","Split Retroactive Date Endorsement","TCPA Sublimit","Title Agency as Additional Insured","Vicarious Liability","Worldwide Coverage Territory"]}

NY = {'amountEndorsements':'52','list':["Additional Named Insured","Additional Named Insured with Scheduled Retro Date","Aggregate Deductible Endorsement","ALFA Endorsement","ALFA Extended Reporting Period","Amend Directors and Officers Capacity","Amend Equity Threshold Exclusion","Amended Bodily Injury Exclusion","Amended Settlement Endorsement","Career Coverage Endorsement (Attorney)","Claims Expenses In Addition To The Limits Endorsement","Claims Made Period Limitation","Claims or Suits Entity Exclusion","Class Action Sublimit of Liability","Damages Only Deductible Endorsement","Damages Only Deductible – Claim Expenses (New York)","Data Breach Exclusion","Defense Offset Endorsement - 50% Deductible Only Offset - NY","Defense Offset Endorsement – 50% Offset – Limit Of Liability And Deductible – NY","Defense Offset Endorsement – 50% Offset – Limit Of Liability Only – NY","Delete Independent Contractor Endorsement","Delete Predecessor Firm Endorsement","Delete Title Agent Endorsement","Director, Officer, Manager Exclusion","Fee Collection and Dispute Endorsement","Handling of Funds Exclusion","Internet Legal Services Exclusion","Management Committee Endorsement","Manuscript Endorsement","Named Individual Extended Reporting Period","Office or Staff Sharing Exclusion","Optional Extended Reporting Period","Prior Knowledge Date","Professional Services Entity Exclusion","Professional Services Extension","Public Officials Endorsement","Punitive Damages Exclusion","Quota Share Endorsement","Reduced Limits for Specified Person or Entity","Reduced Limits for Specified Services","Reduced Settlement Deductible","Social Engineering Exclusion","Social Engineering Sublimit","Specific Claim or Matter Exclusion","Specified Person or Entity Endorsement","Specified Person or Entity Exclusion","Specified Person or Entity with Limited Prior Acts Endorsement","Specified Predecessor Firm Exclusion","Specified Services Exclusion","Split Retroactive Date Endorsement","TCPA Sublimit","Title Agency as Additional Insured"]}


CA = {'amountEndorsements':'54','list':["Additional Defense Coverage Endorsement","Additional Named Insured","Additional Named Insured with Scheduled Retro Date","Aggregate Deductible Endorsement","ALFA Endorsement","ALFA Extended Reporting Period","Amend Directors and Officers Capacity","Amend Equity Threshold Exclusion","Amended Bodily Injury Exclusion","Amended Settlement Endorsement","Career Coverage Endorsement (Attorney)","Claims Expenses In Addition To The Limits Endorsement","Claims Made Period Limitation","Class Action Sublimit of Liability","Damages Only Deductible Endorsement","Damages Only Deductible – Claim Expenses","Data Breach Coverage Endorsement","Data Breach Exclusion","Delete Independent Contractor Endorsement","Delete Predecessor Firm Endorsement","Delete Title Agent Endorsement","Director, Officer, Manager Exclusion","Fee Collection and Dispute Endorsement","Handling of Funds Exclusion","Internet Legal Services Exclusion","Management Committee","Manuscript Endorsement","Named Individual Extended Reporting Period","Office or Staff Sharing Exclusion","Optional Extended Reporting Period","Prior Knowledge Date","Professional Services Entity Exclusion","Professional Services Extension","Public Officials Endorsement","Punitive Damages Exclusion","Quota Share Endorsement","Reduced Limits for Specified Person or Entity","Reduced Limits for Specified Services","Reduced Settlement Deductible","Service of Suit","Service of Suit","Social Engineering Damages Exclusion","Social Engineering Exclusion","Social Engineering Sublimit","Specific Claim or Matter Exclusion","Specified Client, Contract, or Project Limit","Specified Person or Entity Endorsement","Specified Person or Entity Exclusion","Specified Person or Entity with Limited Prior Acts Endorsement","Specified Predecessor Firm Exclusion","Specified Services Exclusion","Split Retroactive Date Endorsement","TCPA Sublimit","Title Agency as Additional Insured","Vicarious Liability","Worldwide Coverage Territory"]}

CT = {'amountEndorsements':'54','list':["Additional Defense Coverage Endorsement","Additional Named Insured","Additional Named Insured with Scheduled Retro Date","Aggregate Deductible Endorsement","ALFA Endorsement","ALFA Extended Reporting Period","Amend Directors and Officers Capacity","Amend Equity Threshold Exclusion","Amended Bodily Injury Exclusion","Amended Settlement Endorsement","Career Coverage Endorsement (Attorney)","Claims Expenses In Addition To The Limits Endorsement","Claims Made Period Limitation","Class Action Sublimit of Liability","Damages Only Deductible Endorsement","Damages Only Deductible – Claim Expenses","Data Breach Coverage Endorsement","Data Breach Exclusion","Delete Independent Contractor Endorsement","Delete Predecessor Firm Endorsement","Delete Title Agent Endorsement","Director, Officer, Manager Exclusion","Fee Collection and Dispute Endorsement","Handling of Funds Exclusion","Internet Legal Services Exclusion","Management Committee","Manuscript Endorsement","Named Individual Extended Reporting Period","Office or Staff Sharing Exclusion","Optional Extended Reporting Period","Prior Knowledge Date","Professional Services Entity Exclusion","Professional Services Extension","Public Officials Endorsement","Punitive Damages Exclusion","Quota Share Endorsement","Reduced Limits for Specified Person or Entity","Reduced Limits for Specified Services","Reduced Settlement Deductible","Service of Suit","Service of Suit","Social Engineering Damages Exclusion","Social Engineering Exclusion","Social Engineering Sublimit","Specific Claim or Matter Exclusion","Specified Client, Contract, or Project Limit","Specified Person or Entity Endorsement","Specified Person or Entity Exclusion","Specified Person or Entity with Limited Prior Acts Endorsement","Specified Predecessor Firm Exclusion","Specified Services Exclusion","Split Retroactive Date Endorsement","TCPA Sublimit","Title Agency as Additional Insured","Vicarious Liability","Worldwide Coverage Territory"]}

FL = {'amountEndorsements':'54','list':["Additional Defense Coverage Endorsement","Additional Named Insured","Additional Named Insured with Scheduled Retro Date","Aggregate Deductible Endorsement","ALFA Endorsement","ALFA Extended Reporting Period","Amend Directors and Officers Capacity","Amend Equity Threshold Exclusion","Amended Bodily Injury Exclusion","Amended Settlement Endorsement","Career Coverage Endorsement (Attorney)","Claims Expenses In Addition To The Limits Endorsement","Claims Made Period Limitation","Class Action Sublimit of Liability","Damages Only Deductible Endorsement","Damages Only Deductible – Claim Expenses","Data Breach Coverage Endorsement","Data Breach Exclusion","Delete Independent Contractor Endorsement","Delete Predecessor Firm Endorsement","Delete Title Agent Endorsement","Director, Officer, Manager Exclusion","Fee Collection and Dispute Endorsement","Handling of Funds Exclusion","Internet Legal Services Exclusion","Management Committee","Manuscript Endorsement","Named Individual Extended Reporting Period","Office or Staff Sharing Exclusion","Optional Extended Reporting Period","Prior Knowledge Date","Professional Services Entity Exclusion","Professional Services Extension","Public Officials Endorsement","Punitive Damages Exclusion","Quota Share Endorsement","Reduced Limits for Specified Person or Entity","Reduced Limits for Specified Services","Reduced Settlement Deductible","Service of Suit","Service of Suit","Social Engineering Damages Exclusion","Social Engineering Exclusion","Social Engineering Sublimit","Specific Claim or Matter Exclusion","Specified Client, Contract, or Project Limit","Specified Person or Entity Endorsement","Specified Person or Entity Exclusion","Specified Person or Entity with Limited Prior Acts Endorsement","Specified Predecessor Firm Exclusion","Specified Services Exclusion","Split Retroactive Date Endorsement","TCPA Sublimit","Title Agency as Additional Insured","Vicarious Liability","Worldwide Coverage Territory"]}

KS = {'amountEndorsements':'54','list':["Additional Defense Coverage Endorsement","Additional Named Insured","Additional Named Insured with Scheduled Retro Date","Aggregate Deductible Endorsement","ALFA Endorsement","ALFA Extended Reporting Period","Amend Directors and Officers Capacity","Amend Equity Threshold Exclusion","Amended Bodily Injury Exclusion","Amended Settlement Endorsement","Career Coverage Endorsement (Attorney)","Claims Expenses In Addition To The Limits Endorsement","Claims Made Period Limitation","Class Action Sublimit of Liability","Damages Only Deductible Endorsement","Damages Only Deductible – Claim Expenses","Data Breach Coverage Endorsement","Data Breach Exclusion","Delete Independent Contractor Endorsement","Delete Predecessor Firm Endorsement","Delete Title Agent Endorsement","Director, Officer, Manager Exclusion","Fee Collection and Dispute Endorsement","Handling of Funds Exclusion","Internet Legal Services Exclusion","Management Committee","Manuscript Endorsement","Named Individual Extended Reporting Period","Office or Staff Sharing Exclusion","Optional Extended Reporting Period","Prior Knowledge Date","Professional Services Entity Exclusion","Professional Services Extension","Public Officials Endorsement","Punitive Damages Exclusion","Quota Share Endorsement","Reduced Limits for Specified Person or Entity","Reduced Limits for Specified Services","Reduced Settlement Deductible","Service of Suit","Service of Suit","Social Engineering Damages Exclusion","Social Engineering Exclusion","Social Engineering Sublimit","Specific Claim or Matter Exclusion","Specified Client, Contract, or Project Limit","Specified Person or Entity Endorsement","Specified Person or Entity Exclusion","Specified Person or Entity with Limited Prior Acts Endorsement","Specified Predecessor Firm Exclusion","Specified Services Exclusion","Split Retroactive Date Endorsement","TCPA Sublimit","Title Agency as Additional Insured","Vicarious Liability","Worldwide Coverage Territory"]}

# NY = {'amountEndorsements': '55',
#               'list': ['List','variable']}
# LA = {'amountEndorsements': '10',
#               'list': ['List','variable']}
# SF = {'amountEndorsements': '45',
#               'list': ['List','variable']}
NY_SL_P = {
    'amountEndorsements': '22',
    'list': [
        "Additional Defense Coverage Endorsement",
        "Additional Named Insured Endorsement",
        "Additional Named Insured With Scheduled Retroactive Date Endorsement",
        "Amended Hammer Clause Endorsement",
        "Claims or Suits By Any Specified Person or Entity Exclusion",
        "Damages Only Deductible Endorsement",
        "Damages Re-Defined To Not Include Punitive Or Exemplary Damages Endorsement",
        "Fee Collection and Fee Dispute Exclusion Endorsement",
        "Fee Collection And Fee Dispute Exclusion With Specified",
        "Lead Quota Share Endorsement",
        "Limitation of Claims Made Coverage Period Endorsement",
        "Management Committee Endorsement",
        "NY Defense Offset End't - Fifty Percent Offset - Deductible Only",
        "NY Defense Offset End't Fifty Percent Offset - Limit of Liability AND Deductible",
        "NY Defense Offset End't Fifty Percent Offset - Limit of Liability Only",
        "Office or Staff Sharing Exclusion Endorsement",
        "Policy Changes Endorsement",
        "Specific Claim or Matter Exclusion",
        "Specified Attorneys With Limited Prior Acts Coverage Endorsement",
        "Specified Client, Contract or Project Additional Limit Endorsement",
        "Specified Predecessor Firm Exclusion Endorsement",
        "Telephone Consumer Protection Act Sublimit of Liability"
    ]
}

NY_SL_E = {
    'amountEndorsements': '15',
    'list': [
        "Anti-Stacking of Limits Endorsement",
        "Cancellation Endorsement",
        "Follow Form to Mid-Term Endorsement",
        "Follow Form to Specified Sublimit Endorsement",
        "Non-Follow Form To Specified Coverage",
        "Non-Follow Form To Specified Coverage But Recognize Erosion",
        "Policy Changes",
        "Prior Acts Exclusion",
        "Prior and or Pending Litigation Exclusion",
        "Prior Knowledge Exclusion",
        "Professional Services Exclusion",
        "Quota Share Endorsement",
        "Reliance on Another Carrier's Application Endorsement",
        "Specific Entity Exclusion",
        "Specific Litigation Exclusion"
    ]
}


def get_variables(env):
    if env == 'NY':
        return NY
    elif env == 'CA':
        return CA
    elif env == 'VA':
        return VA
    elif env == 'CT':
        return CT  
    elif env == 'FL':
        return FL 
    elif env == 'KS':
        return KS  
    elif env == 'AOP':
        return AOP   
    elif env == 'AOP_Primary':
        return AOP_Primary
    elif env == 'AOP_Excess':
        return AOP_Excess   
    elif env == 'NY_SL_P':
        return NY_SL_P
    elif env == 'NY_SL_E':
        return NY_SL_E 
    else:
        # default variables
        return VA