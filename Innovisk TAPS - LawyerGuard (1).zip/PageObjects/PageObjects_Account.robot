*** Settings ***
Library                        QWeb
Library                        QForce
#Library                       QVision
Library                        FakerLibrary
Library                        String
Library                        BuiltIn
Library                        DateTime
Resource                       ../resources/common.robot

*** Variables ***
${billingaddressBS}
${billingaddressState}
${ZipCodeU}


*** Keywords ***
Account click
    # Author = Amol
    [tags]                     Contacts
    ClickText                  Accounts
    VerifyText                 Recently Viewed             anchor=span                 timeout=40s
    Log To Console             ------Account Clicked Successfully-------

Validate new Account record fields
    # Author = Amol
    [tags]                     ContactTypes
    ClickText                  Accounts
    VerifyText                 Recently Viewed             anchor=span                 timeout=40s
    # ClickText                New
    ClickElement               (//a[@title\="New"])[1]
    UseModal                   On
    ClickText                  BrokerAn agency or brokerage
    ClickText                  BusinessAn account that is considered to be a company or organization
    ClickText                  Insurance CompanyAn insurance carrier or writing company
    ClickText                  BusinessAn account that is considered to be a company or organization
    VerifyText                 An account that is considered to be a company or organization

    Log To Console             ------Account fields verified Successfully-------


Validate account form fields
    # Author = Amol
    [tags]                     Verify Account Fields
    Home
    ClickText                  Accounts
    VerifyText                 Recently Viewed             anchor=span                 timeout=40s
    # ClickText                New
    ClickElement               (//a[@title\="New"])[1]
    UseModal                   On
    VerifyText                 Business
    VerifyText                 Broker
    VerifyText                 Insurance Company
    ClickText                  Next                        partial_match=off
    VerifyText                 Account Name
    VerifyText                 Website
    VerifyText                 SIC Code
    VerifyText                 SIC Description
    VerifyText                 Number of Attorneys
    VerifyText                 Total CLE
    VerifyText                 Previous Account Name
    VerifyText                 Account Owner
    VerifyText                 Account Record Type
    VerifyText                 Parent Account
    VerifyText                 Phone
    VerifyText                 Total Revenues
    VerifyText                 Employees
    VerifyText                 Billing Address
    VerifyText                 Mailing Address
    VerifyText                 Billing Country
    VerifyText                 Billing Street
    VerifyText                 Mailing Country
    VerifyText                 Mailing Street
    VerifyText                 Billing City
    VerifyText                 Billing State/Province
    VerifyText                 Billing Zip/Postal Code
    VerifyText                 Mailing same as Billing address?
    VerifyText                 Mailing Country
    VerifyText                 Mailing Street
    VerifyText                 Mailing City
    VerifyText                 Mailing State/Province
    VerifyText                 Mailing Zip/Postal Code

    Log To Console             ------Account Form Fields Validated Successfully-------

    VerifyAttribute            //label[text()\='Account Name']/parent::div//input      maxlength                 255
    VerifyAttribute            //label[text()\='Account Name']/parent::div//input      type                      text
    VerifyAttribute            //label[text()\='Website']/parent::div//input           maxlength                 255
    VerifyAttribute            //label[text()\='Website']/parent::div//input           type                      text
    VerifyAttribute            //label[text()\='SIC Code']/parent::div//input          maxlength                 20
    VerifyAttribute            //label[text()\='SIC Code']/parent::div//input          type                      text
    VerifyAttribute            //label[text()\='SIC Description']/parent::div//input                             maxlength                   80
    VerifyAttribute            //label[text()\='SIC Description']/parent::div//input                             type                        text
    # Could Not find Max Length
    VerifyAttribute            //label[text()\='Number of Attorneys']/parent::div//input                         inputmode                   decimal
    VerifyAttribute            //label[text()\='Number of Attorneys']/parent::div//input                         type                        text
    # Could Not find Max Length
    VerifyAttribute            //label[text()\='Total CLE']/parent::div//input         inputmode                 decimal
    VerifyAttribute            //label[text()\='Total CLE']/parent::div//input         type                      text
    VerifyAttribute            //label[text()\='Previous Account Name']/parent::div//input                       maxlength                   255
    VerifyAttribute            //label[text()\='Previous Account Name']/parent::div//input                       type                        text
    VerifyAttribute            //label[text()\='Parent Account']/parent::lightning-grouped-combobox//div/input                               maxlength        255
    VerifyAttribute            //label[text()\='Parent Account']/parent::lightning-grouped-combobox//div/input                               type             text
    VerifyAttribute            //label[text()\='Phone']/parent::div//input             maxlength                 40
    VerifyAttribute            //label[text()\='Phone']/parent::div//input             type                      text
    # Could Not find Max Length
    VerifyAttribute            //label[text()\='Total Revenues']/parent::div//input    inputmode                 decimal
    VerifyAttribute            //label[text()\='Total Revenues']/parent::div//input    type                      text
    VerifyAttribute            //label[text()\='Employees']/parent::div//input         inputmode                 decimal
    VerifyAttribute            //label[text()\='Employees']/parent::div//input         type                      text
    VerifyAttribute            (//legend[text()\='Billing Address']/parent::fieldset//div/input)[1]              role                        combobox         anchor=1
    VerifyAttribute            (//legend[text()\='Billing Address']/parent::fieldset//div/input)[1]              type                        text             anchor=1


    VerifyAttribute            //label[text()\='Billing Country']/parent::div//input                             role                        combobox
    VerifyAttribute            //label[text()\='Billing Country']/parent::div//input                             type                        text
    VerifyAttribute            //label[text()\='Billing Street']/parent::lightning-textarea//textarea            maxlength                   255
    #VerifyAttribute           //label[text()\='Billing Street']/parent::lightning-textarea//textarea            type                        text
    VerifyAttribute            //label[text()\='Billing City']/parent::div//input      maxlength                 40
    VerifyAttribute            //label[text()\='Billing City']/parent::div//input      type                      text
    # Could Not find Max Length
    #VerifyAttribute           //label[text()\='Billing State/Province']/parent::div//input                      maxlength                   40
    VerifyAttribute            //label[text()\='Billing State/Province']/parent::div//input                      type                        text

    VerifyAttribute            //label[text()\='Billing Zip/Postal Code']/parent::div//input                     maxlength                   20
    VerifyAttribute            //label[text()\='Billing Zip/Postal Code']/parent::div//input                     type                        text
    # Could Not find Max Length
    #VerifyAttribute           //span[text()\='Mailing same as Billing address?']/parent::div//input             maxlength                   40
    VerifyAttribute            //span[text()\='Mailing same as Billing address?']/parent::label/parent::lightning-primitive-input-checkbox//input             type    checkbox



    VerifyAttribute            (//legend[text()\='Mailing Address']/parent::fieldset//div/input)[1]              role                        combobox
    VerifyAttribute            (//legend[text()\='Mailing Address']/parent::fieldset//div/input)[1]              type                        text


    VerifyAttribute            //label[text()\='Mailing Country']/parent::div//input                             role                        combobox
    VerifyAttribute            //label[text()\='Mailing Country']/parent::div//input                             type                        text
    VerifyAttribute            //label[text()\='Mailing Street']/parent::lightning-textarea//textarea            maxlength                   255
    #VerifyAttribute           //label[text()\='Billing Street']/parent::lightning-textarea//textarea            type                        text
    VerifyAttribute            //label[text()\='Mailing City']/parent::div//input      maxlength                 40
    VerifyAttribute            //label[text()\='Mailing City']/parent::div//input      type                      text
    # Could Not find Max Length
    #VerifyAttribute           //label[text()\='Billing State/Province']/parent::div//input                      maxlength                   40
    VerifyAttribute            //label[text()\='Mailing State/Province']/parent::div//input                      type                        text

    VerifyAttribute            //label[text()\='Mailing Zip/Postal Code']/parent::div//input                     maxlength                   20
    VerifyAttribute            //label[text()\='Mailing Zip/Postal Code']/parent::div//input                     type                        text

    Log To Console             ------Account Form Attributes Validated Successfully-------

    VerifyText                 Cancel                      partial_match=false
    VerifyText                 Save & New                  partial_match=false
    VerifyText                 Save                        partial_match=false

    Log To Console             ------Account Form Buttons Validated Successfully -------

Validate New submission
    # Author = Amol
    [Documentation]            Checking LawyerGuard
    [tags]                     All
    Home


    ClickText                  Next                        anchor=New Submission
    ClickText                  LawyerGuard
    VerifyText                 LawyerGuard                 anchor=Home
    VerifyText                 New Submission
    VerifyText                 Existing Submission
    VerifyText                 Post Bind Endorsement
    ClickText                  Next

    UseModal                   On
    VerifyText                 New Submission
    VerifyText                 Record Type
    ClickText                  LawyerGuard                 anchor=Record Type
    VerifyText                 Product
    ClickText                  LawyerGuard                 anchor=Product
    ClickText                  Next                        anchor=Cancel
    Log To Console             ------New Submission Elements Validated Successfully -------


Creating a new Account
    # Author = Amol
    [tags]                     Lead
    Home
    ClickText                  Accounts
    VerifyText                 Recently Viewed             anchor=span                 timeout=40s
    #ClickText                 New
    ClickElement               (//a[@title\="New"])[1]

    UseModal                   On
    VerifyText                 New Account
    # ClickText                Business
    # Log To Console           Buisness Clicked
    ClickText                  Next                        anchor=span                 timeout=20s
    Sleep                      10s
    Log To Console             ------New Buisness Account Clicked-------


    ## Entering data in the Account
    ${currTime}=               Get Current Date            result_format=%-d%-m%Y%-H%f
    ${name1}=                  Name Male
    Set Global Variable        ${name1}
    ${random_email}=           Set Variable                ${name1}@gmail.com
    Set Global Variable        ${random_email}
    ${uniqueName}=             Set Variable                ${name1}${currTime}
    Set Global Variable        ${uniqueName}
    Log To Console             ${uniqueName}
    ${pdf_insuredname}=        Set Variable                ${uniqueName}
    Set Global Variable        ${pdf_insuredname}
    ${sic}=                    Generate Random String      10                          123456789
    Set Global Variable        ${sic}
    ${sicdescription}=         Set Variable                My Description
    Set Global Variable        ${sicdescription}

    ${noofattorneys}=          Set Variable                5
    Set Global Variable        ${noofattorneys}

    ${totalcle}=               Set Variable                3534
    Set Global Variable        ${totalcle}
    ${previousaccountname}=    Set Variable                Nathan123
    Set Global Variable        ${previousaccountname}
    ${accrecordtype}=          Set Variable                Business
    Set Global Variable        ${accrecordtype}
    ${parentaccount}=          Set Variable                SHRADDHA Test
    Set Global Variable        ${parentaccount}
    ${phone}=                  Generate Random String      10                          1234567890
    Log To Console             ${phone}
    Set Global Variable        ${phone}
    ${rev}=                    Generate Random String      6                           123456789
    Set Global Variable        ${rev}

    ${employee}=               Set Variable                4
    Set Global Variable        ${employee}

    ${billingaddress}=         Set Variable                902 Alabama
    Set Global Variable        ${billingaddress}

    Log To Console             ------Global Variables Saved Successfully-------

    VerifyText                 Account Name
    TypeText                   Account Name                ${uniqueName}
    TypeText                   Website                     ${random_email}
    TypeText                   SIC Code                    ${sic}
    TypeText                   SIC Description             ${sicdescription}
    TypeText                   Number of Attorneys         ${noofattorneys}
    TypeText                   Total CLE                   ${totalcle}
    TypeText                   Previous Account Name       ${previousaccountname}
    #VerifyField               Account Owner               Copado-LGO Automation-User
    VerifyField                Account Record Type         ${accrecordtype}
    #ComboBox                  Parent Account              ${parentaccount}            delay=2s


    TypeText                   //input[@placeholder\='Search Accounts...']             SHRADDHA Test

    Sleep                      5s
    #ClickElement              (//li[@role\='presentation'])[1]
    ClickElement               (//lightning-base-combobox-item[@data-value\='actionAdvancedSearch']/parent::div//li)[1]
    # --------------------------Setting Address from lsit in every run ---------------------------------

    Run Keyword                Generate Dynamic Address
    Log To Console             Using dynamic Billing Street: ${billingaddressBS}
    TypeText                   Billing Street              ${billingaddressBS}
    PickList                   Billing Country             United States
    sleep                      2s
    PickList                   Billing State/Province      ${billingaddressState}
    sleep                      2s
    TypeText                   Billing City                ${billingaddressState}
    TypeText                   Billing Zip/Postal Code     ${ZipCodeU}
    ClickText                  Mailing same as Billing address?

    # --------------------------Setting Address from lsit in every run ---------------------------------


    TypeText                   Phone                       ${phone}

    TypeText                   Total Revenues              ${rev}
    TypeText                   Employees                   ${employee}
    #TypeText                  Billing Address             ${billingaddress}
    # ClickText                902 Alabama Drive

    # ClickText                Mailing same as Billing address?

    ClickText                  Save                        partial_match=false
    UseModal                   Off
    Log To Console             ------New Account Created Successfully-------

Creating a new Account state NY
    # Author = Rugveda
    [tags]                     Lead
    Home
    ClickText                  Accounts
    VerifyText                 Recently Viewed             anchor=span                 timeout=40s
    # ClickText                New
    ClickElement               (//a[@title\="New"])[1]

    UseModal                   On
    VerifyText                 New Account
    # ClickText                Business
    # Log To Console           Buisness Clicked
    ClickText                  Next                        anchor=span                 timeout=20s
    Log To Console             ------New Buisness Account Clicked-------


    ## Entering data in the Account
    ${currTime}=               Get Current Date            result_format=%-d%-m%Y%-H%f
    ${name1}=                  Name Male
    Set Global Variable        ${name1}
    ${random_email}=           Set Variable                ${name1}@gmail.com
    Set Global Variable        ${random_email}
    ${uniqueName}=             Set Variable                ${name1}${currTime}
    Set Global Variable        ${uniqueName}
    Log To Console             ${uniqueName}
    ${pdf_insuredname}=        Set Variable                ${uniqueName}
    Set Global Variable        ${pdf_insuredname}
    ${sic}=                    Generate Random String      10                          123456789
    Set Global Variable        ${sic}
    ${sicdescription}=         Set Variable                My Description
    Set Global Variable        ${sicdescription}

    ${noofattorneys}=          Set Variable                5
    Set Global Variable        ${noofattorneys}

    ${totalcle}=               Set Variable                3534
    Set Global Variable        ${totalcle}
    ${previousaccountname}=    Set Variable                Nathan123
    Set Global Variable        ${previousaccountname}
    ${accrecordtype}=          Set Variable                Business
    Set Global Variable        ${accrecordtype}
    ${parentaccount}=          Set Variable                SHRADDHA Test
    Set Global Variable        ${parentaccount}
    ${phone}=                  Generate Random String      10                          1234567890
    Log To Console             ${phone}
    Set Global Variable        ${phone}
    ${rev}=                    Generate Random String      6                           123456789
    Set Global Variable        ${rev}

    ${employee}=               Set Variable                4
    Set Global Variable        ${employee}

    ${billingaddress}=         Set Variable                88-21 208th Street
    Set Global Variable        ${billingaddress}

    Log To Console             ------Global Variables Saved Successfully-------

    VerifyText                 Account Name
    TypeText                   Account Name                ${uniqueName}
    TypeText                   Website                     ${random_email}
    TypeText                   SIC Code                    ${sic}
    TypeText                   SIC Description             ${sicdescription}
    TypeText                   Number of Attorneys         ${noofattorneys}
    TypeText                   Total CLE                   ${totalcle}
    TypeText                   Previous Account Name       ${previousaccountname}
    #VerifyField               Account Owner               Copado-LGO Automation-User
    VerifyField                Account Record Type         ${accrecordtype}
    #ComboBox                  Parent Account              ${parentaccount}            delay=2s


    TypeText                   //input[@placeholder\='Search Accounts...']             SHRADDHA Test

    Sleep                      5s
    #ClickElement              (//li[@role\='presentation'])[1]
    ClickElement               (//lightning-base-combobox-item[@data-value\='actionAdvancedSearch']/parent::div//li)[1]



    TypeText                   Phone                       ${phone}

    TypeText                   Total Revenues              ${rev}
    TypeText                   Employees                   ${employee}
    TypeText                   Billing Address             ${billingaddress}
    ClickText                  88-21 208th Street

    ClickText                  Mailing same as Billing address?

    ClickText                  Save                        partial_match=false
    UseModal                   Off
    Log To Console             ------New Account Created Successfully-----

Creating an account with a state Connecticut
    # Author = Shraddha
    [tags]                     Lead
    Home
    ClickText                  Accounts
    VerifyText                 Recently Viewed             anchor=span                 timeout=40s
    # ClickText                New
    ClickElement               (//a[@title\="New"])[1]

    UseModal                   On
    VerifyText                 New Account
    # ClickText                Business
    # Log To Console           Buisness Clicked
    ClickText                  Next                        anchor=span                 timeout=20s
    Log To Console             ------New Buisness Account Clicked-------


    ## Entering data in the Account
    ${currTime}=               Get Current Date            result_format=%-d%-m%Y%-H%f
    ${name1}=                  Name Male
    Set Global Variable        ${name1}
    ${random_email}=           Set Variable                ${name1}@gmail.com
    Set Global Variable        ${random_email}
    ${uniqueName}=             Set Variable                ${name1}${currTime}
    Set Global Variable        ${uniqueName}
    Log To Console             ${uniqueName}
    ${pdf_insuredname}=        Set Variable                ${uniqueName}
    Set Global Variable        ${pdf_insuredname}
    ${sic}=                    Generate Random String      10                          123456789
    Set Global Variable        ${sic}
    ${sicdescription}=         Set Variable                My Description
    Set Global Variable        ${sicdescription}

    ${noofattorneys}=          Set Variable                5
    Set Global Variable        ${noofattorneys}

    ${totalcle}=               Set Variable                3534
    Set Global Variable        ${totalcle}
    ${previousaccountname}=    Set Variable                Nathan123
    Set Global Variable        ${previousaccountname}
    ${accrecordtype}=          Set Variable                Business
    Set Global Variable        ${accrecordtype}
    ${parentaccount}=          Set Variable                SHRADDHA Test
    Set Global Variable        ${parentaccount}
    ${phone}=                  Generate Random String      10                          1234567890
    Log To Console             ${phone}
    Set Global Variable        ${phone}
    ${rev}=                    Generate Random String      6                           123456789
    Set Global Variable        ${rev}

    ${employee}=               Set Variable                4
    Set Global Variable        ${employee}

    ${billingaddress}=         Set Variable                1500 Connecticut 12
    Set Global Variable        ${billingaddress}

    Log To Console             ------Global Variables Saved Successfully-------

    VerifyText                 Account Name
    TypeText                   Account Name                ${uniqueName}
    TypeText                   Website                     ${random_email}
    TypeText                   SIC Code                    ${sic}
    TypeText                   SIC Description             ${sicdescription}
    TypeText                   Number of Attorneys         ${noofattorneys}
    TypeText                   Total CLE                   ${totalcle}
    TypeText                   Previous Account Name       ${previousaccountname}
    #VerifyField               Account Owner               Copado-LGO Automation-User
    VerifyField                Account Record Type         ${accrecordtype}
    #ComboBox                  Parent Account              ${parentaccount}            delay=2s


    TypeText                   //input[@placeholder\='Search Accounts...']             SHRADDHA Test

    Sleep                      5s
    #ClickElement              (//li[@role\='presentation'])[1]
    ClickElement               (//lightning-base-combobox-item[@data-value\='actionAdvancedSearch']/parent::div//li)[1]



    TypeText                   Phone                       ${phone}

    TypeText                   Total Revenues              ${rev}
    TypeText                   Employees                   ${employee}
    TypeText                   Billing Address             ${billingaddress}
    ClickText                  1500 Connecticut 12

    ClickText                  Mailing same as Billing address?

    ClickText                  Save                        partial_match=false
    UseModal                   Off
    Log To Console             ------New Account Created Successfully-----
    
    
Creating an account with a state California
    # Author = Shraddha
    [tags]                     Lead
    Home
    ClickText                  Accounts
    VerifyText                 Recently Viewed             anchor=span                 timeout=40s
    # ClickText                New
    ClickElement               (//a[@title\="New"])[1]

    UseModal                   On
    VerifyText                 New Account
    # ClickText                Business
    # Log To Console           Buisness Clicked
    ClickText                  Next                        anchor=span                 timeout=20s
    Log To Console             ------New Buisness Account Clicked-------


    ## Entering data in the Account
    ${currTime}=               Get Current Date            result_format=%-d%-m%Y%-H%f
    ${name1}=                  Name Male
    Set Global Variable        ${name1}
    ${random_email}=           Set Variable                ${name1}@gmail.com
    Set Global Variable        ${random_email}
    ${uniqueName}=             Set Variable                ${name1}${currTime}
    Set Global Variable        ${uniqueName}
    Log To Console             ${uniqueName}
    ${pdf_insuredname}=        Set Variable                ${uniqueName}
    Set Global Variable        ${pdf_insuredname}
    ${sic}=                    Generate Random String      10                          123456789
    Set Global Variable        ${sic}
    ${sicdescription}=         Set Variable                My Description
    Set Global Variable        ${sicdescription}

    ${noofattorneys}=          Set Variable                5
    Set Global Variable        ${noofattorneys}

    ${totalcle}=               Set Variable                3534
    Set Global Variable        ${totalcle}
    ${previousaccountname}=    Set Variable                Nathan123
    Set Global Variable        ${previousaccountname}
    ${accrecordtype}=          Set Variable                Business
    Set Global Variable        ${accrecordtype}
    ${parentaccount}=          Set Variable                SHRADDHA Test
    Set Global Variable        ${parentaccount}
    ${phone}=                  Generate Random String      10                          1234567890
    Log To Console             ${phone}
    Set Global Variable        ${phone}
    ${rev}=                    Generate Random String      6                           123456789
    Set Global Variable        ${rev}

    ${employee}=               Set Variable                4
    Set Global Variable        ${employee}

    ${billingaddress}=         Set Variable                10600 Highland Springs Avenue
    Set Global Variable        ${billingaddress}

    Log To Console             ------Global Variables Saved Successfully-------

    VerifyText                 Account Name
    TypeText                   Account Name                ${uniqueName}
    TypeText                   Website                     ${random_email}
    TypeText                   SIC Code                    ${sic}
    TypeText                   SIC Description             ${sicdescription}
    TypeText                   Number of Attorneys         ${noofattorneys}
    TypeText                   Total CLE                   ${totalcle}
    TypeText                   Previous Account Name       ${previousaccountname}
    #VerifyField               Account Owner               Copado-LGO Automation-User
    VerifyField                Account Record Type         ${accrecordtype}
    #ComboBox                  Parent Account              ${parentaccount}            delay=2s


    TypeText                   //input[@placeholder\='Search Accounts...']             SHRADDHA Test

    Sleep                      5s
    #ClickElement              (//li[@role\='presentation'])[1]
    ClickElement               (//lightning-base-combobox-item[@data-value\='actionAdvancedSearch']/parent::div//li)[1]



    TypeText                   Phone                       ${phone}

    TypeText                   Total Revenues              ${rev}
    TypeText                   Employees                   ${employee}
    TypeText                   Billing Address             ${billingaddress}
    ClickText                  10600 Highland Springs Avenue

    ClickText                  Mailing same as Billing address?

    ClickText                  Save                        partial_match=false
    UseModal                   Off
    Log To Console             ------New Account Created Successfully-----

Verify Account Created Fields
    # Author = Amol
    [Tags]                     VerifyAccount
    Home
    Account click
    VerifyText                 Recently Viewed             timeout=120s
    # ${acc_1}=                GetText                     ${uniquename}
    # ${acc_2}=                GetText                     ${uniquename1}
    #                          ${uniquename1}=             GetText                     (//span[@data-cell-type\="lstOutputLookup"])[1]
    ClickText                  ${uniquename}
    VerifyField                Website                     ${random_email}
    VerifyField                SIC Code                    ${sic}
    VerifyField                SIC Description             ${sicdescription}
    VerifyField                Number of Attorneys         ${noofattorneys}
    # Verifying Total CLE
    ${totcl}=                  GetFieldValue               Total CLE
    Log To Console             ${totcl}
    ${totcl1}=                 Remove String               ${totcl}                    ,
    Log To Console             ${totcl1}
    IF                         ${totalcle} == ${totcl1}
        Log To Console         Success
    ELSE
        Fail                   Assertion Failed
    END
    Log Screenshot

    VerifyField                Previous Account Name       ${previousaccountname}
    ${pcc}=                    GetFieldValue               Parent Account

    ${paac1}=                  Remove String               ${pcc}                      Open                      Preview
    ${paac2}=                  Convert To String           ${paac1}
    Log To Console             ${paac2}
    ${dmparentacc}=            Convert To String           ${parentaccount}
    Log To Console             ${dmparentacc}

    #phone no validation
    ${pno}=                    GetFieldValue               Phone
    ${pno1}=                   Remove String               ${pno}                      -                         (                           )    ${SPACE}
    Log To Console             ${pno1}
    ${phone2}=                 Remove String               ${phone}                    -                         (                           )    ${SPACE}
    IF                         '${phone2}' == '${pno1}'
        Log To Console         Success
    ELSE
        Fail                   Assertion Failed
    END
    Log Screenshot
    ${trev}=                   GetFieldValue               Total Revenues
    ${trev1}=                  Remove String               ${trev}                     $                         ,
    Log To Console             ${rev}
    ${rev1}=                   set Variable                USD${SPACE}${rev}.00
    Log To Console             ${rev1}
    Log To Console             ${trev1}
    IF                         '${trev1}' == '${rev1}'
        Log To Console         Success
    ELSE
        Fail                   Assertion Failed
    END
    Log Screenshot

    #Verifying address
    ${Address}=                Catenate                    ${billingaddressBS}${billingaddressState},            ${billingaddressState}      ${ZipCodeU}United States
    Log To Console             ${Address}
    Log To Console             ${Address}
    ${sf_address}=             GetFieldValue               Billing Address
    ${words}=                  Remove String               ${sf_address}               \n
    Log To Console             ${words}
    IF                         '${Address}' == '${words}'
        Log To Console         Success
    ELSE
        Fail                   Assertion Failed
    END
    Log Screenshot

    ${b_add1}=                 GetFieldValue               Billing Address
    ${b_add2}=                 Remove String               ${b_add1}                   \n
    ${m_add1}=                 GetFieldValue               Mailing Address
    ${m_add2}=                 Remove String               ${m_add1}                   \n
    Log To Console             ${b_add2}
    Log To Console             ${m_add2}
    IF                         '${b_add2}' == '${m_add2}'
        Log To Console         Success
    ELSE
        Fail                   Assertion Failed
    END
    Log Screenshot

    Log To Console             ------New Account Created Fields Validated Successfully-------

Validate Account Elements
    # Author = Amol
    [Tags]                     VerifyAccount
    Home
    ClickText                  Accounts
    VerifyText                 Recently Viewed             anchor=span
    # ${uniquename1}=          GetText                     (//span[@data-cell-type\="lstOutputLookup"])[1]
    ClickText                  ${uniquename}
    VerifyText                 Details
    VerifyText                 Submission                  anchor=Details
    VerifyText                 Policies                    anchor=Details
    VerifyText                 Contact                     anchor=Details
    VerifyText                 Notes                       anchor=Details
    VerifyText                 Sanction                    anchor=Details              partial_match=false
    VerifyText                 Document                    anchor=Details
    VerifyText                 View Account Hierarchy
    VerifyText                 Generate Loss Run Doc
    VerifyText                 View Document
    VerifyText                 Export Attorney
    VerifyText                 Attorney Import
    VerifyText                 Follow
    VerifyText                 Document
    Log To Console             ------ Account Page Elements Validated Successfully-------

Editing the Account    
    # Author = Amol
    [Tags]                     EditingAccount
    [Documentation]            Editing an account
    Home
    ClickText                  Accounts
    #${uniquename1}=           GetText                     (//span[@data-cell-type\="lstOutputLookup"])[1]
    #ClickText                 ${uniquename1}
    ClickElement               //a[contains(@href, '/lightning/r/')][1]
    ClickElement               (//span[text()\='Show more actions']/parent::button)[1]
    ClickElement               //span[text()\='Edit']/parent::a                        Delay=3s
    Log To Console             ------ Edit Button Clicked on Account Successfully-------
    UseModal                   On
    #TypeText                  Account Name                A
    PressKey                   Account Name                {CONTROL + A + DELETE}

    PressKey                   Website                     {CONTROL + A + DELETE}
    PressKey                   SIC Code                    {CONTROL + A + DELETE}
    PressKey                   SIC Description             {CONTROL + A + DELETE}
    PressKey                   Number of Attorneys         {CONTROL + A + DELETE}
    PressKey                   Total CLE                   {CONTROL + A + DELETE}
    PressKey                   Previous Account Name       {CONTROL + A + DELETE}
    PressKey                   Account Owner               {CONTROL + A + DELETE}
    #VerifyText                Parent Account
    PressKey                   Phone                       {CONTROL + A + DELETE}
    PressKey                   Total Revenues              {CONTROL + A + DELETE}
    PressKey                   Employees                   {CONTROL + A + DELETE}

    Log To Console             ------ Account Fields Cleared Successfully-------

    ${currTime}=               Get Current Date            result_format=%-d%-m%Y%-H%f
    ${name2}=                  Name Male
    ${uniquename1}=            Set Variable                ${name2}${currTime}
    Set Global Variable        ${uniquename1}
    TypeText                   Account Name                ${uniquename1}
    TypeText                   Website                     Gibbson@gmail.com
    TypeText                   SIC Code                    12313
    TypeText                   SIC Description             Testing Editing
    TypeText                   Number of Attorneys         72
    TypeText                   Total CLE                   12
    TypeText                   Previous Account Name       Martin Garris
    #VerifyField               Account Owner               Copado-LGO Automation-User
    #VerifyField               Account Record Type         ${accrecordtype}
    #TypeText                  Parent Account              ${parentaccount}
    #ClickElement              (//li[@role\='presentation'])[1]
    TypeText                   Phone                       1234567121
    TypeText                   Total Revenues              78923
    TypeText                   Employees                   16
    TypeText                   Billing Address             743 Spring Street
    ClickText                  743 Spring Street Northeast
    Log Screenshot
    ClickText                  Save                        partial_match=false
    UseModal                   Off
    #VerifyField               Account Name                ${uniquename1}
    Log To Console             ------ New Field Values Added and Record Saved Successfully-------
    Log Screenshot



Delete Account Click   
    # Author = Amol
    [Tags]                     Delete Account
    Home
    ClickText                  Accounts
    VerifyText                 Recently Viewed             anchor=span
    # ${uniquename1}=          GetText                     (//span[@data-cell-type\="lstOutputLookup"])[1]
    #ClickText                 ${uniquename}
    ClickElement               //a[contains(@href, '/lightning/r/')][1]
    ClickElement               (//span[text()\='Show more actions']/parent::button)[1]
    ClickElement               //span[text()\='Delete']/parent::a
    ClickText                  Delete                      anchor=Cancel
    Log To Console             ------ Account Deleted -------


Creating a new Account with Save and new
    # Author = Amol
    [tags]                     Lead
    Home
    ClickText                  Accounts
    VerifyText                 Recently Viewed             anchor=span                 timeout=40s
    #ClickText                 New
    ClickElement               (//a[@title\="New"])[1]


    UseModal                   On
    VerifyText                 New Account
    # ClickText                Business
    # Log To Console           Buisness Clicked
    ClickText                  Next                        anchor=span                 timeout=20s

    Log To Console             ------ Navigated to Account -------

    ## Entering data in the Account
    ${currTime}=               Get Current Date            result_format=%-d%-m%Y%-H%f
    ${name1}=                  Name Male
    Set Global Variable        ${name1}
    ${random_email}=           Set Variable                ${name1}@gmail.com
    Set Global Variable        ${random_email}
    ${uniqueName}=             Set Variable                ${name1}${currTime}
    Set Global Variable        ${uniquename}
    ${sic}=                    Generate Random String      10                          123456789
    Set Global Variable        ${sic}
    ${sicdescription}=         Set Variable                My Description
    Set Global Variable        ${sicdescription}

    ${noofattorneys}=          Set Variable                5
    Set Global Variable        ${noofattorneys}

    ${totalcle}=               Set Variable                3534
    Set Global Variable        ${totalcle}
    ${previousaccountname}=    Set Variable                Nathan123
    Set Global Variable        ${previousaccountname}
    ${accrecordtype}=          Set Variable                Business
    Set Global Variable        ${accrecordtype}
    ${parentaccount}=          Set Variable                SHRADDHA Test
    Set Global Variable        ${parentaccount}
    ${phone}=                  Generate Random String      10                          1234567890
    Set Global Variable        ${phone}
    ${rev}=                    Generate Random String      6                           123456
    Set Global Variable        ${rev}

    ${employee}=               Set Variable                4
    Set Global Variable        ${employee}

    ${billingaddress}=         Set Variable                902 Alabama
    Set Global Variable        ${billingaddress}

    Log To Console             ------ Global Variabled are Set -------

    VerifyText                 Account Name
    TypeText                   Account Name                ${uniqueName}
    TypeText                   Website                     ${random_email}
    TypeText                   SIC Code                    ${sic}
    TypeText                   SIC Description             ${sicdescription}
    TypeText                   Number of Attorneys         ${noofattorneys}
    TypeText                   Total CLE                   ${totalcle}
    TypeText                   Previous Account Name       ${previousaccountname}
    #VerifyField               Account Owner               Copado-LGO Automation-User
    VerifyField                Account Record Type         ${accrecordtype}
    # ComboBox                 Parent Account              ${parentaccount}            delay=2s
    sleep                      2s
    TypeText                   //input[@placeholder\='Search Accounts...']             SHRADDHA Test

    Sleep                      5s
    #ClickElement              (//li[@role\='presentation'])[1]
    ClickElement               (//lightning-base-combobox-item[@data-value\='actionAdvancedSearch']/parent::div//li)[1]




    TypeText                   Phone                       ${phone}

    TypeText                   Total Revenues              ${rev}
    TypeText                   Employees                   ${employee}
    TypeText                   Billing Address             ${billingaddress}
    ClickText                  902 Alabama Drive

    # TypeText                 Billing Address             234 Greene
    # ClickText                234 Greene Avenue
    ClickText                  Save & New                  partial_match=false

    Log To Console             ------ Account Fileds Entered and Account is Saved Variabled are Set -------
    VerifyText                 New Account
    ClickText                  Next                        anchor=Cancel

    Log To Console             ------ Save and New Clicked -------

    ## Entering data in the Account
    ${currTime}=               Get Current Date            result_format=%-d%-m%Y%-H%f
    ${namesaveandnew1}=        Name Male
    Set Global Variable        ${namesaveandnew1}
    ${random_email}=           Set Variable                ${namesaveandnew1}@gmail.com
    Set Global Variable        ${random_email}
    ${uniqueName2}=            Set Variable                ${namesaveandnew1}${currTime}
    Set Global Variable        ${uniqueName2}
    ${sic}=                    Generate Random String      10                          123456789
    Set Global Variable        ${sic}
    ${sicdescription}=         Set Variable                My Description
    Set Global Variable        ${sicdescription}

    ${noofattorneys}=          Set Variable                5
    Set Global Variable        ${noofattorneys}

    ${totalcle}=               Set Variable                3534
    Set Global Variable        ${totalcle}
    ${previousaccountname}=    Set Variable                Nathan123
    Set Global Variable        ${previousaccountname}
    ${accrecordtype}=          Set Variable                Business
    Set Global Variable        ${accrecordtype}
    ${parentaccount}=          Set Variable                SHRADDHA Test
    Set Global Variable        ${parentaccount}
    ${phone}=                  Generate Random String      10                          1234567890
    Set Global Variable        ${phone}
    ${rev}=                    Generate Random String      6                           123456789
    Set Global Variable        ${rev}

    ${employee}=               Set Variable                4
    Set Global Variable        ${employee}

    ${billingaddress}=         Set Variable                902 Alabama
    Set Global Variable        ${billingaddress}

    Log To Console             ------ Global Variabled Set -------

    VerifyText                 Account Name
    TypeText                   Account Name                ${uniqueName2}
    TypeText                   Website                     ${random_email}
    TypeText                   SIC Code                    ${sic}
    TypeText                   SIC Description             ${sicdescription}
    TypeText                   Number of Attorneys         ${noofattorneys}
    TypeText                   Total CLE                   ${totalcle}
    TypeText                   Previous Account Name       ${previousaccountname}
    #VerifyField               Account Owner               Copado-LGO Automation-User
    #VerifyField               Account Record Type         '${accrecordtype}'
    # ComboBox                 Parent Account              ${parentaccount}            delay=2s

    # TypeText                 //input[@placeholder\='Search Accounts...']             SHRADDHA Test
    # ClickElement             (//li[@role\='presentation'])[1]

    TypeText                   Phone                       ${phone}

    TypeText                   Total Revenues              ${rev}
    TypeText                   Employees                   ${employee}
    TypeText                   Billing Address             ${billingaddress}
    ClickText                  902 Alabama Drive
    ClickText                  Save                        partial_match=false

    Log To Console             ------ Second Account Created Successfully -------
    UseModal                   Off
    ClickText                  Accounts
    VerifyText                 Recently Viewed             anchor=span
    ${acc_1}=                  GetText                     ${uniquename}
    ${acc_2}=                  GetText                     ${uniqueName2}
    IF                         "${acc_1} == ${uniquename} and $(acc_1} == ${uniquename}"
        Log To Console         Success
    ELSE
        Fail
    END



Creation of Account Cancel 
    # Author = Amol
    [tags]                     Lead
    Home
    ClickText                  Accounts
    VerifyText                 Recently Viewed             anchor=span                 timeout=40s
    #ClickText                 New
    ClickElement               (//a[@title\="New"])[1]


    UseModal                   On
    VerifyText                 New Account
    # ClickText                Business
    # Log To Console           Buisness Clicked
    ClickText                  Next                        anchor=span                 timeout=20s

    Log To Console             ------ Creating Global Variables -------
    ## Entering data in the Account
    ${currTime}=               Get Current Date            result_format=%-d%-m%Y%-H%f
    ${name1}=                  Name Male
    Set Global Variable        ${name1}
    ${random_email}=           Set Variable                ${name1}@gmail.com
    Set Global Variable        ${random_email}
    ${uniqueName}=             Set Variable                ${name1}${currTime}
    Set Global Variable        ${uniqueName}
    ${sic}=                    Generate Random String      10                          123456789
    Set Global Variable        ${sic}
    ${sicdescription}=         Set Variable                My Description
    Set Global Variable        ${sicdescription}

    ${noofattorneys}=          Set Variable                5
    Set Global Variable        ${noofattorneys}

    ${totalcle}=               Set Variable                3534
    Set Global Variable        ${totalcle}
    ${previousaccountname}=    Set Variable                Nathan123
    Set Global Variable        ${previousaccountname}
    ${accrecordtype}=          Set Variable                Business
    Set Global Variable        ${accrecordtype}
    ${parentaccount}=          Set Variable                SHRADDHA Test
    Set Global Variable        ${parentaccount}
    ${phone}=                  Phone Number
    Set Global Variable        ${phone}
    ${rev}=                    Generate Random String      6                           123456789
    Set Global Variable        ${rev}

    ${employee}=               Set Variable                4
    Set Global Variable        ${employee}

    ${billingaddress}=         Set Variable                902 Alabama
    Set Global Variable        ${billingaddress}

    Log To Console             ------ Global Variabled For Account Set Successfully -------

    VerifyText                 Account Name
    TypeText                   Account Name                ${uniqueName}
    TypeText                   Website                     ${random_email}
    TypeText                   SIC Code                    ${sic}
    TypeText                   SIC Description             ${sicdescription}
    TypeText                   Number of Attorneys         ${noofattorneys}
    TypeText                   Total CLE                   ${totalcle}
    TypeText                   Previous Account Name       ${previousaccountname}
    #VerifyField               Account Owner               Copado-LGO Automation-User
    VerifyField                Account Record Type         ${accrecordtype}
    #ComboBox                  Parent Account              ${parentaccount}            delay=2s
    TypeText                   //input[@placeholder\='Search Accounts...']             SHRADDHA Test
    Sleep                      5s
    # ClickElement             (//li[@role\='presentation'])[1]
    ClickElement               (//lightning-base-combobox-item[@data-value\='actionAdvancedSearch']/parent::div//li)[1]

    TypeText                   Phone                       ${phone}

    TypeText                   Total Revenues              ${rev}
    TypeText                   Employees                   ${employee}
    TypeText                   Billing Address             ${billingaddress}
    ClickText                  902 Alabama Drive
    ClickText                  Mailing same as Billing address?
    ClickText                  Cancel                      partial_match=false
    UseModal                   Off
    Log To Console             ------ Cancel Clicked Successfully -------



Follow Edit and Delete Account Click
    #Author=Amol
    [Tags]                     Account
    Home
    ClickText                  Accounts
    VerifyText                 Recently Viewed             anchor=span
    ClickElement               //a[contains(@href, '/lightning/r/')][1]
    VerifyText                 Follow
    ClickText                  Follow
    Log To Console             ------ Follow Clicked Successfully -------
    Editing the Account
    Log To Console             ------ Editing the Account Successfully -------
    Delete Account Click
    Log To Console             ------ Account Deleted Successfully -------


Generate Dynamic Address

    ${random_street}=          Evaluate                    random.choice(["1200 Alabama Drive VA","1200 Alabama Drive NC","234 Greene Avenue MB", "333, S. Figueroa Street, Los Angeles","500, Post Street (Mason Street), San francisco."," 125 Music Mountain Drive, Pigeon Forge, TN 37863","2341 Collins Ave, Miami Beach, FL 33139","3654 S Lindbergh Blvd, Saint Louis, MO 63127-1204","351 Pitkin St, East Hartford, CT 06108"," 1 Newport Dr, Bar Harbor, Mount Desert Island, ME 04609-1898"])    modules=random
    Set Global Variable        ${billingaddressBS}         ${random_street}
    ${random_state}=           Evaluate                    random.choice(["Arizona", "California", "Texas", "Connecticut", "Alaska"])
    Set Global Variable        ${billingaddressState}      ${random_state}

    IF                         "${billingaddressState}" == "Arizona"
        ${ZipCode}=            Set Variable                86313
        Set Global Variable    ${ZipCodeU}                 ${ZipCode}
    ELSE IF                    "${billingaddressState}" == "California"
        ${ZipCode}=            Set Variable                90002
        Set Global Variable    ${ZipCodeU}                 ${ZipCode}
    ELSE IF                    "${billingaddressState}" == "Texas"
        ${ZipCode}=            Set Variable                75001
        Set Global Variable    ${ZipCodeU}                 ${ZipCode}
    ELSE IF                    "${billingaddressState}" == "Connecticut"
        ${ZipCode}=            Set Variable                06108
        Set Global Variable    ${ZipCodeU}                 ${ZipCode}
    ELSE IF                    "${billingaddressState}" == "Alaska"
        ${ZipCode}=            Set Variable                99505
        Set Global Variable    ${ZipCodeU}                 ${ZipCode}
    END