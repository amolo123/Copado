*** Settings ***
Library                      QWeb
Library                      QForce
#Library                     QVision
Library                      FakerLibrary
Library                      String
Library                      BuiltIn
Library                      DateTime
Resource                     ../resources/common.robot

Library                      ../libraries/MailLib.py     ${tenant_id}                ${client_id_mail}    ${client_secret_mail}

Library                      ${CURDIR}/../libraries/graph.py
Resource                     ${CURDIR}/../resources/graph.resource


*** Keywords ***

Validate Attributes
    #Author=Amol
    [tags]                   Underwriting

    VerifyAttribute          //label[text()\='DRI Status']/parent::div//button       type                 button
    VerifyAttribute          //label[text()\='Total Defense AOP%']/parent::div//input                     type                     text
    VerifyAttribute          //label[text()\='Level of Coverage']/parent::div//button                     type                     button
    VerifyAttribute          //label[text()\='Number of Attorneys (if applicable)']/parent::div//input    type                     text
    VerifyAttribute          //span[text()\='Individuals - All Other']/parent::*//input                   max                      100
    VerifyAttribute          //span[text()\='Individuals - High Net Worth (>$10M assets)']/parent::*//input                        max    100
    VerifyAttribute          //span[text()\='Small Private Companies (<$100M revenues)']/parent::*//input                          max    100
    VerifyAttribute          //span[text()\='Large Private Companies (>$100M revenues)']/parent::*//input                          max    100
    VerifyAttribute          //span[text()\='Small Public Companies (<$100M revenues)']/parent::*//input                           max    100
    VerifyAttribute          //span[text()\='Large Public Companies (>$100M revenues)']/parent::*//input                           max    100
    VerifyAttribute          //span[text()\='Government or Public Institutions']/parent::*//input         max                      100
    VerifyAttribute          //span[text()\='Non Profit Organizations or Charities']/parent::*//input     max                      100
    VerifyAttribute          //span[text()\='Other']/parent::*//input                max                  100
    VerifyAttribute          //span[text()\='Years Continuously Insured for Professional Liability']/parent::*//input              type    text
    #                        VerifyAttribute             (//span[text()\='Y']/parent::*/parent::span/input)[1]                     part    radio
    #                        VerifyAttribute             (//span[text()='N']/parent::*/parent::span/input)[1]                      part    radio
    #                        VerifyAttribute             (//span[text()\='Y']/parent::*/parent::span/input)[2]                     part    radio
    #                        VerifyAttribute             (//span[text()\='N']/parent::*/parent::span/input)[2]                     part    radio
    VerifyCheckbox           //span[text()\='Bar Complaints/Disciplinary Actions']/parent::*/parent::*
    VerifyCheckbox           //span[text()\='Claims/Suits']/parent::*/parent::*
    VerifyAttribute          //label[text()\='Loss Ratio']/parent::*//input          type                 text

    Log To Console           ------Attributes Validated Successfully-------




Verify Underwriting Analysis Page Elements
    #Author=Amol
    [tags]                   Underwriting
    VerifyText               Total Percentage:
    VerifyText               Area of Practice
    VerifyText               DRI Status
    VerifyText               Total Defense AOP%
    VerifyText               Level of Coverage
    VerifyText               Number of Attorneys (if applicable)
    VerifyText               Individuals - All Other
    VerifyText               Individuals - High Net Worth (>$10M assets)
    VerifyText               Small Private Companies (<$100M revenues)
    VerifyText               Large Private Companies (>$100M revenues)
    VerifyText               Small Public Companies (<$100M revenues)
    VerifyText               Large Public Companies (>$100M revenues)
    VerifyText               Government or Public Institutions
    VerifyText               Non Profit Organizations or Charities
    VerifyText               Other
    VerifyText               Years Continuously Insured for Professional Liability
    VerifyText               Coverage Gaps
    VerifyText               Declined/Cancelled/Non-Renewed
    VerifyText               Predecessor Firms
    VerifyText               Litigation History
    VerifyText               Bar Complaints/Disciplinary Actions
    VerifyText               Claims/Suits
    VerifyText               Loss Ratio
    VerifyText               Subjectivities
    VerifyText               Underwriting Comments (if applicable):
    Log To Console           ------Page Elements Validated Successfully-------




Add Area Of Practice
    #Author=Amol
    [tags]                   Underwriting
    ClickElement             (//button[@title\='Add Area of Practice'])
    UseModal                 On
    VerifyText               Area of Practice Description                            timeout=10s
    TypeText                 Admiralty-Defense           100
    ClickText                (//button[text()\='Add'])
    Sleep                    3s
    VerifyText               Success               timeout=30s
    Log To Console           ------Area Of Practice Added Successfully-------



Add Details In Underwriter Analysis Tab
    #Author=Amol
    [tags]                   Underwriting

    ClickElement             //button[@name\='DRI_Status__c']
    ClickText                DRI                         partial_match=False
    TypeText                 Years Continuously Insured for Professional Liability                        3
    ClickElement             //span[text()\='Level of Coverage']/parent::slot//button
    ClickText                Specified Attorneys         partial_match=False
    TypeText                 Number of Attorneys (if applicable)                     2
    ClickText                Y                           anchor=Coverage Gaps
    ClickText                Y                           anchor=Declined/Cancelled/Non-Renewed
    TypeText                 Predecessor Firms           Test Info 123
    ClickElement             (//span[text()\='Litigation History']//ancestor::lightning-accordion-section//button)[3]
    TypeText                 Enter Claim Matter          Test Claim
    ClickElement             //button[@name\='Severity']
    ClickText                Minimal
    TypeText                 Number of Lawyers           2
    ClickText                Bar Complaints/Disciplinary Actions
    ClickText                Claims/Suits
    TypeText                 Losses                      2
    TypeText                 Loss Ratio                  3
    ClickElement             //button[@title\='Add Subjectivities']
    UseModal                 On
    VerifyText               Subjectivities
    ClickElement             //th[@data-label\='Amend the Area of Practice grid to equal 100%']/parent::tr/td
    ClickElement             //th[@data-label\='Claim Supplement']/parent::tr/td
    ClickText                Add                         partial_match=False
    TypeText                 Comments                    Test Data
    ClickText                Save                        anchor=Qualify Submission
    ClickText                Qualify Submission          anchor=Save
    VerifyText               Quote Console               timeout=55s
    Log To Console           ------Details Added Successfully-------



Verify Area Of Practice
    #Author=Amol
    [tags]                   Underwriting
    [Arguments]              ${AOP}
    ClickElement             (//button[@title\='Add Area of Practice'])
    UseModal                 On

    Import Variables         ${CURDIR}/Statevariables.py                             ${AOP}
    Log To Console           ${CURDIR}

    FOR                      ${index}                    IN RANGE                    ${amounts}
        Log                  ${index}                    # 0-9
        ${rownum}=           Evaluate                    ${index}+1

        Log To Console       ${list}[${index}]
        UseTable             Area of Practice Description
        ${text}=             GetText                     //div[@title\='${list}[${index}]']
        Log To Console       ${text}
        IF                   '${list}[${index}]'=='${text}'
            Log To Console                               Success
        ELSE
            FAIL
        END
    END
    Log To Console           ------AOP List Validated Successfully-------



Verify AOP Search Functionality
    #Author=Amol Gaymukhe
    [Documentation]          Search Of AOP
    [Tags]                   search
    [Arguments]              ${AOPS}

    Import Variables         ${CURDIR}/Statevariables.py                             ${AOPS}
    Log To Console           ${CURDIR}

    ${index}=                Set Variable                0
    Log To Console           ${index}
    FOR                      ${index}                    IN RANGE                    ${amounts}
        Log                  ${index}                    # 0-9
        ${rownum}=           Evaluate                    ${index}+1

        Log To Console       ${list}[${index}]
        ClickElement         //input[@placeholder\='Search...']
        TypeText             //input[@placeholder\='Search...']                      ${list}[${index}]
        #PressKey            //input[@placeholder\='Search...']                      {ENTER}
        ClickElement         //span[text()\='${list}[${index}]']
        UseTable             Area of Practice Description
        ${text}=             GetText                     //div[@title\='${list}[${index}]']
        Log To Console       ${text}
        IF                   '${list}[${index}]'=='${text}'
            Log To Console                               Success
        ELSE
            FAIL
        END
        Log To Console       ${rownum}
        ClickElement         //span[@part\='pill']//button
        Sleep                2s
        #PressKey            //input[@placeholder\='Search...']                      {CONTROL + A + DELETE}
    END
    Log To Console           ------AOP List With Search functionality Validated Successfully-------



Add Litigation History On Underwriter Analysis Page
    #Author=Amol Gaymukhe
    [Documentation]          Add Litigation History
    [Tags]                   add
    ScrollText               Litigation History
    ClickElement             (//span[text()\='Litigation History']//ancestor::lightning-accordion-section//button)[3]
    #ClickElement            //button[@title\='']/parent::lightning-button-icon
    TypeText                 Enter Claim Matter          Test Claim
    ClickElement             //button[@name\='Severity']
    ClickText                Minimal
    TypeText                 Number of Lawyers           2
    ClickText                Bar Complaints/Disciplinary Actions
    ClickText                Claims/Suits
    TypeText                 Losses                      2
    TypeText                 Loss Ratio                  3
    ClickElement             (//button[@title\='Save'])                              anchor=Litigation History
    Log To Console           ------Litigation History added Successfully-------




Verify Litigation History after Renewal
    ClickText                Underwriting Analysis
    ${lit_history}=          GetInputValue               //input[@name\='Enter Claim Matter']
    Log To Console           ${lit_history}
    IF                       '${lit_history}' == 'Test Claim'
        Log To Console       Success.....Litigation History after renewal verified
    ELSE
        Fail
    END

Add Subjectivity On Underwriter Analysis Page
    #Author=Amol Gaymukhe
    [Documentation]          Add Subjectivity
    [Tags]                   add

    Expand Subjectivities
    ClickElement             //button[@title\='Add Subjectivities']
    UseModal                 On
    ClickElement             (//table//span[@part\='indicator'])[1]
    ClickElement             (//table//span[@part\='indicator'])[2]
    ClickElement             (//table//span[@part\='indicator'])[3]
    Sleep                    2s
    ClickElement             //button[@title\='Add']
    Log To Console           ------ Subjectivity Added Successfully ------



Add Closed Subjectivity On Underwriter Analysis Page
    #Author=Amol Gaymukhe
    [Documentation]          Add Subjectivity
    [Tags]                   add

    ClickElement             //button[@title\='Add Subjectivities']
    UseModal                 On
    ClickElement             (//table//span[@part\='indicator'])[4]
    ClickElement             (//table//span[@part\='indicator'])[5]
    ClickElement             (//table//span[@part\='indicator'])[6]

    ClickElement             //button[@title\='Add']

    UseModal                 Off
    Sleep                    4s
    ScrollTo                 (//label[text()\='Status'])[6]/parent::div
    ClickElement             (//label[text()\='Status'])[4]/parent::div

    ClickElement             (//span[@title\='Completed'])[1]

    ClickElement             (//label[text()\='Status'])[5]/parent::div
    ClickElement             (//span[@title\='Completed'])[2]

    ClickElement             (//label[text()\='Status'])[6]/parent::div
    ClickElement             (//span[@title\='Completed'])[3]


Input Data in Predecessor Firm On Underwriter Analysis
    #Author=Amol Gaymukhe
    [Documentation]          Underwriting Analysis
    [Tags]                   add
    ClickText                Underwriting Analysis
    Sleep                    5s
    TypeText                 Predecessor Firm            Test Predecessor Data
    Log To Console           --------Input predecessor data successfull-----




    # Send Mail On Submission Page
    #                        #Author=Amol
    #                        [Documentation]             Sending Mail From Policy Page
    #                        [Tags]                      Validating
    #                        [Arguments]                 ${Mailtype}
    #                        ClickText                   Send Mail
    #                        UseModal                    On
    #                        ClickElement                //select

    #                        # #ClickText                Binder Transmittal
    #                        IF                          "${Mailtype}"=="Additional Information Request"
    #                        DropDown                    Select a Template:          [[1]]
    #                        ELSE IF                     "${Mailtype}"=="BOR Acknowledgement Midterm"
    #                        DropDown                    Select a Template:          [[2]]
    #                        ELSE IF                     "${Mailtype}"=="BOR Acknowledgement New/Renewal"
    #                        DropDown                    Select a Template:          [[3]]
    #                        ELSE IF                     "${Mailtype}"=="BOR Countermanding"
    #                        DropDown                    Select a Template:          [[4]]
    #                        ELSE IF                     "${Mailtype}"=="Claim Verification"
    #                        DropDown                    Select a Template:          [[5]]
    #                        ELSE IF                     "${Mailtype}"=="Coverage Expired – File Closed Transmittal"
    #                        DropDown                    Select a Template:          [[6]]
    #                        ELSE IF                     "${Mailtype}"=="Declination"
    #                        DropDown                    Select a Template:          [[7]]
    #                        ELSE IF                     "${Mailtype}"=="Duplicate Submission – Already Declined"
    #                        DropDown                    Select a Template:          [[8]]
    #                        ELSE IF                     "${Mailtype}"=="Duplicate Submission – BOR Requested"
    #                        DropDown                    Select a Template:          [[9]]
    #                        ELSE IF                     "${Mailtype}"=="Duplicate Submission – Inner Circle"
    #                        DropDown                    Select a Template:          [[10]]
    #                        ELSE IF                     "${Mailtype}"=="Indication Transmittal"
    #                        DropDown                    Select a Template:          [[11]]
    #                        ELSE IF                     "${Mailtype}"=="Non-Renewal Transmittal"
    #                        DropDown                    Select a Template:          [[12]]
    #                        ELSE IF                     "${Mailtype}"=="Not Quoted - Pricing"
    #                        DropDown                    Select a Template:          [[13]]
    #                        ELSE IF                     "${Mailtype}"=="Quote Transmittal"
    #                        DropDown                    Select a Template:          [[14]]
    #                        ELSE IF                     "${Mailtype}"=="Streamline Proposal Follow Up Transmittal"
    #                        DropDown                    Select a Template:          [[15]]
    #                        END
    #                        ${subjectline}=             GetInputValue               Subject:             timeout=45s
    #                        Log To Console              ${subjectline}
    #                        Set Global Variable         ${subjectline}
    #                        ClickText                   Send                        anchor=Cancel
    #                        Sleep                       40s
    #                        ${body}=                    Get Email Content           ${client_id_mail}    ${client_secret_mail}    ${tenant_id}    QA.Testing.Inbox@innovisk.global    ${subjectline}
    #                        Log To Console              ${body}
    #                        Set Global Variable         ${body}


    # Verify Email Contains same limit and deductibles
    #                        Should Contain              ${body}                     Limit of Liability: Each Claim ($1000000), Aggregate ($1000000), Limit Type (Defense Expenses Within Limit). Deductible: Each Claim ($1000), Aggregate (None), Deductible Type (Damages and Defense Expenses). This would be approximately ($2427.00).











