*** Settings ***
Library                        QWeb
Library                        QForce
#Library                       QVision
Library                        FakerLibrary
Library                        String
Library                        BuiltIn
Library                        DateTime
Resource                       ../resources/common.robot
Resource                       ../PageObjects/PageObjects_Account.robot
Resource                       ../PageObjects/PageObjects_CompareAndRateQuote.robot


Library                        ../libraries/MailLib.py     ${tenant_id}                ${client_id_mail}           ${client_secret_mail}

Library                        ${CURDIR}/../libraries/graph.py
Resource                       ${CURDIR}/../resources/graph.resource


*** Keywords ***

Click Quote On Policy Page and Select Quote
    #Author=Amol
    [Documentation]            Clicking Quote Screen Elements
    [Tags]                     Validating

    ClickElement               //li[@title\='Quote']
    Sleep                      5s
    ClickElement               (//records-hoverable-link//a)[last()]                   timeout=10s
    #ClickText                 ${uniqueName} 1             timeout=10s

Validate Policy Screen Static Elements
    #Author=Amol
    [Documentation]            Validating Quote Screen Elements
    [Tags]                     Validating

    VerifyText                 Policy Number
    VerifyText                 Policy Status
    VerifyText                 Total Premium
    VerifyText                 Effective Date
    VerifyText                 Expiration Date
    VerifyText                 Policy Name
    VerifyText                 Parent Policy
    VerifyText                 Policy Status
    VerifyText                 Effective Date
    VerifyText                 Expiration Date
    VerifyText                 Cancellation Date
    VerifyText                 Cancellation Reason
    VerifyText                 Reinstatement Date
    VerifyText                 Account
    VerifyText                 Product Name
    VerifyText                 Total Premium
    VerifyText                 Initial Premium
    VerifyText                 Net Endorsement
    VerifyText                 Owner
    VerifyText                 Issued Date
    VerifyText                 Issued By
    VerifyText                 Issued Flag
    VerifyText                 Currency
    VerifyText                 Suspense Applied
    VerifyText                 Last Cyber Supplement Received

    VerifyText                 Suspense Comments
    VerifyText                 Streamlined Ineligible
    VerifyText                 Streamlined Ineligible Comments
    VerifyText                 ERP Type
    VerifyText                 ERP Term
    VerifyText                 Azure ID
    VerifyText                 Last Modified By
    VerifyText                 Created By
    VerifyText                 External Id

    VerifyText                 Policy Document
    VerifyText                 View Document
    VerifyText                 Send Mail
    VerifyText                 Change Policy
    VerifyText                 Renewal

    VerifyText                 Details
    VerifyText                 Documents
    VerifyText                 Submissions
    VerifyText                 Quote
    VerifyText                 Emails
    VerifyText                 G Trac


Validate Policy Screen Dynamic Elements
    #Author=Amol
    [Documentation]            Validating Dynamic Elements
    [Tags]                     Validating

    VerifyField                Policy Status               Bound
    ${Account_name}=           GetFieldValue               Account
    Log To Console             ${Account_name}
    Set Global Variable        ${Account_name}
    VerifyField                Product Name                LawyerGuard
    ${cur_date}=               Get Current Date            increment=5 day             result_format=%-m/%-d/%Y
    ${xpiration_Date}=         Get Current Date            increment=370 day           result_format=%-m/%-d/%Y
    VerifyField                Effective Date              ${cur_date}
    VerifyField                Expiration Date             ${xpiration_Date}
    VerifyField                Currency                    USD - U.S. Dollar
    ${PolicyName}=             GetFieldValue               Policy Name
    Log To Console             ${PolicyName}
    Set Global Variable        ${PolicyName}
    ${Policy_Number}=          GetFieldValue               Policy Number
    Log To Console             ${Policy_Number}
    Set Global Variable        ${Policy_Number}

Verify Policy Screen Dynamic Elements SL 
    #Author=Shraddha
    [Documentation]            Validating Dynamic Elements
    [Tags]                     SL

    VerifyField                Policy Status               Bound
    ${Account_name}=           GetFieldValue               Account
    Log To Console             ${Account_name}
    Set Global Variable        ${Account_name}
    VerifyField                Product Name                LawyerGuard_SL
    ${cur_date}=               Get Current Date            increment=5 day             result_format=%-m/%-d/%Y
    ${xpiration_Date}=         Get Current Date            increment=370 day           result_format=%-m/%-d/%Y
    VerifyField                Effective Date              ${cur_date}
    VerifyField                Expiration Date             ${xpiration_Date}
    VerifyField                Currency                    USD - U.S. Dollar

    ${policy_number}=          GetFieldValue               Policy Number
    ${policy_name}=            GetFieldValue               Policy Name

    IF                         "${policy_number}"=="${EMPTY}" and "${policy_name}"=="${EMPTY}"
        Fail
    ELSE
        Log To Console         Success Pass
    END

Send Mail On Policy Page
    #Author=Amol
    [Documentation]            Sending Mail From Policy Page
    [Tags]                     Validating
    [Arguments]                ${Mailtype}
    ClickText                  Send Mail
    UseModal                   On
    ClickElement               //select
    #ClickText                 Binder Transmittal
    IF                         "${Mailtype}"=="Binder Transmittal"
        DropDown               Select a Template:          [[1]]
    ELSE IF                    "${Mailtype}"=="Endorsement Transmittal"
        DropDown               Select a Template:          [[2]]
    ELSE IF                    "${Mailtype}"=="Policy Transmittal"
        DropDown               Select a Template:          [[3]]
    ELSE
        DropDown               Select a Template:          [[4]]
    END
    Log To Console             ------------Mailtype Selected---------
    ${subjectline}=            GetInputValue               Subject:                    timeout=45s
    Log To Console             ${subjectline}
    Set Global Variable        ${subjectline}
    ClickText                  Send                        anchor=Cancel
    Log To Console             ----------Subjectline Saved and sent----------
    Sleep                      40s
    ${body}=                   Get Email Content           ${client_id_mail}           ${client_secret_mail}       ${tenant_id}             QA.Testing.Inbox@innovisk.global              ${subjectline}
    Log To Console             ----------Mail Validated----------


Click On Renewal
    #Author=Amol
    [Documentation]            Opting For Renewal
    [Tags]                     Renewal

    ClickText                  Renewal


Click On Submissions            
    #Author=Amol
    [Documentation]            Opting For Renewal
    [Tags]                     Renewal
    ClickText                  Submissions                 anchor=Documents


Click Quote On Policy Page
    #Author=Amol
    [Documentation]            Clicking Quote Screen Elements
    [Tags]                     Validating
    ClickElement               //li[@title\='Quote']
    Log To Console             ----- On Quote --------


Click Renewal Submission
    #Author=Amol
    [Documentation]            Opting For Renewal
    [Tags]                     Renewal
    ClickText                  ${uniquename}               4
    ClickText                  Compare & Rate Quotes
    Click On Rate



Change Policy Functionality    
    #Author=Amol
    [Documentation]            Opting For Amendment
    [Tags]                     Renewal
    [Arguments]                ${changetypeone}

    ClickText                  Change Policy
    UseModal                   On
    DropDown                   Endorsement Type            ${changetypeone}
    Log TO Console             -----------Change Policy Opened-------------


Select Change Endorsement Input
    #Author=Amol
    [Documentation]            Opting For Amendment
    [Tags]                     Renewal

    ClickText                  Endorsement Effective Date                              timeout=55s
    ${cur_data}=               Get Current Date            result_format=%b %-d, %Y
    ${comp_effective_date}=    Get Current Date            increment=7 day             result_format=%b %-d, %Y
    Log To Console             ${comp_effective_date}
    TypeText                   Endorsement Effective Date*                             ${comp_effective_date}
    # ${subdate1}=             Get Substring               ${cur_data}                 4                           -6
    # Log To Console           ${subdate1}
    # ClickElement             //a[@title\='Go to next month']
    # ClickElement             //span[text()\='${subdate1}']                           timeout=10s
    ClickText                  Confirm                     anchor=Back
    Log To Console             --------- Amendment Popup Successful ------------
    Sleep                      10s

Select Change Name Input
    #Author=Amol
    [Documentation]            Opting For Amendment
    [Tags]                     Renewal
    TypeText                   Account Name                ${uniquename}-Test

    ClickText                  Effective Date              timeout=55s
    ${cur_data}=               Get Current Date            result_format=%b %-d, %Y
    # ${comp_effective_date}=                              Get Current Date            increment=5 day             result_format=%b %-d, %Y
    # Log To Console           ${comp_effective_date}
    ${subdate1}=               Get Substring               ${cur_data}                 4                           -6
    Log To Console             ${subdate1}
    ClickElement               //a[@title\='Go to next month']
    ClickElement               //span[text()\='${subdate1}']                           timeout=10s
    ClickText                  Ok                          anchor=Cancel

Select BOR Input

    ClickText                  Broker Contact
    PressKey                   Broker Contact              {CONTROL + A + DELETE}
    TypeText                   Broker Contact              Shraddha Kulkarni

    ClickElement               (//div[@role\='listbox']//li)[1]
    ClickText                  Confirm                     anchor=Back
    VerifyText                 Success                     anchor=Broker record has been Updated


Select Change Amendment Input
    #Author=Amol
    [Documentation]            Opting For Amendment
    [Tags]                     Renewal
    ClickText                  Endorsement Effective Date                              timeout=55s
    ${cur_data}=               Get Current Date            result_format=%b %-d, %Y
    ${comp_effective_date}=    Get Current Date            increment=7 day             result_format=%b %-d, %Y
    Log To Console             ${comp_effective_date}
    TypeText                   Endorsement Effective Date*                             ${comp_effective_date}
    # ${subdate1}=             Get Substring               ${cur_data}                 4                           -6
    # Log To Console           ${subdate1}
    # ClickElement             //a[@title\='Go to next month']
    # ClickElement             //span[text()\='${subdate1}']                           timeout=10s
    ClickText                  Confirm                     anchor=Back
    Log To Console             --------- Amendment Popup Successful ------------
    Sleep                      10s


Select Change Address Input
    #Author=Amol
    [Documentation]            Opting For Amendment
    [Tags]                     Renewal
    TypeText                   Street                      902 Alabama Drive
    TypeText                   City                        Richmond
    ClickText                  Effective Date              timeout=55s
    ${cur_data}=               Get Current Date            result_format=%b %-d, %Y
    # ${comp_effective_date}=                              Get Current Date            increment=5 day             result_format=%b %-d, %Y
    # Log To Console           ${comp_effective_date}
    ${subdate1}=               Get Substring               ${cur_data}                 4                           -6
    Log To Console             ${subdate1}
    ClickElement               //a[@title\='Go to next month']
    ClickElement               //span[text()\='${subdate1}']                           timeout=10s
    ClickText                  Ok                          anchor=Cancel
    VerifyText                 Success                     anchor=Account has been Updated                         timeout=45s




Select Change Extension Input

    ClickText                  Endorsement Expiration Date                             timeout=55s
    ${cur_data}=               Get Current Date            result_format=%b %-d, %Y
    Log To Console             ${cur_data}
    ${subdate1}=               Get Substring               ${cur_data}                 4                           -6
    Log To Console             ${subdate1}
    ClickElement               //a[@title\='Go to next month']
    ClickElement               //span[text()\='${subdate1}']
    ClickText                  Confirm                     anchor=Back
    Sleep                      20s
    Log To Console             ----- Change Extension Input Successfull ------

Select Change Midterm Cancellation Input
    #Author=Amol
    [Documentation]            Opting For Amendment
    [Tags]                     Renewal

    ClickText                  Cancellation Date           timeout=55s
    ${cur_data}=               Get Current Date            result_format=%b %-d, %Y
    ${comp_effective_date}=    Get Current Date            increment=5 day             result_format=%b %-d, %Y
    Log To Console             ${comp_effective_date}
    ${subdate1}=               Get Substring               ${comp_effective_date}      4                           -6
    Log To Console             ${subdate1}
    ClickElement               //a[@title\='Go to next month']
    ClickElement               //span[text()\='${subdate1}']
    ClickText                  Confirm                     anchor=Back
    Sleep                      20s
    Log To Console             ----- Midterm Cancellation Input Success -------

Select Change ERP date Input
    #Author=Amol
    [Documentation]            Opting For Amendment
    [Tags]                     Renewal
    TypeText                   Number of ERP Attorneys     3

    ClickText                  Endorsement Effective Date                              timeout=55s
    ${cur_data}=               Get Current Date            result_format=%b %-d, %Y
    ${comp_effective_date}=    Get Current Date            increment=5 day             result_format=%b %-d, %Y
    Log To Console             ${comp_effective_date}
    ${subdate1}=               Get Substring               ${comp_effective_date}      4                           -6
    Log To Console             ${subdate1}
    ClickElement               //a[@title\='Go to next month']
    ClickElement               //span[text()\='${subdate1}']
    ClickText                  Confirm                     anchor=Cancel
    Sleep                      20s
    Log To console             ----- ERP Input Successfull -----

Select flat cancellation Input
    ClickText                  Cancellation Date           timeout=55s
    ${cur_data}=               Get Current Date            result_format=%b %-d, %Y
    ${comp_effective_date}=    Get Current Date            increment=5 day             result_format=%b %-d, %Y
    Log To Console             ${comp_effective_date}
    TypeText                   Cancellation Date           ${comp_effective_date}
    ClickText                  Confirm                     anchor=Back
    Sleep                      20s
    Log To Console             ----- Flat Cancellation Input Success -------
Select Change Cancel & Replacement Input

    #Author=Amol
    [Documentation]            Cancel & Replacemeent
    [Tags]                     Cancel                      regression
    UseModal                   On
    ClickElement               //span[text()\='Select Item 1']/ancestor::span
    ClickText                  Confirm                     anchor=Back
    Sleep                      3s
    VerifyText                 Confirmation
    ClickText                  Confirm                     anchor=Cancel



Send Binder Transmittal Mail And Check Outstanding Subjectivities 
    #Author=Amol
    [Documentation]            Sending Mail From Policy Page
    [Tags]                     Validating

    ClickText                  Send Mail
    UseModal                   On
    ClickElement               //select
    #ClickElement              //option[@label\='Binder Transmittal']
    #ClickText                 Binder Transmittal
    DropDown                   Select a Template:          00X6g000000hbAjEAI
    DropDown                   Select a Template:          00X6g000000hbAjEAI
    DropDown                   Select a Template:          00X6g000000hbAjEAI
    DropDown                   Select a Template:          00X6g000000hbAjEAI
    Sleep                      5s
    ScrollTo                   Body
    VerifyText                 Annual hours for Of Counsel, Contractors, and/or Part-Time attorneys
    #VerifyText                 Amend the Area of Practice grid to equal 100%
    #VerifyText                 Alternative higher limit offered assumes no exposure changes
    VerifyText                 Amend the Area of Practice grid to equal 100%
    VerifyText                 Alternative higher limit offered assumes no exposure changes
    #VerifyText                 Address and/or Firm Name on Application / Letterhead differ. Please confirm.
    ${subjectline}=            GetInputValue               Subject:                    timeout=45s
    Log To Console             ${subjectline}
    Set Global Variable        ${subjectline}
    #ClickText                 Send                        anchor=Cancel
    Log To Console             ----------Subjectline Saved and sent----------
    #Sleep                     40s
    #${body}=                  Get Email Content           ${client_id_mail}           ${client_secret_mail}       ${tenant_id}             QA.Testing.Inbox@innovisk.global              ${subjectline}
    ClickText                  Send                        anchor=Cancel
    #Should Contain            ${emailbody}                Answer the following question on the supplement
    #Should Contain            ${emailbody}                Amend the Area of Practice grid to equal 100%


Verify Coverage Cancel replace on policy quote
    #Author=Amol
    [Documentation]            Sending Mail From Policy Page
    [Tags]                     Validating
    ClickText                  Quote                       anchor=Submissions
    VerifyText                 Cancelled
    VerifyText                 Correction
    VerifyText                 Bound                       anchor=New Business
    #VerifyText                USD ${changed_premium}




Generate Document On Policy Page
    #Author=Amol
    [Documentation]            Generating document on Policy Page
    [Tags]                     Validating
    [Arguments]                ${document_name}
    ClickText                  Policy Document
    UseModal                   On
    Sleep                      5s
    ClickElement               //select
    DropDown                   Document Type               ${document_name}
    Sleep                      9s
    ClickText                  Generate                    anchor=Cancel
    VerifyText                 Success                     anchor=Document has been generated sucessfully!         timeout=100s




Create a Renewal Flow
    #Author=Renewal
    [Documentation]            Generating document on Policy Page
    [Tags]                     Validating

    ${Renewal_text}=           IsElement                   //button[text()\='Renewal']
    Log To Console             ${Renewal_text}
    IF                         ${Renewal_text} == True
        ClickElement           //button[text()\='Renewal']
    ELSE

        ClickElement           //lightning-button-menu//button//lightning-primitive-icon[following-sibling::span[text()\='Show more actions']]
        Sleep                  2s
        ClickElement           //span[text()\='Renewal']
    END
    ClickText                  Submissions                 anchor=Policy
    ClickText                  ${uniqueName}               anchor=Renewal Submissions
    #ClickElement              (//records-hoverable-link//a)[first()]
    #Sleep                     30s
    #ClickElement              //lightning-primitive-cell-factory[@data-label\='Submission Name']
    Sleep                      10s
    ClickText                  Save                        timeout=35s
    Log To Console             -----Save Successfull------
    Sleep                      20s
    ClickText                  NEXT:Underwriter Analysis >
    VerifyText                 Area of Practice
    Log To Console             -----Moved To Underwriter Analysis Successfully------
    Sleep                      3s
    ClickText                  Qualify Submission          timeout=10s
    Sleep                      10s
    VerifyText                 Quote Console               timeout=30s
    Log To Console             -----Moved To Compare & Rate Quotes Successfully------
    Log To Console             ------ Renewal Flow Successfull ---------

Generate Document On Policy Page SL
    #Author=Amol
    [Documentation]            Generating document on Policy Page
    [Tags]                     Validating
    [Arguments]                ${document_name}
    ClickText                  Policy Document
    UseModal                   On
    Sleep                      5s
    ClickElement               //select
    DropDown                   Document Type               ${document_name}
    Sleep                      9s
    ClickText                  Generate                    anchor=Cancel
    VerifyText                 Success                     anchor=Document has been generated sucessfully!         timeout=100s



Verify Change ERP Functionality firm SL
    #Author=SHRADDHA
    [Documentation]            Opting For Firm
    [Tags]                     ERP
    [Arguments]                ${Erp_firm}

    ClickElement               Name Individual
    UseModal                   On
    DropDown                   ERP Type                    ${Erp_firm}
    Log TO Console             -----------Change Policy Opened-------------

Empty Directory command

    ${count}=                  Count Files In Directory    ${OUTPUT_DIR}
    Log To Console             ${count}
    @{downloads}=              List Files In Directory     ${OUTPUT_DIR}
    Log Many                   @{downloads}
    # ${count2}=               Count Files In Directory    ${downloads_folder}
    # Log To Console           ${count}
    ${bdir}=                   Empty Directory             ${OUTPUT_DIR}
    Sleep                      2s
    IF                         "${EXECDIR}"=="/home/executor/execution"
    # normal test run environment
        ${downloads_folder}=                               Set Variable                /home/executor/Downloads
        Log To Console         Folder set Regression
    ELSE                       # Live Testing environment
        ${downloads_folder}=                               Set Variable                /home/services/Downloads
        Log To Console         Folder set Live
    END
    Log To Console             If success
    Sleep                      5s
    #Get file name from download folder
    ${count}=                  Count Files In Directory    ${downloads_folder}
    Log To Console             ${count}
    ${cdir}=                   Empty Directory             ${downloads_folder}


Select Reinstatement Admitted
    #Author = Shraddha
    [Documentation]            Reinstatment Input

    ClickText                  Endorsement Effective Date                              timeout=55s
    ${cur_data}=               Get Current Date            result_format=%b %-d, %Y
    ${comp_effective_date}=    Get Current Date            increment=5 day             result_format=%b %-d, %Y
    Log To Console             ${comp_effective_date}
    ${subdate1}=               Get Substring               ${comp_effective_date}      4                           -6
    Log To Console             ${subdate1}
    ClickElement               //a[@title\='Go to next month']
    ClickElement               //span[text()\='${subdate1}']
    ClickText                  Confirm                     anchor=Cancel

 Renewal flow for upload attorney                             
    #Author=Rugveda
    [Tags]                     Validating

    ${Renewal_text}=           IsElement                   //button[text()\='Renewal']
    Log To Console             ${Renewal_text}
    IF                         ${Renewal_text} == True
        ClickElement           //button[text()\='Renewal']
    ELSE

        ClickElement           //lightning-button-menu//button//lightning-primitive-icon[following-sibling::span[text()\='Show more actions']]
        Sleep                  2s
        ClickElement           //span[text()\='Renewal']
    END
    ClickText                  Submissions                 anchor=Policy
    ClickText                  ${uniqueName}               anchor=Renewal Submissions
    #ClickElement              (//records-hoverable-link//a)[first()]
    #Sleep                     30s
    #ClickElement              //lightning-primitive-cell-factory[@data-label\='Submission Name']
    Sleep                      10s
    ClickText                  < PREVIOUS:Insured Info
    ClickElement               (//lightning-button-menu[@class\='slds-dropdown-trigger slds-dropdown-trigger_click'])[last()]
    ClickElement               (//lightning-button-menu[@class\='slds-dropdown-trigger slds-dropdown-trigger_click'])[last()]
    #ClickElement              ((//table)[1]//tbody//tr//lightning-button-menu[@class\='slds-dropdown-trigger slds-dropdown-trigger_click'])[1]
    #ClickElement              (//div[@class\="dt-outer-container"])[last()]//table//tbody//tr[1]//lightning-button-menu
    Sleep                      2s
    ClickElement               //span[text()\='Delete']/parent::a
    #Sleep                     2s

Import Attorneys
    #Author=Rugveda
    ClickText                  Attorney Import
    UseModal                   On
    UploadFile                 Upload Files                ${CURDIR}/../resources/ImportA.csv
    ${countActive}=            Get Element Count           //table//tbody//tr//th//span//div//lightning-base-formatted-text[text()\="Active"]
    Log To Console             The number of data with active status : ${countActive}
    Set Global Variable        ${countActive}
    ClickText                  Yes                         delay=3s

Compare Attorneys On Renewal
    #Author=Rugveda
    [Documentation]            Compare Attorneys

    ${ValueX}                  GetInputValue               Number Of Attorneys
    Set Global Variable        ${ValueX}

    # ${ValueY}                GetInputValue               Ratable Attorney

    IF                         int("${ValueX}") == int("${countActive}")

        Log To Console         Total No of attorneys(${ValueX})
    ELSE
        Fail
    END

Compare Attorneys On New Business
    #Author=Rugveda
    [Documentation]            Compare Attorneys

    ${ValueB}                  GetInputValue               Number Of Attorneys

    ${Valuec}                  GetInputValue               Ratable Attorney

    IF                         "${ValueB}"=="${ValueC}"

        Log To Console         success pass
    ELSE
        Fail
    END



