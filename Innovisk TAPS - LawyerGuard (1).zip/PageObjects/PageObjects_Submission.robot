*** Settings ***
Library               QWeb
Library               QForce
#Library              QVision
Library               FakerLibrary
Library               String
Library               BuiltIn
Library               DateTime
Resource              ../resources/common.robot




*** Keywords ***

Validate LaweyrGuard New submission Fields
    #Author=Amol
    [tags]            submission
    Home
    #ClickElement     //button[@class\='slds-button slds-show']
    RefreshPage
    ClickElement      //span[text()\='App Launcher']
    TypeText          //input[@placeholder\='Search apps and items...']    Lawyer
    ClickText         LawyerGuard
    RefreshPage
    Sleep             5s
    VerifyText        LawyerGuard                 anchor=Home
    VerifyText        New Submission
    VerifyText        Existing Submission
    VerifyText        Post Bind Endorsement
    # ClickText       Next                        anchor=What do you want to work on?
    #ClickElement     (//button[text()\='Next'])[1]                     anchor=What do you want to work on?
    Clicktext         Submissions                 anchor=Policies
    ClickElement      //a//span[text()\="New Submission"]
    UseModal          On
    VerifyText        New Submission
    VerifyText        Record Type
    ClickText         LawyerGuard                 anchor=Record Type
    VerifyText        Product
    ClickText         LawyerGuard                 anchor=Product
    ClickText         Next                        anchor=Cancel
    UseModal          Off
    Log To Console    ----- New Submission Fields Validated Successfully -----

Select LawyerGuard SL from product
    [Arguments]       ${Product}

    #Author=Shraddha T Patil
    [tags]            submission
    Home
    #ClickElement     //button[@class\='slds-button slds-show']
    ClickElement      //span[text()\='App Launcher']
    TypeText          //input[@placeholder\='Search apps and items...']    Lawyer
    ClickText         LawyerGuard
    VerifyText        LawyerGuard                 anchor=Home
    VerifyText        New Submission
    VerifyText        Existing Submission
    VerifyText        Post Bind Endorsement
    ClickText         Next

    UseModal          On
    VerifyText        New Submission
    VerifyText        Record Type
    ClickText         LawyerGuard                 anchor=Record Type
    VerifyText        Product
    ClickText         ${Product}                  anchor=Product
    ClickText         Next                        anchor=Cancel
    UseModal          Off
    Log To Console    ----- New Submission Fields Validated Successfully -----
Checking Cancel Button On New Submission
    #Author=Amol
    [tags]            submission
    Home
    ClickElement      //span[text()\='App Launcher']
    TypeText          //input[@placeholder\='Search apps and items...']    Lawyer
    ClickText         LawyerGuard
    VerifyText        LawyerGuard                 anchor=Home
    VerifyText        New Submission
    VerifyText        Existing Submission
    VerifyText        Post Bind Endorsement
    ClickText         Next

    UseModal          On
    VerifyText        New Submission
    VerifyText        Record Type
    ClickText         LawyerGuard                 anchor=Record Type
    VerifyText        Product
    ClickText         LawyerGuard                 anchor=Product
    ClickText         Cancel
    UseModal          Off
    Log To Console    ----- Cancel Button Validated Successfully -----

Checking Cancel Button On New Submission For SL
    #Author=Shraddha
    [Arguments]       ${Product}

    [tags]            submission
    Home
    ClickElement      //span[text()\='App Launcher']
    TypeText          //input[@placeholder\='Search apps and items...']    Lawyer
    ClickText         LawyerGuard
    VerifyText        LawyerGuard                 anchor=Home
    VerifyText        New Submission
    VerifyText        Existing Submission
    VerifyText        Post Bind Endorsement
    ClickText         Next

    UseModal          On
    VerifyText        New Submission
    VerifyText        Record Type
    ClickText         LawyerGuard                 anchor=Record Type
    VerifyText        Product
    ClickText         LawyerGuard                 anchor=Product
    ClickText         ${Product}                  anchor=Product
    ClickText         Cancel
    UseModal          Off
    Log To Console    ----- Cancel Button Validated Successfully -----


Checking Next Button On New Submission For SL
    #Author=Shraddha
    [Arguments]       ${Product}
    [tags]            submission
    Home
    ClickElement      //span[text()\='App Launcher']
    TypeText          //input[@placeholder\='Search apps and items...']    Lawyer
    ClickText         LawyerGuard
    VerifyText        LawyerGuard                 anchor=Home
    VerifyText        New Submission
    VerifyText        Existing Submission
    VerifyText        Post Bind Endorsement
    Sleep             10s
    ClickElement      //button[text()\="Next"]/parent::lightning-button    timeout=30s
    

    VerifyText        Record Type
    UseModal          On
    VerifyText        New Submission
    VerifyText        Record Type
    ClickText         LawyerGuard                 anchor=Record Type
    VerifyText        Product
    ClickText         LawyerGuard                 anchor=Product
    ClickText         ${Product}                  anchor=Product
    ClickText         Next                        anchor=Cancel
    UseModal          Off
    Log To Console    ----- Next Button Validated Successfully -----


Validate LaweyrGuard New submission Fields SL
    #Author=Shraddha
    [tags]            submission
    Home
    #ClickElement     //button[@class\='slds-button slds-show']
    ClickElement      //span[text()\='App Launcher']
    TypeText          //input[@placeholder\='Search apps and items...']    Lawyer
    ClickText         LawyerGuard
    VerifyText        LawyerGuard                 anchor=Home
    VerifyText        New Submission
    VerifyText        Existing Submission
    VerifyText        Post Bind Endorsement
    ClickText         Next

    UseModal          On
    VerifyText        New Submission
    VerifyText        Record Type
    ClickText         LawyerGuard                 anchor=Record Type
    VerifyText        Product
    ClickText         LawyerGuard_SL              anchor=Product
    ClickText         Next                        anchor=Cancel
    UseModal          Off
    Log To Console    ----- New Submission Fields Validated Successfully -----