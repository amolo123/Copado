*** Settings ***
Library                  QWeb
Library                  QForce
Library                  QVision
Library                  FakerLibrary
Library                  String
Library                  BuiltIn
Library                  DateTime

Resource                 PageObjects_Account.robot

*** Keywords ***

Open PDF in Chrome
    [Arguments]          ${uniqueName_T}             ${Doc_Name}
    Sleep                10s
    RefreshPage
    OpenWindow
    Go To                chrome://downloads
    ${date}=             Get Current Date            increment=5days    result_format=%-m-%-d-%Y
    #QVision.ClickText                               ACCOUNT SUMMARY - ${uniqueName_T}, ${date}.pdf
    QVision.ClickText    ${Doc_Name}                 index=1

    SwitchWindow         1
    RefreshPage
    SwitchWindow         3
    Sleep                5s