*** Settings ***
Library             QWeb
Library             QForce
#Library            QVision
Library             FakerLibrary
Library             String
Library             BuiltIn
Library             DateTime
Resource            ../../../resources/common.robot
Resource            ../PageObjects_Accounts.robot
Resource            ../PageObjects_Submissions.robot
Library             BuiltIn
Library             DateTime

*** Keywords ***

Verify Underwriter Analysis Page Elements
    # Author = Amol Gaymukhe
    [tags]          Insured Info
    VerifyText      Account                     partial_match=false
    VerifyText      Agency
    VerifyText      Underwriter                 partial_match=false
    VerifyText      Stage
    VerifyText      Effective Date
    VerifyText      Quoted Premium

    VerifyText      Industry Class
    VerifyText      Annual Revenues
    VerifyText      Prior acts coverage
    VerifyText      Service Classification

    VerifyText      Company Info
    VerifyText      Avg Staff Experience
    VerifyText      Written Training & Procedures
    VerifyText      Jurisdiction

    VerifyText      Contracts and Contractors
    VerifyText      Use of Independent Contractors
    VerifyText      % of Written Contracts Used
    VerifyText      Written Contracts Used
    VerifyText      Contracts Reviewed by Counsel

    VerifyText      Endorsements and Loss History
    VerifyText      Claim Free Credit
    VerifyText      Restrictive Endorsements
    VerifyText      Expansive Endorsements



Enter Data in Underwriter Analysis Page
    # Author = Amol Gaymukhe
    [tags]          Insured Info
    TypeText        //span[text()\='Annual Revenues']/parent::*/following::td//input    5000000

 Enter Data in Underwriter Analysis Page Max Revenue 5000000000
    # Author = Mitesh Patil
    [tags]          Insured Info
    TypeText        //span[text()\='Annual Revenues']/parent::*/following::td//input    5000000000 
