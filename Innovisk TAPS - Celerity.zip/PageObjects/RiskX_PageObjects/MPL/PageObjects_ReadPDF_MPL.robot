*** Settings ***
Library                QWeb
Library                QForce
#Library               QVision
Library                FakerLibrary
Library                String
Library                BuiltIn
Library                DateTime

Resource               ../../../resources/common.robot
Resource               ../PageObjects_Accounts.robot
Resource               ../PageObjects_Submissions.robot
Resource               ../../../resources/ReadPDF.robot
Resource               ../Celerity_Common.robot

Resource               ../../../PageObjects/RiskX_PageObjects/MPL/PageObjects_MPL_InsuredInfo.robot
Resource               ../../../PageObjects/RiskX_PageObjects/MPL/PageObjects_MPL_SubmissionInfo.robot
Resource               ../../../PageObjects/RiskX_PageObjects/MPL/PageObjects_MPL_UnderwriterAnalysis.robot
Resource               ../../../PageObjects/RiskX_PageObjects/MPL/PageObjects_MPL_CompareAndRateQuote.robot


*** Keywords ***
Read Doc Quote Letter Static Document MPL
    #Author=Amol Gaymukhe
    [Documentation]    Read Static data of Quote Letter
    [Tags]             smoke                       regression
    #Log To Console    ${read_doc}
    Test PDF File      QUOTE LETTER
    Test PDF File      Completed Surplus Lines Tax Form (PRIOR TO BINDING)
    Test PDF File      PREMIUM:
    Test PDF File      MGA FEE:
    Test PDF File      TOTAL:
    Test PDF File      LIST OF ENDORSEMENTS
    Test PDF File      Compensation


Read Doc Quote Letter Dynamic Document MPL
    #Author=Amol Gaymukhe
    [Documentation]    Read Static data of Quote Letter
    [Tags]             smoke                       regression
    Test PDF File      ${Quote_date}
    #Test PDF File     ${pdf_brokername}
    Test PDF File      ${uniqueName}
    Test PDF File      ${eff_date_final} to ${exp_final}
    Test PDF File      $${PDF_Premium}
    Test PDF File      $${PDF_PolFee}
    Test PDF File      $${PDF_TotalFee}

Read Policy Letter Static Document MPL
    #Author=Amol Gaymukhe
    [Documentation]    Read Static data of Policy Letter
    [Tags]             smoke                       regression
    Test PDF File      This Insurance
    Test PDF File      The Insured
    Test PDF File      Previous
    Test PDF File      Name and address of the Assured:
    Test PDF File      Effective from
    Test PDF File      FRAUD NOTICE
    #Test PDF File      SURPLUS LINES NOTICE
    Test PDF File      CELERITY RISK - MISCELLANEOUS PROFESSIONAL LIABILITY DECLARATIONS
    Test PDF File      CELERITY RISK
    Test PDF File      MISCELLANEOUS PROFESSIONAL LIABILITY POLICY
    Read State wise Surplus License


Read Policy Letter Dynamic Document MPL
    #Author=Amol Gaymukhe
    [Documentation]    Read Static data of Policy Letter
    [Tags]             smoke                       regression
    Test PDF File      This Insurance
    Test PDF File      ${uniqueName}
    Test PDF File      From: ${eff_date_final}
    Test PDF File      To: ${exp_final}
    Test PDF File      $${PDF_Premium}


Read Policy Letter Static Document MPL Excess
    #Author=Amol Gaymukhe
    [Documentation]    Read Static data of Policy Letter
    [Tags]             smoke                       regression
    Test PDF File      This Insurance
    Test PDF File      The Insured
    Test PDF File      Previous
    Test PDF File      Name and address of the Assured:
    Test PDF File      Effective from
    Test PDF File      FRAUD NOTICE
    Read State wise Surplus License
    #Test PDF File      SURPLUS LINES NOTICE
    #Test PDF File      CELERITY RISK - MISCELLANEOUS PROFESSIONAL LIABILITY DECLARATIONS
    #Test PDF File      CELERITY RISK
    #Test PDF File      MISCELLANEOUS PROFESSIONAL LIABILITY POLICY

    

Read State wise Surplus License
    #Author=Amol Gaymukhe
    [Documentation]             Read Static data for State wise surplus license
    [Tags]                      smoke                       regression


    #${billingaddressState}=     GetText                     ${billingaddressState}
    Log To Console              ${billingaddressState}

    IF                          "${billingaddressState}" == 'Arizona'
        Log To Console          {billingaddressState}
        Test PDF File           ARIZONA POLICYHOLDER NOTICE


    ELSE IF                     "${billingaddressState}" == 'California'

        Log To Console          {billingaddressState}
        Test PDF File           CALIFORNIA POLICYHOLDER NOTICE

    ELSE IF                     "${billingaddressState}" == 'Texas'

        Log To Console          {billingaddressState}
        Test PDF File           TEXAS POLICYHOLDER NOTICE

    ELSE IF                     "${billingaddressState}" == 'Oregon'

        Log To Console          {billingaddressState}
        Test PDF File           OREGON POLICYHOLDER NOTICE

    ELSE IF                     "${billingaddressState}" == 'Alaska'

        Log To Console          {billingaddressState}
        Test PDF File           ALASKA POLICYHOLDER NOTICE

    ELSE
        Fail
    END
