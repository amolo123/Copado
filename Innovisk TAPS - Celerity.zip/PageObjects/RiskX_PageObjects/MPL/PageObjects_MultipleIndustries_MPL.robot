*** Settings ***
Library                         QWeb
Library                         QForce
#Library                        QVision
Library                         FakerLibrary
Library                         String
Library                         BuiltIn
Library                         DateTime
Resource                        ../../../resources/common.robot
Library                         BuiltIn
Library                         DateTime


Library                         ../../../libraries/MailLib.py                              ${tenant_id}         ${client_id_mail}        ${client_secret_mail}

Library                         ../../../libraries/graph.py
Resource                        ../../../resources/graph.resource
Resource                        ../../../PageObjects/RiskX_PageObjects/MPL/PageObjects_MPL_InsuredInfo.robot
Resource                        ../../../PageObjects/RiskX_PageObjects/MPL/PageObjects_MPL_SubmissionInfo.robot
Resource                        ../../../PageObjects/RiskX_PageObjects/MPL/PageObjects_MPL_UnderwriterAnalysis.robot


*** Keywords ***


Select Eligible industry on MPL
    [Documentation]             Select Eligible industry on MPL
    [Arguments]                 ${Industry_MPL_S}           ${Service_Classification}


    IF                          "${Service_Classification}" == "Auctioneer"

        Log To Console          ${Service_Classification}
        Sleep                   5s
        Select Industry         ${Industry_MPL_S}
        Select Classification                               ${Service_Classification}
        ClickText               Save                        anchor=NEXT:Underwriter Analysis >
        Sleep                   10s
        ClickText               NEXT:Underwriter Analysis >
        Enter Data in Underwriter Analysis Page
        ClickText               Save                        anchor=Check Risk Health
        VerifyText              Success                     anchor=Update records successfully!
        ClickText               Check Risk Health           anchor=Save
        ${Suggestion}=          Get Text                    //td[contains(@class,'Proceed')]//lightning-base-formatted-text
        Log To Console          ${Service_Classification}
        Log To Console          ${Suggestion}
        ClickElement            //button[contains(@title, 'Close')]
        HoverElement            //span[contains(text(), 'Submission Info')]
        ClickElement            //span[contains(text(), 'Submission Info')]

    ELSE IF                     "${Service_Classification}" == "Commercial Appraisers"

        Log To Console          ${Service_Classification}
        Sleep                   5s
        Select Industry         ${Industry_MPL_S}
        Select Classification                               ${Service_Classification}
        ClickText               Save                        anchor=NEXT:Underwriter Analysis >
        Sleep                   10s
        ClickText               NEXT:Underwriter Analysis >
        Enter Data in Underwriter Analysis Page
        ClickText               Save                        anchor=Check Risk Health
        VerifyText              Success                     anchor=Update records successfully!
        ClickText               Check Risk Health           anchor=Save
        ${Suggestion}=          Get Text                    //td[contains(@class,'Proceed')]//lightning-base-formatted-text
        Log To Console          ${Service_Classification}
        Log To Console          ${Suggestion}
        VerifyText              Proceed
        ClickElement            //button[contains(@title, 'Close')]
        HoverElement            //span[contains(text(), 'Submission Info')]
        ClickElement            //span[contains(text(), 'Submission Info')]

    ELSE IF                     "${Service_Classification}" == "Mortgage Broker"


        Log To Console          ${Service_Classification}
        Sleep                   5s
        Select Industry         ${Industry_MPL_S}
        Select Classification                               ${Service_Classification}
        ClickText               Save                        anchor=NEXT:Underwriter Analysis >
        Sleep                   10s
        ClickText               NEXT:Underwriter Analysis >
        Enter Data in Underwriter Analysis Page
        ClickText               Save                        anchor=Check Risk Health
        VerifyText              Success                     anchor=Update records successfully!
        ClickText               Check Risk Health           anchor=Save
        Log To Console          ${Service_Classification}
        ${Suggestion}=          Get Text                    //td[contains(@class,'Proceed with Caution')]//lightning-base-formatted-text
        Log To Console          ${Suggestion}
        VerifyText              Proceed with Caution
        ClickElement            //button[contains(@title, 'Close')]
        HoverElement            //span[contains(text(), 'Submission Info')]
        ClickElement            //span[contains(text(), 'Submission Info')]


    ELSE IF                     "${Service_Classification}" == "Building Construction"

        Log To Console          ${Service_Classification}
        Sleep                   5s
        Select Industry         ${Industry_MPL_S}
        Select Classification                               ${Service_Classification}
        ClickText               Save                        anchor=NEXT:Underwriter Analysis >
        Sleep                   10s
        ClickText               NEXT:Underwriter Analysis >
        Enter Data in Underwriter Analysis Page
        ClickText               Save                        anchor=Check Risk Health
        VerifyText              Success                     anchor=Update records successfully!
        ClickText               Check Risk Health           anchor=Save
        Log To Console          ${Service_Classification}
        ${Suggestion}=          Get Text                    //td[contains(@class,'Stop! Decline!')]//lightning-base-formatted-text
        Log To Console          ${Suggestion}
        VerifyText              Stop! Decline!
        ClickElement            //button[contains(@title, 'Close')]
        HoverElement            //span[contains(text(), 'Submission Info')]
        ClickElement            //span[contains(text(), 'Submission Info')]



    END
    Log To Console              ------Selected multiple industry successfully for MPL -------


