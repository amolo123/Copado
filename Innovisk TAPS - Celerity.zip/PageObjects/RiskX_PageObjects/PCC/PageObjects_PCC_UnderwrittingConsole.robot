*** Settings ***
Library             QWeb
Library             QForce
#Library            QVision
Library             FakerLibrary
Library             String
Library             BuiltIn
Library             DateTime
Resource            ../../../resources/common.robot
Resource            ../PageObjects_Accounts.robot
Resource            ../PageObjects_Submissions.robot
Library             BuiltIn
Library             DateTime

*** Keywords ***

Verify Underwriter Analysis Page Elements
    # Author = Amol Gaymukhe
    [tags]          Insured Info

    VerifyText      D&O
    VerifyText      Policy
    VerifyText      Account Name
    VerifyText      Effective Date
    VerifyText      Expiration Date
    VerifyText      Industry
    VerifyText      Service Classification

    VerifyText      Industry & Sector
    VerifyText      Asset Size
    VerifyText      Domicile
    VerifyText      Ownership Structure

    VerifyText      Public Debt
    VerifyText      Operating History
    VerifyText      Growth Trend
    VerifyText      Capital Developments

    VerifyText      Merger or Acquisition Activity
    VerifyText      Solvency - Traditional Analysis
    VerifyText      Prior Loss History / Litigation History


    VerifyText      Underwriter Analysis
    # VerifyText      Annual Revenue
    VerifyText      D&O Notes


Enter Data In D&O 
    # Author = Amol Gaymukhe
    [tags]          Insured Info

    ClickElement    //span[text()\='Asset Size']//ancestor::lightning-layout//lightning-combobox
    ClickElement    //lightning-base-combobox-item[@data-value\='Total assets from $1 Million to $75 Million-"SME"']

    ClickElement    //span[text()\='Domicile']//ancestor::lightning-layout//lightning-combobox
    ClickElement    //lightning-base-combobox-item[@data-value\='Company is domiciled in any state except California, New York or Florida']      

    ClickElement    //span[text()\='Ownership Structure']//ancestor::lightning-layout//lightning-combobox
    ClickElement    //lightning-base-combobox-item[@data-value\='Company is private and majority held (over 50%) amongst the Directors & Officers']

    ClickElement    //span[text()\='Public Debt']//ancestor::lightning-layout//lightning-combobox
    ClickElement    //lightning-base-combobox-item[@data-value\='Company has no public debt']

    ClickElement    //span[text()\='Operating History']//ancestor::lightning-layout//lightning-combobox
    ClickElement    //lightning-base-combobox-item[@data-value\='Company has been in business for 5 years or greater']
   
    ScrollTo        //span[text()\='Asset Size']//ancestor::lightning-layout//lightning-combobox
    Sleep           3s
    ClickElement    //span[text()\='Growth Trend']//ancestor::lightning-layout//lightning-combobox
    ClickElement    //lightning-base-combobox-item[@data-value\='Unknown']

    ClickElement    //span[text()\='Capital Developments']//ancestor::lightning-layout//lightning-combobox
    ClickElement    //lightning-base-combobox-item[@data-value\='Company has not completed any public or private placements within the past 12 months']

    ClickElement    //span[text()\='Merger or Acquisition Activity']//ancestor::lightning-layout//lightning-combobox
    ClickElement    //lightning-base-combobox-item[@data-value\='No current merger or acquisition activity in the past 12-18 months']

    ClickElement    //span[text()\='Solvency - Traditional Analysis']//ancestor::lightning-layout//lightning-combobox
    ClickElement    //lightning-base-combobox-item[@data-value\='Company is at low risk of bankruptcy']

    ClickElement    //span[text()\='Prior Loss History / Litigation History']//ancestor::lightning-layout//lightning-combobox
    ClickElement    //lightning-base-combobox-item[@data-value\='Company has not reported any D&O claims during the past 3 years']

    #Annual revenue is moved to Insured info page
    #TypeText        Annual Revenue              5000000

    ClickText       Save                        anchor=New Primary Quote
    VerifyText      Success                     anchor=Record is saved !




Enter Data In EPL 
    # Author = Amol Gaymukhe
    [tags]          Insured Info

    ClickElement    //span[text()\='EPL']/parent::*

    ScrollTo        //span[text()\='Employee Turnover Rate / Potential Reductions in Workforce']//ancestor::lightning-layout//lightning-combobox
    Sleep           3s

    ClickElement    //span[text()\='Employee Count']//ancestor::lightning-layout//lightning-combobox
    ClickElement    //lightning-base-combobox-item[@data-value\='None']

    ClickElement    //span[text()\='Employee Compensation']//ancestor::lightning-layout//lightning-combobox
    ClickElement    //lightning-base-combobox-item[@data-value\='None']

    ClickElement    //span[text()\='Employment Procedures']//ancestor::lightning-layout//lightning-combobox
    ClickElement    //lightning-base-combobox-item[@data-value\='None']

    ClickElement    //span[text()\='Employee Turnover Rate / Potential Reductions in Workforce']//ancestor::lightning-layout//lightning-combobox
    ClickElement    //lightning-base-combobox-item[@data-value\='None']

    ClickElement    //span[text()\='Prior Loss History / Litigation History']//ancestor::lightning-layout//lightning-combobox
    ClickElement    //lightning-base-combobox-item[@data-value\='None']

    ClickElement    //span[text()\='Merger or Acquisition Activity']//ancestor::lightning-layout//lightning-combobox
    ClickElement    //lightning-base-combobox-item[@data-value\='None']

    ClickElement    //span[text()\='Key Coverage Concerns']//ancestor::lightning-layout//lightning-combobox
    ClickElement    //lightning-base-combobox-item[@data-value\='None']



Enter Data In Fiduciary 
    # Author = Amol Gaymukhe
    [tags]          Insured Info

    ClickElement    //span[text()\='Fiduciary']/parent::*

    ScrollTo        //span[text()\='Type of Benefit Plan and Number of Participants']//ancestor::lightning-layout//lightning-combobox
    ClickElement    //span[text()\='Plan Assets']//ancestor::lightning-layout//lightning-combobox
    ClickElement    //lightning-base-combobox-item[@data-value\='None']

    ClickElement    //span[text()\='ERISA Compliance']//ancestor::lightning-layout//lightning-combobox
    ClickElement    //lightning-base-combobox-item[@data-value\='None']

    ClickElement    //span[text()\='Type of Benefit Plan and Number of Participants']//ancestor::lightning-layout//lightning-combobox
    ClickElement    //lightning-base-combobox-item[@data-value\='None']

    ScrollTo        //span[text()\='Type of Benefit Plan and Number of Participants']//ancestor::lightning-layout//lightning-combobox
    ClickElement    //span[text()\='If Defined Benefit Plan, Plan Funding']//ancestor::lightning-layout//lightning-combobox
    ClickElement    //lightning-base-combobox-item[@data-value\='None']

    ClickElement    //span[text()\='ESOP Exposure']//ancestor::lightning-layout//lightning-combobox
    ClickElement    //lightning-base-combobox-item[@data-value\='None']

    ClickElement    //span[text()\='Plan Termination, Conversion']//ancestor::lightning-layout//lightning-combobox
    ClickElement    //lightning-base-combobox-item[@data-value\='None']

    ClickElement    //span[text()\='Prior Loss History / Litigation History']//ancestor::lightning-layout//lightning-combobox
    ClickElement    //lightning-base-combobox-item[@data-value\='None']


Enter Data In Crime 
    # Author = Amol Gaymukhe
    [tags]          Insured Info

    ClickElement    //span[text()\='Crime']/parent::*

    ScrollTo        //span[text()\='Internal Controls']//ancestor::lightning-layout//lightning-combobox
    ClickElement    //span[text()\='Asset Size']//ancestor::lightning-layout//lightning-combobox
    ClickElement    //lightning-base-combobox-item[@data-value\='None']

    ClickElement    //span[text()\='Locations']//ancestor::lightning-layout//lightning-combobox
    ClickElement    //lightning-base-combobox-item[@data-value\='None']

    ClickElement    //span[text()\='Human Resources']//ancestor::lightning-layout//lightning-combobox
    ClickElement    //lightning-base-combobox-item[@data-value\='None']


    ClickElement    //span[text()\='Internal Controls']//ancestor::lightning-layout//lightning-combobox
    ClickElement    //lightning-base-combobox-item[@data-value\='None']

    ClickElement    //span[text()\='Prior Loss History / Litigation History']//ancestor::lightning-layout//lightning-combobox[@data-product-name\='Crime']
    ClickElement    //lightning-base-combobox-item[@data-value\='None']

    ClickElement    //span[text()\='Key Coverage Concerns']//ancestor::lightning-layout//lightning-combobox
    ClickElement    //lightning-base-combobox-item[@data-value\='None']



Enter EPL Underwritting Input Fields
    # Author = Amol Gaymukhe
    [tags]          Insured Info
    ClickElement    (//span[text()\='Underwriter Analysis'])[2]

    TypeText        (//lightning-input[@data-product-name\='EPL'])[1]       200
    TypeText        (//lightning-input[@data-product-name\='EPL'])[2]       20
    TypeText        (//lightning-input[@data-product-name\='EPL'])[3]       2


Enter Fiduciary Underwritting Input Fields   
    # Author = Amol Gaymukhe
    [tags]          Insured Info
    ClickElement    (//span[text()\='Underwriter Analysis'])[3]

    TypeText        Plan Assets                 2000


Enter Crime Underwritting Input Fields   
    # Author = Amol Gaymukhe
    [tags]          Insured Info
    ClickElement    (//span[text()\='Underwriter Analysis'])[4]

    TypeText        Plan Assets                 2000

