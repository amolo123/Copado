*** Settings ***
Library                    QWeb
Library                    QForce
#Library                   QVision
Library                    FakerLibrary
Library                    String
Library                    BuiltIn
Library                    DateTime
Resource                   ../../../resources/common.robot
Resource                   ../PageObjects_Accounts.robot
Resource                   ../PageObjects_Submissions.robot
Library                    BuiltIn
Library                    DateTime

*** Keywords ***
Verify elements on Quote Console Page for Primary

    VerifyText             Quote Details
    VerifyText             Inception Date
    VerifyText             Expiry Date
    VerifyText             Broker Commission %
    VerifyText             ERP Duration
    VerifyText             Total Premium
    VerifyText             Rate Charged
    VerifyText             Surplus Lines Tax
    VerifyText             MGA Fee
    VerifyText             Insured State
    VerifyText             Policy Period Adjustment Factor
    VerifyText             Commission Adjustment Factor
    VerifyText             Coverage
    VerifyText             Limit
    VerifyText             Deductibles
    VerifyText             Technical Premium

    VerifyText             Total Before discount for shared agg.
    VerifyText             Is aggregate limit to be shared?
    VerifyText             Technical Premium
    VerifyText             Combined Maximum Aggregate Limit of Liability
    VerifyText             Total After discount for shared agg.
    VerifyText             Premium Calculator
    VerifyText             Total Premium

    VerifyText             D&O
    VerifyText             Required Limit
    VerifyText             Insuring Agg C Date
    VerifyText             Insuring Agg A and B Date
    VerifyText             Selected Industry
    VerifyText             Prior Claim Activity
    VerifyText             Private Placement Activity
    VerifyText             Quality of Balance Sheet
    VerifyText             Financial Trends
    VerifyText             Number of Years in Business
    VerifyText             Complexity of Risk
    VerifyText             Rating Justification
    VerifyText             Policy Retention
    VerifyText             Security Holder Limit
    VerifyText             Annual Revenue
    VerifyText             Coverage Endorsements
    VerifyText             Ownership
    VerifyText             Management Stability
    VerifyText             Outside Directorship Complexity
    VerifyText             Quality of Management
    VerifyText             Merger and Acquisition Activity
    VerifyText             Company Litigation

    Scroll                 //html                      page_down
    Scroll                 //html                      page_down
    Sleep                  2s
    ClickText              EPL
    VerifyText             Required Limit
    VerifyText             EPL Insuring Agg B Date
    VerifyText             Rateable Employees
    VerifyText             Part Time Ratio
    VerifyText             Selected Industry
    VerifyText             Prior Claim Activity
    VerifyText             EPL Diversity
    VerifyText             HR Training and Communication
    VerifyText             Salary Range
    VerifyText             Quality of Management
    VerifyText             Merger and Acquisition Activity
    VerifyText             Complexity of Risk
    VerifyText             Rating Justification

    VerifyText             Policy Retention
    VerifyText             EPL Insuring Agg A Date
    VerifyText             Part Time Employees
    VerifyText             Foreign Ratio
    VerifyText             Significant Terms & Conditions
    VerifyText             Reductions in Workforce
    VerifyText             HR Practices and Procedures
    VerifyText             HR Loss Prevention and Mitigation
    VerifyText             Financial Stability
    VerifyText             Number of Years in Business
    VerifyText             % of Employees located in CA
    VerifyText             Third Party Liability Exposure

    Scroll                 //html                      page_down
    Scroll                 //html                      page_down
    ScrollTo               Crime
    Sleep                  2s
    ClickText              Crime
    VerifyText             Selected Industry
    VerifyText             Required Limit
    VerifyText             Organizational Complexity
    VerifyText             High Value Processing Materials
    VerifyText             Internal Controls
    VerifyText             Inventory Management
    VerifyText             Prior Claim Activity
    VerifyText             Number of Years in Business
    VerifyText             Complexity of Risk
    VerifyText             Rating Justification
    VerifyText             Profile of Workforce
    VerifyText             Foreign Location Exposure
    VerifyText             Audit Functions
    VerifyText             Pre-Employment Screening
    VerifyText             Vendor Management Guidelines
    VerifyText             Financial Stability
    VerifyText             Merger and Acquisition Activity
    VerifyText             Significant Terms & Conditions

    Scroll                 //html                      page_down
    Scroll                 //html                      page_down
    Sleep                  2s
    ClickText              Fiduciary
    VerifyText             Required Limit
    VerifyText             Fiduciary Coverage Insuring Agreement B Limit
    VerifyText             Fiduciary Coverage Pending or Prior A Date
    VerifyText             Plan Assets
    VerifyText             Significant Terms & Conditions
    VerifyText             Plan and Regulatory Compliance
    VerifyText             Employee Stock Ownership Modifier
    VerifyText             Type of Plan Management
    VerifyText             Funding Position
    VerifyText             Quality of Management
    VerifyText             Merger and Acquisition Activity
    VerifyText             Third Party Liability Exposure

    #Elements verification
    VerifyText             //button[text()\='Rate']
    VerifyText             //span[text()\='Save']
    VerifyText             //button[text()\='Finalize']
    VerifyText             //lightning-icon[@title\='Generate Document']
    VerifyText             //button[@title\='Clone']
    VerifyText             //lightning-icon[@title\='Close']
    VerifyText             //lightning-icon[@title\='Endorsements & Subjectivities']


Verify elements on Quote Console Page for Excess

    VerifyText             Quote Details
    VerifyText             Inception Date
    VerifyText             Expiry Date
    VerifyText             Broker Commission %
    VerifyText             ERP Duration
    VerifyText             Total Premium
    VerifyText             Rate Charged

    VerifyText             MGA Fee
    VerifyText             Coverage
    VerifyText             Limit
    VerifyText             Deductibles
    VerifyText             Technical Premium
    VerifyText             Quoted Premium
    VerifyText             Override Premium
    VerifyText             Minimum Premium
    VerifyText             Transaction Premium
    VerifyText             Override Premium%

    VerifyText             Total Before discount for shared agg.
    VerifyText             Is aggregate limit to be shared?
    VerifyText             Technical Premium
    VerifyText             Combined Maximum Aggregate Limit of Liability
    VerifyText             Total After discount for shared agg.
    VerifyText             Premium Calculator
    VerifyText             Total Premium

    VerifyText             D&O
    VerifyText             Required Limit
    VerifyText             Insuring Agg C Date
    VerifyText             Insuring Agg A and B Date
    VerifyText             Selected Industry
    VerifyText             Prior Claim Activity
    VerifyText             Private Placement Activity
    VerifyText             Quality of Balance Sheet
    VerifyText             Financial Trends
    VerifyText             Number of Years in Business
    VerifyText             Complexity of Risk
    VerifyText             Rating Justification
    VerifyText             Policy Retention
    VerifyText             Security Holder Limit
    VerifyText             Annual Revenue
    VerifyText             Coverage Endorsements
    VerifyText             Ownership
    VerifyText             Management Stability
    VerifyText             Outside Directorship Complexity
    VerifyText             Quality of Management
    VerifyText             Merger and Acquisition Activity
    VerifyText             Company Litigation

    Scroll                 //html                      page_down
    Scroll                 //html                      page_down
    Sleep                  2s
    ClickText              EPL
    VerifyText             Required Limit
    VerifyText             EPL Insuring Agg B Date
    VerifyText             Rateable Employees
    VerifyText             Part Time Ratio
    VerifyText             Selected Industry
    VerifyText             Prior Claim Activity
    VerifyText             EPL Diversity
    VerifyText             HR Training and Communication
    VerifyText             Salary Range
    VerifyText             Quality of Management
    VerifyText             Merger and Acquisition Activity
    VerifyText             Complexity of Risk
    VerifyText             Rating Justification

    VerifyText             Policy Retention
    VerifyText             EPL Insuring Agg A Date
    VerifyText             Part Time Employees
    VerifyText             Foreign Ratio
    VerifyText             Significant Terms & Conditions
    VerifyText             Reductions in Workforce
    VerifyText             HR Practices and Procedures
    VerifyText             HR Loss Prevention and Mitigation
    VerifyText             Financial Stability
    VerifyText             Number of Years in Business
    VerifyText             % of Employees located in CA
    VerifyText             Third Party Liability Exposure

    Scroll                 //html                      page_down
    Scroll                 //html                      page_down
    ScrollTo               Crime
    Sleep                  2s
    ClickText              Crime
    VerifyText             Selected Industry
    VerifyText             Required Limit
    VerifyText             Organizational Complexity
    VerifyText             High Value Processing Materials
    VerifyText             Internal Controls
    VerifyText             Inventory Management
    VerifyText             Prior Claim Activity
    VerifyText             Number of Years in Business
    VerifyText             Complexity of Risk
    VerifyText             Rating Justification
    VerifyText             Profile of Workforce
    VerifyText             Foreign Location Exposure
    VerifyText             Audit Functions
    VerifyText             Pre-Employment Screening
    VerifyText             Vendor Management Guidelines
    VerifyText             Financial Stability
    VerifyText             Merger and Acquisition Activity
    VerifyText             Significant Terms & Conditions

    Scroll                 //html                      page_down
    Scroll                 //html                      page_down
    Sleep                  2s
    ClickText              Fiduciary
    VerifyText             Required Limit
    VerifyText             Fiduciary Coverage Insuring Agreement B Limit
    VerifyText             Fiduciary Coverage Pending or Prior A Date
    VerifyText             Plan Assets
    VerifyText             Significant Terms & Conditions
    VerifyText             Plan and Regulatory Compliance
    VerifyText             Employee Stock Ownership Modifier
    VerifyText             Type of Plan Management
    VerifyText             Funding Position
    VerifyText             Quality of Management
    VerifyText             Merger and Acquisition Activity
    VerifyText             Third Party Liability Exposure

    #Elements verification
    VerifyText             //button[text()\='Rate']
    VerifyText             //span[text()\='Save']
    VerifyText             //button[text()\='Finalize']
    VerifyText             //lightning-icon[@title\='Generate Document']
    VerifyText             //button[@title\='Clone']
    VerifyText             //lightning-icon[@title\='Close']
    VerifyText             //lightning-icon[@title\='Endorsements & Subjectivities']

Click On Rate
    # Author = Amol Gaymukhe
    [tags]                 Compare and Rate
    ClickElement           //button[text()\='Rate']
    VerifyText             Success                     anchor=Rating successfully!                             timeout=65s            partial_match=false

Click On Save  
    # Author = Amol Gaymukhe
    [tags]                 Compare and Rate
    ClickElement           //span[text()\='Save']
    VerifyText             Confirmation
    ClickText              Confirm                     anchor=Cancel
    VerifyText             Success                     anchor=Update records successfully!                     timeout=65s            partial_match=false


Click On Finalize 
    # Author = Amol Gaymukhe
    [tags]                 Compare and Rate
    ClickElement           //button[text()\='Finalize']
    VerifyText             Success                     anchor=Finalize quote successfully!                     timeout=65s            partial_match=false


Click On Generate Document
    # Author = Amol Gaymukhe
    [tags]                 Compare and Rate
    ClickElement           //lightning-icon[@title\='Generate Document']
    VerifyText             Success                     anchor=Document has been generated successfully!        timeout=65s            partial_match=false

Click On Clone
    # Author = Amol Gaymukhe
    [tags]                 Compare and Rate
    ClickElement           //button[@title\='Clone']

Click On Clone Excess
    # Author = Amol Gaymukhe
    [tags]                 Compare and Rate
    ClickElement           //button[@title\='Clone excess Quote']

Close cloned Quote
    # Author = Amol Gaymukhe
    [tags]                 Compare and Rate
    ClickElement           (//span[text()\='Show menu'])[2]
    ClickElement           //span[text()\='Close Quote']
    PickList               Closed Reason               No activity
    ClickText              Yes                         anchor=No

Click On Close Quote 
    # Author = Amol Gaymukhe
    [tags]                 Compare and Rate
    ClickElement           //lightning-icon[@title\='Close']
    VerifyText             Close Quote
    ClickText              Closed Reason
    ClickText              No activity
    ClickText              Yes                         anchor=No


Click On Endorsement and Subjectivity
    # Author = Amol Gaymukhe
    [tags]                 Compare and Rate
    ClickElement           //lightning-icon[@title\='Endorsements & Subjectivities']


Click On Bind Button
    # Author = Amol Gaymukhe
    ClickElement           //button[@title\='Bind']    timeout=65s                 partial_match=false
    VerifyText             Bind Quote
    # ${random_Pay_plan}=                              Evaluate                    random.choice(["By Check", "Credit Card", "ACH",])
    # Set Global Variable                              ${Pay_plan}                 ${random_Pay_plan}
    # PickList             Pay plan                    ${Pay_plan}
    ClickElement           (//span[text()\='Select Item 1'])[last()]
    ClickText              Bind                        anchor=Cancel
    VerifyText             Success                     anchor=Bind Quote Successful                            timeout=105s           partial_match=false


Click on first Quote to download
    # Author = Amol Gaymukhe
    ClickElement           (((//lightning-card)[4])//a)[1]
    VerifyText             Success                     anchor=Document has been downloaded successfully!       timeout=65s            partial_match=false

Update Insured Name and Address Change complete
    VerifyText             Quote Details
    ClickElement           (//button[text()\='Rate'])[last()]
    VerifyText             Success                     anchor=Rating successfully!                             timeout=65s            partial_match=false

    ClickElement           (//button[text()\='Finalize'])[last()]
    VerifyText             Success                     anchor=Finalize quote successfully!                     timeout=65s            partial_match=false

    ClickElement           (//button[text()\='Bind'])[last()]
    VerifyText             Bind Quote
    ClickElement           (//span[text()\='Select Item 1'])[last()]
    ClickText              Bind                        anchor=Cancel
    #VerifyText            Success                     anchor=Bind Quote successfully!                         timeout=65s

Midterm Cancellation Flow Complete
    # Author = Amol Gaymukhe
    VerifyText             Quote Details
    ClickElement           //button[text()\='Rate']
    VerifyText             Success                     anchor=Rating successfully!                             timeout=65s            partial_match=false
    ClickElement           //button[text()\='Finalize']
    VerifyText             Success                     anchor=Finalize quote successfully!                     timeout=65s            partial_match=false
    Sleep                  10s
    ClickElement           //button[@title\='Bind']
    VerifyText             Bind Quote
    # ${random_Pay_plan}=                              Evaluate                    random.choice(["By Check", "Credit Card", "ACH",])
    # Set Global Variable                              ${Pay_plan}                 ${random_Pay_plan}
    # PickList             Pay plan                    ${Pay_plan}
    ClickElement           (//span[text()\='Select Item 1'])
    ClickText              Bind                        anchor=Cancel
    VerifyText             Success                     anchor=Bind quote successfully!                         timeout=65s            partial_match=false





Amendment Flow Complete
    # Author = Amol Gaymukhe
    VerifyText             Quote Details
    ClickElement           //button[text()\='Rate']
    VerifyText             Success                     anchor=Rating successfully!                             timeout=65s            partial_match=false
    ClickElement           //button[text()\='Finalize']
    VerifyText             Success                     anchor=Finalize quote successfully!                     timeout=65s            partial_match=false
    Sleep                  10s
    ClickElement           //button[@title\='Bind']
    VerifyText             Bind Quote
    # ${random_Pay_plan}=                              Evaluate                    random.choice(["By Check", "Credit Card", "ACH",])
    # Set Global Variable                              ${Pay_plan}                 ${random_Pay_plan}
    # PickList             Pay plan                    ${Pay_plan}
    ClickElement           (//span[text()\='Select Item 1'])
    ClickText              Bind                        anchor=Cancel
    VerifyText             Success                     anchor=Bind quote successfully!                         timeout=65s            partial_match=false



Update Name and Insured Address Change Complete
    # Author = Amol Gaymukhe
    TypeText               //label[text()\='Billing Address']/parent::*//input     2345 Silver Drive
    ClickElement           (//span[text()\='2345 Silver Drive, Columbus, OH, USA'])[1]
    ClickText              Save
    Sleep                  5s
    ClickText              NEXT:Underwriting Console >
    Sleep                  5s
    VerifyText             Quote Console
    ClickText              Quote Console
    VerifyText             Quote Details
    ClickElement           //button[text()\='Rate']
    VerifyText             Success                     anchor=Rating successfully!                             timeout=65s            partial_match=false
    ClickElement           //button[text()\='Finalize']
    VerifyText             Success                     anchor=Finalize quote successfully!                     timeout=65s            partial_match=false
    Sleep                  10s
    ClickElement           //button[@title\='Bind']
    VerifyText             Bind Quote
    # ${random_Pay_plan}=                              Evaluate                    random.choice(["By Check", "Credit Card", "ACH",])
    # Set Global Variable                              ${Pay_plan}                 ${random_Pay_plan}
    # PickList             Pay plan                    ${Pay_plan}
    ClickElement           (//span[text()\='Select Item 1'])[last()]
    ClickText              Bind                        anchor=Cancel
    VerifyText             Success                     anchor=Bind quote successfully!                         timeout=65s            partial_match=false



Cancel Coverage Replace Complete flow
    # Author = Amol Gaymukhe
    VerifyText             Quote Details
    ClickElement           //button[text()\='Rate']
    VerifyText             Success                     anchor=Rating successfully!                             timeout=65s            partial_match=false
    ClickElement           //button[text()\='Finalize']
    VerifyText             Success                     anchor=Finalize quote successfully!                     timeout=65s            partial_match=false
    Sleep                  15s
    ClickElement           //button[@title\='Bind']
    VerifyText             Bind Quote
    # ${random_Pay_plan}=                              Evaluate                    random.choice(["By Check", "Credit Card", "ACH",])
    # Set Global Variable                              ${Pay_plan}                 ${random_Pay_plan}
    # PickList             Pay plan                    ${Pay_plan}
    ClickElement           (//span[text()\='Select Item 1'])[last()]
    ClickText              Bind                        anchor=Cancel
    VerifyText             Success                     anchor=Bind quote successfully!                         timeout=65s            partial_match=false

ERP flow Complete
    # Author = Amol Gaymukhe
    VerifyText             Quote Details
    RefreshPage
    Sleep                  10s
    RefreshPage
    Sleep                  10s
    ClickElement           //button[text()\='Rate']
    VerifyText             Success                     anchor=Rating successfully!                             timeout=65s            partial_match=false

    ClickElement           //button[text()\='Finalize']
    VerifyText             Success                     anchor=Finalize quote successfully!                     timeout=65s            partial_match=false
    Sleep                  5s
    ClickElement           //button[@title\='Bind']
    VerifyText             Bind Quote
    # ${random_Pay_plan}=                              Evaluate                    random.choice(["By Check", "Credit Card", "ACH",])
    # Set Global Variable                              ${Pay_plan}                 ${random_Pay_plan}
    # PickList             Pay plan                    ${Pay_plan}
    ClickElement           (//span[text()\='Select Item 1'])[last()]
    ClickText              Bind                        anchor=Cancel
    VerifyText             Success                     anchor=Bind quote successfully!                         timeout=65s            partial_match=false


Policy Duration Change Flow Complete
    # Author = Amol Gaymukhe
    VerifyText             Quote Details
    RefreshPage
    Sleep                  10s
    RefreshPage
    Sleep                  10s
    ClickElement           //button[text()\='Rate']
    VerifyText             Success                     anchor=Rating successfully!                             timeout=65s            partial_match=false
    ClickElement           //button[text()\='Finalize']
    VerifyText             Success                     anchor=Finalize quote successfully!                     timeout=65s            partial_match=false
    Sleep                  15s
    ClickElement           //button[@title\='Bind']
    VerifyText             Bind Quote
    # ${random_Pay_plan}=                              Evaluate                    random.choice(["By Check", "Credit Card", "ACH",])
    # Set Global Variable                              ${Pay_plan}                 ${random_Pay_plan}
    # PickList             Pay plan                    ${Pay_plan}
    ClickElement           (//span[text()\='Select Item 1'])
    ClickText              Bind                        anchor=Cancel
    VerifyText             Success                     anchor=Bind quote successfully!                         timeout=65s            partial_match=false


Get Quote Letter Dynamic Document PCC
    #Author=Amol
    [Documentation]        Dynamic Document Elements and Setting as Set Global Variable

    ${Quote_date}=         Get Current Date            result_format=%B %-d, %Y
    Log To Console         ${Quote_date}
    Set Global Variable    ${Quote_date}

    # ${pdf_agency}=       GetText                     //p[text()\='Agency']/parent::*//a
    # Log To Console       ${pdf_agency}
    # Set Global Variable                              ${pdf_agency}

    ${eff_date}=           GetInputValue               Inception Date
    Log To Console         ${eff_date}


    ${fr1}=                Convert Date                ${eff_date}                 date_format=%b %d, %Y
    ${eff_date_final}=     Convert Date                ${fr1}                      result_format=%B %-d, %Y
    Set Global Variable    ${eff_date_final}


    ${exp_date}=           GetInputValue               Expiry Date
    Log To Console         ${exp_date}

    #${conv2}=             Convert Date                ${exp_date}                 result_format=%B %m, %Y
    ${from1}=              Convert Date                ${exp_date}                 date_format=%b %d, %Y
    ${exp_final}=          Convert Date                ${from1}                    result_format=%B %-d, %Y
    Set Global Variable    ${exp_final}

    #Premium
    ${premium}=            GetInputValue               Total Premium
    Log To Console         ${premium}

    ${premium2}=           Remove String               ${premium}                  $                           .00
    ${PDF_Premium}=        Set Variable                ${premium2}
    Set Global Variable    ${PDF_Premium}

    #Policy Fee
    ${pol_fee}=            GetInputValue               MGA Fee
    Log To Console         ${pol_fee}

    ${polfee2}=            Remove String               ${pol_fee}                  $                           .00
    ${PDF_PolFee}=         Set Variable                ${polfee2}
    Set Global Variable    ${PDF_PolFee}

    #Total Premium
    ${tota_premium}=       GetInputValue               Total Premium
    Log To Console         ${tota_premium}

    ${totalfee2}=          Remove String               ${tota_premium}             $                           .00                    ,
    ${PDF_TotalFee}=       Set Variable                ${totalfee2}
    ${PDF_TotalFee}=       Evaluate                    ${totalfee2} + ${PDF_PolFee}
    ${PDF_TotalFee}=       Format String               {:,}                        ${PDF_TotalFee}
    Log To Console         ${PDF_TotalFee}
    Set Global Variable    ${PDF_TotalFee}



Get Quote Letter Dynamic Document PCC Excess   
    #Author=Amol
    [Documentation]        Dynamic Document Elements and Setting as Set Global Variable

    ${Quote_date}=         Get Current Date            result_format=%B %-d, %Y
    Log To Console         ${Quote_date}
    Set Global Variable    ${Quote_date}

    # ${pdf_agency}=       GetText                     //p[text()\='Agency']/parent::*//a
    # Log To Console       ${pdf_agency}
    # Set Global Variable                              ${pdf_agency}

    ${eff_date}=           GetInputValue               Inception Date
    Log To Console         ${eff_date}


    ${fr1}=                Convert Date                ${eff_date}                 date_format=%b %d, %Y
    ${eff_date_final}=     Convert Date                ${fr1}                      result_format=%B %-d, %Y
    Set Global Variable    ${eff_date_final}


    ${exp_date}=           GetInputValue               Expiry Date
    Log To Console         ${exp_date}

    ${from1}=              Convert Date                ${exp_date}                 date_format=%b %d, %Y
    ${exp_final}=          Convert Date                ${from1}                    result_format=%B %-d, %Y
    Set Global Variable    ${exp_final}

    #Premium
    ${premium}=            GetInputValue               Total Premium
    Log To Console         ${premium}

    ${premium2}=           Remove String               ${premium}                  $                           .00
    ${PDF_Premium}=        Set Variable                ${premium2}
    Set Global Variable    ${PDF_Premium}

    #Policy Fee
    ${pol_fee}=            GetInputValue               MGA Fee
    Log To Console         ${pol_fee}

    ${polfee2}=            Remove String               ${pol_fee}                  $                           .00
    ${PDF_PolFee}=         Set Variable                ${polfee2}
    Set Global Variable    ${PDF_PolFee}

    #Total Premium
    ${tota_premium}=       GetInputValue               Total Premium
    Log To Console         ${tota_premium}

    ${totalfee2}=          Remove String               ${tota_premium}             $                           .00                    ,
    ${PDF_TotalFee}=       Set Variable                ${totalfee2}
    ${PDF_TotalFee}=       Evaluate                    ${totalfee2} + ${PDF_PolFee}
    ${PDF_TotalFee}=       Format String               {:,}                        ${PDF_TotalFee}
    Log To Console         ${PDF_TotalFee}
    Set Global Variable    ${PDF_TotalFee}
