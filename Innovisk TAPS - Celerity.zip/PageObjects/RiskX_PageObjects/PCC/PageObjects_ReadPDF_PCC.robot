*** Settings ***
Library                QWeb
Library                QForce
#Library               QVision
Library                FakerLibrary
Library                String
Library                BuiltIn
Library                DateTime

Resource               ../../../resources/common.robot
Resource               ../PageObjects_Accounts.robot
Resource               ../PageObjects_Submissions.robot
Resource               ../../../resources/ReadPDF.robot
Resource               ../Celerity_Common.robot

Resource               ../../../PageObjects/RiskX_PageObjects/PageObjects_Accounts.robot
Resource               ../../../PageObjects/RiskX_PageObjects/PageObjects_HomePage.robot
Resource               ../../../PageObjects/RiskX_PageObjects/PCC/PageObjects_PCC_InsuredInfo.robot
Resource               ../../../PageObjects/RiskX_PageObjects/PCC/PageObjects_PCC_UnderwrittingConsole.robot
Resource               ../../../PageObjects/RiskX_PageObjects/PCC/PageObjects_PCC_QuoteConsole.robot




*** Keywords ***
Read Doc Quote Letter Static Document PCC
    #Author=Amol Gaymukhe
    [Documentation]    Read Static data of Quote Letter
    [Tags]             smoke                       regression
    #Log To Console    ${read_doc}
    Test PDF File      QUOTE LETTER
    Test PDF File      Based upon the information submitted
    Test PDF File      ALL COVERAGE SECTIONS:
    Test PDF File      POLICY FEE:
    Test PDF File      TOTAL:
    Test PDF File      LIST OF ENDORSEMENTS
    Test PDF File      Compensation


Read Doc Quote Letter Dynamic Document PCC
    #Author=Amol Gaymukhe
    [Documentation]    Read Static data of Quote Letter
    [Tags]             smoke                       regression
    Test PDF File      ${eff_date_final}
    #Test PDF File     ${pdf_brokername}
    Test PDF File      ${uniqueName}
    Test PDF File      ${eff_date_final} to ${exp_final}
    Test PDF File      $${PDF_Premium}
    Test PDF File      $${PDF_PolFee}
    Test PDF File      ${PDF_Premium}



Read Policy Letter Static Document PCC
    #Author=Amol Gaymukhe
    [Documentation]    Read Static data of Policy Letter
    [Tags]             smoke                       regression
    Test PDF File      This Insurance
    Test PDF File      The Insured
    Test PDF File      Previous
    Test PDF File      Name and address of the Assured:
    Test PDF File      Effective from
    Test PDF File      FRAUD NOTICE
    #Test PDF File      SURPLUS LINES NOTICE
    Test PDF File      PRIVATE COMPANY VINDICATOR
    Test PDF File      GENERAL TERMS AND CONDITIONS DECLARATIONS
    Test PDF File      PRCV COV 10 23
    Read State wise Surplus License


Read Policy Letter Dynamic Document PCC
    #Author=Amol Gaymukhe
    [Documentation]    Read Static data of Policy Letter
    [Tags]             smoke                       regression
    Test PDF File      This Insurance
    Test PDF File      ${uniqueName}
    Test PDF File      ${eff_date_final} To: ${exp_final}
    Test PDF File      $${PDF_Premium}


Read Policy Letter Static Document PCC Excess
    #Author=Amol Gaymukhe
    [Documentation]    Read Static data of Policy Letter
    [Tags]             smoke                       regression
    Test PDF File      This Insurance
    Test PDF File      The Insured
    Test PDF File      Previous
    Test PDF File      Name and address of the Assured:
    Test PDF File      Effective from
    Test PDF File      FRAUD NOTICE
    #Test PDF File      SURPLUS LINES NOTICE
    Test PDF File      FOLLOW FORM EXCESS LIABILITY
    Test PDF File      EXCESS FOLLOW FORM LIABILITY POLICY
    Read State wise Surplus License



Read Doc Quote Letter Static Document PCC Excess
    #Author=Amol Gaymukhe
    [Documentation]    Read Static data of Quote Letter
    [Tags]             smoke                       regression
    #Log To Console    ${read_doc}
    Test PDF File      QUOTE LETTER
    Test PDF File      Based upon the information submitted
    Test PDF File      POLICY FEE:
    Test PDF File      TOTAL:
    Test PDF File      LIST OF ENDORSEMENTS
    Test PDF File      Compensation



Read State wise Surplus License
    #Author=Amol Gaymukhe
    [Documentation]             Read Static data for State wise surplus license
    [Tags]                      smoke                       regression


    #${billingaddressState}=     GetText                     ${billingaddressState}
    Log To Console              ${billingaddressState}

    IF                          "${billingaddressState}" == 'Arizona'
        Log To Console          {billingaddressState}
        Test PDF File           ARIZONA POLICYHOLDER NOTICE


    ELSE IF                     "${billingaddressState}" == 'California'

        Log To Console          {billingaddressState}
        Test PDF File           CALIFORNIA POLICYHOLDER NOTICE

    ELSE IF                     "${billingaddressState}" == 'Texas'

        Log To Console          {billingaddressState}
        Test PDF File           TAXAS POLICYHOLDER NOTICE

    ELSE IF                     "${billingaddressState}" == 'Oregon'

        Log To Console          {billingaddressState}
        Test PDF File           OREGON POLICYHOLDER NOTICE

    ELSE IF                     "${billingaddressState}" == 'Alaska'

        Log To Console          {billingaddressState}
        Test PDF File           ALASKA POLICYHOLDER NOTICE

    ELSE
        Fail
    END