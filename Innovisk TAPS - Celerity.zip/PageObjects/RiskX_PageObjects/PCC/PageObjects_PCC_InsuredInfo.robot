*** Settings ***
Library                QWeb
Library                QForce
#Library               QVision
Library                FakerLibrary
Library                String
Library                BuiltIn
Library                DateTime
Resource               ../../../resources/common.robot
Resource               ../PageObjects_Accounts.robot
Resource               ../PageObjects_HomePage.robot



*** Keywords ***

Validate field on Insured Info page for PCC
    # Author = Amol Gaymukhe
    [tags]             Insured Info
    ClickText          Home                        anchor=Celerity Underwriting
    VerifyText         Celerity Underwriting       anchor=Home
    ClickText          Private Company Combo v2
    ClickElement       (//input[@placeholder\="Search..."])[1]
    TypeText           Search...                   ${uniqueName}               anchor=Insured Name
    ClickElement       (//li[@role\='presentation']/span)[1]
    Log To Console     ----- Insured Info page Add Account Verified Successfully -----

    sleep              5s
    ClickText          Save                        anchor=NEXT:Underwriting Console >
    VerifyText         Success                     anchor=Record is saved !

    Log To Console     ----- Account added -----
    # ${Phone_value}=                              GetFieldValue               Phone
    # Log To Console                               ${Phone_value}
    #VerifyInputValue                              Account Name                ${uniqueName}
    VerifyText         Account                     anchor=3
    # VerifyText       Agency
    # VerifyText       Underwriter                 anchor=4
    # VerifyText       Stage
    Verifytext         Effective Date
    Verifytext         Expiration Date
    VerifyText         Industry
    VerifyText         Service Classification
    VerifyText         Account Name
    VerifyText         Billing Address
    VerifyText         Broker Contact
    VerifyText         Relationship Type
    VerifyText         Country
    VerifyText         Primary Broker?
    VerifyText         Street
    VerifyText         Alien Broker
    VerifyText         City
    VerifyText         State

    VerifyText         Submission Information
    VerifyText         D&O
    VerifyText         EPL
    VerifyText         Crime
    VerifyText         Fiduciary

    VerifyText         Industry
    VerifyText         Service Classification
    VerifyText         Effective Date
    VerifyText         Received Date
    VerifyText         Expiration Date
    # VerifyText         Close Date
    VerifyText         Retroactive Date
    VerifyText         Prior/Pending Litigation Date
    VerifyText         Stage
    VerifyText         Closed Reason
    VerifyText         Type
    VerifyText         Submission Owner
    VerifyText         Annual Revenue
    VerifyText         Broker Layer Requested
    #VerifyText         Additional Insured Details



    Log To Console     ----- Insured Info field Validated Successfully-----

Enter data on Insured info Page for PCC Max Revenue 5000000000
    # Author = Amol Gaymukhe
    [tags]             Insured Info

    ClickText          Home                        anchor=Celerity Underwriting
    VerifyText         Celerity Underwriting       anchor=Home
    ClickText          Private Company Combo v2
    ClickElement       (//input[@placeholder\="Search..."])[1]
    TypeText           Search...                   ${uniqueName}               anchor=Insured Name
    ClickElement       (//li[@role\='presentation']/span)[1]
    Log To Console     ----- Insured Info page Add Account Verified Successfully -----

    sleep              5s
    TypeText           *Annual Revenue             5000000000

    ClickText          Save                        anchor=NEXT:Underwriting Console >
    VerifyText         Success                     anchor=Record is saved !
    Log To Console     ----- Data Entered On Insured Info Page Successfully ---------------

Enter data on Insured info Page for PCC
    # Author = Amol Gaymukhe
    [tags]             Insured Info

    ClickText          Home                        anchor=Celerity Underwriting
    VerifyText         Celerity Underwriting       anchor=Home
    ClickText          Private Company Combo v2
    ClickElement       (//input[@placeholder\="Search..."])[1]
    TypeText           Search...                   ${uniqueName}               anchor=Insured Name
    ClickElement       (//li[@role\='presentation']/span)[1]
    Log To Console     ----- Insured Info page Add Account Verified Successfully -----

    sleep              5s
    TypeText           *Annual Revenue             5000000

    ClickText          Save                        anchor=NEXT:Underwriting Console >
    VerifyText         Success                     anchor=Record is saved !
    Log To Console     ----- Data Entered On Insured Info Page Successfully ---------------

Click On Account Link 
    # Author = Amol Gaymukhe
    [tags]             Insured Info

    ClickElement       //label[text()\='Account Name']/parent::*//a
    VerifyText         Details
    VerifyText         Account Product
    VerifyText         Underwriting File
    VerifyText         Related
    VerifyText         Claims
    VerifyText         Account History
    VerifyText         Sfiles                      partial_match=False



Select state CO
    # Author = Amol Gaymukhe
    [tags]             Insured Info
    ClickText          Insured Info
    PickList           Province                    Colorado
    ClickText          Save                        anchor=NEXT:Submission Info >
    ClickText          NEXT:Submission Info >


Enter Data in Underwriter Analysis Page
    # Author = Amol Gaymukhe
    [tags]             Insured Info
    TypeText           //span[text()\='Annual Revenues']/parent::*/following::td//input               5000000



Select Industry
    #Author=Amol Gaymukhe
    [Documentation]    Additional Insured Industry
    [Arguments]        ${industry}
    PickList           Industry                    ${Industry}

Select Classification 
    #Author=Amol Gaymukhe
    [Documentation]    Additional Insured Classification
    [Arguments]        ${service}
    PickList           Service Classification      ${service}


Select Broker 
    #Author=Amol Gaymukhe
    [Documentation]    Additional Insured Details validation
    TypeText           //label[text()\='Broker Contact']/parent::*//input      Celerity Broker
    ClickElement       //label[text()\='Broker Contact']/parent::*//input
    ClickElement       //label[text()\='Broker Contact']/parent::c-generate-element-lwc-aq-cel//ul[@role\="presentation"]/li


Select Product
    #Author=Amol Gaymukhe
    [Documentation]    Additional Insured Details validation
    [Arguments]        ${product_name}
    ClickElement       //lightning-input[@data-name\='${product_name}']