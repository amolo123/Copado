*** Settings ***
Library                         QWeb
Library                         QForce
#Library                        QVision
Library                         FakerLibrary
Library                         String
Library                         BuiltIn
Library                         DateTime
Resource                        ../../resources/common.robot
Library                         BuiltIn
Library                         DateTime


Library                         ../../libraries/MailLib.py                              ${tenant_id}                ${client_id_mail}        ${client_secret_mail}

Library                         ../../libraries/graph.py
Resource                        ../../resources/graph.resource


*** Keywords ***
Verify Elements On Policy Page
    # Author = Amol Gaymukhe
    [tags]                      Insured Info
    VerifyText                  Policy Number
    VerifyText                  Policy Status
    VerifyText                  Total Premium
    VerifyText                  Effective Date
    VerifyText                  Expiration Date

    VerifyText                  Policy Name
    VerifyText                  Policy Number               anchor=2
    VerifyText                  Policy Status               anchor=2
    VerifyText                  Effective Date              anchor=2
    VerifyText                  Expiration Date             anchor=2
    VerifyText                  Cancellation Date
    VerifyText                  Cancellation Reason
    VerifyText                  Product Name
    VerifyText                  NIPR Results
    VerifyText                  Binding License Number
    VerifyText                  Invoice Status
    VerifyText                  Policy Document sent
    VerifyText                  Currency
    VerifyNoText                Renewal Completed?
    VerifyText                  Azure ID
    VerifyText                  Created By

    VerifyText                  Account                     anchor=3
    VerifyText                  Total Premium               anchor=2
    VerifyText                  Initial Premium
    VerifyText                  Owner
    VerifyText                  NJ Transaction Code
    #VerifyText                 Master Binder
    VerifyText                  Binding License Owner
    VerifyText                  Binding License Owner Name
    VerifyText                  Binding License Owner Address
    VerifyText                  Number Open Subjectivity Bound Quote
    VerifyText                  Pending or Prior Proceedings Date
    VerifyText                  Is Signature Pack Uploaded
    VerifyText                  Last Modified By



Change Policy
    # Author = Amol Gaymukhe
    [tags]                      Change Policy
    [Arguments]                 ${Endorsement_Type}
    ClickText                   Change Policy
    Sleep                       5s
    DropDown                    Endorsement Type            ${Endorsement_Type}


Change Policy ERP
    # Author = Saurabh Salgaonkar
    # Select ERP on policy chnage
    [tags]                      Change Policy
    ClickText                   Change Policy
    Sleep                       5s
    DropDown                    Endorsement Type            Extended Reporting Period (ERP)


Flat Cancellation Input
    Sleep                       3s
    ClickText                   Confirm                     anchor=Back


Midterm Cancellation Input
    Sleep                       2s
    ${cancellation_date}=       Get Current Date            result_format=%b %-d, %Y    increment= 9 day
    Log To Console              ${cancellation_date}
    TypeText                    Cancellation Date*          ${cancellation_date}
    ClickText                   Confirm                     anchor=Back

Midterm Cancellation Input PDO
    Sleep                       2s
    ${cancellation_date}=       Get Current Date            result_format=%b %-d, %Y    increment=5 day
    Log To Console              ${cancellation_date}
    TypeText                    Cancellation Date           ${cancellation_date}
    ClickText                   Confirm                     anchor=Back


Midterm Cancellation Input Complete PDO
    VerifyText                  Quote Console               timeout=85s
    ClickElement                (//button[@title\='Rating test'])[last()]
    VerifyText                  Success                     anchor=Rating successful!                               partial_match=false      timeout=65s
    ClickElement                (//lightning-icon[@title\='Finalize Quote'])[last()]
    VerifyText                  Success                     anchor=Finalize quote and Document Generation Successful!                        partial_match=false         timeout=65s
    ClickElement                //lightning-icon[@title\='Bind']                        timeout=65s                 partial_match=false
    VerifyText                  Bind Quote
    ClickElement                (//span[text()\='Select Item 1'])
    ClickText                   Bind                        anchor=Cancel
    VerifyText                  Success                     anchor=Bind Quote Successful                            partial_match=false      timeout=65s

Amendment Input Complete PDO
    VerifyText                  Quote Console               timeout=85s
    ClickElement                (//button[@title\='Rating test'])[last()]
    VerifyText                  Success                     anchor=Rating successful!                               partial_match=false      timeout=65s
    ClickElement                (//lightning-icon[@title\='Finalize Quote'])[last()]
    VerifyText                  Success                     anchor=Finalize quote and Document Generation Successful!                        partial_match=false         timeout=65s
    ClickElement                //lightning-icon[@title\='Bind']                        timeout=55s
    VerifyText                  Bind Quote
    ClickElement                (//span[text()\='Select Item 1'])
    ClickText                   Bind                        anchor=Cancel
    VerifyText                  Success                     anchor=Bind Quote Successful                            partial_match=false      timeout=65s

Amendment Input
    Sleep                       3s
    ClickText                   Confirm                     anchor=Back

Update Name and Insured Input
    Sleep                       3s
    ClickText                   Confirm                     anchor=Back

Broker on Record Change Input
    Sleep                       3s
    TypeText                    Broker Contact              Celerity DNO
    ClickElement                //label[text()\='Broker Contact']/parent::*//li
    ClickText                   Confirm                     anchor=Back

Broker on Record Change Input Complete PDO
    Sleep                       2s
    ${cancellation_date}=       Get Current Date            result_format=%b %-d, %Y    increment=5 day
    Log To Console              ${cancellation_date}
    TypeText                    Endorsement Effective Date                              ${cancellation_date}
    TypeText                    Broker Contact              Celerity DNO
    ClickElement                //label[text()\='Broker Contact']/parent::*//li
    ClickText                   Confirm                     anchor=Back
    VerifyText                  Quote Console               timeout=85s
    ClickElement                (//button[@title\='Rating test'])[last()]
    VerifyText                  Success                     anchor=Rating successful!                               partial_match=false      timeout=65s
    ClickElement                (//lightning-icon[@title\='Finalize Quote'])[last()]
    VerifyText                  Success                     anchor=Finalize quote and Document Generation Successful!                        partial_match=false         timeout=65s
    VerifyText                  Success                     anchor=Finalize quote successful!                       partial_match=false      timeout=65s
    ClickElement                //lightning-icon[@title\='Bind']
    VerifyText                  Bind Quote
    #ClickText                  Individual broker license
    ClickElement                (//span[text()\='Select Item 1'])
    ClickText                   Bind                        anchor=Cancel
    VerifyText                  Success                     anchor=Bind Quote Successful                            partial_match=false      timeout=65s



Cancel Coverage Replace Input Complete PDO
    VerifyText                  Quote Console               timeout=85s
    ClickElement                (//button[@title\='Rating test'])[1]
    VerifyText                  Success                     anchor=Rating successful!                               partial_match=false      timeout=65s
    ClickElement                (//lightning-icon[@title\='Finalize Quote'])            anchor=Rated
    VerifyText                  Success                     anchor=Finalize quote and Document Generation Successful!                        partial_match=false         timeout=65s
    VerifyText                  Success                     anchor=Finalize quote successful!                       partial_match=false      timeout=65s
    ClickElement                //lightning-icon[@title\='Bind']
    VerifyText                  Bind Quote
    #ClickText                  Individual broker license
    ClickElement                (//span[text()\='Select Item 1'])
    ClickText                   Bind                        anchor=Cancel
    VerifyText                  Success                     anchor=Bind Quote Successful                            partial_match=false      timeout=65s



Update Insured Name or Address Input Complete PDO
    VerifyText                  Quote Console               timeout=85s
    ClickElement                (//button[@title\='Rating test'])[last()]
    VerifyText                  Success                     anchor=Rating successful!                               partial_match=false      timeout=65s
    ClickElement                (//lightning-icon[@title\='Finalize Quote'])[last()]
    VerifyText                  Success                     anchor=Finalize quote and Document Generation Successful!                        partial_match=false         timeout=65s
    ClickElement                //lightning-icon[@title\='Bind']
    VerifyText                  Bind Quote
    #ClickText                  Individual broker license
    ClickElement                (//span[text()\='Select Item 1'])
    ClickText                   Bind                        anchor=Cancel
    VerifyText                  Success                     anchor=Bind Quote Successful                            partial_match=false      timeout=65s


Policy Duration Chage Input Complete PDO
    VerifyText                  Quote Console               timeout=85s
    ClickElement                (//button[@title\='Rating test'])[last()]
    VerifyText                  Success                     anchor=Rating successful!                               partial_match=false      timeout=65s
    ClickElement                (//lightning-icon[@title\='Finalize Quote'])[last()]
    VerifyText                  Success                     anchor=Finalize quote and Document Generation Successful!                        partial_match=false         timeout=65s
    ClickElement                //lightning-icon[@title\='Bind']
    VerifyText                  Bind Quote
    #ClickText                  Individual broker license
    ClickElement                (//span[text()\='Select Item 1'])
    ClickText                   Bind                        anchor=Cancel
    VerifyText                  Success                     anchor=Bind Quote Successful                            partial_match=false      timeout=65s


Midterm Cancellation Input and select

    ClickText                   Change Policy
    ClickElement                //select
    Sleep                       2s
    DropDown                    Endorsement Type            [[2]]


Broker on Record Change and select

    ClickText                   Change Policy
    ClickElement                //select
    Sleep                       2s
    DropDown                    Endorsement Type            [[6]]

Policy Duration Change Input and select

    ClickText                   Change Policy
    ClickElement                //select
    Sleep                       2s
    DropDown                    Endorsement Type            [[4]]
    Sleep                       3s
    ClickText                   Confirm                     anchor=Back



Cancel Coverage Replace Input and select
    ClickText                   Change Policy
    ClickElement                //select
    Sleep                       2s
    DropDown                    Endorsement Type            [[5]]
    Sleep                       3s
    ClickText                   Confirm                     anchor=Back
    ClickText                   Confirm                     anchor=Cancel


Reinstatement Input
    Sleep                       3s
    ClickText                   Confirm                     anchor=Back


Verify Endorsement Type Field On Change Endorsement 
    # Author = Amol Gaymukhe
    [tags]                      Change Policy
    ClickText                   Change Policy
    Sleep                       5s
    ${Endorsement_Type}=        GetDropDownValues           Endorsement Type
    Log To Console              ${Endorsement_Type}
    @{Endorsement_Type_list}=                               Create List                 Amendment                   Update Insured Name or Address                       Midterm Cancellation      Flat Cancellation           Policy Duration Change     Coverage Cancel & Replace    Broker on Record Change
    Log To Console              ${Endorsement_Type_list}
    Lists Should Be Equal       ${Endorsement_Type}         ${Endorsement_Type_list}    ignore_order=true


Policy Document Dropdown Check
    # Author = Amol Gaymukhe
    [tags]                      Change Policy
    ClickText                   Policy Document
    ClickElement                //select[@name\='docType']
    ClickText                   Binder

    ${Document_Type}=           GetDropDownValues           Document Type
    Log To Console              ${Document_Type}
    @{Document_Type_list}=      Create List
    Log To Console              ${Document_Type_list}
    Lists Should Be Equal       ${Document_Type}            ${Document_Type_list}       ignore_order=true


Show More Actions
    # Author = Amol Gaymukhe
    [tags]                      Change Policy
    ClickElement                (//span[text()\='Show more actions'])


Verify Show More Actions List
    # Author = Amol Gaymukhe
    [tags]                      Change Policy
    VerifyText                  New Note
    VerifyText                  New Lead
    VerifyText                  Clone
    VerifyText                  Submit for Approval
    VerifyText                  Delete
    VerifyText                  Change Record Type
    VerifyText                  Sharing
    VerifyText                  Change Owner
    VerifyText                  Edit                        anchor=Change Owner
    VerifyText                  Printable View
    VerifyText                  Renewal



Generate Document on Policy
    #Author=Amol Gaymukhe
    [Documentation]             Close and Reopen
    [Arguments]                 ${doc_type}

    ${value}=                   Set Variable                1
    Log To Console              ${value}
    FOR                         ${value}                    IN RANGE                    3
        ClickText               Policy Document
        Sleep                   5s
        ClickElement            //span[text()\='Cancel and close']
        RefreshPage
        ${value}=               Set Variable                ${value}+1
    END

    # CssSelectors              on
    # ClickText                 option[value\='CompletePolicy']                         value
    # Log To Console            ${value}
    # CssSelectors              off

    # DropDown                  Document Type               Policy                      timeout=30s
    # ClickElement              //select
    # VerifyText                Binder


    ClickText                   Policy Document
    UseModal                    On
    VerifyText                  Generate Policy Document
    DropDown                    Document Type               ${doc_type}                 timeout=30s
    ClickText                   Generate                    anchor=Cancel
    VerifyText                  Success                     anchor=Document has been generated successfully!        timeout=120s
    UseModal                    Off

Generate Document on Policy ChangeEndorsement
    #Author=Amol Gaymukhe
    [Documentation]             Close and Reopen
    [Arguments]                 ${doc_type}

    ${value}=                   Set Variable                1
    Log To Console              ${value}
    FOR                         ${value}                    IN RANGE                    3
        ClickText               Policy Document
        Sleep                   5s
        ClickElement            //span[text()\='Cancel and close']
        RefreshPage
        ${value}=               Set Variable                ${value}+1
    END

    # CssSelectors              on
    # ClickText                 option[value\='CompletePolicy']                         value
    # Log To Console            ${value}
    # CssSelectors              off

    # DropDown                  Document Type               Policy                      timeout=30s
    # ClickElement              //select
    # VerifyText                Binder


    ClickText                   Policy Document
    UseModal                    On
    VerifyText                  Generate Policy Document
    DropDown                    Document Type               ${doc_type}                 timeout=30s
    ClickElement                //span[text()\='Select Item 1']
    ClickText                   Generate                    anchor=Cancel
    VerifyText                  Success                     anchor=Document has been generated successfully!        timeout=120s
    UseModal                    Off

Send Mail On Submission Page
    #Author=Amol
    [Documentation]             Sending Mail From Submission Page
    [Tags]                      Validating
    [Arguments]                 ${Mailtype}
    Show More Actions
    ClickText                   Send Mail
    UseModal                    On
    ClickElement                //select

    # #ClickText                Binder Transmittal
    IF                          "${Mailtype}"=="Bind email"
        DropDown                Select a Template:          [[1]]
    ELSE IF                     "${Mailtype}"=="Decline email"
        DropDown                Select a Template:          [[2]]
    ELSE IF                     "${Mailtype}"=="Quote email"
        DropDown                Select a Template:          [[3]]
    ELSE IF                     "${Mailtype}"=="Submission email"
        DropDown                Select a Template:          [[4]]
    END
    ${subjectline}=             GetInputValue               Subject:                    timeout=45s
    ${subjectline}=             Set Variable                ${subjectline}
    Log To Console              ${subjectline}
    Set Global Variable         ${subjectline}
    ClickText                   Send                        anchor=Cancel
    Sleep                       40s
    ${body}=                    Get Email Content           ${client_id_mail}           ${client_secret_mail}       ${tenant_id}             QA.Testing.Inbox@innovisk.global                      ${subjectline}
    #Log To Console             ${body}
    Set Global Variable         ${body}
    Log To Console              --------Send Email for ${Mailtype} is successfull------
