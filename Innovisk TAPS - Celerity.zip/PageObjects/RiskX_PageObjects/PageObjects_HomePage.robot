*** Settings ***
Library           QWeb
Library           QForce
#Library          QVision
Library           FakerLibrary
Resource          ../../resources/common.robot



*** Keywords ***
Verify All HomePage Elemets
    # Author = Amol
    [tags]        All
    Home
    VerifyText    Home
    VerifyText    Accounts
    VerifyText    Contacts
    VerifyText    Reports
    VerifyText    Policies

    VerifyText    Private Company Combo v2
    VerifyText    Cyber v2
    VerifyText    Miscellaneous Professional Liability v2
    VerifyText    Existing Submission

    ClickText     Accounts                    anchor=Home
    VerifyText    Recently Viewed
    VerifyText    Account Name
    VerifyText    Account Record Type
    VerifyText    Billing Street
    VerifyText    Billing City
    VerifyText    Billing State/Province
    VerifyText    Billing Zip/Postal Code
    VerifyText    Phone
    VerifyText    FEIN
    VerifyText    Parent Account
    VerifyText    Account Owner Alias

    Home
    ClickText     Contacts                    anchor=Accounts
    VerifyText    Recently Viewed
    VerifyText    Name
    VerifyText    Account Name
    VerifyText    Phone
    VerifyText    Email                       partial_match=false
    VerifyText    Status
    VerifyText    Account: Billing Street
    VerifyText    Account: Billing City
    VerifyText    Account: Billing State/Province
    
    Home
    ClickText     Policies                    anchor=Reports
    VerifyText    Policy Name
    VerifyText    Policy Number
    VerifyText    Account Name
    VerifyText    Effective Date
    VerifyText    Product Name                       partial_match=false
    VerifyText    Policy Status
    VerifyText    Created Date
    




