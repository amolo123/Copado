*** Settings ***
Library               QWeb
Library               QForce
#Library              QVision
Library               FakerLibrary
Library               String
Library               BuiltIn
Library               DateTime
Resource              ../../resources/common.robot




*** Keywords ***
Validate Aqueous New submission Fields
    #Author=Pinki
    [tags]            submission
    Home
    #ClickElement     //button[@class\='slds-button slds-show']
    ClickElement      //span[text()\='App Launcher']
    TypeText          //input[@placeholder\='Search apps and items...']    Aqueous
    ClickText         Celerity Underwriting
    VerifyText        Celerity Underwriting                 anchor=Home
    VerifyText        New Submission
    VerifyText        Existing Submission
    VerifyText        Existing Policy Submission
    ClickText         Next

    UseModal          On
    VerifyText        New Submission
    VerifyText        Record Type
    ClickText         Aqueous                 anchor=Record Type
    VerifyText        Product
    ClickText         Professional Indemnity                 anchor=Product
    ClickText         Next                        anchor=Cancel
    UseModal          Off
    Log To Console    ----- New Submission Fields Validated Successfully -----
