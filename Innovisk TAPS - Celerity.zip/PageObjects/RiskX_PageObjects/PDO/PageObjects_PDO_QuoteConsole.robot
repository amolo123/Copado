*** Settings ***
Library                    QWeb
Library                    QForce
#Library                   QVision
Library                    FakerLibrary
Library                    String
Library                    BuiltIn
Library                    DateTime
Resource                   ../../../resources/common.robot
Resource                   ../PageObjects_Accounts.robot
Resource                   ../PageObjects_HomePage.robot



*** Keywords ***
Verify the details displayed on Quote console page for Primary and Excess Quote
    # Author = Amol Gaymukhe
    [Documentation]        Validating All Fields Of Quote Console
    [tags]                 Quote Console
    VerifyAll              Quote Console, Primary Quote, Excess Quotes, Generate Document, View Document, New Primary Quote, New Excess Quote, Expand All, Collapse All
    VerifyAll              Quote Data, Quote Type, Effective Date, Expiration Date, Commission %, State, MGA Fee, Underwriter Comments
    VerifyAll              Premium Data, Technical Premium, Quote Premium, Transaction Premium, Override Premium, Override Rationale, Total Premium, Override Premium %, Minimum Premium
    VerifyAll              Additional Data, Open Subjectivity, Aggregate Info, Agg Limit, Retention Insuring Agreement A, Derivative Demand Sublimit, Insuring Agg B Retention Non Securities
    VerifyAll              Insuring Agg B and C Retention Securities, Coverage, Schedule Modifiers, Make up of Board ( - ), Longevity of Board and Senior Management ( - ), Quality of Corporate Governance ( - )
    VerifyAll              Risk Modifiers, Industry (0.800 - 1.150), State (1.000 - 1.000), Historic Stock Volatility (0.750 - 1.750), Insider Trading in last 6-9 months (0.750 - 1.500), Short Position (0.900 - 1.200)
    VerifyAll              Activist Shareholders holdings (1.000 - 1.250), Nature/Complexity of Operations (0.850 - 1.250), Merger and Acquisition (0.950 - 1.250), Regulatory Environment (0.950 - 1.500), Auditor Change (0.950 - 1.250), Accounting Concerns (1.000 - 1.250)
    VerifyAll              Revenue Growth (0.900 - 1.300), Regulatory Investigations (0.950 - 1.250), Class Action Lawsuits (0.950 - 1.250), Corporate Litigation (0.950 - 1.250), Prior Acts (0.700 - 1.000), Stock Offering (1.000 - 5.000), Rating Mod Rationale

    ClickText              New Excess Quote
    VerifyText             //a[@title\='${uniquename} Celerity_PublicDO Excess 1']                             timeout=60s

    VerifyAll              Quote Console, Primary Quote, Excess Quotes, Generate Document, View Document, New Primary Quote, New Excess Quote, Expand All, Collapse All
    VerifyAll              Quote Data, Quote Type, Effective Date, Expiration Date, Commission %, State, MGA Fee, Underwriter Comments
    VerifyAll              Premium Data, Technical Premium, Quote Premium, Transaction Premium, Override Premium, Override Rationale, Total Premium, Override Premium %, Minimum Premium
    VerifyAll              Additional Data, Open Subjectivity, Aggregate Info, Agg Limit, Attachment Point, Derivative Demand Sublimit, Insuring Agg B Retention Non Securities, Insuring Agg B and C Retention Securities, Coverage
    VerifyAll              Schedule Modifiers, Make up of Board ( - ), Longevity of Board and Senior Management ( - ), Quality of Corporate Governance ( - )
    VerifyAll              Risk Modifiers, Industry (0.800 - 1.150), State (1.000 - 1.000), Historic Stock Volatility (0.750 - 1.750), Insider Trading in last 6-9 months (0.750 - 1.500), Short Position (0.900 - 1.200), Activist Shareholders holdings (1.000 - 1.250)
    VerifyAll              Nature/Complexity of Operations (0.850 - 1.250), Merger and Acquisition (0.950 - 1.250), Regulatory Environment (0.950 - 1.500), Auditor Change (0.950 - 1.250), Accounting Concerns (1.000 - 1.250), Revenue Growth (0.900 - 1.300), Regulatory Investigations (0.950 - 1.250)
    VerifyAll              Class Action Lawsuits (0.950 - 1.250), Corporate Litigation (0.950 - 1.250), Prior Acts (0.700 - 1.000), Stock Offering (1.000 - 5.000), Rating Mod Rationale



Rate Quote Click
    # Author = Amol Gaymukhe
    [Documentation]        Validating Rating Of Quote Console
    [tags]                 Quote Console
    ClickElement           //button[@title\='Rating test']
    VerifyText             Success                     anchor=Rating successful!                               partial_match=false    timeout=65s


Click On Save  
    # Author = Amol Gaymukhe
    [tags]                 Compare and Rate
    ClickElement           //span[text()\='Save']
    VerifyText             Confirmation
    ClickText              Confirm                     anchor=Cancel
    VerifyText             Success                     anchor=Update records successfully!                     partial_match=false    timeout=65s


Click On Finalize 
    # Author = Amol Gaymukhe
    [tags]                 Compare and Rate
    ClickElement           //lightning-icon[@title\='Finalize Quote']
    VerifyText             Success                     anchor=Finalize quote and Document Generation Successful!              partial_match=false    timeout=65s

Verify Bind Page Elements
    # Author = Amol Gaymukhe
    ClickElement           //lightning-icon[@title\='Bind']
    VerifyAll              Bind Quote, Account Name, Broker, Expiry Date, Surplus License Broker, Pay plan, Agency broker license, Individual broker license
    VerifyText             Effective Date              anchor=2
    VerifyText             Commission %                anchor=2
    VerifyText             Quote Premium               anchor=2
    ClickText              Cancel                      anchor=Bind

Click On Bind Button
    # Author = Amol Gaymukhe
    ClickElement           //lightning-icon[@title\='Bind']
    VerifyText             Bind Quote
    ClickElement           (//span[text()\='Select Item 1'])[last()]
    ClickText              Bind                        anchor=Cancel
    VerifyText             Success                     anchor=Bind Quote Successful                            partial_match=false    timeout=65s

Click On Clone
    # Author = Amol Gaymukhe
    [tags]                 Compare and Rate
    ClickElement           //button[@title\='Clone Quote']
    VerifyText             //a[@title\='${uniquename} Celerity_PublicDO Primary 2']                            timeout=25s

Close Clone Quote
    # Author = Amol Gaymukhe
    [tags]                 Compare and Rate
    ClickElement           (//span[text()\='Show menu'])[last()]
    ClickText              Close Quote
    VerifyText             Closed Reason
    ClickText              Closed Reason
    ClickText              No activity
    ClickText              Yes                         anchor=No


Click On Endorsement and Subjectivity
    # Author = Amol Gaymukhe
    [tags]                 Compare and Rate
    ClickElement           //lightning-icon[@title\='Endorsements & Subjectivities']


Select Endorsements
    #Author=Amol Gaymukhe
    [Documentation]        Selecting Endorsements
    VerifyText             Endorsement and Subjectivity
    UseModal               On

    ClickElement           //span[text()\='Select Item 1']
    ClickElement           //span[text()\='Select Item 2']
    ClickElement           //button[@title\='Add']
    VerifyText             Success                     anchor=The data is saved successfully
    ClickText              Save                        anchor=Return Quote Process
    ClickText              Return Quote Process
    Log To Console         ----- Endorsements selected successful------


Select Subjectivities
    #Author=Amol Gaymukhe
    [Documentation]        Selecting Endorsements
    VerifyText             Endorsement and Subjectivity
    UseModal               On
    ClickText              Subjectivities              anchor=Manuscript Endorsements
    ClickElement           (//table[@c-subjectivitylayout_subjectivitylayout]//input[@type\='checkbox'])[2]

    ClickElement           //button[@title\='Add']
    VerifyText             Success                     anchor=Subjectivities added successfully.
    ClickText              Return Quote Process


Enter Data In Override Premium  
    #Author=Amol Gaymukhe
    [Documentation]        Selecting Override Premium
    ClickElement           (//div[@data-id\='PremiumData'])[4]
    TypeText               (//div[@data-id\='PremiumData'])[4]//input              1000
    ClickElement           (//div[@data-id\='PremiumData'])[5]
    TypeText               (//div[@data-id\='PremiumData'])[5]//input              500

Get Premium Value before Override
    #Author=Amol Gaymukhe
    [Documentation]        Selecting Override Premium
    ${before_pre}=         GetText                     //lightning-formatted-number
    ${before_pre1}=        Remove String               ${before_pre}               $
    Set Global Variable    ${before_pre1}

Get Premium Value after Override and check change
    #Author=Amol Gaymukhe
    [Documentation]        Selecting Override Premium
    ${after_pre}=          GetText                     //lightning-formatted-number
    ${after_pre1}=         Remove String               ${after_pre}                $
    Set Global Variable    ${after_pre1}
    Log To Console         ${before_pre1}
    Log To Console         ${after_pre1}
    IF                     "${before_pre1}" == "${after_pre1}"
        Fail
    ELSE
        Log To Console     Success
    END


Click On Generate Document
    # Author = Amol Gaymukhe
    [tags]                 Compare and Rate
    ClickElement           //lightning-icon[@title\='View Document']
    VerifyText             Success                     anchor=Document has been downloaded successfully!       timeout=65s

Get Quote Letter Dynamic Document PDO
    # Author = Amol Gaymukhe
    ${Quote_date}=         Get Current Date            result_format=%B %-d, %Y
    Log To Console         ${Quote_date}
    Set Global Variable    ${Quote_date}

    # ${pdf_agency}=       GetText                     //p[text()\='Agency']/parent::*//a
    # Log To Console       ${pdf_agency}
    # Set Global Variable                              ${pdf_agency}

    ${eff_date}=           GetInputValue               //input[contains(@name,'-Effective Date')]
    Log To Console         ${eff_date}
    Set Global Variable    ${eff_date}

    ${fr1}=                Convert Date                ${eff_date}                 date_format=%m/%d/%Y
    ${eff_date_final}=     Convert Date                ${fr1}                      result_format=%B %-d, %Y
    Set Global Variable    ${eff_date_final}


    ${exp_date}=           GetInputValue               //input[contains(@name,'-Expiration Date')]
    Log To Console         ${exp_date}
    Set Global Variable    ${exp_date}


    #${conv2}=             Convert Date                ${exp_date}                 result_format=%B %m, %Y
    ${from1}=              Convert Date                ${exp_date}                 date_format=%m/%d/%Y
    ${exp_final}=          Convert Date                ${from1}                    result_format=%B %-d, %Y
    Set Global Variable    ${exp_final}

    #Premium
    ${premium}=            GetInputValue               //input[contains(@name,'-Technical Premium')]
    Log To Console         ${premium}

    ${premium2}=           Remove String               ${premium}                  $                           .00
    ${PDF_Premium}=        Set Variable                ${premium2}
    Set Global Variable    ${PDF_Premium}

    #Policy Fee
    ${pol_fee}=            GetInputValue               //input[contains(@name,'-MGA Fee')]
    Log To Console         ${pol_fee}

    ${polfee2}=            Remove String               ${pol_fee}                  $                           .00
    ${PDF_PolFee}=         Set Variable                ${polfee2}
    Set Global Variable    ${PDF_PolFee}

    #Total Premium
    ${tota_premium}=       GetInputValue               //input[contains(@name,'-Total Premium')]
    Log To Console         ${tota_premium}

    ${totalfee2}=          Remove String               ${tota_premium}             $                           .00
    ${PDF_TotalFee}=       Set Variable                ${totalfee2}
    Set Global Variable    ${PDF_TotalFee}
