*** Settings ***
Library                QWeb
Library                QForce
#Library               QVision
Library                FakerLibrary
Library                String
Library                BuiltIn
Library                DateTime

Resource               ../../../resources/common.robot
Resource               ../PageObjects_Accounts.robot
Resource               ../PageObjects_Submissions.robot
Resource               ../../../resources/ReadPDF.robot
Resource               ../Celerity_Common.robot
Resource               ../../../resources/common.robot
Resource               ../../../PageObjects/RiskX_PageObjects/PDO/PageObjects_PDO_SubmissionInfo.robot
Resource               ../../../PageObjects/RiskX_PageObjects/PDO/PageObjects_PDO_UnderwrittingConsole.robot
Resource               ../../../PageObjects/RiskX_PageObjects/PDO/PageObjects_PDO_QuoteConsole.robot

*** Keywords ***
Read Doc Quote Letter Static Document PDO
    #Author=Amol Gaymukhe
    [Documentation]    Read Static data of Quote Letter
    [Tags]             smoke                       regression
    Test PDF File      PUBLIC COMPANY QUOTE
    Test PDF File      Completed Surplus Lines Tax Form (PRIOR TO BINDING)
    Test PDF File      PREMIUM:
    Test PDF File      MGA FEE:
    Test PDF File      TOTAL PAYABLE:
    Test PDF File      LIST OF APPLICABLE ENDORSEMENTS
    Test PDF File      Underwriter Comments:


Read Doc Quote Letter Dynamic Document PDO
    #Author=Amol Gaymukhe
    [Documentation]    Read Static data of Quote Letter
    [Tags]             smoke                       regression
    Test PDF File      ${Quote_date}
    Test PDF File      ${uniqueName}
    Test PDF File      ${eff_date_final} to ${exp_final}
    Test PDF File      $${PDF_Premium}
    Test PDF File      $${PDF_PolFee}
    Test PDF File      $${PDF_TotalFee}


Read Binder Letter Static Document PDO
    #Author=Amol Gaymukhe
    [Documentation]    Read Static data of Policy Letter
    [Tags]             smoke                       regression
    Test PDF File      FRAUD NOTICE
    # Test PDF File      SURPLUS LINES NOTICE
    Read State wise Surplus License
    Test PDF File      PUBLIC COMPANY
    Test PDF File      CONDITIONAL BINDER
    Test PDF File      Completed Surplus Lines Tax Form (PRIOR TO BINDING)
    Test PDF File      NAMED INSURED:
    Test PDF File      PREMIUM:
    Test PDF File      MGA FEE:
    Test PDF File      LIST OF APPLICABLE ENDORSEMENTS


Read Binder Letter Dynamic Document PDO  
    #Author=Amol Gaymukhe
    [Documentation]    Read Static data of Quote Letter
    [Tags]             smoke                       regression
    Test PDF File      ${Quote_date}
    Test PDF File      ${uniqueName}
    Test PDF File      ${eff_date_final} to ${exp_final}
    Test PDF File      $${PDF_Premium}
    Test PDF File      $${PDF_PolFee}
    Test PDF File      $${PDF_TotalFee}


Read Policy Letter Static Document PDO
    #Author=Amol Gaymukhe
    [Documentation]    Read Static data of Policy Letter
    [Tags]             smoke                       regression
    Test PDF File      This Insurance
    Test PDF File      The Insured
    Test PDF File      Previous
    Test PDF File      Name and address of the Assured:
    Test PDF File      Effective from
    Test PDF File      FRAUD NOTICE
    #Test PDF File      SURPLUS LINES NOTICE
    #Test PDF File      NOTICE TO INSURED
    Test PDF File      CELERITY RISK PUBLIC COMPANY D&O INSURANCE POLICY
    Read State wise Surplus License


Read Policy Letter Dynamic Document PDO  
    #Author=Amol Gaymukhe
    [Documentation]    Read Static data of Quote Letter
    [Tags]             smoke                       regression
    Test PDF File      ${Quote_date}
    Test PDF File      ${uniqueName}
    Test PDF File      ${eff_date}
    Test PDF File      ${exp_date}
    Test PDF File      $${PDF_Premium}
    Test PDF File      $${PDF_PolFee}
    Test PDF File      $${PDF_TotalFee}


Read Change Endorsement Letter Static Document PDO
    #Author=Amol Gaymukhe
    [Documentation]    Read Static data of Policy Letter
    [Tags]             smoke                       regression
    Test PDF File      The attached forms(s) amend your policy.

Read Change Endorsement Letter Dynamic Document PDO  
    #Author=Amol Gaymukhe
    [Documentation]    Read Static data of Quote Letter
    [Tags]             smoke                       regression


Read State wise Surplus License
    #Author=Amol Gaymukhe
    [Documentation]             Read Static data for State wise surplus license
    [Tags]                      smoke                       regression


    #${billingaddressState}=     GetText                     ${billingaddressState}
    Log To Console              ${billingaddressState}

    IF                          "${billingaddressState}" == 'Arizona'
        Log To Console          {billingaddressState}
        Test PDF File           ARIZONA POLICYHOLDER NOTICE


    ELSE IF                     "${billingaddressState}" == 'California'

        Log To Console          {billingaddressState}
        Test PDF File           CALIFORNIA POLICYHOLDER NOTICE

    ELSE IF                     "${billingaddressState}" == 'Texas'

        Log To Console          {billingaddressState}
        Test PDF File           TEXAS POLICYHOLDER NOTICE

    ELSE IF                     "${billingaddressState}" == 'Oregon'

        Log To Console          {billingaddressState}
        Test PDF File           OREGON POLICYHOLDER NOTICE

    ELSE IF                     "${billingaddressState}" == 'Alaska'

        Log To Console          {billingaddressState}
        Test PDF File           ALASKA POLICYHOLDER NOTICE

    ELSE
        Fail
    END