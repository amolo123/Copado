*** Settings ***
Library                QWeb
Library                QForce
#Library               QVision
Library                FakerLibrary
Library                String
Library                BuiltIn
Library                DateTime
Resource               ../../../resources/common.robot
Resource               ../PageObjects_Accounts.robot
Resource               ../PageObjects_HomePage.robot



*** Keywords ***
Validate the picklist and button displayed on Underwriting Console
    # Author = Amol Gaymukhe
    [Documentation]    Validating All Fields Of Underwriting Console
    [tags]             Underwriting Console
    VerifyAll          < PREVIOUS:Submission Console, Save, New Primary Quote, New Excess Quote
    VerifyAll          Industry & Sector, Nature of Operations, Domicile of Risk, Market Capitalization (Current), Historic and Implied Stock Performance, Quality of Management, Insider/ Maj Shareholder sales- Include 10B51
    VerifyAll          Accounting Changes, CFO and Accounting Firm Changes, ESG Score (Environmental Social Governance), Cyber Exposure/Disclosures, IPO Status, SPACs, Other Offerings, M&A Activity: Consider higher M&A retention versus securities retention, Classes of Common & Preferred Stock, Prior Claim Activity (Timing)
    VerifyAll          Market Cap, Celerity_PublicDO Notes

Verify that the Submission gets decline when u/w select the answer of the question whose status is Stop!Decline!
    # Author = Amol Gaymukhe
    [Documentation]    Validating All Fields Of Underwriting Console
    [tags]             Underwriting Console
    ClickElement       //span[text()\='Nature of Operations']/ancestor::lightning-layout//button
    ClickText          None of the above

    ClickElement       //span[text()\='Domicile of Risk']/ancestor::lightning-layout//button
    ClickText          All other states

    ClickElement       //span[text()\='Market Capitalization (Current)']/ancestor::lightning-layout//button
    ClickText          Largecap (Over $10B)

    ClickElement       //span[text()\='Historic and Implied Stock Performance']/ancestor::lightning-layout//button
    ClickText          //span[text()\='Historic and Implied Stock Performance']/ancestor::lightning-layout//lightning-base-combobox-item[@data-value\='None of the above']

    ClickElement       //span[text()\='Quality of Management']/ancestor::lightning-layout//button
    ClickText          Board and senior management have robust resumes and are not controversial persons

    ClickElement       //span[text()\='Insider/ Maj Shareholder sales- Include 10B51, exercised options - 10%+ holders']/ancestor::lightning-layout//button
    ClickText          Insiders and majority holders showing little or stable pattern of insider sales past 24 months

    ClickElement       //span[text()\="Accounting Changes: Search 10K,10Q, public docs for 'altered', 'modified', etc."]/ancestor::lightning-layout//button
    ClickText          No material changes in rev recognition, allowance for bad debt or product returns, inventory valuation, est. useful life, depreciation, backlog, or other key accounting changes, estimates, assumptions, or classifications in the past 12 months

    ClickElement       //span[text()\='CFO and Accounting Firm Changes']/ancestor::lightning-layout//button
    ClickText          Chief Financial Officer (CFO) and Accounting Firm in place more than 12 months - Proceed

    ClickElement       //span[text()\='ESG Score (Environmental Social Governance)']/ancestor::lightning-layout//button
    ClickText          //span[text()\='ESG Score (Environmental Social Governance)']/ancestor::lightning-layout//lightning-base-combobox-item[@data-value\='None']


    ClickElement       //span[text()\='Cyber Exposure/Disclosures']/ancestor::lightning-layout//button
    ClickText          Public disclosures appear more than adequate

    ClickElement       //span[text()\='IPO Status']/ancestor::lightning-layout//button
    ClickText          Four or more years since IPO

    ClickElement       //span[text()\='SPACs']/ancestor::lightning-layout//button
    ClickText          //span[text()\='SPACs']/ancestor::lightning-layout//lightning-base-combobox-item[@data-value\='None']


    ClickElement       //span[text()\='Other Offerings']/ancestor::lightning-layout//button
    ClickText          //span[text()\='Other Offerings']/ancestor::lightning-layout//lightning-base-combobox-item[@data-value\='None']


    ClickElement       //span[text()\='M&A Activity: Consider higher M&A retention versus securities retention']/ancestor::lightning-layout//button
    ClickText          No merger or acquisition activity in the past 12 months

    ClickElement       //span[text()\='Classes of Common & Preferred Stock']/ancestor::lightning-layout//button
    ClickText          One class of shares (common only)

    ClickElement       //span[text()\='Prior Claim Activity (Timing)']/ancestor::lightning-layout//button
    ClickText          More than one securities claim, other claim, demand, administrative proceeding, complaints or other filed lawsuit in prior 3 years

    TypeText           Market Cap                  4000000
    ClickText          Save                        anchor=New Primary Quote
    VerifyText         Auto Decline!               anchor=Due to Stop Auto Decline condition, your submission will be Declined. Please select a Decline Reason    timeout=35s
   
    VerifyText         Account Information         timeout=25s
    VerifyText         Declined                    anchor=Stage


Verify that the Underwriting analysis details are saved successfully 
    # Author = Amol Gaymukhe
    [Documentation]    Validating All Fields Of Underwriting Console
    [tags]             Underwriting Console
    ClickElement       //span[text()\='Nature of Operations']/ancestor::lightning-layout//button
    ClickText          None of the above

    ClickElement       //span[text()\='Domicile of Risk']/ancestor::lightning-layout//button
    ClickText          All other states

    ClickElement       //span[text()\='Market Capitalization (Current)']/ancestor::lightning-layout//button
    ClickText          Microcap (Up to $500M)

    ClickElement       //span[text()\='Historic and Implied Stock Performance']/ancestor::lightning-layout//button
    ClickText          //span[text()\='Historic and Implied Stock Performance']/ancestor::lightning-layout//lightning-base-combobox-item[@data-value\='None of the above']

    ClickElement       //span[text()\='Quality of Management']/ancestor::lightning-layout//button
    ClickText          Board and senior management have robust resumes and are not controversial persons

    ClickElement       //span[text()\='Insider/ Maj Shareholder sales- Include 10B51, exercised options - 10%+ holders']/ancestor::lightning-layout//button
    ClickText          Insiders and majority holders showing little or stable pattern of insider sales past 24 months

    ClickElement       //span[text()\="Accounting Changes: Search 10K,10Q, public docs for 'altered', 'modified', etc."]/ancestor::lightning-layout//button
    ClickText          No material changes in rev recognition, allowance for bad debt or product returns, inventory valuation, est. useful life, depreciation, backlog, or other key accounting changes, estimates, assumptions, or classifications in the past 12 months

    ClickElement       //span[text()\='CFO and Accounting Firm Changes']/ancestor::lightning-layout//button
    ClickText          Chief Financial Officer (CFO) and Accounting Firm in place more than 12 months - Proceed

    ClickElement       //span[text()\='ESG Score (Environmental Social Governance)']/ancestor::lightning-layout//button
    ClickText          //span[text()\='ESG Score (Environmental Social Governance)']/ancestor::lightning-layout//lightning-base-combobox-item[@data-value\='None']


    ClickElement       //span[text()\='Cyber Exposure/Disclosures']/ancestor::lightning-layout//button
    ClickText          Public disclosures appear more than adequate

    ClickElement       //span[text()\='IPO Status']/ancestor::lightning-layout//button
    ClickText          Four or more years since IPO

    ClickElement       //span[text()\='SPACs']/ancestor::lightning-layout//button
    ClickText          //span[text()\='SPACs']/ancestor::lightning-layout//lightning-base-combobox-item[@data-value\='None']


    ClickElement       //span[text()\='Other Offerings']/ancestor::lightning-layout//button
    ClickText          //span[text()\='Other Offerings']/ancestor::lightning-layout//lightning-base-combobox-item[@data-value\='None']


    ClickElement       //span[text()\='M&A Activity: Consider higher M&A retention versus securities retention']/ancestor::lightning-layout//button
    ClickText          No merger or acquisition activity in the past 12 months

    ClickElement       //span[text()\='Classes of Common & Preferred Stock']/ancestor::lightning-layout//button
    ClickText          One class of shares (common only)

    ClickElement       //span[text()\='Prior Claim Activity (Timing)']/ancestor::lightning-layout//button
    ClickText          No securities claims, other claims, demands, administrative proceedings, complaints or other filed lawsuits in prior 3 years

    TypeText           Market Cap                  4000000
    ClickText          Save                        anchor=New Primary Quote

