*** Settings ***
Library                QWeb
Library                QForce
#Library               QVision
Library                FakerLibrary
Library                String
Library                BuiltIn
Library                DateTime
Resource               ../../../resources/common.robot
Resource               ../PageObjects_Accounts.robot
Resource               ../PageObjects_HomePage.robot



*** Keywords ***

Validate field on Insured Info page for PDO
    # Author = Amol Gaymukhe
    [Documentation]    Validating All Fields Of Submission Console
    [tags]             Submission Console
    ClickText          Home                        anchor=Celerity Underwriting
    VerifyText         Celerity Underwriting       anchor=Home
    ClickText          Public D&O
    ClickElement       (//input[@placeholder\="Search..."])[1]
    TypeText           Search...                   ${uniqueName}               anchor=Insured Name
    ClickElement       (//li[@role\='presentation']/span)[1]
    Log To Console     ----- Insured Info page Add Account Verified Successfully -----

    sleep              5s
    ClickText          Save                        anchor=NEXT:Underwriting Console >
    VerifyText         Success                     anchor=Account updated

    Log To Console     ----- Account added -----

    VerifyAll          Account Name, Effective Date, Expiration Date, Industry, Service Classification, PostalCode, Underwriting Console, Submission Console, Quote Console
    VerifyText         Save
    VerifyAll          Account Name, Broker Contact, Billing Address, Relationship Type, Country, Primary Broker?, Street, Alien Broker, City, State, PostalCode, Company Info,Ticker symbol

    VerifyText         https://www.sec.gov
    VerifyText         https://www.otcmarkets.com/index.html
    VerifyText         https://finance.yahoo.com/
    VerifyText         https://securities.stanford.edu/
    VerifyText         https://stockanalysis.com/

    VerifyAll          Industry, Service Classification, Effective Date, Received Date, Expiration Date, Close Date, Retroactive Date, Prior/Pending Litigation Date, Stage, Closed Reason, Type, Submission Owner, Broker Layer Requested, Carrier, Limits, Retention, Premium
    VerifyText         NEXT:Underwriting Console >
    Log To Console     ----- Submission Info Validated Successfully-----


Add the details displayed on Additional Insured Details
    # Author = Amol Gaymukhe
    [Documentation]    Validating All Fields Of Submission Console
    [tags]             Submission Console
    ClickElement       //button[text()\='New']
    UseModal           On
    VerifyText         Additional Insured Details                              anchor=3
    TypeText           //label[text()\='Additional Account']/parent::*/following::div//input          Akshay
    ClickText          //label[text()\='Additional Account']/parent::*/following::div//input
    ClickText          Akshay Data
    ClickText          Save                        anchor=Cancel
    VerifyText         Success                     anchor=Additional Insured Account is added successfully!          partial_match=false    timeout=35s

    
Validate the details displayed on Additional Insured Details pop up
    # Author = Amol Gaymukhe
    [Documentation]    Validating All Fields Of Submission Console
    [tags]             Submission Console
    # ClickElement       //button[text()\='New']
    # UseModal           On
    # VerifyText         Additional Insured Details                              anchor=3
    # VerifyText         Submission                  anchor=Additional Account
    # VerifyText         Additional Insured Name     anchor=Additional Account
    # VerifyText         Additional Account
    # TypeText           //label[text()\='Additional Account']/parent::*/following::div//input          Akshay
    # ClickText          //label[text()\='Additional Account']/parent::*/following::div//input
    # VerifyText         Akshay Data
    # ClickText          Cancel                      anchor=Save

Validate Ask Ollie
    # Author = Amol Gaymukhe
    [Documentation]    Validating All Fields Of Ask Ollie
    [tags]             Submission Console
    ClickElement       //button[text()\='Ask Ollie']
    CloseWindow

Enter data on Submission info Page for PDO
    # Author = Amol Gaymukhe
    [Documentation]    Validating All Fields Of Submission Console
    [tags]             Insured Info
    ClickText          Home                        anchor=Celerity Underwriting
    VerifyText         Celerity Underwriting       anchor=Home
    ClickText          Public D&O
    ClickElement       (//input[@placeholder\="Search..."])[1]
    TypeText           Search...                   ${uniqueName}               anchor=Insured Name
    ClickElement       (//li[@role\='presentation']/span)[1]
    Log To Console     ----- Insured Info page Add Account Verified Successfully -----

    sleep              5s
    ClickText          Save                        anchor=NEXT:Underwriting Console >
    VerifyText         Success!                    anchor=Record is saved !    timeout=35s
    Log To Console     ----- Data Entered On Submission Console Page Successfully ---------------


Add Data In submission console
    # Author = Amol Gaymukhe
    [Documentation]    Validating All Fields Of Submission Console
    [tags]             Insured Info
    TypeText           (//label[text()\='Broker Contact']/parent::*//input)[last()]                   Celerity Automation
    ClickElement       (//label[text()\='Broker Contact']/parent::*//input)[last()]
    #ClickText          Celerity Automation - Pinki L - New York - New York
    ClickText          Celerity Automation

    TypeText           Retroactive Date            12/12/2022
    TypeText           Prior/Pending Litigation Date                           12/12/2023
    ClickText          Broker Layer Requested
    ClickText          Primary
    TypeText           Carrier                     PDO Carrier
    TypeText           Limits                      1000000
    TypeText           Retention                   2000000
    TypeText           Premium                     3000000

    ClickText          //label[text()\='Industry']/parent::div//lightning-base-combobox
    ClickText          Business Services
    ClickText          //label[text()\='Service Classification']/parent::div//lightning-base-combobox
    ClickText          Accounting & Auditing



Validate the Industry drop picklist value and Service Classification picklist values
    # Author = Amol Gaymukhe
    [Documentation]    Validating All Fields Of Submission Console
    [tags]             Insured Info

    ScrollText         Ticker symbol
    VerifyText         Industry                    anchor=Service Classification
    ClickText          //label[text()\='Industry']/parent::div//lightning-base-combobox
    ClickText          --None--

    ClickText          //label[text()\='Industry']/parent::div//lightning-base-combobox
    ClickText          Aerospace & Defense
    ClickText          //label[text()\='Service Classification']/parent::div//lightning-base-combobox
    VerifyText         Manufacturing Electronics & All Other

    ClickText          //label[text()\='Industry']/parent::div//lightning-base-combobox
    ClickText          Agriculture Forestry Fishing
    ClickText          //label[text()\='Service Classification']/parent::div//lightning-base-combobox
    VerifyAll          Agricultural Services Forestry Livestock Fisheries Crops, Cannabis Growers

    ClickText          //label[text()\='Industry']/parent::div//lightning-base-combobox
    ClickText          Basic Materials
    ClickText          //label[text()\='Service Classification']/parent::div//lightning-base-combobox
    VerifyAll          Chemical (Manufacturing), Industrial Metals & Mining (Service Industry/Manufacturing/Transportation), Precious Metals

    ClickText          //label[text()\='Industry']/parent::div//lightning-base-combobox
    ClickText          Biotechnology
    ClickText          //label[text()\='Service Classification']/parent::div//lightning-base-combobox
    VerifyAll          All other Biotech, Life Sciences, Medical Devices Supplies and Products, Pharmaceutical

    ClickText          //label[text()\='Industry']/parent::div//lightning-base-combobox
    ClickText          Business Services
    ClickText          //label[text()\='Service Classification']/parent::div//lightning-base-combobox
    VerifyAll          Accounting & Auditing, Accreditation & Certification Services, Administrators, Advertising & Marketing Agencies, Alarm Monitors, Architectural & Engineering, Auctioneer, Audio/Video, Billing Services, Bookkeeper & Record Keeper, Business Training & Seminars, Collection Agencies, Court Reporting, Direct Mail Advertising, Dispute Resolution, Employment Agencies, Energy & Environmental Consulting, Event Planner, Executive Placement, Franchisors, Funeral & Crematories,General Consulting, Interior & Graphic Design, Legal Services, Literary Agents, Management & Business Consulting, Membership Organizations, Modeling/Talent Agency, Notary Public, Office Management, Pet Related Services, Photographic Studios, Printers, Process Server, Research /Laboratory & Testing Services, Tax Preparation (NON-CPA SERVICES), Telemarketing, Translation & Interpretation Services, Trustees, Yacht/Boat Broker

    ClickText          //label[text()\='Industry']/parent::div//lightning-base-combobox
    ClickText          Construction
    ClickText          //label[text()\='Service Classification']/parent::div//lightning-base-combobox
    VerifyAll          Building Construction, General & Subcontractors, Heavy Construction

    ClickText          //label[text()\='Industry']/parent::div//lightning-base-combobox
    ClickText          Education
    ClickText          //label[text()\='Service Classification']/parent::div//lightning-base-combobox
    VerifyAll          Educational Support & Test Development, Elementary and Secondary Schools, Exam Preparation and Tutoring, For-Profit Universities and Colleges, Vocational & Trade Schools

    ClickText          //label[text()\='Industry']/parent::div//lightning-base-combobox
    ClickText          Financial
    ClickText          //label[text()\='Service Classification']/parent::div//lightning-base-combobox
    VerifyAll          Commercial Bank - National, Commercial Bank - State/Regional, Consumer Credit Reporting, Credit Union, Crypto Exchanges, Financial Technology (FinTech), Investment Advisors/Portfolio Management, Investment Bank, Loan Servicing, Mortgage Banker & Lender, Mortgage Broker, Non - Depository Institutions, Payment & Credit Card Processors, Private Equity/Venture Capital/Hedge Fund, Security & Commodity Brokers, Security & Commodity Exchanges, Stock Transfer Agent

    ClickText          //label[text()\='Industry']/parent::div//lightning-base-combobox
    ClickText          Financial & Insurance
    ClickText          //label[text()\='Service Classification']/parent::div//lightning-base-combobox
    VerifyAll          All other Financial & Insurance

    ClickText          //label[text()\='Industry']/parent::div//lightning-base-combobox
    ClickText          Healthcare
    ClickText          //label[text()\='Service Classification']/parent::div//lightning-base-combobox
    VerifyAll          Allied Health, All Other Healthcare, Hospital (<500 beds), Hospital (>500 beds), Marijuana, Medical Laboratories, Medical Office, Nursing Homes

    ClickText          //label[text()\='Industry']/parent::div//lightning-base-combobox
    ClickText          Insurance                   anchor=Leisure
    ClickText          //label[text()\='Service Classification']/parent::div//lightning-base-combobox
    VerifyAll          Insurance (Title Company), Insurance Agents & Brokers, Insurance Company (Life), Insurance Company (P&C), Insurance Technology-InsurTech, Managing General Agent/Third Party Administrator

    ClickText          //label[text()\='Industry']/parent::div//lightning-base-combobox
    ClickText          Leisure
    ClickText          //label[text()\='Service Classification']/parent::div//lightning-base-combobox
    VerifyAll          Casinos & Gaming, Hotels & Motels, Professional Sports Leagues, Restaurants & Bars, Sports & Recreation

    ClickText          //label[text()\='Industry']/parent::div//lightning-base-combobox
    ClickText          Manufacturing
    ClickText          //label[text()\='Service Classification']/parent::div//lightning-base-combobox
    VerifyAll          All other Manufacturing, Ammunition and Firearms, Apparel and other Finished Products, Beverages (Alcoholic), Beverages (Non-Alcoholic), Chemical and Allied Products, Computer Equipment Electronic and other Electrical Equipment, Food and Kindred Products, Nutraceutical Manufacturing, Pharmaceutical, Tobacco and Vaping Products

    ClickText          //label[text()\='Industry']/parent::div//lightning-base-combobox
    ClickText          Media
    ClickText          //label[text()\='Service Classification']/parent::div//lightning-base-combobox
    VerifyAll          Broadcasting & Entertainment, Diversified Media, Media Agencies, Public Relations, Publishing, Streaming Services

    ClickText          //label[text()\='Industry']/parent::div//lightning-base-combobox
    ClickText          Oil & Gas
    ClickText          //label[text()\='Service Classification']/parent::div//lightning-base-combobox
    VerifyAll          Alternative Energy, Oil & Gas Producers, Oil Equipment Services & Distribution, Oil Exploration/Production

    ClickText          //label[text()\='Industry']/parent::div//lightning-base-combobox
    ClickText          Public Administration and Government Entities
    ClickText          //label[text()\='Service Classification']/parent::div//lightning-base-combobox
    VerifyAll          Municipalities, Public Administration and Government Entity


    ClickText          //label[text()\='Industry']/parent::div//lightning-base-combobox
    ClickText          Real Estate
    ClickText          //label[text()\='Service Classification']/parent::div//lightning-base-combobox
    VerifyAll          Commercial Appraisers, Commercial Property Management, Escrow Agent, Home Inspectors, Real Estate Agent, Real Estate Development, REIT, Relocation Agent, Residential Appraisers, Residential Property Management, Surveyor, Title Abstractor, Title Agent, Valuers / Valuation

    ClickText          //label[text()\='Industry']/parent::div//lightning-base-combobox
    ClickText          Retail
    ClickText          //label[text()\='Service Classification']/parent::div//lightning-base-combobox
    VerifyAll          Auto Dealership, Cannabis Stores, Food & Drug Retailer, General Retailer, Nutraceutricals Retail, Specialty Retail

    ClickText          //label[text()\='Industry']/parent::div//lightning-base-combobox
    ClickText          Technology
    ClickText          //label[text()\='Service Classification']/parent::div//lightning-base-combobox
    VerifyAll          Hardware: Design, Hardware: Manufacturing, Hardware: Resale (developed by others), Service Provider: Business Process Outsourcing, Service Provider: Cloud Service Provider, Service Provider: Data Center/Co-location, Service Provider: Domain Name Registrar, Service Provider: Internet Service Provider, Service Provider: IT Consulting, Service Provider: Managed Services/Security, Service Provider: Search Engine Optimization, Service Provider: Shared/Gig Economy, Service Provider: Telecommunications Services, Service Provider: Website Design, Service Provider: Website Hosting, Social Networking, Software: Custom Development, Software: Installation Integration & Support, Software: Mobile Application Development, Software: Pre-packaged Development, Software: Resale (developed by others), Software: Software as a Service

    ClickText          //label[text()\='Industry']/parent::div//lightning-base-combobox
    ClickText          Telecommunications
    ClickText          //label[text()\='Service Classification']/parent::div//lightning-base-combobox
    VerifyAll          Diversified Telecomm, Fixed Line Telecom, Mobile Telecom / Cable, Service & Repair

    ClickText          //label[text()\='Industry']/parent::div//lightning-base-combobox
    ClickText          Transportation
    ClickText          //label[text()\='Service Classification']/parent::div//lightning-base-combobox
    VerifyAll          Customs Broker, Freight (Truck Rail Air Ship), Freight Broker (no shipping), Freight Forwarder, Passenger Transportation, Sanitary & Refuse Systems, Travel Agencies/Tour Operators

    ClickText          //label[text()\='Industry']/parent::div//lightning-base-combobox
    ClickText          Utility (Electric Gas Telephone Water)
    ClickText          //label[text()\='Service Classification']/parent::div//lightning-base-combobox
    VerifyAll          Electric, Gas, Independent Power & Renewable Energy, Multi-Utilities, Water

    ClickText          //label[text()\='Industry']/parent::div//lightning-base-combobox
    ClickText          Wholesale Trade
    ClickText          //label[text()\='Service Classification']/parent::div//lightning-base-combobox
    VerifyAll          Durable Goods, Non-Durable Goods, Specialty Wholesale

    ClickText          //label[text()\='Industry']/parent::div//lightning-base-combobox
    ClickText          Default
    ClickText          //label[text()\='Service Classification']/parent::div//lightning-base-combobox
    VerifyAll          Default
