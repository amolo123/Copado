*** Settings ***
Library                         QWeb
Library                         QForce
Library                         String
Library                         Collections
Library                         DateTime
Library                         OperatingSystem
Library                         BuiltIn

Library                         ../../libraries/MailLib.py     ${tenant_id}                ${client_id_mail}         ${client_secret_mail}

Library                         ../../libraries/graph.py
Resource                        ../../resources/graph.resource
Library                         ../../libraries/read_docx.py



*** Keywords ***

Get WORD document and attach it to log
    [Documentation]             This keyword will read the downloaded document
    ...                         Will store it in a suite variable ${read_doc}
    ...                         And will attach it to the execution log
    Sleep                       10s

    IF                          "${EXECDIR}"=="/home/executor/execution"
    # normal test run environment
        ${downloads_folder}=    Set Variable                /home/executor/Downloads
    ELSE                        # Live Testing environment
        ${downloads_folder}=    Set Variable                /home/services/Downloads
    END
    Wait Until Keyword Succeeds                             30 sec                      2 sec                     Directory Should Exist    ${downloads_folder}
    @{list_files}               List Files In Directory     ${downloads_folder}         *.docx
    #@{list_files}              List Files In Directory     ${OUTPUT_DIR}               *.docx
    Log To Console              ${list_files}[0]
    Move File                   ${downloads_folder}/${list_files}[0]                    ${OUTPUT_DIR}
    Sleep                       2s
    #File Should Exist          ${downloads_folder}/${list_files}[0]
    #read Docx File             ${downloads_folder}/${list_files}[0]
    Log To Console              ${OUTPUT_DIR}/${list_files}[0]
    ${read_doc}=                read docx file              ${OUTPUT_DIR}/${list_files}[0]
    Log To Console              ${read_doc}
    #${testdoc}=                Get File                    ${OUTPUT_DIR}/${list_files}[0]
    # Attach file to log
    #Copy File                  ${downloads_folder}${list_files}[1]                     ${OUTPUT DIR}
    Set Suite Variable          ${read_doc}