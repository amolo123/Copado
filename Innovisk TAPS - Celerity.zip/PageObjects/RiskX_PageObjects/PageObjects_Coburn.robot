*** Settings ***
Library            QWeb
Library            QForce
#Library           QVision
Library            FakerLibrary
Library            String
Library            BuiltIn
Library            DateTime
Resource           ../../resources/common.robot



*** Keywords ***
Verify Billing Record details 
    [Arguments]    ${QuoteType_BR}
    # Author = Amol
    [tags]         Verify Billing Record details

    Click Text     Billing                     anchor=Payments
    Verify Text    Suppressed                  anchor=${QuoteType_BR}
    ClickText      BR                          anchor=Billing Record ID
    VerifyField    Invoice Status              Suppressed
