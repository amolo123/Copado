*** Settings ***
Library             QWeb
Library             QForce
#Library            QVision
Library             FakerLibrary
Library             String
Library             BuiltIn
Library             DateTime
Resource            ../../../resources/common.robot
Resource            ../PageObjects_Accounts.robot
Resource            ../PageObjects_Submissions.robot
Library             BuiltIn
Library             DateTime

*** Keywords ***

Verify Underwriter Analysis Page Elements
    # Author = Amol Gaymukhe
    [tags]          Insured Info
    VerifyText      Account                     partial_match=false
    VerifyText      Agency
    VerifyText      Underwriter                 partial_match=false
    VerifyText      Stage
    VerifyText      Effective Date
    VerifyText      Quoted Premium

    VerifyText      Base Rate
    VerifyText      Next Year Revenue
    VerifyText      Number of years Prior Acts coverage
    VerifyText      Cyber Intel Service
    VerifyText      Cyber Intel BitSight Rules

    VerifyText      Service Classification
    VerifyText      Significant Terms and Conditions Factor
    VerifyText      Cyber Intel Score
    VerifyText      Cyber Intel Failed Reason

    VerifyText      Exposure Information
    VerifyText      Current Year Revenue
    VerifyText      Previous Year Revenue
    VerifyText      PII Record Count
    VerifyText      PHI Record Count
    VerifyText      Social Security Record Count
    VerifyText      PCI Level
    VerifyText      Credit Card Record Count

    VerifyText      Rate Modifiers
    VerifyText      Security Controls
    VerifyText      Policies & Goverance
    VerifyText      Vendor Oversight
    VerifyText      Media
    VerifyText      Contracts
    VerifyText      Regulatory
    VerifyText      Social Engineering
    VerifyText      Eplace Score Range


Enter Data in Underwriter Analysis Page
    # Author = Amol Gaymukhe
    [tags]          Insured Info
    TypeText        //span[text()\='Next Year Revenue']/parent::*/following::td//input    5000000
    TypeText        Number of years Prior Acts coverage                2
    ClickElement    //span[text()\='Select an Option']/parent::*
    ClickText       Neutral


Enter Data in Underwriter Analysis Page Max Revenue 5000000000 
    # Author = Amol Gaymukhe
    [tags]          Insured Info
    TypeText        //span[text()\='Next Year Revenue']/parent::*/following::td//input    5000000000
    TypeText        Number of years Prior Acts coverage                2
    ClickElement    //span[text()\='Select an Option']/parent::*
    ClickText       Neutral
