*** Settings ***
Library                    QWeb
Library                    QForce
#Library                   QVision
Library                    FakerLibrary
Library                    String
Library                    BuiltIn
Library                    DateTime
Resource                   ../../../resources/common.robot
Resource                   ../PageObjects_Accounts.robot
Resource                   ../PageObjects_Submissions.robot
Library                    BuiltIn
Library                    DateTime

*** Keywords ***
Verify Elements on Compare and Rate Quote Primary
    # Author = Amol Gaymukhe
    [tags]                 Insured Info
    VerifyText             Account                     partial_match=false
    VerifyText             Agency
    VerifyText             Underwriter                 partial_match=false
    VerifyText             Stage
    VerifyText             Effective Date
    VerifyText             Quoted Premium

    VerifyText             Quote Console
    VerifyText             Primary Quotes
    VerifyText             Excess Quotes
    VerifyText             Expand All
    VerifyText             Collapse All
    VerifyText             New Primary Quote
    VerifyText             New Excess Quote

    VerifyText             Quote Data
    VerifyText             Quote Type
    VerifyText             Effective Date              anchor=2
    VerifyText             Expiration Date
    VerifyText             Policy
    VerifyText             Commission %
    VerifyText             State
    VerifyText             MGA Fee
    VerifyText             Surplus Lines Tax
    VerifyText             Premium Data
    VerifyText             Technical Premium
    VerifyText             Quote Premium
    VerifyText             Override Premium

    VerifyText             Transaction Premium
    VerifyText             Total Premium
    VerifyText             Additional Data
    VerifyText             Open Subjectivity
    VerifyText             Aggregate Info
    VerifyText             Cyber Primary Limit
    VerifyText             Cyber Primary Retention
    VerifyText             Cyber Coverage Waiting Period
    VerifyText             Enterprise Level Factors
    VerifyText             3rd Party Network Scan (0.750 - 1.250)
    VerifyText             Centralized Policies & Procedures (0.750 - 1.250)
    VerifyText             Financial Condition (0.750 - 1.250)
    VerifyText             Loss History (0.750 - 1.250)
    VerifyText             Nature of Operations (0.750 - 1.250)
    VerifyText             Network Security
    VerifyText             Physical Security
    VerifyText             Quality of Service Providers (0.750 - 1.250)
    VerifyText             Quality of Service Provider Contracts (0.750 - 1.250)
    VerifyText             Risk Management Controls (0.750 - 1.250)
    VerifyText             Overall, Risk modifier ( - )
    VerifyText             Base Policy Limits
    VerifyText             Data Breach Liability
    VerifyText             Regulatory Fines & Penalties
    VerifyText             PCI Fines & Assessments
    VerifyText             Electronic, Social, and Printed Media Liability
    VerifyText             Incident Response
    VerifyText             Business Int. & Extra Exp.
    VerifyText             Network Data Recovery
    VerifyText             Network Extortion
    VerifyText             First Party Endorsement
    VerifyText             BI EE Option Type
    VerifyText             Dependent BI
    VerifyText             System Failure
    VerifyText             Dependent System Failure
    VerifyText             Crime Endorsement
    VerifyText             Cyber Crime Option Type
    VerifyText             Social Engineering Limit
    VerifyText             Funds Transfer Fraud Limit
    VerifyText             Invoice Manipulation Limit
    VerifyText             Telecommunications Fraud Limit
    VerifyText             Other Endorsements
    VerifyText             Tech & Prof. E&O Limit
    VerifyText             Betterment
    VerifyText             Reputational Harm
    VerifyText             Bricking
    VerifyText             Number of Individuals (Outside)
    VerifyText             Number of Individuals (Within)
    VerifyText             Contingent BI PD Limit
    VerifyText             Cryptojacking Limit


Verify Elements on Compare and Rate Quote Excess
    # Author = Amol Gaymukhe
    [tags]                 Insured Info
    VerifyText             Account                     partial_match=false
    VerifyText             Agency
    VerifyText             Underwriter                 partial_match=false
    VerifyText             Stage
    VerifyText             Effective Date
    VerifyText             Quoted Premium

    VerifyText             Quote Console
    VerifyText             Primary Quotes
    VerifyText             Excess Quotes
    VerifyText             Expand All
    VerifyText             Collapse All
    VerifyText             New Primary Quote
    VerifyText             New Excess Quote

    VerifyText             Quote Data
    VerifyText             Quote Type
    VerifyText             Effective Date              anchor=2
    VerifyText             Expiration Date
    VerifyText             Policy
    VerifyText             Commission %
    VerifyText             State
    VerifyText             MGA Fee
    VerifyText             Surplus Lines Tax
    VerifyText             Premium Data
    VerifyText             Technical Premium
    #VerifyText            Quote Premium
    VerifyText             Override Premium

    VerifyText             Transaction Premium
    #VerifyText            Total Premium
    VerifyText             Additional Data
    VerifyText             Open Subjectivity
    VerifyText             Enterprise Level Factors
    VerifyText             3rd Party Network Scan (0.750 - 1.250)
    VerifyText             Centralized Policies & Procedures (0.750 - 1.250)
    VerifyText             Financial Condition (0.750 - 1.250)
    VerifyText             Loss History (0.750 - 1.250)
    VerifyText             Nature of Operations (0.750 - 1.250)
    VerifyText             Network Security (0.750 - 1.250)
    VerifyText             Physical Security (0.750 - 1.250)
    VerifyText             Quality of Service Providers (0.750 - 1.250)
    VerifyText             Quality of Service Provider Contracts (0.750 - 1.250)
    VerifyText             Risk Management Controls (0.750 - 1.250)
    VerifyText             Overall, Risk modifier ( - )
    VerifyText             Base Policy Limits
    VerifyText             Data Breach Liability
    VerifyText             Regulatory Fines & Penalties
    VerifyText             PCI Fines & Assessments
    VerifyText             Electronic, Social, and Printed Media Liability
    VerifyText             Incident Response
    VerifyText             Business Int. & Extra Exp.
    VerifyText             Network Data Recovery
    VerifyText             Network Extortion
    VerifyText             First Party Endorsement
    VerifyText             BI EE Option Type
    VerifyText             Dependent BI
    VerifyText             System Failure
    VerifyText             Dependent System Failure
    VerifyText             Crime Endorsement
    VerifyText             Cyber Crime Option Type
    VerifyText             Social Engineering Limit
    VerifyText             Funds Transfer Fraud Limit
    VerifyText             Invoice Manipulation Limit
    VerifyText             Telecommunications Fraud Limit
    VerifyText             Other Endorsements
    VerifyText             Tech & Prof. E&O Limit
    VerifyText             Betterment
    VerifyText             Reputational Harm
    VerifyText             Bricking
    VerifyText             Number of Individuals (Outside)
    VerifyText             Number of Individuals (Within)
    VerifyText             Contingent BI PD Limit
    VerifyText             Cryptojacking Limit


Click On Rate
    # Author = Amol Gaymukhe
    [tags]                 Compare and Rate
    Sleep                  30s
    ClickElement           //button[@title\='Rating test']
    VerifyText             Success                     anchor=Rating successful!                               timeout=65s            partial_match=false

Click On Save  
    # Author = Amol Gaymukhe
    [tags]                 Compare and Rate
    ClickElement           //span[text()\='Save']
    VerifyText             Confirmation
    ClickText              Confirm                     anchor=Cancel
    VerifyText             Success                     anchor=Update records successfully!                     timeout=65s            partial_match=false


Click On Finalize 
    # Author = Amol Gaymukhe
    [tags]                 Compare and Rate
    Sleep                  30s
    ClickElement           //lightning-icon[@title\='Finalize Quote']
    VerifyText             Success                     anchor=Finalize quote and Document Generation Successful!                      timeout=65s    partial_match=false


Click On Generate Document
    # Author = Amol Gaymukhe
    [tags]                 Compare and Rate
    ClickElement           //lightning-icon[@title\='View Document']
    VerifyText             Success                     anchor=Document has been downloaded successfully!       timeout=65s            partial_match=false

Click On Clone
    # Author = Amol Gaymukhe
    [tags]                 Compare and Rate
    ClickElement           //button[@title\='Clone Quote']                         timeout=65s

Click On Clone Excess
    # Author = Amol Gaymukhe
    [tags]                 Compare and Rate
    ClickElement           //button[@title\='Clone excess Quote']                  timeout=65s

Close cloned Quote
    # Author = Amol Gaymukhe
    [tags]                 Compare and Rate
    ClickElement           (//span[text()\='Show menu'])[2]
    ClickElement           //span[text()\='Close Quote']
    PickList               Closed Reason               No activity
    ClickText              Yes                         anchor=No

Click On Endorsement and Subjectivity
    # Author = Amol Gaymukhe
    [tags]                 Compare and Rate
    ClickElement           //lightning-icon[@title\='Endorsements & Subjectivities']


Click On Bind Button
    # Author = Amol Gaymukhe
    ClickElement           //lightning-icon[@title\='Bind']                        timeout=65s                 partial_match=false
    VerifyText             Bind Quote
    # ${random_Pay_plan}=    Evaluate                    random.choice(["By Check", "Credit Card", "ACH",])
    # Set Global Variable    ${Pay_plan}                 ${random_Pay_plan}
    # PickList               Pay plan                    ${Pay_plan}
    ClickElement           (//span[text()\='Select Item 1'])[last()]
    ClickText              Bind                        anchor=Cancel
    VerifyText             Success                     anchor=Bind Quote Successful                            timeout=105s           partial_match=false

Update Insured Name and Address Change complete
    VerifyText             Quote Console
    RefreshPage
    Sleep                  10s
    RefreshPage
    Sleep                  2s
    ClickElement           (//button[@title\='Rating test'])[last()]
    VerifyText             Success                     anchor=Rating successful!                               timeout=65s            partial_match=false

    ClickElement           (//lightning-icon[@title\='Finalize Quote'])[last()]    timeout=65s                 partial_match=false
    VerifyText             Success                     anchor=Finalize quote Successful!                       timeout=65s            partial_match=false

    ClickElement           (//lightning-icon[@title\='Bind'])[last()]              timeout=65s                 partial_match=false
    VerifyText             Bind Quote
    # ${random_Pay_plan}=    Evaluate                    random.choice(["By Check", "Credit Card", "ACH",])
    # Set Global Variable    ${Pay_plan}                 ${random_Pay_plan}
    # PickList               Pay plan                    ${Pay_plan}
    ClickElement           (//span[text()\='Select Item 1'])[last()]
    ClickText              Bind                        anchor=Cancel
    VerifyText             Success                     anchor=Bind Quote Successful                            timeout=65s            partial_match=false


Midterm Cancellation Flow Complete
    # Author = Amol Gaymukhe
    VerifyText             Quote Console
    RefreshPage
    Sleep                  10s
    RefreshPage
    Sleep                  10s
    ClickElement           (//button[@title\='Rating test'])[last()]
    VerifyText             Success                     anchor=Rating successful!                               timeout=65s            partial_match=false

    ClickElement           (//lightning-icon[@title\='Finalize Quote'])[last()]    timeout=65s                 partial_match=false
    VerifyText             Success                     anchor=Finalize quote Successful!                       timeout=65s            partial_match=false

    ClickElement           (//lightning-icon[@title\='Bind'])[last()]              timeout=65s                 partial_match=false
    VerifyText             Bind Quote
    # ${random_Pay_plan}=    Evaluate                    random.choice(["By Check", "Credit Card", "ACH",])
    # Set Global Variable    ${Pay_plan}                 ${random_Pay_plan}
    # PickList               Pay plan                    ${Pay_plan}
    ClickElement           (//span[text()\='Select Item 1'])[last()]
    ClickText              Bind                        anchor=Cancel
    VerifyText             Policy Number               timeout=65s


ERP flow Complete
    # Author = Amol Gaymukhe
    VerifyText             Quote Console
    RefreshPage
    Sleep                  10s
    RefreshPage
    Sleep                  10s
    ClickElement           (//button[@title\='Rating test'])[last()]
    VerifyText             Success                     anchor=Rating successful!                               timeout=65s            partial_match=false

    ClickElement           (//lightning-icon[@title\='Finalize Quote'])[last()]    timeout=65s                 partial_match=false
    VerifyText             Success                     anchor=Finalize quote Successful!                       timeout=65s            partial_match=false

    ClickElement           (//lightning-icon[@title\='Bind'])[last()]              timeout=65s                 partial_match=false
    VerifyText             Bind Quote
    # ${random_Pay_plan}=    Evaluate                    random.choice(["By Check", "Credit Card", "ACH",])
    # Set Global Variable    ${Pay_plan}                 ${random_Pay_plan}
    # PickList               Pay plan                    ${Pay_plan}
    ClickElement           (//span[text()\='Select Item 1'])[last()]
    ClickText              Bind                        anchor=Cancel
    VerifyText             Success                     anchor=Bind Quote Successful                            timeout=65s            partial_match=false


Amendment Flow Complete
    # Author = Amol Gaymukhe
    VerifyText             Quote Console
    RefreshPage
    Sleep                  10s
    RefreshPage
    Sleep                  10s
    ClickElement           (//button[@title\='Rating test'])[last()]
    VerifyText             Success                     anchor=Rating successful!                               timeout=65s            partial_match=false

    ClickElement           (//lightning-icon[@title\='Finalize Quote'])[last()]    timeout=65s                 partial_match=false
    VerifyText             Success                     anchor=Finalize quote Successful!                       timeout=65s            partial_match=false

    ClickElement           (//lightning-icon[@title\='Bind'])[last()]              timeout=65s                 partial_match=false
    VerifyText             Bind Quote
    # ${random_Pay_plan}=    Evaluate                    random.choice(["By Check", "Credit Card", "ACH",])
    # Set Global Variable    ${Pay_plan}                 ${random_Pay_plan}
    # PickList               Pay plan                    ${Pay_plan}
    ClickElement           (//span[text()\='Select Item 1'])[last()]
    ClickText              Bind                        anchor=Cancel
    VerifyText             Policy Number               timeout=65s



Update Name and Insured Address Change Complete
    # Author = Amol Gaymukhe
    TypeText               //label[text()\='Billing Address']/parent::*//input     2345 Silver Drive
    ClickElement           (//span[text()\='2345 Silver Drive, Columbus, OH, USA'])[1]
    ClickText              Save
    Sleep                  5s
    ClickText              NEXT:Submission Info >
    Sleep                  5s
    ClickText              NEXT:Underwriter Analysis >
    Sleep                  5s
    ClickText              Compare & Rate Quotes
    VerifyText             Quote Console

    RefreshPage
    ClickElement           (//button[@title\='Rating test'])[last()]
    VerifyText             Success                     anchor=Rating successful!                               timeout=65s            partial_match=false

    ClickElement           (//lightning-icon[@title\='Finalize Quote'])[last()]    timeout=65s                 partial_match=false
    VerifyText             Success                     anchor=Finalize quote Successful!                       timeout=65s            partial_match=false

    ClickElement           (//lightning-icon[@title\='Bind'])[last()]              timeout=65s                 partial_match=false
    VerifyText             Bind Quote
    # ${random_Pay_plan}=    Evaluate                    random.choice(["By Check", "Credit Card", "ACH",])
    # Set Global Variable    ${Pay_plan}                 ${random_Pay_plan}
    # PickList               Pay plan                    ${Pay_plan}
    ClickElement           (//span[text()\='Select Item 1'])[last()]
    ClickText              Bind                        anchor=Cancel
    VerifyText             Policy Number               timeout=65s


Policy Duration Change Flow Complete
    # Author = Amol Gaymukhe
    VerifyText             Quote Console
    RefreshPage
    Sleep                  10s
    RefreshPage
    Sleep                  10s
    ClickElement           (//button[@title\='Rating test'])[last()]
    VerifyText             Success                     anchor=Rating successful!                               timeout=65s            partial_match=false

    ClickElement           (//lightning-icon[@title\='Finalize Quote'])[last()]    timeout=65s                 partial_match=false
    VerifyText             Success                     anchor=Finalize quote Successful!                       timeout=65s            partial_match=false

    ClickElement           (//lightning-icon[@title\='Bind'])[last()]              timeout=65s                 partial_match=false
    VerifyText             Bind Quote
    # ${random_Pay_plan}=    Evaluate                    random.choice(["By Check", "Credit Card", "ACH",])
    # Set Global Variable    ${Pay_plan}                 ${random_Pay_plan}
    # PickList               Pay plan                    ${Pay_plan}
    ClickElement           (//span[text()\='Select Item 1'])[last()]
    ClickText              Bind                        anchor=Cancel
    VerifyText             Success                     anchor=Bind Quote Successful                            timeout=65s            partial_match=false


Cancel Coverage Replace Complete flow
    # Author = Amol Gaymukhe
    VerifyText             Quote Console
    RefreshPage
    Sleep                  10s
    RefreshPage
    Sleep                  10s
    ClickElement           (//button[@title\='Rating test'])[1]                    timeout=55s
    VerifyText             Success                     anchor=Rating successful!                               timeout=65s            partial_match=false

    ClickElement           (//lightning-icon[@title\='Finalize Quote'])[1]         timeout=65s                 partial_match=false
    VerifyText             Success                     anchor=Finalize quote and Document Generation Successful!                      timeout=65s    partial_match=false

    ClickElement           (//lightning-icon[@title\='Bind'])[1]                   timeout=65s                 partial_match=false
    VerifyText             Bind Quote
    # ${random_Pay_plan}=    Evaluate                    random.choice(["By Check", "Credit Card", "ACH",])
    # Set Global Variable    ${Pay_plan}                 ${random_Pay_plan}
    # PickList               Pay plan                    ${Pay_plan}
    ClickElement           (//span[text()\='Select Item 1'])[last()]
    ClickText              Bind                        anchor=Cancel
    VerifyText             Success                     anchor=Bind Quote Successful                            timeout=65s            partial_match=false


Get Quote Letter Dynamic Document Cyber
    #Author=Amol
    [Documentation]        Dynamic Document Elements and Setting as Set Global Variable
    Sleep                  30s
    ${Quote_date}=         Get Current Date            result_format=%B %-d, %Y
    Log To Console         ${Quote_date}
    Set Global Variable    ${Quote_date}

    ${pdf_agency}=         GetText                     //p[text()\='Agency']/parent::*//a
    Log To Console         ${pdf_agency}
    Set Global Variable    ${pdf_agency}

    ${eff_date}=           GetInputValue               //input[contains(@name,'-Effective Date')]
    Log To Console         ${eff_date}


    ${fr1}=                Convert Date                ${eff_date}                 date_format=%m/%d/%Y
    ${eff_date_final}=     Convert Date                ${fr1}                      result_format=%B %-d, %Y
    Set Global Variable    ${eff_date_final}


    ${exp_date}=           GetInputValue               //input[contains(@name,'-Expiration Date')]
    Log To Console         ${exp_date}

    #${conv2}=             Convert Date                ${exp_date}                 result_format=%B %m, %Y
    ${from1}=              Convert Date                ${exp_date}                 date_format=%m/%d/%Y
    ${exp_final}=          Convert Date                ${from1}                    result_format=%B %-d, %Y
    Set Global Variable    ${exp_final}

    #Premium
    ${premium}=            GetInputValue               //input[contains(@name,'-Technical Premium')]
    Log To Console         ${premium}

    ${premium2}=           Remove String               ${premium}                  $                           .00
    ${PDF_Premium}=        Set Variable                ${premium2}
    Set Global Variable    ${PDF_Premium}

    #Policy Fee
    ${pol_fee}=            GetInputValue               //input[contains(@name,'-MGA Fee')]
    Log To Console         ${pol_fee}

    ${polfee2}=            Remove String               ${pol_fee}                  $                           .00
    ${PDF_PolFee}=         Set Variable                ${polfee2}
    Set Global Variable    ${PDF_PolFee}

    #Total Premium
    ${tota_premium}=       GetInputValue               //input[contains(@name,'-Total Premium')]
    Log To Console         ${tota_premium}

    ${totalfee2}=          Remove String               ${tota_premium}             $                           .00
    ${PDF_TotalFee}=       Set Variable                ${totalfee2}
    Set Global Variable    ${PDF_TotalFee}



Get Quote Letter Dynamic Document Cyber Excess   
    #Author=Amol
    [Documentation]        Dynamic Document Elements and Setting as Set Global Variable

    ${Quote_date}=         Get Current Date            result_format=%B %-d, %Y
    Log To Console         ${Quote_date}
    Set Global Variable    ${Quote_date}

    ${pdf_agency}=         GetText                     //p[text()\='Agency']/parent::*//a
    Log To Console         ${pdf_agency}
    Set Global Variable    ${pdf_agency}

    ${eff_date}=           GetInputValue               //input[contains(@name,'-Effective Date')]
    Log To Console         ${eff_date}


    ${fr1}=                Convert Date                ${eff_date}                 date_format=%m/%d/%Y
    ${eff_date_final}=     Convert Date                ${fr1}                      result_format=%B %-d, %Y
    Set Global Variable    ${eff_date_final}


    ${exp_date}=           GetInputValue               //input[contains(@name,'-Expiration Date')]
    Log To Console         ${exp_date}

    #${conv2}=             Convert Date                ${exp_date}                 result_format=%B %m, %Y
    ${from1}=              Convert Date                ${exp_date}                 date_format=%m/%d/%Y
    ${exp_final}=          Convert Date                ${from1}                    result_format=%B %-d, %Y
    Set Global Variable    ${exp_final}

    #Premium
    ${premium}=            GetInputValue               //input[contains(@name,'-Technical Premium')]
    Log To Console         ${premium}

    ${premium2}=           Remove String               ${premium}                  $                           .00
    ${PDF_Premium}=        Set Variable                ${premium2}
    Set Global Variable    ${PDF_Premium}

    #Policy Fee
    ${pol_fee}=            GetInputValue               //input[contains(@name,'-MGA Fee')]
    Log To Console         ${pol_fee}

    ${polfee2}=            Remove String               ${pol_fee}                  $                           .00
    ${PDF_PolFee}=         Set Variable                ${polfee2}
    Set Global Variable    ${PDF_PolFee}

    #Total Premium
    ${tota_premium}=       GetInputValue               //input[contains(@name,'-Transaction Premium')]
    Log To Console         ${tota_premium}

    ${PDF_Premium}=        Remove String               ${PDF_Premium}              ,

    ${PDF_TotalFee}=       Evaluate                    ${PDF_PolFee}+${PDF_Premium}
    Log To Console         ${PDF_TotalFee}
    ${PDF_TotalFee}=       Format String               {:,}                        ${PDF_TotalFee}
    # ${totalfee2}=        Remove String               ${tota_premium}             $                           .00
    # ${PDF_TotalFee}=     Set Variable                ${totalfee2}
    Set Global Variable    ${PDF_TotalFee}


Click On Bind Button more than once
    # Author = Amol Gaymukhe
    
    ClickElement           //lightning-icon[@title\='Bind']                        timeout=65s                 partial_match=false
    VerifyText             Bind Quote
     
    ${Values}=             Create List                 ([1, 2, 3,]) 
    ${random_Pay_plan}=    Evaluate                    random.choice(["By Check", "Credit Card", "ACH",])
    ${index}=    Get Index From List    ${Values}   ${random_Pay_plan}
    ${actual_index}=    Evaluate    ${index}
    #PickList    Pay plan    ${actual_index}
    #Set Global Variable    ${Pay_plan}                 ${random_Pay_plan}
    
    Log To Console  Selecting: ${random_Pay_plan} at Index: ${actual_index}
    PickList               Pay plan                    ${random_Pay_plan} at Index: ${actual_index}
    #PickList               Pay plan                    ${index}
    ClickElement           (//span[text()\='Select Item 1'])[last()]
    ClickText              Bind                        anchor=Cancel
    VerifyText             Success                     anchor=Bind Quote Successful                            timeout=105s           partial_match=false