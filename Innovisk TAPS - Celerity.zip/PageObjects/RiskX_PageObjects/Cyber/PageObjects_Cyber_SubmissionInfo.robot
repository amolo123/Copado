*** Settings ***
Library                       QWeb
Library                       QForce
#Library                      QVision
Library                       FakerLibrary
Library                       String
Library                       BuiltIn
Library                       DateTime
Resource                      ../../../resources/common.robot
Resource                      ../PageObjects_Accounts.robot
Resource                      ../PageObjects_Submissions.robot
Library                       BuiltIn
Library                       DateTime

*** Keywords ***

Validate SubmissionInfo New submission Fields
    #Author=Amol
    [tags]                    submission
    [Documentation]           Complete Documentation
    VerifyText                Submission Name             anchor=Account Name         partial_match=False
    VerifyText                Submission Owner
    VerifyText                Account Name
    VerifyText                Product
    VerifyText                Industry
    VerifyText                Account Clearance
    VerifyText                Service Classification
    VerifyText                Eplace Score
    VerifyText                Service Classification
    VerifyText                Type
    VerifyText                UW Status
    VerifyText                Layer Broker Requested
    VerifyText                Alien Broker

    VerifyText                Keys Date
    VerifyText                Effective Date
    VerifyText                Effective Date (Docs)
    VerifyText                Expiration Date
    VerifyText                Received Date
    VerifyText                Retroactive Date
    VerifyText                Retroactive Date (Docs)
    VerifyText                Close Date

    VerifyText                Submission Status
    VerifyText                Stage
    VerifyText                Policy

    VerifyText                Closed Reason
    VerifyText                Amount

    VerifyText                Account Information (imported from Account)
    VerifyText                Broker Account

    VerifyText                Broker ID
    VerifyText                Broker Name
    VerifyText                Primary Broker?
    VerifyText                Relationship Type

    #VerifyText                Additional Insured Details
    VerifyText                Broker Name
    VerifyText                Primary Broker?
    VerifyText                Relationship Type




    VerifyText                Type                        partial_match=False
    VerifyText                Product
    VerifyText                Submission Owner

    VerifyText                Broker Account              anchor=Relationship Type
    VerifyText                New                         anchor=Broker Account
    VerifyElement             (//button[text()\='New'])
    VerifyText                PREVIOUS:Insured Info       anchor=Broker Account
    VerifyElement             (//button[text()\='< PREVIOUS:Insured Info'])
    VerifyText                Save
    VerifyElement             (//button[text()\='Save'])
    VerifyText                NEXT:Underwriter Analysis
    VerifyElement             (//button[text()\='NEXT:Underwriter Analysis >'])
    Log To Console            ----- Submission Info Fileds Validated Successfully -----



Verify SubmissionInfo Page Input Details
    #Author=Amol Gaymukhe
    [tags]                    SubmissionInfo
    [Documentation]           Add the details

    ${effective_date}=        GetInputValue               //input[@name\='Effective_Date__c']

    ${inception_Date}=        GetInputValue               //input[@name\='Received_Date__c']

    ${cur_data}=              Get Current Date            result_format=%-m/%-d/%Y
    # ${comp_effective_date}=                             Get Current Date            increment=5 day         result_format=%b %-d, %Y
    # ${comp_xpiration_Date}=                             Get Current Date            increment=370 day       result_format=%b %-d, %Y


    IF                        "${inception_date}"== "${cur_data}" and "${effective_date}"=="${cur_data}"
        Log To Console        Success
    ELSE
        Fail
    END
    Log To Console            ----- Received date, Efective data, Expiration date     Validated Successfully -----

    #Verify Broker
    UseTable                  Broker ID
    ${Broker_name}=           GetCellText                 r2/c?Broker Name
    ${primary_broker}=        GetCellText                 r2/c?Primary Broker?
    ${relationship_type}=     GetCellText                 r2/c?Relationship Type

    Log To Console            ${primary_broker}           ${Broker_name}              ${relationship_type}
    ${pdf_brokername}=        Set Variable                ${Broker_name}
    Set Global Variable       ${pdf_brokername}

    IF                        "${Broker_name}"=="${EMPTY}" and "${primary_broker}"=="${EMPTY}" and "${relationship_type}"=="${EMPTY}"
        Fail
    ELSE
        Log To Console        Success
    END
    Log To Console            ----- Broker date, Primary Broker, Relationship Type    Validated Successfully -----



Add Details In SubmissionInfo Page
    #Author-Amol Gaymukhe
    [Documentation]           Add the details
    # TypeText                Expiring Attorneys          2
    # TypeText                Expiring Premium            2000
    # TypeText                Current Carrier             LGO
    # #ClickText              LGO One LLC
    # TypeText                Current Revenue             2000
    # VerifyCheckboxValue     25% Client Revenue          off
    # VerifyCheckboxValue     Signed & dated within 60/90 (N/R) day                   off
    # VerifyCheckboxValue     Officer/Director/ Ownership in Client(s)                off
    # VerifyCheckboxValue     Retroactive Date Inception(RDI)                         off
    # TypeText                Underwriting Comments (if applicable):                  Test Comments

    # ${pdf_underwriter}=     GetText                     //label[text()\='Underwriter']/parent::c-generate-element-lwc//a/span
    # Set Global Variable     ${pdf_underwriter}
    UseTable                  Broker ID
    ${pdf_brokername}=        GetCellText                 r1c1
    Log To Console            ${pdf_brokername}
    Set Global Variable       ${pdf_brokername}


    Log To Console            ----- Submission Info Input Details Added Successfully -----


Verify Decline 
    #Author=Amol Gaymukhe
    [Documentation]           Decline
    ClickText                 Decline
    UseModal                  On
    VerifyText                Decline Submission
    PickList                  *Closed Reason              Already Seen
    ClickText                 Yes                         anchor=No
    VerifyText                Declined                    anchor=Stage
    Log To Console            ----- Decline Done Successfully -----

Verify Un Decline  
    #Author=Amol Gaymukhe
    [Documentation]           Decline
    ClickText                 Un Decline


Verify Copy
    #Author=Amol Gaymukhe
    [Documentation]           Decline
    ClickText                 Copy


    # Check WorkFlow Status Indication Release
    #                         #Author=Amol Gaymukhe
    #                         ${workflow_status}=         GetAttribute                //label[text()\='Workflow Status']/parent::div//button    data-value
    #                         Log To Console              ${workflow_status}
    #                         IF                          '${workflow_status}' == 'Indication Released'
    #                         Log To Console              Sucess
    #                         ELSE
    #                         Fail
    #                         END
    #                         ClickText                   NEXT:Underwriter Analysis >


    # Check WorkFlow Status Quote Release
    #                         ClickText                   Submission Info
    #                         Sleep                       10s
    #                         ${workflow_status2}=        GetAttribute                //label[text()\='Workflow Status']/parent::div//button    data-value
    #                         Log To Console              ${workflow_status2}
    #                         IF                          '${workflow_status2}' == 'Quote Released'
    #                         Log To Console              Sucess
    #                         ELSE
    #                         Fail
    #                         END

    # Check WorkFlow Status Initial Review

    #                         Sleep                       10s
    #                         ${workflow_status2}=        GetAttribute                //label[text()\='Workflow Status']/parent::div//button    data-value
    #                         Log To Console              ${workflow_status2}
    #                         IF                          '${workflow_status2}' == 'Initial Review'
    #                         Log To Console              Sucess
    #                         ELSE
    #                         Fail
    #                         END


    # Check WorkFlow Additional Information Requested

    #                         Sleep                       10s
    #                         ${workflow_status2}=        GetAttribute                //label[text()\='Workflow Status']/parent::div//button    data-value
    #                         Log To Console              ${workflow_status2}
    #                         IF                          '${workflow_status2}' == 'Additional Information Requested'
    #                         Log To Console              Sucess
    #                         ELSE
    #                         Fail
    #                         END

Additional Insured Details Validation
    #Author=Amol Gaymukhe
    [Documentation]           Additional Insured Details Validation
    ClickElement              //lightning-icon[@title\='Open Additional Insured Page']//lightning-primitive-icon
    UseModal                  On
    VerifyText                Additional Insured Details
    VerifyText                New                         anchor=Additional Insured Details
    ClickText                 New                         anchor=Additional Insured Details
    VerifyText                Submission                  anchor=Additional Insured Details
    VerifyText                Additional Account
    VerifyText                Additional Insured Name
    TypeText                  //input[@placeholder\='Search...']                      Kenny and Mag
    ClickElement              //input[@placeholder\='Search...']
    ClickElement              //span[text()\='Kenny and Mag']
    UseModal                  On
    ClickText                 Save                        anchor=Cancel
    ClickText                 Return Quote Process

Change Broker
    #Author=Amol Gaymukhe
    [Documentation]           Additional Insured Details validation
    [Arguments]               ${Broker_Name}
    #ScrollTo                 //button//span[text()\='Show actions']
    Scroll                    //html
    Sleep                     4s
    ClickElement              //span[text()\='Show actions']
    Sleep                     2s
    ClickElement              //span[text()\='Delete']
    VerifyText                Confirmation
    ClickText                 Yes                         anchor=No
    ClickElement              (//button[text()\='New'])[2]
    TypeText                  //label[text()\='Broker Contact']/parent::*//input      ${Broker_Name}
    ClickElement              //label[text()\='Broker Contact']/parent::*//li
    ClickText                 Save                        anchor=Cancel


Delete Broker
    ScrollTo                  //button//span[text()\='Show actions']
    Sleep                     2s
    ClickElement              //button//span[text()\='Show actions']
    Sleep                     2s
    ClickElement              //span[text()\='Delete']
    VerifyText                Confirmation
    ClickText                 Yes                         anchor=No

Validate New Submission Form Fields 
    #Author=Amol Gaymukhe
    [Documentation]           Additional Insured Details validation
    VerifyText                Account Name
    VerifyText                Submission Record Type
    VerifyText                Product                     partial_match=false
    VerifyText                Service to Run
    VerifyText                Broker Contact
    VerifyText                Relationship Type
    VerifyText                Primary Broker?
    VerifyText                Alien Broker
    VerifyText                Next


Select Broker and Click On Next 
    #Author=Amol Gaymukhe
    [Documentation]           Additional Insured Details validation
    TypeText                  Broker Contact              Celerity Broker
    ClickElement              //lightning-base-combobox-formatted-text[@title\='Celerity broker']
    ClickText                 Next                        anchor=Cancel


Select Industry
    #Author=Amol Gaymukhe
    [Documentation]           Additional Insured Industry
    [Arguments]               ${industry}
    PickList                  Industry                    ${Industry}

Select Classification 
    #Author=Amol Gaymukhe
    [Documentation]           Additional Insured Classification
    [Arguments]               ${service}
    PickList                  Service Classification      ${service}

Click On Account 
    #Author=Amol Gaymukhe
    [Documentation]           Additional Insured Classification
    ClickElement              //p[text()\='Account']/parent::*//a

Click On Submission Owner   
    #Author=Amol Gaymukhe
    [Documentation]           Additional Insured Classification
    ClickElement              //a[text()\='Automation-user Copado-CEL']

Click On Product 
    #Author=Amol Gaymukhe
    [Documentation]           Additional Insured Classification
    ClickElement              //a[text()\='Cyber Standalone v2']

Verify Effective Date Received date and Close date   
    #Author=Amol Gaymukhe
    [Documentation]           Additional Insured Classification

    ${eff_date}=              GetInputValue               Effective Date              partial_match=false
    Log To Console            ${eff_date}
    ${curr_eff_date}=         Get Current Date            result_format=%-m/%-d/%Y    #increment= 1 day
    Log To Console            ${curr_eff_date}
    ${eff_date_1}=            Get Current Date            result_format=%-m/%-d/%Y    increment= 1 day
    Log To Console            ${eff_date_1}
    ${eff_date_2}=            Get Current Date            result_format=%-m/%-d/%Y    increment= -1 day
    Log To Console            ${eff_date_2}

    ${Expiration_date}=       GetInputValue               Expiration Date             partial_match=false
    Log To Console            ${Expiration_date}
    ${curr_exp_date}=         Get Current Date            result_format=%-m/%-d/%Y    increment= 366 day
    Log To Console            ${curr_exp_date}

    ${Received_date}=         GetInputValue               Received Date               partial_match=false
    Log To Console            ${Received_date}
    ${curr_Received_date}=    Get Current Date            result_format=%-m/%-d/%Y    #increment= -1 day
    Log To Console            ${curr_Received_date}

    ${close_date}=            GetInputValue               Close Date                  partial_match=false
    Log To Console            ${Close_date}
    ${curr_close_date}=       Get Current Date            result_format=%-m/%-d/%Y    increment= 90 day
    Log To Console            ${curr_close_date}

    IF                        "${eff_date}"=="${curr_eff_date}" or "${eff_date}"=="${eff_date_1}" or "${eff_date}"=="${eff_date_2}"
        Log To Console        Success
    ELSE
        Fail
    END
    
    IF                        "${Expiration_date}"=="${curr_exp_date}" and "${Received_date}"=="${curr_Received_date}" and "${close_date}"=="${curr_close_date}"
        Log To Console        Success
    ELSE
        Fail
    END


Verify Submission Info Fields 
    #Author=Amol Gaymukhe
    [Documentation]           Additional Insured Classification
    Log To Console            ${uniquename}
    VerifyText                ${uniquename} Cyber Standalone v2
    VerifyText                Automation-user Copado-CEL
    VerifyText                Business Services
    VerifyText                Administrators
    VerifyText                New Business
    VerifyText                ${uniquename}               partial_match=false
    VerifyText                Cyber Standalone v2         partial_match=false
    VerifyText                Cleared
    VerifyText                Eplace Score
    VerifyText                Awaiting UW Review

    VerifyText                Keys Date
    VerifyText                Effective Date
    VerifyText                Expiration Date
    VerifyText                Retroactive Date
    VerifyText                Close Date
    VerifyText                Effective Date
    VerifyText                Received Date
    VerifyText                Retroactive Date
    VerifyText                Submission Status

    VerifyText                Stage
    VerifyText                Policy
    VerifyText                Closed Reason
    VerifyText                Amount

    VerifyText                Broker Account
    #Additional insured field is Removed from Celerity al products.
    #VerifyText                Additional Insured Details