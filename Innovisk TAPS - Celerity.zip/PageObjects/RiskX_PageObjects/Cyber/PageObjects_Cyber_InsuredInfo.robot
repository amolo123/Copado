*** Settings ***
Library               QWeb
Library               QForce
#Library              QVision
Library               FakerLibrary
Library               String
Library               BuiltIn
Library               DateTime
Resource              ../../../resources/common.robot
Resource              ../PageObjects_Accounts.robot
Resource              ../PageObjects_HomePage.robot



*** Keywords ***

Validate field on Insured Info page for Cyber
    # Author = Amol Gaymukhe
    [tags]            Insured Info
    ClickText         Home                        anchor=Celerity Underwriting
    VerifyText        Celerity Underwriting       anchor=Home
    ClickText         Cyber v2
    ClickElement      (//input[@placeholder\="Search..."])[1]
    TypeText          Search...                   ${uniqueName}               anchor=Insured Name
    ClickElement      (//li[@role\='presentation']/span)[1]
    Log To Console    ----- Insured Info page Add Account Verified Successfully -----

    sleep             5s
    ClickElement      (//button[@name\='SaveAccount'])
    VerifyText        Success                     anchor=Account updated

    Log To Console    ----- Account added -----
    # ${Phone_value}=                             GetFieldValue               Phone
    # Log To Console                              ${Phone_value}
    #VerifyInputValue                             Account Name                ${uniqueName}
    VerifyText        Account                     anchor=3
    VerifyText        Agency
    VerifyText        Underwriter                 anchor=4
    VerifyText        Stage
    Verifytext        Effective Date
    VerifyText        Quoted Premium
    VerifyText        Province
    VerifyText        PostalCode
    VerifyText        Operations
    VerifyText        Contact Info

    VerifyText        Insured Info
    VerifyText        Submission Info
    VerifyText        Underwriting Analysis
    VerifyText        Compare & Rate Quotes

    VerifyText        Save

    VerifyText        Account Name
    VerifyText        Website
    VerifyText        Billing Address
    VerifyText        Country
    Verifytext        Street
    VerifyText        City
    VerifyText        Province
    VerifyText        PostalCode
    VerifyText        Operations
    VerifyText        Contact Info

    VerifyText        Insured Contact Info

   
    Log To Console    ----- Insured Info field Validated Successfully-----

Enter data on Insured info Page for Cyber

    # Author = Amol Gaymukhe
    [tags]            Insured Info

    ClickText         Home                        anchor=Celerity Underwriting
    VerifyText        Celerity Underwriting       anchor=Home
    ClickText         Cyber v2
    ClickElement      (//input[@placeholder\="Search..."])[1]
    TypeText          Search...                   ${uniqueName}               anchor=Insured Name
    ClickElement      (//li[@role\='presentation']/span)[1]
    Log To Console    ----- Insured Info page Add Account Verified Successfully -----

    sleep             5s
    ClickElement      (//button[@name\='SaveAccount'])
    VerifyText        Success                     anchor=Account updated
    Log To Console    ----- Data Entered On Insured Info Page Successfully ---------------



Click On Account Link 
    # Author = Amol Gaymukhe
    [tags]            Insured Info

    ClickElement      //label[text()\='Account Name']/parent::*//a
    VerifyText        Details
    VerifyText        Account Product
    VerifyText        Underwriting File
    VerifyText        Related
    VerifyText        Claims
    VerifyText        Account History
    VerifyText        Sfiles                    partial_match=False



Select state CO
    # Author = Amol Gaymukhe
    [tags]            Insured Info
    ClickText         Insured Info
    PickList          Province                    Colorado
    ClickText         Save                        anchor=NEXT:Submission Info >
    ClickText         NEXT:Submission Info >