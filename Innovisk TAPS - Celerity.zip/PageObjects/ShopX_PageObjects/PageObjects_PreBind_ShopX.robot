*** Settings ***
Library                QWeb
Library                QForce
#Library               QVision
Library                FakerLibrary
Library                String
Library                BuiltIn
Library                DateTime



*** Keywords ***
Validate all the elements on Pre bind page
    [Documentation]    Validate all the elements on Pre bind page
    [Arguments]        ${Product_Celerity}


    IF                 "${Product_Celerity}" == "MPL"

        VerifyText     Thanks for wanting to Bind!
        VerifyText     To bind the policy, we need your Surplus Lines License information & Signature Pack.
        VerifyText     Surplus Lines License
        VerifyElement                              //mat-label[text()\='Surplus License Number']
        VerifyElement                              //mat-label[text()\='Surplus License Owner']
        ClickElement                               //mat-label[text()\='Surplus License Owner']
        VerifyElement                              //mat-label[text()\='Surplus License Owner Name']
        VerifyText     Agency
        VerifyText     Producer
        ClickElement                               //span[text()\=' Agency ']
        VerifyElement                              //mat-label[text()\='Surplus License address']
        VerifyText     Add/edit address details manually
        ClickElement                               (//input[@type\="checkbox"])[1]
        VerifyElement                              //mat-label[text()\='Address1']
        VerifyElement                              //mat-label[text()\='Address2']
        VerifyElement                              //mat-label[text()\='City']
        VerifyElement                              //mat-label[text()\='State Province']
        VerifyElement                              //mat-label[text()\='Postal Zip']
        VerifyText     DOWNLOAD
        VerifyText     your Signature Pack. Once the Signature Pack is signed by your Insured,
        VerifyText     UPLOAD
        VerifyText     it here
        VerifyText     I don't have a signed Signature Pack but will provide a signed and dated version to Celerity within 10 days.
        VerifyText     Note any changes to the Signature Pack may result in a pricing or coverage change, or policy termination.
        ClickElement                               (//input[@type\="checkbox"])[2]
        VerifyText     Your Premium :
        VerifyText     Commission

    ELSE IF            "${Product_Celerity}" == "Cyber"

        VerifyText     Thanks for wanting to Bind!
        VerifyText     To bind the policy, we need your Surplus Lines License information & Signature Pack.
        VerifyText     Insured Contact Information
        VerifyText     In order to receive complimentary access to Celerity Pro’s Cyber Defense loss prevention services, please provide the following information:
        VerifyText     Name of internal contact for network security/cyber risk management (CISO, Head of IT or equivalent)
        VerifyElement                              //mat-label[text()\='First Name']
        VerifyElement                              //mat-label[text()\='Last Name']
        VerifyElement                              //mat-label[text()\='Email']
        VerifyElement                              //mat-label[text()\='Telephone']
        VerifyText     Surplus Lines License
        VerifyElement                              //mat-label[text()\='Surplus License Number']
        VerifyElement                              //mat-label[text()\='Surplus License Owner']
        ClickElement                               //mat-label[text()\='Surplus License Owner']
        VerifyElement                              //mat-label[text()\='Surplus License Owner Name']
        VerifyText     Agency
        VerifyText     Producer
        ClickElement                               //span[text()\=' Agency ']
        VerifyElement                              //mat-label[text()\='Surplus License address']
        VerifyText     Add/edit address details manually
        ClickElement                               (//input[@type\="checkbox"])[1]
        VerifyElement                              //mat-label[text()\='Address1']
        VerifyElement                              //mat-label[text()\='Address2']
        VerifyElement                              //mat-label[text()\='City']
        VerifyElement                              //mat-label[text()\='State Province']
        VerifyElement                              //mat-label[text()\='Postal Zip']
        VerifyText     DOWNLOAD
        VerifyText     your Signature Pack. Once the Signature Pack is signed by your Insured,
        VerifyText     UPLOAD
        VerifyText     it here
        VerifyText     I don't have a signed Signature Pack but will provide a signed and dated version to Celerity within 10 days.
        VerifyText     Note any changes to the Signature Pack may result in a pricing or coverage change, or policy termination.
        ClickElement                               (//input[@type\="checkbox"])[2]
        VerifyText     Your Premium :
        VerifyText     Commission


    ELSE IF            "${Product_Celerity}" == "PCC"
        VerifyText     Thanks for wanting to Bind!
        VerifyText     To bind the policy, we need your Surplus Lines License information & Signature Pack.
        VerifyText     Surplus Lines License
        VerifyElement                              //mat-label[text()\='Surplus License Number']
        VerifyElement                              //mat-label[text()\='Surplus License Owner']
        ClickElement                               //mat-label[text()\='Surplus License Owner']
        VerifyElement                              //mat-label[text()\='Surplus License Owner Name']
        VerifyText     Agency
        VerifyText     Producer
        ClickElement                               //span[text()\=' Agency ']
        VerifyElement                              //mat-label[text()\='Surplus License address']
        VerifyText     Add/edit address details manually
        ClickElement                               (//input[@type\="checkbox"])[1]
        VerifyElement                              //mat-label[text()\='Address1']
        VerifyElement                              //mat-label[text()\='Address2']
        VerifyElement                              //mat-label[text()\='City']
        VerifyElement                              //mat-label[text()\='State Province']
        VerifyElement                              //mat-label[text()\='Postal Zip']
        VerifyText     DOWNLOAD
        VerifyText     your Signature Pack. Once the Signature Pack is signed by your Insured,
        VerifyText     UPLOAD
        VerifyText     it here
        VerifyText     I don't have a signed Signature Pack but will provide a signed and dated version to Celerity within 10 days.
        VerifyText     Note any changes to the Signature Pack may result in a pricing or coverage change, or policy termination.
        ClickElement                               (//input[@type\="checkbox"])[2]
        VerifyText     Your Premium :
        VerifyText     Commission


    END

    Log To Console     ------Celerity ShopX Pre bind page Validated Successfully-------



Validate entering all the details on Pre bind page
    [Documentation]    Validate searching with Product name
    [Arguments]        ${Product_Celerity}         ${SurplusLicenseNumber}     ${SurplusLicenseOwnerName}                 ${Address1}    ${Address2}                     ${City}         ${State_Province}               ${PostalZip}                ${FirstName1}    ${LastName}    ${Email}    ${Telephone}

    IF                 "${Product_Celerity}" == "MPL"

        TypeText       Surplus License Number      ${SurplusLicenseNumber}
        TypeText       Surplus License Owner Name                              ${SurplusLicenseOwnerName}
        ClickElement                               //mat-label[text()\='Surplus License Owner']
        ClickElement                               //span[text()\=" Agency "]
        Sleep          5s
        TypeText       Surplus License address     2300 M St NW, Washington, DC 20037, USA
        ClickText      DC 20037, USA

        ClickElement                               (//input[@type\="checkbox"])[1]
        TypeText       Address1                    ${Address1}
        TypeText       Address2                    ${Address2}
        TypeText       City                        ${City}
        #TypeText      Country                     ${USA}
        ClickElement                        //mat-select[@formcontrolname\='state']//span
        ClickElement                              //span[text()\=' DC ']
        TypeText       Postal Zip                  ${PostalZip}
        ClickElement                               (//input[@type\="checkbox"])[2]

    ELSE IF            "${Product_Celerity}" == "Cyber"

        TypeText       First Name                  ${FirstName1}
        TypeText       Last Name                   ${LastName}
        TypeText       Email                       ${Email}
        TypeText       Telephone                   ${Telephone}
        TypeText       Surplus License Number      ${SurplusLicenseNumber}
        TypeText       Surplus License Owner Name                              ${SurplusLicenseOwnerName}
        ClickElement                               //mat-label[text()\='Surplus License Owner']
        ClickElement                               //span[text()\=" Agency "]
        Sleep          5s
        TypeText       Surplus License address     2300 M St NW, Washington, DC 20037, USA
        ClickText      DC 20037, USA

        ClickElement                               (//input[@type\="checkbox"])[1]
        TypeText       Address1                    ${Address1}
        TypeText       Address2                    ${Address2}
        TypeText       City                        ${City}
        #TypeText      Country                     ${USA}
        #ClickElement                               //mat-select[formcontrolname\='State']
        ClickElement                        //mat-select[@formcontrolname\='state']//span
        ClickElement                              //span[text()\=' DC ']
        TypeText       Postal Zip                  ${PostalZip}
        ClickElement                               (//input[@type\="checkbox"])[2]

    ELSE IF            "${Product_Celerity}" == "PCC"

        TypeText       Surplus License Number      ${SurplusLicenseNumber}
        TypeText       Surplus License Owner Name                              ${SurplusLicenseOwnerName}
        ClickElement                               //mat-label[text()\='Surplus License Owner']
        ClickElement                               //span[text()\=" Agency "]
        Sleep          5s
        TypeText       Surplus License address     2300 M St NW, Washington, DC 20037, USA
        ClickText      DC 20037, USA

        ClickElement                               (//input[@type\="checkbox"])[1]
        TypeText       Address1                    ${Address1}
        TypeText       Address2                    ${Address2}
        TypeText       City                        ${City}
        #TypeText      Country                     ${USA}
        ClickElement                        //mat-select[@formcontrolname\='state']//span
        ClickElement                              //span[text()\=' DC ']
        TypeText       Postal Zip                  ${PostalZip}
        ClickElement                               (//input[@type\="checkbox"])[2]

    END
Validate clicking on bind quote button on Pre-bind Page
    [Documentation]    Validate clicking on bind quote button on Pre-bind Page

    ClickElement       //button[text()\=' BIND QUOTE ']
    VerifyText         My Policies


Validate all the elements on Pre bind page PCC
    [Documentation]    Validate searching with Product name PCC

    ClickElement       //mat-label[text()\='Select a search filter']
    VerifyText         Product Name
    ClickElement       //span[@class\='mat-option-text' and text()\='Product Name']
    ClickElement       //mat-label[text()\='SELECT A PRODUCT']
    ClickElement       //span[text()\='PCC']

Validate Download quote letter button
    [Documentation]    Validate Download quote letter button

    ClickElement       //*[contains(@class, 'ellipsis d-flex align-items-center justify-content-center mx-auto')]
    ClickText          Download Quote Letter
    sleep              10s


Validate Download signature pack button 
    [Documentation]    Validate Download signature pack button

    ClickElement       //*[contains(@class, 'ellipsis d-flex align-items-center justify-content-center mx-auto')]
    ClickText          Signature Pack
    sleep              10s

    #Validate Bind Quote button
    [Documentation]

    ClickElement       //*[contains(@class, 'ellipsis d-flex align-items-center justify-content-center mx-auto')]
    ClickText          Bind Quote
    VerifyText         Thanks for wanting to Bind!