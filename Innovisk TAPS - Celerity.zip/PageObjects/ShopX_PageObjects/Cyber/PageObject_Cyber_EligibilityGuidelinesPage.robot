*** Settings ***
Library                QWeb
Library                QForce
#Library               QVision
Library                FakerLibrary
Library                String
Library                BuiltIn
Library                DateTime



*** Keywords ***

Validate elements on Eligibility Guidelines Page for Cyber
    [Documentation]    Validate elements on Eligibility Guidelines Page for Cyber


    VerifyText         Your time is our priority. Please check our Cyber Guidelines below for portal eligibility.
    VerifyText         Our Eligibility Guidelines
    VerifyText         Multifactor Authentication is enforced across the organization for e-mail, privileged user and remote access.
    VerifyText         Off-network Backup Solution is utilized for key server configurations and data. Backups are updated at least weekly.
    VerifyText         Insured does not collect, store or process personal, health or confidential information for more than 1,000,000 individuals.
    VerifyText         The Insured does not store or process more than 1,000,000 credit card transactions annually. They or their outsourced payment processor are PCI-DSS compliant.
    VerifyText         All sensitive data and information stored on the Insured's network is encrypted.
    VerifyText         The Insured is not aware of any fact, circumstance or situation that could reasonably be expected to give rise to an incident or claim.
    VerifyText         In the last three years, the Insured has incurred less than $50,000 in losses in relation to any security breach, privacy incident or network outage event.

    VerifyText         Yes, the Insured meets each of the Guidelines and I would like an instant quote
    VerifyText         No, the Insured doesn't meet some of the Guidelines and I would like to send my submission to

    VerifyElement      //input[@value\='confirm']
    VerifyElement      //input[@value\='remove']
    VerifyElement      //button[text()\=' Back ']
    VerifyElement      //button[text()\=' Next ']

Click on Next Button - Eligibility Guidelines Page

    [Documentation]    Click on Next Button - Eligibility Guidelines Page


    ClickElement       //input[@value\='confirm']
    ClickElement       //button[text()\=' Next ']

    VerifyText         Let's get you started...

Click on Back Button - Eligibility Guidelines Page

    ClickElement       //input[@value\='remove']
    ClickElement       //button[text()\=' Back ']
    ${Skip}=           IsText                      Skip

    IF                 "${Skip}" == "True"
        ClickText      Skip
    END

    VerifyText         Home
