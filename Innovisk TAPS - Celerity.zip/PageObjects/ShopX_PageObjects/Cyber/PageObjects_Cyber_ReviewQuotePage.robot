*** Settings ***
Library                   QWeb
Library                   QForce
#Library                  QVision
Library                   FakerLibrary
Library                   String
Library                   BuiltIn
Library                   DateTime



*** Keywords ***
Validate Static Elements on Review Quote page for Cyber
    [Documentation]       Validate Static Elements on Review Quote page for Cyber
    [Arguments]           ${Industry_Cyber_S}

    IF                    "${Industry_Cyber_S}" == "Business Services - Billing Services"
        VerifyText        Review My Quote
        VerifyText        VIEW BASIC LIMITS
        VerifyText        BASE POLICY LIMITS
        VerifyText        Full Prior Acts Coverage Provided
        VerifyText        LIMIT                       anchor=BASE POLICY LIMITS
        VerifyText        RETENTION
        ClickElement      //mat-select[@formcontrolname\='desiredLimit']//span
        VerifyText        $1,000,000
        VerifyText        $2,000,000
        ClickElement      //span[@class\='mat-option-text']
        sleep             5s
        ClickElement      //mat-select[@formcontrolname\='desiredRetention']//span
        VerifyText        $2,500
        VerifyText        $5,000
        VerifyText        $7,500
        VerifyText        $10,000
        VerifyText        $15,000
        ClickElement      //span[@class\='mat-option-text']
        VerifyText        Data Breach Liability
        VerifyText        Regulatory Defense And Penalties
        VerifyText        PCI Fines And Assessments
        VerifyText        Media
        VerifyText        Cyber Incident Response
        VerifyText        Business Interruption & Extra Expense
        VerifyText        Network Data Recovery
        VerifyText        Network Extortion
        VerifyText        ADDITIONAL COVERAGES PROVIDED
        VerifyText        Business Interruption & Extra Expense Enhancement
        VerifyText        Included                    anchor=Business Interruption & Extra Expense Enhancement
        VerifyText        Dependent Business Interruption
        VerifyText        $1,000,000                  anchor=Dependent Business Interruption
        VerifyText        Waiting Period 8 Hours
        VerifyText        System Failure
        VerifyText        $1,000,000                  anchor=System Failure
        VerifyText        Waiting Period 8 Hours      anchor=System Failure
        VerifyText        Dependent System Failure
        VerifyText        $1,000,000
        VerifyText        Waiting Period 8 Hours
        VerifyText        Bricking
        VerifyText        $1,000,000                  anchor=Bricking
        VerifyText        Included                    anchor=Bricking
        VerifyText        Reputational Harm
        VerifyText        $1,000,000                  anchor=Reputational Harm
        VerifyText        Included                    anchor=Reputational Harm
        VerifyText        Cryptojacking
        VerifyText        $1,000,000                  anchor=Cryptojacking
        VerifyText        Included                    anchor=Cryptojacking
        VerifyText        Cyber Crime Coverage
        VerifyText        Included                    anchor=Cyber Crime Coverage
        VerifyText        Social Engineering
        VerifyText        $100,000
        VerifyText        Funds Transfer
        VerifyText        $100,000
        VerifyText        Invoice Manipulation
        Verifytext        $50,000
        VerifyText        Telecommunications Fraud
        VerifyText        $50,000
        VerifyText        Additional Cyber Crime limits are available, if the Insured meets all these criteria.
        ClickText         Additional Cyber Crime limits are available, if the Insured meets all these criteria.
        VerifyText        In the last 12 months, the insured has provided anti-fraud training to all employees responsible for authorizing and executing payments for funds-transfer requests.
        VerifyText        There is a written policy for anti-fraud training that is provided to all employees responsible for disbursing or transmitting funds.
        VerifyText        All payments or funds-transfers over $25,000 require internal dual written authorization before release.
        VerifyText        All change requests regarding vendor account information are confirmed by a direct call to that vendor, using only the telephone number provided by the vendor PRIOR to the change request being received.
        VerifyText        Yes, the insured meets all these criteria
        VerifyText        I'd like to revise my quote and want to refer to Celerity Pro underwriters.
        VerifyText        Your Cyber Premium
        #VerifyText       $2,807.00
        VerifyText        Commission
        #VerifyText       $421.00
        VerifyText        Commission %
        #VerifyText        15
        VerifyText        SAVE TO MY QUOTES
        VerifyText        Back

    ELSE IF               "${Industry_Cyber_S}" == "Business Services - Membership Organizations"
        VerifyText        Review My Quote
        VerifyText        VIEW BASIC LIMITS
        VerifyText        BASE POLICY LIMITS
        VerifyText        Full Prior Acts Coverage Provided
        VerifyText        LIMIT                       anchor=BASE POLICY LIMITS
        VerifyText        RETENTION
        ClickElement      //mat-select[@formcontrolname\='desiredLimit']//span
        VerifyText        $1,000,000
        VerifyText        $2,000,000
        ClickElement      //span[@class\='mat-option-text']
        sleep             5s
        ClickElement      //mat-select[@formcontrolname\='desiredRetention']//span
        VerifyText        $2,500
        VerifyText        $5,000
        VerifyText        $7,500
        VerifyText        $10,000
        VerifyText        $15,000
        ClickElement      //span[@class\='mat-option-text']
        VerifyText        Data Breach Liability
        VerifyText        Regulatory Defense And Penalties
        VerifyText        PCI Fines And Assessments
        VerifyText        Media
        VerifyText        Cyber Incident Response
        VerifyText        Business Interruption & Extra Expense
        VerifyText        Network Data Recovery
        VerifyText        Network Extortion
        VerifyText        ADDITIONAL COVERAGES PROVIDED
        VerifyText        Business Interruption & Extra Expense Enhancement
        VerifyText        Included                    anchor=Business Interruption & Extra Expense Enhancement
        VerifyText        Dependent Business Interruption
        VerifyText        $1,000,000                  anchor=Dependent Business Interruption
        VerifyText        Waiting Period 8 Hours
        VerifyText        System Failure
        VerifyText        $1,000,000                  anchor=System Failure
        VerifyText        Waiting Period 8 Hours      anchor=System Failure
        VerifyText        Dependent System Failure
        VerifyText        $1,000,000
        VerifyText        Waiting Period 8 Hours
        VerifyText        Bricking
        VerifyText        $1,000,000                  anchor=Bricking
        VerifyText        Included                    anchor=Bricking
        VerifyText        Reputational Harm
        VerifyText        $1,000,000                  anchor=Reputational Harm
        VerifyText        Included                    anchor=Reputational Harm
        VerifyText        Cryptojacking
        VerifyText        $1,000,000                  anchor=Cryptojacking
        VerifyText        Included                    anchor=Cryptojacking
        VerifyText        Cyber Crime Coverage
        VerifyText        Included                    anchor=Cyber Crime Coverage
        VerifyText        Social Engineering
        VerifyText        $100,000
        VerifyText        Funds Transfer
        VerifyText        $100,000
        VerifyText        Invoice Manipulation
        Verifytext        $50,000
        VerifyText        Telecommunications Fraud
        VerifyText        $50,000
        VerifyText        Additional Cyber Crime limits are available, if the Insured meets all these criteria.
        ClickText         Additional Cyber Crime limits are available, if the Insured meets all these criteria.
        VerifyText        In the last 12 months, the insured has provided anti-fraud training to all employees responsible for authorizing and executing payments for funds-transfer requests.
        VerifyText        There is a written policy for anti-fraud training that is provided to all employees responsible for disbursing or transmitting funds.
        VerifyText        All payments or funds-transfers over $25,000 require internal dual written authorization before release.
        VerifyText        All change requests regarding vendor account information are confirmed by a direct call to that vendor, using only the telephone number provided by the vendor PRIOR to the change request being received.
        VerifyText        Yes, the insured meets all these criteria
        VerifyText        I'd like to revise my quote and want to refer to Celerity Pro underwriters.
        VerifyText        Your Cyber Premium
        #VerifyText       $2,807.00
        VerifyText        Commission
        #VerifyText       $421.00
        VerifyText        Commission %
        #VerifyText        15
        VerifyText        SAVE TO MY QUOTES
        VerifyText        Back

    ELSE IF               "${Industry_Cyber_S}" == "Business Services - Yacht/Boat Broker"
        VerifyText        Review My Quote
        VerifyText        VIEW BASIC LIMITS
        VerifyText        BASE POLICY LIMITS
        VerifyText        Full Prior Acts Coverage Provided
        VerifyText        LIMIT                       anchor=BASE POLICY LIMITS
        VerifyText        RETENTION
        ClickElement      //mat-select[@formcontrolname\='desiredLimit']//span
        VerifyText        $1,000,000
        VerifyText        $2,000,000
        ClickElement      //span[@class\='mat-option-text']
        sleep             5s
        ClickElement      //mat-select[@formcontrolname\='desiredRetention']//span
        VerifyText        $2,500
        VerifyText        $5,000
        VerifyText        $7,500
        VerifyText        $10,000
        VerifyText        $15,000
        ClickElement      //span[@class\='mat-option-text']
        VerifyText        Data Breach Liability
        VerifyText        Regulatory Defense And Penalties
        VerifyText        PCI Fines And Assessments
        VerifyText        Media
        VerifyText        Cyber Incident Response
        VerifyText        Business Interruption & Extra Expense
        VerifyText        Network Data Recovery
        VerifyText        Network Extortion
        VerifyText        ADDITIONAL COVERAGES PROVIDED
        VerifyText        Business Interruption & Extra Expense Enhancement
        VerifyText        Included                    anchor=Business Interruption & Extra Expense Enhancement
        VerifyText        Dependent Business Interruption
        VerifyText        $1,000,000                  anchor=Dependent Business Interruption
        VerifyText        Waiting Period 8 Hours
        VerifyText        System Failure
        VerifyText        $1,000,000                  anchor=System Failure
        VerifyText        Waiting Period 8 Hours      anchor=System Failure
        VerifyText        Dependent System Failure
        VerifyText        $1,000,000
        VerifyText        Waiting Period 8 Hours
        VerifyText        Bricking
        VerifyText        $1,000,000                  anchor=Bricking
        VerifyText        Included                    anchor=Bricking
        VerifyText        Reputational Harm
        VerifyText        $1,000,000                  anchor=Reputational Harm
        VerifyText        Included                    anchor=Reputational Harm
        VerifyText        Cryptojacking
        VerifyText        $1,000,000                  anchor=Cryptojacking
        VerifyText        Included                    anchor=Cryptojacking
        VerifyText        Cyber Crime Coverage
        VerifyText        Included                    anchor=Cyber Crime Coverage
        VerifyText        Social Engineering
        VerifyText        $100,000
        VerifyText        Funds Transfer
        VerifyText        $100,000
        VerifyText        Invoice Manipulation
        Verifytext        $50,000
        VerifyText        Telecommunications Fraud
        VerifyText        $50,000
        VerifyText        Additional Cyber Crime limits are available, if the Insured meets all these criteria.
        ClickText         Additional Cyber Crime limits are available, if the Insured meets all these criteria.
        VerifyText        In the last 12 months, the insured has provided anti-fraud training to all employees responsible for authorizing and executing payments for funds-transfer requests.
        VerifyText        There is a written policy for anti-fraud training that is provided to all employees responsible for disbursing or transmitting funds.
        VerifyText        All payments or funds-transfers over $25,000 require internal dual written authorization before release.
        VerifyText        All change requests regarding vendor account information are confirmed by a direct call to that vendor, using only the telephone number provided by the vendor PRIOR to the change request being received.
        VerifyText        Yes, the insured meets all these criteria
        VerifyText        I'd like to revise my quote and want to refer to Celerity Pro underwriters.
        VerifyText        Your Cyber Premium
        #VerifyText       $2,807.00
        VerifyText        Commission
        #VerifyText       $421.00
        VerifyText        Commission %
        #VerifyText        15
        VerifyText        SAVE TO MY QUOTES
        VerifyText        Back


    ELSE IF               "${Industry_Cyber_S}" == "Insurance - Insurance Company (Life)"

        VerifyText        Review My Quote
        VerifyText        VIEW BASIC LIMITS
        VerifyText        BASE POLICY LIMITS
        VerifyText        Full Prior Acts Coverage Provided
        VerifyText        LIMIT                       anchor=BASE POLICY LIMITS
        VerifyText        RETENTION
        ClickElement      //mat-select[@formcontrolname\='desiredLimit']//span
        VerifyText        $1,000,000
        VerifyText        $2,000,000
        ClickElement      //span[@class\='mat-option-text']
        sleep             5s
        ClickElement      //mat-select[@formcontrolname\='desiredRetention']//span
        VerifyText        $5,000
        VerifyText        $7,500
        VerifyText        $10,000
        VerifyText        $15,000
        VerifyText        $25,000
        VerifyText        $35,000
        VerifyText        $50,000
        ClickElement      //span[@class\='mat-option-text']
        VerifyText        Data Breach Liability
        VerifyText        Regulatory Defense And Penalties
        VerifyText        PCI Fines And Assessments
        VerifyText        Media
        VerifyText        Cyber Incident Response
        VerifyText        Business Interruption & Extra Expense
        VerifyText        Network Data Recovery
        VerifyText        Network Extortion
        VerifyText        ADDITIONAL COVERAGES PROVIDED
        VerifyText        Business Interruption & Extra Expense Enhancement
        VerifyText        Included                    anchor=Business Interruption & Extra Expense Enhancement
        VerifyText        Dependent Business Interruption
        VerifyText        $1,000,000                  anchor=Dependent Business Interruption
        VerifyText        Waiting Period 8 Hours
        VerifyText        System Failure
        VerifyText        $1,000,000                  anchor=System Failure
        VerifyText        Waiting Period 8 Hours      anchor=System Failure
        VerifyText        Dependent System Failure
        VerifyText        $1,000,000
        VerifyText        Waiting Period 8 Hours
        VerifyText        Bricking
        VerifyText        $1,000,000                  anchor=Bricking
        VerifyText        Included                    anchor=Bricking
        VerifyText        Reputational Harm
        VerifyText        $1,000,000                  anchor=Reputational Harm
        VerifyText        Included                    anchor=Reputational Harm
        VerifyText        Cryptojacking
        VerifyText        $1,000,000                  anchor=Cryptojacking
        VerifyText        Included                    anchor=Cryptojacking
        VerifyText        Cyber Crime Coverage
        VerifyText        Included                    anchor=Cyber Crime Coverage
        VerifyText        Social Engineering
        VerifyText        $100,000
        VerifyText        Funds Transfer
        VerifyText        $100,000
        VerifyText        Invoice Manipulation
        Verifytext        $50,000
        VerifyText        Telecommunications Fraud
        VerifyText        $50,000
        VerifyText        Additional Cyber Crime limits are available, if the Insured meets all these criteria.
        ClickText         Additional Cyber Crime limits are available, if the Insured meets all these criteria.
        VerifyText        In the last 12 months, the insured has provided anti-fraud training to all employees responsible for authorizing and executing payments for funds-transfer requests.
        VerifyText        There is a written policy for anti-fraud training that is provided to all employees responsible for disbursing or transmitting funds.
        VerifyText        All payments or funds-transfers over $25,000 require internal dual written authorization before release.
        VerifyText        All change requests regarding vendor account information are confirmed by a direct call to that vendor, using only the telephone number provided by the vendor PRIOR to the change request being received.
        VerifyText        Yes, the insured meets all these criteria
        VerifyText        I'd like to revise my quote and want to refer to Celerity Pro underwriters.
        VerifyText        Your Cyber Premium
        #VerifyText       $2,807.00
        VerifyText        Commission
        #VerifyText       $421.00
        VerifyText        Commission %
        #VerifyText        15
        VerifyText        SAVE TO MY QUOTES
        VerifyText        Back

    END

Validate Static Elements on Review Quote page for Cyber - Insurance - Insurance Company (Life)
    [Documentation]       Validate Static Elements on Review Quote page for Cyber - Insurance - Insurance Company (Life)
    VerifyText            Review My Quote
    VerifyText            VIEW BASIC LIMITS
    VerifyText            BASE POLICY LIMITS
    VerifyText            Full Prior Acts Coverage Provided
    VerifyText            LIMIT                       anchor=BASE POLICY LIMITS
    VerifyText            RETENTION
    ClickElement          //mat-select[@formcontrolname\='desiredLimit']//span
    VerifyText            $1,000,000
    VerifyText            $2,000,000
    ClickElement          //span[@class\='mat-option-text']
    sleep                 5s
    ClickElement          //mat-select[@formcontrolname\='desiredRetention']//span
    VerifyText            $5,000
    VerifyText            $7,500
    VerifyText            $10,000
    VerifyText            $15,000
    VerifyText            $25,000
    VerifyText            $35,000
    VerifyText            $50,000
    ClickElement          //span[@class\='mat-option-text']
    VerifyText            Data Breach Liability
    VerifyText            Regulatory Defense And Penalties
    VerifyText            PCI Fines And Assessments
    VerifyText            Media
    VerifyText            Cyber Incident Response
    VerifyText            Business Interruption & Extra Expense
    VerifyText            Network Data Recovery
    VerifyText            Network Extortion
    VerifyText            ADDITIONAL COVERAGES PROVIDED
    VerifyText            Business Interruption & Extra Expense Enhancement
    VerifyText            Included                    anchor=Business Interruption & Extra Expense Enhancement
    VerifyText            Dependent Business Interruption
    VerifyText            $1,000,000                  anchor=Dependent Business Interruption
    VerifyText            Waiting Period 8 Hours
    VerifyText            System Failure
    VerifyText            $1,000,000                  anchor=System Failure
    VerifyText            Waiting Period 8 Hours      anchor=System Failure
    VerifyText            Dependent System Failure
    VerifyText            $1,000,000
    VerifyText            Waiting Period 8 Hours
    VerifyText            Bricking
    VerifyText            $1,000,000                  anchor=Bricking
    VerifyText            Included                    anchor=Bricking
    VerifyText            Reputational Harm
    VerifyText            $1,000,000                  anchor=Reputational Harm
    VerifyText            Included                    anchor=Reputational Harm
    VerifyText            Cryptojacking
    VerifyText            $1,000,000                  anchor=Cryptojacking
    VerifyText            Included                    anchor=Cryptojacking
    VerifyText            Cyber Crime Coverage
    VerifyText            Included                    anchor=Cyber Crime Coverage
    VerifyText            Social Engineering
    VerifyText            $100,000
    VerifyText            Funds Transfer
    VerifyText            $100,000
    VerifyText            Invoice Manipulation
    Verifytext            $50,000
    VerifyText            Telecommunications Fraud
    VerifyText            $50,000
    VerifyText            Additional Cyber Crime limits are available, if the Insured meets all these criteria.
    ClickText             Additional Cyber Crime limits are available, if the Insured meets all these criteria.
    VerifyText            In the last 12 months, the insured has provided anti-fraud training to all employees responsible for authorizing and executing payments for funds-transfer requests.
    VerifyText            There is a written policy for anti-fraud training that is provided to all employees responsible for disbursing or transmitting funds.
    VerifyText            All payments or funds-transfers over $25,000 require internal dual written authorization before release.
    VerifyText            All change requests regarding vendor account information are confirmed by a direct call to that vendor, using only the telephone number provided by the vendor PRIOR to the change request being received.
    VerifyText            Yes, the insured meets all these criteria
    VerifyText            I'd like to revise my quote and want to refer to Celerity Pro underwriters.
    VerifyText            Your Cyber Premium
    #VerifyText           $2,807.00
    VerifyText            Commission
    #VerifyText           $421.00
    VerifyText            Commission %
    #VerifyText            15
    VerifyText            SAVE TO MY QUOTES
    VerifyText            Back


Validate Clicking on Save to My quote button
    [Documentation]       Validate Clicking on Save to My quote button
    Sleep                 30s
    ${SAVETOMYQUOTES}=    IsText                      SAVE TO MY QUOTES           timeout=20

    IF                    "${SAVETOMYQUOTES}" == "True"
        Clicktext         SAVE TO MY QUOTES
    ELSE
        Clicktext         SAVE CHANGES

        IsText            Updating                    timeout=30s
        Clicktext         SAVE TO MY QUOTES
        IsText            loading                     timeout=30s
    END

    VerifyText            My Saved Quotes



Validate clicking on referral button
    [Documentation]       Validate clicking on referral button
    #[Arguments]          ${Address1}
    VerifyText            I'd like to revise my quote and want to refer to Celerity Pro underwriters.
    Sleep                 5s
    ClickElement          //span[contains(@class,'checkmark')]
    TypeText              I'd like to request ...     Copado Test

Validate actions performed on review quote page with referral
    [Documentation]       Validate actions performed on review quote page with refferal
    VerifyText            SAVE CHANGES
    VerifyText            DISCARD CHANGES
    ClickText             DISCARD CHANGES


Click on back button on Review quote page
    [Documentation]       Validate clicking on back button on Review quote page

    VerifyText            Back
    ClickElement          //button[text()\=' Back ']


Verify Static text for Referral Quote
    #Author=Saurabh
    [Documentation]       Verify Static text for Referral Quote
    VerifyText            The information you entered will need underwriter approval.
    VerifyText            Your quote will be referred when you click Save to My Quotes, until then you can make changes to your quote.ion}

