*** Settings ***
Library                QWeb
Library                QForce
#Library               QVision
Library                FakerLibrary
Library                String
Library                BuiltIn
Library                DateTime



*** Keywords ***

Validate Celerity ShopX Home page
    [Documentation]    Validate Celerity ShopX Home page

    ClickText          Home
    VerifyText         Home
    VerifyText         About
    ClickText          About
    VerifyText         About Celerity Pro
    VerifyText         Testimonials
    VerifyText         Our Team
    VerifyText         Connect with our team of specialists
    #VerifyText         CELERITYAUTOMATION COPADOBROKER
    #ClickText          CELERITYAUTOMATION COPADOBROKER
    VerifyText         Downloads
    VerifyText         Start Quote
    VerifyText         Go to My Saved Quotes
    VerifyText         Logout
    VerifyText         How It Works
    VerifyText         Reach out to a team member today
    VerifyText         Privacy Policy
    VerifyText         Terms of Use
    VerifyText         Find out More
    Log To Console     ------Celerity ShopX Home page Validated Successfully-------

Validate Start Quote button
    [Documentation]    Validate Start Quote button

    ClickText          Start Quote
    ${Skip}=           IsText                      Skip

    IF                 "${Skip}" == "True"
        ClickText      Skip
    END
    VerifyText         New Quote
    #VerifyText         Welcome, Celerityautomation Copadobroker. Select a product to get an instant quote.
    VerifyText         Cyber
    VerifyText         Private Company Combo (PCC)
    VerifyText         Miscellaneous Professional Liability
    VerifyText         MINIMUM PREMIUM STARTS AT                               anchor=Cyber
    VerifyText         $2,500/year
    VerifyText         FEATURES                    anchor=Cyber
    VerifyText         Primary Coverage
    VerifyText         $3M Aggregate Limits available
    VerifyText         Accounts up to $50M Revenue
    VerifyText         Full Prior Acts provided    anchor=Cyber
    VerifyText         Worldwide coverage          anchor=Cyber
    VerifyText         Pre-paid Cyber Loss Prevention Services
    VerifyText         Underwritten by Certain Underwriters at Lloyd's
    VerifyElement      //button[@id\="btn_Cyber"]
    VerifyText         MINIMUM PREMIUM STARTS AT                               anchor=Private Company Combo (PCC)
    VerifyText         $2,000/year
    VerifyText         FEATURES                    anchor=Private Company Combo (PCC)
    VerifyText         Primary D&O, EPL, FID, Crime coverages
    VerifyText         Up to $6 Million Combined Aggregate Limits available
    VerifyText         Accounts up to $50 Million Revenue
    VerifyText         Full Prior Acts provided    anchor=Private Company Combo (PCC)
    VerifyText         Worldwide coverage          anchor=Private Company Combo (PCC)
    VerifyText         Numerous Target Industries
    VerifyText         Underwritten by Certain Underwriters at Lloyd's, London and Other Insurers    anchor=Private Company Combo (PCC)
    VerifyElement      //button[@id\="btn_Private Company Combo (PCC)"]
    VerifyText         MINIMUM PREMIUM STARTS AT                               anchor=Miscellaneous Professional Liability
    VerifyText         $1,000/year
    VerifyText         FEATURES                    anchor=Miscellaneous Professional Liability
    VerifyText         Primary Coverage            anchor=Miscellaneous Professional Liability
    VerifyText         $2M Aggregate Limits available
    VerifyText         Accounts up to $50M Revenue                             anchor=Miscellaneous Professional Liability
    VerifyText         Worldwide coverage          anchor=Miscellaneous Professional Liability
    VerifyText         Expansive Supplemental Coverages included
    VerifyText         Numerous Target Classes
    VerifyText         Pre-paid Cyber Loss Prevention Services
    VerifyText         Underwritten by Certain Underwriters at Lloyd's, London and Other Insurers    anchor=Miscellaneous Professional Liability
    VerifyElement      //button[@id\="btn_Miscellaneous Professional Liability"]
    Sleep              2s
    ClickText          Home
    Log To Console     ------Celerity ShopX start quote page Validated Successfully-------
Validate clicking on Go to My Saved Quotes
    [Documentation]    Validate clicking on Go to My Saved Quotes
    ClickText          Go to My Saved Quotes
    Sleep              10s
    VerifyText         My Saved Quotes
    ClickText          Home
    Log To Console     ------ ShopX Go to My Saved Quotes Validated Successfully-------
Validate clicking on Products
    [Documentation]    Validate clicking on Products
    ClickText          Products
    VerifyText         Our Products
    VerifyText         Looking for smart specialty insurance products that can be bound with ease? You're in the right place.
    VerifyText         Our comprehensive coverage is intelligently packaged to address your customers' management liability, professional liability and cyber insurance needs. Check out what we have on offer.
    VerifyText         Cyber Liability
    VerifyText         Miscellaneous Professional Liability
    VerifyText         Technology E&O
    VerifyText         Private Company D&O/Management Liability Combo
    VerifyText         Public Company D&O / Management Liability Package
    VerifyText         Interested in Downloading Applications and More?
    VerifyText         Visit Our Downloads Page
    ClickText          Cyber Liability
    VerifyText         About The Product
    VerifyText         Cyber Liability
    VerifyText         Cyber breaches of customer or employee information have become commonplace, and threats are increasing with the technological sophistication of hackers and other malicious actors. Our Cyber insurance protects small to mid-sized businesses against first party and third-party liability losses in an increasingly complex digital world.
    VerifyText         Primary coverage
    VerifyText         Up to $5M aggregate limit
    VerifyText         Up to $250M revenue
    VerifyText         Full Prior Acts available
    VerifyText         Duty to defend
    VerifyText         Worldwide coverage
    VerifyText         Enhancements available
    VerifyText         Risk management services
    VerifyText         Excess Follow Form coverage also available
    VerifyText         Policy Coverage Highlights
    VerifyText         Blanket additional insured status where required by contract
    VerifyText         Data breach first responder paid at first dollar
    VerifyText         24/7 Data breach hotline
    VerifyText         Affirmative regulatory coverage in absence of a security breach
    VerifyText         Unintentional wrongful collection covered
    VerifyText         Forensic accounting costs covered at full limits
    VerifyText         Coverage for PCI fines and assessments
    VerifyText         Optional Coverage Enhancements
    VerifyText         Cyber crime endorsement, including Social Engineering, Invoice Manipulation, and more...
    VerifyText         Dependent Business Interruption, System Failure, and Dependent System Failure
    VerifyText         Reputational harm
    VerifyText         Preventative Shutdown
    VerifyText         Betterment
    VerifyText         Bricking
    VerifyText         Risk Management Services
    VerifyText         Included at no additional cost
    VerifyText         Internal phishing campaigns
    VerifyText         Virtual ciso (unlimited advice)
    VerifyText         Employee training
    VerifyText         Complimentary training coordinator
    VerifyText         Compliance resources
    VerifyText         News and alerts
    VerifyText         Interested in Downloading Applications and More?
    VerifyText         Visit Our Downloads Page
    ClickText          < Return to All Products
    ClickText          Miscellaneous Professional Liability
    VerifyText         About The Product
    VerifyText         Miscellaneous Professional Liability
    VerifyText         Firms offering personal or business services are increasingly exposed to claim alleging various wrongful acts, errors or omissions in the provision of such services. With legal and settlement costs extraordinarily expensive, our policy is designed to help small to mid-sized businesses protect themselves from demanding and litigious customers. Our Miscellaneous Professional Liability policy is specially crafted to offer the most important protection you need.
    VerifyText         Primary coverage
    VerifyText         Up to $5M aggregate limit
    VerifyText         Up to $250M revenue
    VerifyText         Full Prior Acts available
    VerifyText         Duty to defend
    VerifyText         Worldwide coverage
    VerifyText         Enhancements available
    VerifyText         Risk management services
    VerifyText         Excess Follow Form coverage also available
    VerifyText         Policy Coverage Highlights
    VerifyText         Wide spectrum of target classes of business
    VerifyText         Customized definition of professional services
    VerifyText         Blanket additional insured status where required by contract
    VerifyText         Personal Injury coverage
    VerifyText         Settlement of a claim with the Insured’s consent
    VerifyText         Punitive damages covered with most favorable venue clause where insurable
    VerifyText         Supplemental Payments in addition to limit
    VerifyText         Automatic Extended Reporting Period included
    VerifyText         Optional Coverage Enhancements
    VerifyText         Contingent BI/PD coverage
    VerifyText         Cyber liability coverage
    VerifyText         Media liability coverage
    VerifyText         Claim Expenses Outside the Limit
    VerifyText         Technology Services Extension
    VerifyText         Interested in Downloading Applications and More?
    VerifyText         Visit Our Downloads Page
    ClickText          < Return to All Products
    ClickText          Technology E&O
    VerifyText         About The Product
    VerifyText         Technology E&O
    VerifyText         Whether a company is designing a Technology software product or providing Technology services to others, any wrongful act, error or omission on their part can result in significant financial damage to their clients. Our Tech E&O insurance policy protects small to mid-sized Technology companies against those third-party liability losses.
    VerifyText         Primary coverage
    VerifyText         Up to $5M aggregate limit
    VerifyText         Up to $250M revenue
    VerifyText         Prior Acts Coverage Available
    VerifyText         Duty to defend
    VerifyText         Worldwide coverage
    VerifyText         Cyber & Media Coverage Available
    VerifyText         Cyber Risk Management Services
    VerifyText         Excess Follow Form coverage also available
    VerifyText         Policy Coverage Highlights
    VerifyText         Technology E&O resulting in Breach of Contract
    VerifyText         If applicable, coverage extended to include Professional Services E&O
    VerifyText         Personal Injury Liability Coverage
    VerifyText         Infringement of Intellectual Property
    VerifyText         Optional Coverage Enhancements
    VerifyText         Media liability coverage included
    VerifyText         Expansive Cyber Liability coverage included
    VerifyText         Learn more about our Cyber Product
    Verifytext         Target Classes (not all-inclusive)
    VerifyText         Software Developers & Providers
    VerifyText         System Implementation Services
    VerifyText         Web Design Services
    VerifyText         Data Processing, Storage & Hosting
    VerifyText         Cloud Providers
    VerifyText         Technology Consultants
    Verifytext         Application Services Providers
    VerifyText         Interested in Downloading Applications and More?
    VerifyText         Visit Our Downloads Page
    ClickText          < Return to All Products
    ClickText          Private Company D&O/Management Liability Combo
    VerifyText         About The Product
    VerifyText         Private Company D&O/Management Liability Combo
    VerifyText         Celerity Pro’s Management Liability private policy offering is purpose-built to protect small and middle market clients in the ever-evolving complex world of Management Liability litigation. It will give your clients peace of mind by helping to protect their balance sheets, company leadership, employees and fiduciaries from lawsuits – so they can focus more on effectively managing their business.
    VerifyText         Primary coverage
    VerifyText         Up to $5M aggregate limit
    VerifyText         Up to $10M policy aggregate
    VerifyText         Up to $250M revenue. Larger companies may be considered
    VerifyText         Full Prior Acts
    VerifyText         Duty to defend
    VerifyText         Worldwide coverage
    VerifyText         Excess Follow Form coverage
    VerifyText         Policy Coverage Highlights
    VerifyText         Broad Private Company Industry Appetite; plus Not-for-Profit firms
    VerifyText         Additional Limit for Side A
    VerifyText         Derivative Demand Costs Sublimit
    VerifyText         Cooperation Severability
    VerifyText         Fully Non-Rescindable
    VerifyText         Fully Non-Cancelable (except for non-payment of premium)
    VerifyText         Full Individual Severability – Representations made on Application
    VerifyText         Priority of Payments
    VerifyText         Conduct & Profit Exclusions – “Final, non-appealable adjudication” + “Underlying proceeding/action” language
    VerifyText         Third Party Coverage
    VerifyText         Settlor Coverage
    VerifyText         Optional Coverage Enhancements
    VerifyText         Crisis Mitigation Costs Extension
    VerifyText         Employed Lawyers Coverage
    VerifyText         Wage & Hour Sublimit
    VerifyText         Fiduciary Civil Fines and Penalties Sublimit
    VerifyText         Social Engineering Sublimit
    VerifyText         Other Optional Coverage Enhancements Available
    VerifyText         Risk Management Services
    VerifyText         Employment Practices Hotline
    VerifyText         Comprehensive Risk Management Website
    VerifyText         Interested in Downloading Applications and More?
    VerifyText         Visit Our Downloads Page
    ClickText          < Return to All Products
    ClickText          Public Company D&O / Management Liability Package
    VerifyText         About The Product
    VerifyText         Public Company D&O / Management Liability Package
    VerifyText         Celerity Pro’s public company Management Liability product is designed to provide coverage for actual or alleged wrongful acts made against directors and officers while managing a publicly traded company. Supported by seasoned underwriters equipped with the flexibility to intelligently package solutions, our product set is available for a broad selection of industries.
    VerifyText         Primary coverage
    VerifyText         Excess Follow Form coverage
    VerifyText         Up to $2 billion in market capitalization (U.S. domiciled risks)
    VerifyText         Full Prior Acts available
    VerifyText         Worldwide coverage
    VerifyText         Standalone Employment Practices
    VerifyText         Standalone Fiduciary Liability
    VerifyText         Excess Follow Form coverage also available
    VerifyText         Policy Coverage Highlights
    VerifyText         Broad Industry Appetite
    VerifyText         Notice limited to Executives
    VerifyText         Retiree Coverage for Insured Persons
    VerifyText         Derivative Demand Investigation Cost Sublimit
    VerifyText         Investigative Inquiry Coverage Sublimit
    VerifyText         Subpoena Coverage Sublimit
    VerifyText         Independent Director Liability Coverage Sublimit
    VerifyText         Third Party Coverage
    VerifyText         Settlor Coverage
    VerifyText         Other Optional Coverage Enhancements Available
    VerifyText         Risk Management Services
    VerifyText         Employment Practices Helpline
    VerifyText         Employment Practices Training
    VerifyText         Interested in Downloading Applications and More?
    VerifyText         Visit Our Downloads Page
    ClickText          < Return to All Products
    ClickText          Home
    Log To Console     ------Celerity ShopX Product page Validated Successfully-------

Validate Download Page
    VerifyText         Downloads
    ClickText          Downloads
    sleep              2s
    VerifyText         Downloads
    VerifyText         Looking for smart specialty insurance products that can be bound with ease? You're in the right place.
    VerifyText         Our comprehensive coverage is intelligently packaged to address your customers' professional liability and cyber needs. Check out what we have on offer.
    VerifyText         Cyber Liability
    VerifyText         Marketing Material          anchor=Cyber Liability
    VerifyText         Celerity Pro Cyber Highlight Sheet
    VerifyText         Miscellaneous Professional Liability
    VerifyText         Marketing Material          anchor=Miscellaneous Professional Liability
    VerifyText         Celerity Pro MPL Highlight Sheet
    VerifyText         Private Company D&O/Management Liability Combo
    VerifyText         Marketing Material          anchor=Private Company D&O/Management Liability Combo
    VerifyText         Vindicator Private Company Highlight Sheet
    VerifyText         Public Company D&O/Management Liability Package
    VerifyText         Marketing Material          anchor=Public Company D&O/Management Liability Package
    VerifyText         Public Company Highlight Sheet
    Log To Console     ------Celerity ShopX Download page Validated Successfully-------

Validate How it Works
    ClickText          Home
    sleep              2s
    ClickText          How It Works
    VerifyElement      //*[contains(@id, 'video')]
    Sleep              2s
    ClickText          CELERITYAUTOMATION COPADOBROKER
    ClickText          How It Works
    sleep              2s
    Log To Console     ------Celerity ShopX How it works page Validated Successfully-------

Validate about Celerity Pro
    Clicktext          About
    VerifyText         About Celerity Pro
    ClickText          About Celerity Pro
    VerifyText         About Celerity Pro
    VerifyText         Want to partner with an insurtech MGA that uses both digital and traditional methods to swiftly deliver specialty insurance products for the small and mid-sized business community?
    VerifyText         Great - that's us!
    VerifyText         Brokers come to Celerity Pro for our expertise in underwriting management liability, professional liability and cyber risks. Learn more about what we do and why we do it.
    Log To Console     ------Celerity ShopX About Celerity pro page Validated Successfully-------

Validate Our Team
    Clicktext          About
    VerifyText         Our Team
    ClickText          Our Team
    VerifyText         Meet the Celerity Team
    VerifyText         Carl Pursiano
    VerifyText         Simon White
    VerifyText         Miosotis (Mio) Rubirosa-Luciano
    VerifyText         Luis Rivera
    VerifyText         Danielle Cordeau
    VerifyText         Charlie Moore-Gillon
    VerifyText         Evan McCarthy
    VerifyText         Erin Hayden
    VerifyText         Joshua Cohen
    VerifyText         Delaney Simpson
    ClickText          Home
    Log To Console     ------Celerity Our Team page Validated Successfully-------

Validate Logout
    VerifyText         Logout
    ClickText          Logout
    VerifyText         Insurtech MGA Focused on Small-to-Mid-sized Businesses
    Log To Console     ------Celerity ShopX Logout Validated Successfully-------


