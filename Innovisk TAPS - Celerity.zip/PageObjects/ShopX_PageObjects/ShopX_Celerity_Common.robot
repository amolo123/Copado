*** Settings ***
Library                    QWeb
Library                    QForce
Library                    String
Library                    Collections
Library                    DateTime
Library                    OperatingSystem

*** Variables ***
${PCC}                     Private Company Combo (PCC)

*** Keywords ***

Select ShopX Product on homepage
    [Documentation]        Select ShopX Product on homepage
    [Arguments]            ${Cel_Product}


    Verifytext             New Quote

    IF                     "${Cel_Product}" == "Cyber"

        ClickElement       //button[@id\="btn_Cyber"]
        Log                Cyber Selected

    ELSE IF                "${Cel_Product}" == "PCC"

        ClickElement       //button[@id\="btn_Private Company Combo (PCC)"]
        log                PCC Selected

    ELSE IF                "${Cel_Product}" == "MPL"

        ClickElement       //button[@id\="btn_Miscellaneous Professional Liability"]
        log                MPL Selected

    END

Convert Name to Upper Case 

    [Documentation]        Convert Name to Upper Case
    [Arguments]            ${Str}

    ${str1}=               Convert To Upper Case       ${Str}
    Set Global Variable    ${str1}
    Log To Console         ${str1}