*** Settings ***
Library                QWeb
Library                QForce
#Library               QVision
Library                FakerLibrary
Library                String
Library                BuiltIn
Library                DateTime



*** Keywords ***
Validate clicking on Go to My Saved Quotes
    [Documentation]    Validate clicking on Go to My Saved Quotes
    ClickText          Home
    ClickText          Go to My Saved Quotes
    VerifyText         My Saved Quotes
    Log To Console     ------Celerity ShopX My Saved Quote page Validated Successfully-------

Validate all the elements on My saved quotes page
    [Documentation]    Validate all the elements on My saved quotes page
    VerifyElement      //*[contains(@class, 'hero-heading mb-0')]
    VerifyText         Go To My Policies
    #VerifyText        Select A search Filter
    VerifyText         SEARCH
    VerifyText         RESET
    ClickElement       //mat-label[text()\='Select a search filter']
    VerifyText         Account Name
    VerifyText         Product Name
    #ClickText         Account Name
    VerifyElement      //span[@class\='mat-option-text' and text()\='Product Name']
    ClickElement       //span[@class\='mat-option-text' and text()\='Account Name']
    VerifyText         PRODUCT
    VerifyText         LIMIT
    VerifyText         RETENTION
    VerifyText         PREMIUM
    VerifyText         COMMISSION
    VerifyText         EFFECTIVE DATE
    VerifyText         STATUS
    VerifyText         ACTION
    VerifyText         Load More
    ClickElement       //*[contains(@class, 'ellipsis d-flex align-items-center justify-content-center mx-auto')]
    VerifyText         Download Quote Letter
    VerifyText         Signature Pack
    VerifyText         Bind Quote
    VerifyText         View Quote
    VerifyText         Delete Quote

    VerifyElement      //button[text()\='SEARCH']
    VerifyElement      //button[text()\='RESET']
    Log To Console     ------Celerity ShopX Home page Validated Successfully-------



Validate Clicking on Search button
    [Documentation]    Validate Clicking on Search button
    ClickElement       //button[text()\='SEARCH']
    Sleep              10s

Validate clicking on Reset button
    [Documentation]    Validate clicking on Reset button

    ClickElement       //button[text()\='RESET']
    VerifyText         Loading...                  timeout=30s


Validate searching with Product name MPL
    [Documentation]        Validate searching with Product name MPL

    ClickElement       //mat-label[text()\='Select a search filter']
    VerifyText         Product Name
    ClickElement       //span[@class\='mat-option-text' and text()\='Product Name']
    ClickElement       //mat-label[text()\='SELECT A PRODUCT']
    ClickElement       //span[text()\='MPL']


Validate searching with Product name Cyber
    [Documentation]        Validate searching with Product name Cyber

    ClickElement       //mat-label[text()\='Select a search filter']
    VerifyText         Product Name
    ClickElement       //span[@class\='mat-option-text' and text()\='Product Name']
    ClickElement       //mat-label[text()\='SELECT A PRODUCT']
    ClickElement       //span[text()\='Cyber']


Validate searching with Product name PCC
    [Documentation]        Validate searching with Product name PCC

    ClickElement       //mat-label[text()\='Select a search filter']
    VerifyText         Product Name
    ClickElement       //span[@class\='mat-option-text' and text()\='Product Name']
    ClickElement       //mat-label[text()\='SELECT A PRODUCT']
    ClickElement       //span[text()\='PCC']

Validate Download quote letter button
    [Documentation]    Validate Download quote letter button

    ClickElement       //*[contains(@class, 'ellipsis d-flex align-items-center justify-content-center mx-auto')]
    sleep              10s
    ClickText          Download Quote Letter
    sleep              10s


Validate Download signature pack button 
    [Documentation]    Validate Download signature pack button 

    ClickElement       //*[contains(@class, 'ellipsis d-flex align-items-center justify-content-center mx-auto')]
    sleep              10s
    ClickText          Signature Pack
    sleep              10s

Validate Bind Quote button
    [Documentation]    

    ClickElement       //*[contains(@class, 'ellipsis d-flex align-items-center justify-content-center mx-auto')]
    ClickText          Bind Quote
    VerifyText         Thanks for wanting to Bind!