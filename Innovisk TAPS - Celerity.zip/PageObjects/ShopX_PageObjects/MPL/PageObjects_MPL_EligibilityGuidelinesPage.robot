*** Settings ***
Library                QWeb
Library                QForce
#Library               QVision
Library                FakerLibrary
Library                String
Library                BuiltIn
Library                DateTime



*** Keywords ***

Validate elements on Eligibility Guidelines Page for MPL
    [Documentation]    Validate elements on Eligibility Guidelines Page for MPL
    [Arguments]        ${Industry_MPL_S}


    IF                 "${Industry_MPL_S}" == "Business Services - Billing Services"

        VerifyText     Your time is our priority. Please check our MPL Guidelines below for portal eligibility.
        VerifyText     Our Eligibility Guidelines

        VerifyText     The Insured has been in business for more than 3 years
        VerifyText     The Insured has incurred less than $50,000 in losses and/or reported less than 3 claim notifications in the past 36 months
        VerifyText     The Insured is not aware of an issue or circumstance that could potentially lead to a claim
        VerifyText     The Insured maintains current and valid professional certifications or designations as required or recognized by industry standards.
        VerifyText     No revenues are generated from debt collecting services.
        VerifyText     The Insured does not provide any medical billing services.

        VerifyText     Yes, the Insured meets each of the Guidelines and I would like an instant quote
        VerifyText     No, the Insured doesn't meet some of the Guidelines and I would like to send my submission to

        VerifyElement                              //input[@value\='confirm']
        VerifyElement                              //input[@value\='remove']
        VerifyElement                              //button[text()\=' Back ']
        VerifyElement                              //button[text()\=' Next ']

    ELSE IF            "${Industry_MPL_S}" == "Business Services - Accreditation & Certification Services"

        VerifyText     Your time is our priority. Please check our MPL Guidelines below for portal eligibility.
        VerifyText     Our Eligibility Guidelines

        VerifyText     The Insured has been in business for more than 3 years
        VerifyText     The Insured has incurred less than $50,000 in losses and/or reported less than 3 claim notifications in the past 36 months
        VerifyText     The Insured is not aware of an issue or circumstance that could potentially lead to a claim
        VerifyText     The Insured does not provide accreditation/certification programs to any healthcare related industry.

        VerifyText     Yes, the Insured meets each of the Guidelines and I would like an instant quote
        VerifyText     No, the Insured doesn't meet some of the Guidelines and I would like to send my submission to

        VerifyElement                              //input[@value\='confirm']
        VerifyElement                              //input[@value\='remove']
        VerifyElement                              //button[text()\=' Back ']
        VerifyElement                              //button[text()\=' Next ']
    
    ELSE IF            "${Industry_MPL_S}" == "Business Services - Alarm Monitors"

        VerifyText     Your time is our priority. Please check our MPL Guidelines below for portal eligibility.
        VerifyText     Our Eligibility Guidelines

        VerifyText     The Insured has been in business for more than 3 years
        VerifyText     The Insured has incurred less than $50,000 in losses and/or reported less than 3 claim notifications in the past 36 months
        VerifyText     The Insured is not aware of an issue or circumstance that could potentially lead to a claim
        VerifyText     The Insured is licensed in all states in which it performs alarm monitoring services.
        VerifyText     No alarm installation services are provided in addition to alarm monitoring.

        VerifyText     Yes, the Insured meets each of the Guidelines and I would like an instant quote
        VerifyText     No, the Insured doesn't meet some of the Guidelines and I would like to send my submission to

        VerifyElement                              //input[@value\='confirm']
        VerifyElement                              //input[@value\='remove']
        VerifyElement                              //button[text()\=' Back ']
        VerifyElement                              //button[text()\=' Next ']
    
    ELSE IF            "${Industry_MPL_S}" == "Business Services - Auctioneer"

        VerifyText     Your time is our priority. Please check our MPL Guidelines below for portal eligibility.
        VerifyText     Our Eligibility Guidelines

        VerifyText     The Insured has been in business for more than 3 years
        VerifyText     The Insured has incurred less than $50,000 in losses and/or reported less than 3 claim notifications in the past 36 months
        VerifyText     The Insured is not aware of an issue or circumstance that could potentially lead to a claim
        VerifyText     The Insured does not include any items that it owns or has a controlling interest in when conducting auctions.
        VerifyText     No written guarantee relating to the authenticity of items is provided at any auction.
        VerifyText     The Insured does not perform any Real Estate auctions.

        VerifyText     Yes, the Insured meets each of the Guidelines and I would like an instant quote
        VerifyText     No, the Insured doesn't meet some of the Guidelines and I would like to send my submission to

        VerifyElement                              //input[@value\='confirm']
        VerifyElement                              //input[@value\='remove']
        VerifyElement                              //button[text()\=' Back ']
        VerifyElement                              //button[text()\=' Next ']
    
    ELSE IF            "${Industry_MPL_S}" == "Business Services - Audio/Video"

        VerifyText     Your time is our priority. Please check our MPL Guidelines below for portal eligibility.
        VerifyText     Our Eligibility Guidelines

        VerifyText     The Insured has been in business for more than 3 years
        VerifyText     The Insured has incurred less than $50,000 in losses and/or reported less than 3 claim notifications in the past 36 months
        VerifyText     The Insured is not aware of an issue or circumstance that could potentially lead to a claim
        VerifyText     The Insured only provides audio/video installation services.

        VerifyText     Yes, the Insured meets each of the Guidelines and I would like an instant quote
        VerifyText     No, the Insured doesn't meet some of the Guidelines and I would like to send my submission to

        VerifyElement                              //input[@value\='confirm']
        VerifyElement                              //input[@value\='remove']
        VerifyElement                              //button[text()\=' Back ']
        VerifyElement                              //button[text()\=' Next ']
    
    ELSE IF            "${Industry_MPL_S}" == "Business Services - Bookkeeper & Record Keeper"

        VerifyText     Your time is our priority. Please check our MPL Guidelines below for portal eligibility.
        VerifyText     Our Eligibility Guidelines

        VerifyText     The Insured has been in business for more than 3 years
        VerifyText     The Insured has incurred less than $50,000 in losses and/or reported less than 3 claim notifications in the past 36 months
        VerifyText     The Insured is not aware of an issue or circumstance that could potentially lead to a claim
        VerifyText     The Insured does not conduct any financial audits or provide attestation services.
        VerifyText     The Insured maintains current and valid professional certifications or designations as required or recognized by industry standards.


        VerifyText     Yes, the Insured meets each of the Guidelines and I would like an instant quote
        VerifyText     No, the Insured doesn't meet some of the Guidelines and I would like to send my submission to

        VerifyElement                              //input[@value\='confirm']
        VerifyElement                              //input[@value\='remove']
        VerifyElement                              //button[text()\=' Back ']
        VerifyElement                              //button[text()\=' Next ']
    
    ELSE IF            "${Industry_MPL_S}" == "Business Services - Business Training & Seminars"

        VerifyText     Your time is our priority. Please check our MPL Guidelines below for portal eligibility.
        VerifyText     Our Eligibility Guidelines

        VerifyText     The Insured has been in business for more than 3 years
        VerifyText     The Insured has incurred less than $50,000 in losses and/or reported less than 3 claim notifications in the past 36 months
        VerifyText     The Insured is not aware of an issue or circumstance that could potentially lead to a claim
        VerifyText     The Insured does not provide any aviation training, medical training, law enforcement training or safety training.
        VerifyText     The Insured is not a school, college, university or other educational institution.
        VerifyText     The Insured maintains current and valid professional certifications or designations as required or recognized by industry standards.

        VerifyText     Yes, the Insured meets each of the Guidelines and I would like an instant quote
        VerifyText     No, the Insured doesn't meet some of the Guidelines and I would like to send my submission to

        VerifyElement                              //input[@value\='confirm']
        VerifyElement                              //input[@value\='remove']
        VerifyElement                              //button[text()\=' Back ']
        VerifyElement                              //button[text()\=' Next ']
    
    ELSE IF            "${Industry_MPL_S}" == "Business Services - Court Reporting"

        VerifyText     Your time is our priority. Please check our MPL Guidelines below for portal eligibility.
        VerifyText     Our Eligibility Guidelines

        VerifyText     The Insured has been in business for more than 3 years
        VerifyText     The Insured has incurred less than $50,000 in losses and/or reported less than 3 claim notifications in the past 36 months
        VerifyText     The Insured is not aware of an issue or circumstance that could potentially lead to a claim
        VerifyText     The Insured maintains current and valid professional certifications or designations as required or recognized by industry standards.

        VerifyText     Yes, the Insured meets each of the Guidelines and I would like an instant quote
        VerifyText     No, the Insured doesn't meet some of the Guidelines and I would like to send my submission to

        VerifyElement                              //input[@value\='confirm']
        VerifyElement                              //input[@value\='remove']
        VerifyElement                              //button[text()\=' Back ']
        VerifyElement                              //button[text()\=' Next ']
    
    ELSE IF            "${Industry_MPL_S}" == "Business Services - Dispute Resolution"

        VerifyText     Your time is our priority. Please check our MPL Guidelines below for portal eligibility.
        VerifyText     Our Eligibility Guidelines

        VerifyText     The Insured has been in business for more than 3 years
        VerifyText     The Insured has incurred less than $50,000 in losses and/or reported less than 3 claim notifications in the past 36 months
        VerifyText     The Insured is not aware of an issue or circumstance that could potentially lead to a claim
        VerifyText     The Insured does not conduct any arbitration proceedings or dispute resolution services outside the US.
        VerifyText     The Insured maintain current and valid professional certifications or designations as required or recognized by industry standards.

        VerifyText     Yes, the Insured meets each of the Guidelines and I would like an instant quote
        VerifyText     No, the Insured doesn't meet some of the Guidelines and I would like to send my submission to

        VerifyElement                              //input[@value\='confirm']
        VerifyElement                              //input[@value\='remove']
        VerifyElement                              //button[text()\=' Back ']
        VerifyElement                              //button[text()\=' Next ']
    
    ELSE IF            "${Industry_MPL_S}" == "Business Services - Employment Agencies"

        VerifyText     Your time is our priority. Please check our MPL Guidelines below for portal eligibility.
        VerifyText     Our Eligibility Guidelines

        VerifyText     The Insured has been in business for more than 3 years
        VerifyText     The Insured has incurred less than $50,000 in losses and/or reported less than 3 claim notifications in the past 36 months
        VerifyText     The Insured is not aware of an issue or circumstance that could potentially lead to a claim
        VerifyText     The Insured does not perform any recruiting activities for medical personnel, including but not limited to nurses, doctors, dentists.
        VerifyText     The Insured performs background checks on all their applicants prior to placement.
        VerifyText     The Insured does not act as a Professional Employer Organization (PEO).
        VerifyText     The Insured does not perform any recruiting activities for temporary drivers including rental car agencies, security guards, teachers or day care providers.

        VerifyText     Yes, the Insured meets each of the Guidelines and I would like an instant quote
        VerifyText     No, the Insured doesn't meet some of the Guidelines and I would like to send my submission to

        VerifyElement                              //input[@value\='confirm']
        VerifyElement                              //input[@value\='remove']
        VerifyElement                              //button[text()\=' Back ']
        VerifyElement                              //button[text()\=' Next ']
    
    ELSE IF            "${Industry_MPL_S}" == "Business Services - Event Planner"

        VerifyText     Your time is our priority. Please check our MPL Guidelines below for portal eligibility.
        VerifyText     Our Eligibility Guidelines

        VerifyText     The Insured has been in business for more than 3 years
        VerifyText     The Insured has incurred less than $50,000 in losses and/or reported less than 3 claim notifications in the past 36 months
        VerifyText     The Insured is not aware of an issue or circumstance that could potentially lead to a claim
        VerifyText     The Insured does not plan or promote any events for competitions, political events, government related sponsored events.
        VerifyText     The Insured does not promote media, artists or entertainers on behalf of or for any entertainment, publishing, music, internet or media company.

        VerifyText     Yes, the Insured meets each of the Guidelines and I would like an instant quote
        VerifyText     No, the Insured doesn't meet some of the Guidelines and I would like to send my submission to

        VerifyElement                              //input[@value\='confirm']
        VerifyElement                              //input[@value\='remove']
        VerifyElement                              //button[text()\=' Back ']
        VerifyElement                              //button[text()\=' Next ']
    
    ELSE IF            "${Industry_MPL_S}" == "Business Services - Executive Placement"

        VerifyText     Your time is our priority. Please check our MPL Guidelines below for portal eligibility.
        VerifyText     Our Eligibility Guidelines

        VerifyText     The Insured has been in business for more than 3 years
        VerifyText     The Insured has incurred less than $50,000 in losses and/or reported less than 3 claim notifications in the past 36 months
        VerifyText     The Insured is not aware of an issue or circumstance that could potentially lead to a claim
        VerifyText     The Insured utilizes background checks on all applicants prior to placement.
        VerifyText     The Insured interviews all candidates before recommending them to clients.

        VerifyText     Yes, the Insured meets each of the Guidelines and I would like an instant quote
        VerifyText     No, the Insured doesn't meet some of the Guidelines and I would like to send my submission to

        VerifyElement                              //input[@value\='confirm']
        VerifyElement                              //input[@value\='remove']
        VerifyElement                              //button[text()\=' Back ']
        VerifyElement                              //button[text()\=' Next ']
    
    ELSE IF            "${Industry_MPL_S}" == "Business Services - Funeral & Crematories"

        VerifyText     Your time is our priority. Please check our MPL Guidelines below for portal eligibility.
        VerifyText     Our Eligibility Guidelines

        VerifyText     The Insured has been in business for more than 3 years
        VerifyText     The Insured has incurred less than $50,000 in losses and/or reported less than 3 claim notifications in the past 36 months
        VerifyText     The Insured is not aware of an issue or circumstance that could potentially lead to a claim
        VerifyText     The Insured is appropriately licensed in all states where services are performed.

        VerifyText     Yes, the Insured meets each of the Guidelines and I would like an instant quote
        VerifyText     No, the Insured doesn't meet some of the Guidelines and I would like to send my submission to

        VerifyElement                              //input[@value\='confirm']
        VerifyElement                              //input[@value\='remove']
        VerifyElement                              //button[text()\=' Back ']
        VerifyElement                              //button[text()\=' Next ']
        
    ELSE IF            "${Industry_MPL_S}" == "Business Services - Interior & Graphic Design"

        VerifyText     Your time is our priority. Please check our MPL Guidelines below for portal eligibility.
        VerifyText     Our Eligibility Guidelines

        VerifyText     The Insured has been in business for more than 3 years
        VerifyText     The Insured has incurred less than $50,000 in losses and/or reported less than 3 claim notifications in the past 36 months
        VerifyText     The Insured is not aware of an issue or circumstance that could potentially lead to a claim
        VerifyText     Other than design or project management services, no more than 20% of the Insureds revenues are generated directly from construction services.
        VerifyText     In the past year, the Insured has not performed any interior design or graphic design services with a total contract value in excess of $500,000.

        VerifyText     Yes, the Insured meets each of the Guidelines and I would like an instant quote
        VerifyText     No, the Insured doesn't meet some of the Guidelines and I would like to send my submission to

        VerifyElement                              //input[@value\='confirm']
        VerifyElement                              //input[@value\='remove']
        VerifyElement                              //button[text()\=' Back ']
        VerifyElement                              //button[text()\=' Next ']

    ELSE IF            "${Industry_MPL_S}" == "Business Services - Literary Agents"

        VerifyText     Your time is our priority. Please check our MPL Guidelines below for portal eligibility.
        VerifyText     Our Eligibility Guidelines

        VerifyText     The Insured has been in business for more than 3 years
        VerifyText     The Insured has incurred less than $50,000 in losses and/or reported less than 3 claim notifications in the past 36 months
        VerifyText     The Insured is not aware of an issue or circumstance that could potentially lead to a claim
        VerifyText     The Insured utilizes legal counsel for review of all material for any potential violations of copyright, trademark, or other intellectual property rights.
        VerifyText     The Insured requires clients to sign off on all changes by the publisher prior to publication.
        VerifyText     The Insured has a process in place to screen materials for potential libel/slander.

        VerifyText     Yes, the Insured meets each of the Guidelines and I would like an instant quote
        VerifyText     No, the Insured doesn't meet some of the Guidelines and I would like to send my submission to

        VerifyElement                              //input[@value\='confirm']
        VerifyElement                              //input[@value\='remove']
        VerifyElement                              //button[text()\=' Back ']
        VerifyElement                              //button[text()\=' Next ']

    ELSE IF            "${Industry_MPL_S}" == "Business Services - Management & Business Consulting"

        VerifyText     Your time is our priority. Please check our MPL Guidelines below for portal eligibility.
        VerifyText     Our Eligibility Guidelines

        VerifyText     The Insured has been in business for more than 3 years
        VerifyText     The Insured has incurred less than $50,000 in losses and/or reported less than 3 claim notifications in the past 36 months
        VerifyText     The Insured is not aware of an issue or circumstance that could potentially lead to a claim
        VerifyText     The Insured does not provide consulting services for any of the following:
        VerifyText     Management of any escrow accounts, trust funds, insurance plans or investment portfolios.
        VerifyText     Design of lotteries, sweepstakes or any game of chance.
        VerifyText     Business valuations or appraisals.

        VerifyText     Yes, the Insured meets each of the Guidelines and I would like an instant quote
        VerifyText     No, the Insured doesn't meet some of the Guidelines and I would like to send my submission to

        VerifyElement                              //input[@value\='confirm']
        VerifyElement                              //input[@value\='remove']
        VerifyElement                              //button[text()\=' Back ']
        VerifyElement                              //button[text()\=' Next ']
    
    ELSE IF            "${Industry_MPL_S}" == "Business Services - Membership Organizations"

        VerifyText     Your time is our priority. Please check our MPL Guidelines below for portal eligibility.
        VerifyText     Our Eligibility Guidelines

        VerifyText     The Insured has been in business for more than 3 years
        VerifyText     The Insured has incurred less than $50,000 in losses and/or reported less than 3 claim notifications in the past 36 months
        VerifyText     The Insured is not aware of an issue or circumstance that could potentially lead to a claim

        VerifyText     Yes, the Insured meets each of the Guidelines and I would like an instant quote
        VerifyText     No, the Insured doesn't meet some of the Guidelines and I would like to send my submission to

        VerifyElement                              //input[@value\='confirm']
        VerifyElement                              //input[@value\='remove']
        VerifyElement                              //button[text()\=' Back ']
        VerifyElement                              //button[text()\=' Next ']
    
    ELSE IF            "${Industry_MPL_S}" == "Business Services - Modeling/Talent Agency"

        VerifyText     Your time is our priority. Please check our MPL Guidelines below for portal eligibility.
        VerifyText     Our Eligibility Guidelines

        VerifyText     The Insured has been in business for more than 3 years
        VerifyText     The Insured has incurred less than $50,000 in losses and/or reported less than 3 claim notifications in the past 36 months
        VerifyText     The Insured is not aware of an issue or circumstance that could potentially lead to a claim

        VerifyText     Yes, the Insured meets each of the Guidelines and I would like an instant quote
        VerifyText     No, the Insured doesn't meet some of the Guidelines and I would like to send my submission to

        VerifyElement                              //input[@value\='confirm']
        VerifyElement                              //input[@value\='remove']
        VerifyElement                              //button[text()\=' Back ']
        VerifyElement                              //button[text()\=' Next ']
    
    ELSE IF            "${Industry_MPL_S}" == "Business Services - Notary Public"

        VerifyText     Your time is our priority. Please check our MPL Guidelines below for portal eligibility.
        VerifyText     Our Eligibility Guidelines

        VerifyText     The Insured has been in business for more than 3 years
        VerifyText     The Insured has incurred less than $50,000 in losses and/or reported less than 3 claim notifications in the past 36 months
        VerifyText     The Insured is not aware of an issue or circumstance that could potentially lead to a claim
        VerifyText     If the Insured performs Remote Online Notarizations, they are in compliance with all state regulations.
        VerifyText     The Insured maintains current and valid professional licenses as required or recognized by industry standards.

        VerifyText     Yes, the Insured meets each of the Guidelines and I would like an instant quote
        VerifyText     No, the Insured doesn't meet some of the Guidelines and I would like to send my submission to

        VerifyElement                              //input[@value\='confirm']
        VerifyElement                              //input[@value\='remove']
        VerifyElement                              //button[text()\=' Back ']
        VerifyElement                              //button[text()\=' Next ']
    
    ELSE IF            "${Industry_MPL_S}" == "Business Services - Office Management"

        VerifyText     Your time is our priority. Please check our MPL Guidelines below for portal eligibility.
        VerifyText     Our Eligibility Guidelines

        VerifyText     The Insured has been in business for more than 3 years
        VerifyText     The Insured has incurred less than $50,000 in losses and/or reported less than 3 claim notifications in the past 36 months
        VerifyText     The Insured is not aware of an issue or circumstance that could potentially lead to a claim

        VerifyText     Yes, the Insured meets each of the Guidelines and I would like an instant quote
        VerifyText     No, the Insured doesn't meet some of the Guidelines and I would like to send my submission to

        VerifyElement                              //input[@value\='confirm']
        VerifyElement                              //input[@value\='remove']
        VerifyElement                              //button[text()\=' Back ']
        VerifyElement                              //button[text()\=' Next ']
    
    ELSE IF            "${Industry_MPL_S}" == "Business Services - Pet Related Services"

        VerifyText     Your time is our priority. Please check our MPL Guidelines below for portal eligibility.
        VerifyText     Our Eligibility Guidelines

        VerifyText     The Insured has been in business for more than 3 years
        VerifyText     The Insured has incurred less than $50,000 in losses and/or reported less than 3 claim notifications in the past 36 months
        VerifyText     The Insured is not aware of an issue or circumstance that could potentially lead to a claim
        VerifyText     The Insured does not prescribe or dispenses any over the counter or prescription drugs.
        VerifyText     The Insured does not work with bloodstock.

        VerifyText     Yes, the Insured meets each of the Guidelines and I would like an instant quote
        VerifyText     No, the Insured doesn't meet some of the Guidelines and I would like to send my submission to

        VerifyElement                              //input[@value\='confirm']
        VerifyElement                              //input[@value\='remove']
        VerifyElement                              //button[text()\=' Back ']
        VerifyElement                              //button[text()\=' Next ']
    
    ELSE IF            "${Industry_MPL_S}" == "Business Services - Photographic Studios"

        VerifyText     Your time is our priority. Please check our MPL Guidelines below for portal eligibility.
        VerifyText     Our Eligibility Guidelines

        VerifyText     The Insured has been in business for more than 3 years
        VerifyText     The Insured has incurred less than $50,000 in losses and/or reported less than 3 claim notifications in the past 36 months
        VerifyText     The Insured is not aware of an issue or circumstance that could potentially lead to a claim
        VerifyText     If the Insured maintains a photo library with images owned by others, they have an indemnification agreement to indemnify them from claims arising out of the use of those images.
        VerifyText     If the Insured photographs models, they obtain a written release from each model appearing in the photographs.

        VerifyText     Yes, the Insured meets each of the Guidelines and I would like an instant quote
        VerifyText     No, the Insured doesn't meet some of the Guidelines and I would like to send my submission to

        VerifyElement                              //input[@value\='confirm']
        VerifyElement                              //input[@value\='remove']
        VerifyElement                              //button[text()\=' Back ']
        VerifyElement                              //button[text()\=' Next ']
    
    ELSE IF            "${Industry_MPL_S}" == "Business Services - Printers"

        VerifyText     Your time is our priority. Please check our MPL Guidelines below for portal eligibility.
        VerifyText     Our Eligibility Guidelines

        VerifyText     The Insured has been in business for more than 3 years
        VerifyText     The Insured has incurred less than $50,000 in losses and/or reported less than 3 claim notifications in the past 36 months
        VerifyText     The Insured is not aware of an issue or circumstance that could potentially lead to a claim
        VerifyText     The Insured does not provide printing for the distribution and/or redemption of coupons, rebates or promotional game materials.
        VerifyText     The Insured's services do not involve the design of any logos or trademarks.
        VerifyText     The Insured has a process in place to screen materials for any potential violations of another party's copyrights, trademarks or other intellectual property rights.
        VerifyText     The Insured requires its clients to approve proof copies before printing.

        VerifyText     Yes, the Insured meets each of the Guidelines and I would like an instant quote
        VerifyText     No, the Insured doesn't meet some of the Guidelines and I would like to send my submission to

        VerifyElement                              //input[@value\='confirm']
        VerifyElement                              //input[@value\='remove']
        VerifyElement                              //button[text()\=' Back ']
        VerifyElement                              //button[text()\=' Next ']
    
    ELSE IF            "${Industry_MPL_S}" == "Business Services - Process Server"

        VerifyText     Your time is our priority. Please check our MPL Guidelines below for portal eligibility.
        VerifyText     Our Eligibility Guidelines

        VerifyText     The Insured has been in business for more than 3 years
        VerifyText     The Insured has incurred less than $50,000 in losses and/or reported less than 3 claim notifications in the past 36 months
        VerifyText     The Insured is not aware of an issue or circumstance that could potentially lead to a claim
        VerifyText     The Insured is appropriately and currently licensed per their state's applicable rules and statutes.

        VerifyText     Yes, the Insured meets each of the Guidelines and I would like an instant quote
        VerifyText     No, the Insured doesn't meet some of the Guidelines and I would like to send my submission to

        VerifyElement                              //input[@value\='confirm']
        VerifyElement                              //input[@value\='remove']
        VerifyElement                              //button[text()\=' Back ']
        VerifyElement                              //button[text()\=' Next ']
    
    ELSE IF            "${Industry_MPL_S}" == "Business Services - Tax Preparation (NON-CPA SERVICES)"

        VerifyText     Your time is our priority. Please check our MPL Guidelines below for portal eligibility.
        VerifyText     Our Eligibility Guidelines

        VerifyText     The Insured has been in business for more than 3 years
        VerifyText     The Insured has incurred less than $50,000 in losses and/or reported less than 3 claim notifications in the past 36 months
        VerifyText     The Insured is not aware of an issue or circumstance that could potentially lead to a claim
        VerifyText     The Insured does not conduct any financial audits or provide attestation services.
        VerifyText     The Insured maintains current and valid professional certifications or designations as required or recognized by industry standards.

        VerifyText     Yes, the Insured meets each of the Guidelines and I would like an instant quote
        VerifyText     No, the Insured doesn't meet some of the Guidelines and I would like to send my submission to

        VerifyElement                              //input[@value\='confirm']
        VerifyElement                              //input[@value\='remove']
        VerifyElement                              //button[text()\=' Back ']
        VerifyElement                              //button[text()\=' Next ']
    
    ELSE IF            "${Industry_MPL_S}" == "Business Services - Translation & Interpretation Services"

        VerifyText     Your time is our priority. Please check our MPL Guidelines below for portal eligibility.
        VerifyText     Our Eligibility Guidelines

        VerifyText     The Insured has been in business for more than 3 years
        VerifyText     The Insured has incurred less than $50,000 in losses and/or reported less than 3 claim notifications in the past 36 months
        VerifyText     The Insured is not aware of an issue or circumstance that could potentially lead to a claim
        VerifyText     The Insured maintains current and valid professional certifications or designations as required or recognized by industry standards.

        VerifyText     Yes, the Insured meets each of the Guidelines and I would like an instant quote
        VerifyText     No, the Insured doesn't meet some of the Guidelines and I would like to send my submission to

        VerifyElement                              //input[@value\='confirm']
        VerifyElement                              //input[@value\='remove']
        VerifyElement                              //button[text()\=' Back ']
        VerifyElement                              //button[text()\=' Next ']
    
    ELSE IF            "${Industry_MPL_S}" == "Education - Exam Preparation and Tutoring"

        VerifyText     Your time is our priority. Please check our MPL Guidelines below for portal eligibility.
        VerifyText     Our Eligibility Guidelines

        VerifyText     The Insured has been in business for more than 3 years
        VerifyText     The Insured has incurred less than $50,000 in losses and/or reported less than 3 claim notifications in the past 36 months
        VerifyText     The Insured is not aware of an issue or circumstance that could potentially lead to a claim
        VerifyText     The Insured does not provide any aviation training, medical training, law enforcement training or safety training.
        VerifyText     The Insured is not a school, college, university or other educational institution.

        VerifyText     Yes, the Insured meets each of the Guidelines and I would like an instant quote
        VerifyText     No, the Insured doesn't meet some of the Guidelines and I would like to send my submission to

        VerifyElement                              //input[@value\='confirm']
        VerifyElement                              //input[@value\='remove']
        VerifyElement                              //button[text()\=' Back ']
        VerifyElement                              //button[text()\=' Next ']
    
    ELSE IF            "${Industry_MPL_S}" == "Media - Public Relations"

        VerifyText     Your time is our priority. Please check our MPL Guidelines below for portal eligibility.
        VerifyText     Our Eligibility Guidelines

        VerifyText     The Insured has been in business for more than 3 years
        VerifyText     The Insured has incurred less than $50,000 in losses and/or reported less than 3 claim notifications in the past 36 months
        VerifyText     The Insured is not aware of an issue or circumstance that could potentially lead to a claim
        VerifyText     The Insured does not provide services to any of the following industries; Tobacco/Alcohol/Marijuana, Gaming, Government/Military, Firearms, Pharmaceuticals.
        VerifyText     The Insured requires its clients to provide approval before releasing any media content.
        VerifyText     The Insured utilizes legal counsel for review of material for the purpose of examining copyright, trademark, or libel/slander exposure.
        VerifyText     The Insured does not create any sweepstakes, games-of-chance, or other contests for their clients.
        VerifyText     Models, actors, photographers, musicians and others providing content to the insured are required to execute releases.

        VerifyText     Yes, the Insured meets each of the Guidelines and I would like an instant quote
        VerifyText     No, the Insured doesn't meet some of the Guidelines and I would like to send my submission to

        VerifyElement                              //input[@value\='confirm']
        VerifyElement                              //input[@value\='remove']
        VerifyElement                              //button[text()\=' Back ']
        VerifyElement                              //button[text()\=' Next ']
    
    ELSE IF            "${Industry_MPL_S}" == "Real Estate - Residential Appraisers"

        VerifyText     Your time is our priority. Please check our MPL Guidelines below for portal eligibility.
        VerifyText     Our Eligibility Guidelines

        VerifyText     The Insured has been in business for more than 3 years
        VerifyText     The Insured has incurred less than $50,000 in losses and/or reported less than 3 claim notifications in the past 36 months
        VerifyText     The Insured is not aware of an issue or circumstance that could potentially lead to a claim
        VerifyText     The Insured maintains current and valid professional certifications or designations as required or recognized by industry standards.

        VerifyText     Yes, the Insured meets each of the Guidelines and I would like an instant quote
        VerifyText     No, the Insured doesn't meet some of the Guidelines and I would like to send my submission to

        VerifyElement                              //input[@value\='confirm']
        VerifyElement                              //input[@value\='remove']
        VerifyElement                              //button[text()\=' Back ']
        VerifyElement                              //button[text()\=' Next ']
    
    ELSE IF            "${Industry_MPL_S}" == "Real Estate - Relocation Agent"

        VerifyText     Your time is our priority. Please check our MPL Guidelines below for portal eligibility.
        VerifyText     Our Eligibility Guidelines

        VerifyText     The Insured has been in business for more than 3 years
        VerifyText     The Insured has incurred less than $50,000 in losses and/or reported less than 3 claim notifications in the past 36 months
        VerifyText     The Insured is not aware of an issue or circumstance that could potentially lead to a claim

        VerifyText     Yes, the Insured meets each of the Guidelines and I would like an instant quote
        VerifyText     No, the Insured doesn't meet some of the Guidelines and I would like to send my submission to

        VerifyElement                              //input[@value\='confirm']
        VerifyElement                              //input[@value\='remove']
        VerifyElement                              //button[text()\=' Back ']
        VerifyElement                              //button[text()\=' Next ']
    
    ELSE IF            "${Industry_MPL_S}" == "Transportation - Travel Agencies/Tour Operators"

        VerifyText     Your time is our priority. Please check our MPL Guidelines below for portal eligibility.
        VerifyText     Our Eligibility Guidelines

        VerifyText     The Insured has been in business for more than 3 years
        VerifyText     The Insured has incurred less than $50,000 in losses and/or reported less than 3 claim notifications in the past 36 months
        VerifyText     The Insured is not aware of an issue or circumstance that could potentially lead to a claim
        VerifyText     The Insured uses legal disclaimers on all sales and marketing materials.
        VerifyText     The Insured belongs to an accredited organization such as the National Tour Association or the U.S. Tour Operators Association.
        VerifyText     Signed waivers of liability are required from all clients.

        VerifyText     Yes, the Insured meets each of the Guidelines and I would like an instant quote
        VerifyText     No, the Insured doesn't meet some of the Guidelines and I would like to send my submission to

        VerifyElement                              //input[@value\='confirm']
        VerifyElement                              //input[@value\='remove']
        VerifyElement                              //button[text()\=' Back ']
        VerifyElement                              //button[text()\=' Next ']
    
    
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
    END
    Log To Console     ------elements on Eligibility Guidelines Page for MPL Validated Successfully-------

Click on Next Button - Eligibility Guidelines Page

    [Documentation]    Click on Next Button - Eligibility Guidelines Page


    ClickElement       //input[@value\='confirm']
    ClickElement       //button[text()\=' Next ']

    

Click on Back Button - Eligibility Guidelines Page
    [Documentation]    Click on Back Button - Eligibility Guidelines Page

    ClickElement       //button[text()\=' Back ']
    

Click on Back Button - Coverage question Page
    [Documentation]    Click on Back Button - Coverage question Page
    ClickElement       //button[text()\=' Back ']
    VerifyText         Home
