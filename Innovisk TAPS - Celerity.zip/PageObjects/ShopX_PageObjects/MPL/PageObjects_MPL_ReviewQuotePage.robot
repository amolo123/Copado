*** Settings ***
Library                QWeb
Library                QForce
#Library               QVision
Library                FakerLibrary
Library                String
Library                BuiltIn
Library                DateTime



*** Keywords ***

Validate elements on Review quote Page for MPL
    [Documentation]    Validate elements on Review quote Page for MPL

    VerifyText         Review My Quote
    ClickElement          //mat-select[@formcontrolname\='desiredLimit']//span
    VerifyText            $1,000,000
    VerifyText            $2,000,000
    ClickElement          //span[@class\='mat-option-text']
    sleep                 5s
    ClickElement          //mat-select[@formcontrolname\='desiredRetention']//span
    VerifyText            $5,000
    VerifyText            $7,500
    VerifyText            $10,000
    VerifyText            $15,000
    VerifyText            $25,000

    VerifyText            POLICY LIMITS
    VerifyText            DEFAULT POLICY LIMITS
    VerifyText            Contingent Bodily Injury and Property Damage Endorsement
    VerifyText            $100,000
    VerifyText            Crisis Management Endorsement
    VerifyText            $10,000
    VerifyText            Pre Claims Assistance Endorsement
    VerifyText            $10,000
    VerifyText            Infringement of Copyright and Trademark Coverage Sublimit Endorsement
    VerifyText            $50,000
    VerifyText            Subpoena Compliance Sublimit
    VerifyText            $10,000
    VerifyText            Your MPL Premium
    VerifyText            Commission
    VerifyText            Commission %

Validate Clicking on Save to My quote button
    [Documentation]       Validate Clicking on Save to My quote button

    ${SAVETOMYQUOTES}=    IsText                      SAVE TO MY QUOTES           timeout=20

    IF                    "${SAVETOMYQUOTES}" == "True"
        Clicktext         SAVE TO MY QUOTES
    ELSE
        Clicktext         SAVE CHANGES

        IsText            Updating                    timeout=120s
        Clicktext         SAVE TO MY QUOTES
        IsText            loading                     timeout=120s
    END

    VerifyText            My Saved Quotes



Validate clicking on referral button
    [Documentation]       Validate clicking on referral button
    #[Arguments]          ${Address1}
    VerifyText            I'd like to revise my quote and want to refer to Celerity Pro underwriters.
    Sleep                 5s
    ClickElement          //span[contains(@class,'checkmark')]
    TypeText              I'd like to request ...     Copado Test

Validate actions performed on review quote page with referral
    [Documentation]       Validate actions performed on review quote page with refferal
    VerifyText            SAVE CHANGES
    VerifyText            DISCARD CHANGES
    ClickText             DISCARD CHANGES


Click on back button on Review quote page
    [Documentation]       Validate clicking on back button on Review quote page

    VerifyText            Back
    ClickElement          //button[text()\=' Back ']


Verify Static text for Referral Quote
    #Author=Saurabh
    [Documentation]       Verify Static text for Referral Quote
    VerifyText            The information you entered will need underwriter approval.
    VerifyText            Your quote will be referred when you click Save to My Quotes, until then you can make changes to your quote.ion}



