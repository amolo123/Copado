*** Settings ***
Library                    QWeb
Library                    QForce
#Library                   QVision
Library                    FakerLibrary
Library                    String
Library                    BuiltIn
Library                    DateTime



*** Keywords ***

Verify Actions performed on Insured details Page for MPL

    [Documentation]        Verify Actions performed on Insured details Page for MPL
    [Arguments]            ${Industry_MPL}             ${Address1}                 ${Address2}    ${City}    ${State_Province}    ${PostalZip}    ${projected_revenue}

    TypeText               Industry                    ${Industry_MPL}
    ClickElement           //span[text()\=" ${Industry_MPL} "]
    Sleep                  2s

    ${currTime}=           Get Current Date            result_format=%-d%-m%Y%-H%f
    ${name1}=              Name Male
    Set Global Variable    ${name1}
    ${random_email}=       Set Variable                ${name1}@gmail.com
    Set Global Variable    ${random_email}
    ${uniqueName}=         Set Variable                ${name1}${currTime}
    Set Global Variable    ${uniqueName}
    Log To Console         ${uniqueName}
    TypeText               Insured Name                ${uniqueName}

    TypeText               Insured address *           2300 M St NW, Washington, DC 20037, USA
    ClickText              DC 20037, USA

    ClickElement           (//input[@type\="checkbox"])[1]
    TypeText               Address1                    ${Address1}
    TypeText               Address2                    ${Address2}
    TypeText               City                        ${City}
    #TypeText              Country                     ${USA}
    ClickElement           //mat-select
    ClickElement           //span[text()\=" ${State_Province} "]
    TypeText               Postal Zip                  ${PostalZip}

    TypeText               Insured 12-month projected revenue                      ${projected_revenue}

    ClickElement           //button[text()\=' Next ']
    VerifyText             Your time is our priority. Please check our MPL Guidelines below for portal eligibility.


Enter MPL Industry for validating eligibility             
    [Arguments]            ${Industryarg1}

    TypeText               Industry                    ${Industryarg1}
    ClickElement           //span[text()\=" ${Industryarg1} "]
    Sleep                  2s

    ClickElement           //button[text()\=' Next ']
    VerifyText             Your time is our priority. Please check our MPL Guidelines below for portal eligibility. 


Click on Next Button - Insured Details Page MPL

    [Documentation]        Click on Next Button - Insured Details Page
    [Arguments]            ${Industry_Cyber}           ${Address1}                 ${Address2}    ${City}              ${State_Province}    ${PostalZip}            ${projected_revenue}

    TypeText               Insured Website URL         choiceip.com
    TypeText               Industry                    ${Industry_Cyber}
    Sleep                  2s
    ClickElement           //span[text()\=" ${Industry_Cyber} "]
    ClickElement           //button[text()\=' Next ']
    VerifyText             Tell us about your Insured

    ${currTime}=           Get Current Date            result_format=%-d%-m%Y%-H%f
    ${name1}=              Name Male
    Set Global Variable    ${name1}
    ${random_email}=       Set Variable                ${name1}@gmail.com
    Set Global Variable    ${random_email}
    ${uniqueName}=         Set Variable                ${name1}${currTime}
    Set Global Variable    ${uniqueName}
    Log To Console         ${uniqueName}
    TypeText               Insured Name                ${uniqueName}

    TypeText               Insured address *           2300 M St NW, Washington, DC 20037, USA
    ClickText              DC 20037, USA

    ClickElement           (//input[@type\="checkbox"])[1]
    TypeText               Address1                    ${Address1}
    TypeText               Address2                    ${Address2}
    TypeText               City                        ${City}
    #TypeText              Country                     ${USA}
    ClickElement           //mat-select
    ClickElement           //span[text()\=" ${State_Province} "]
    TypeText               Postal Zip                  ${PostalZip}

    TypeText               Insured 12-month projected revenue                      ${projected_revenue}

    ClickElement           //button[text()\=' Next ']
    Sleep                  40s


Click on Next Button - Insured Details Page 1 MPL

    [Documentation]        Click on Next Button - Insured Details Page 1

    [Arguments]            ${Industry_Cyber}

    TypeText               Insured Website URL         choiceip.com
    TypeText               Industry                    ${Industry_Cyber}
    Sleep                  2s
    ClickElement           //span[text()\=" ${Industry_Cyber} "]
    ClickElement           //button[text()\=' Next ']
    VerifyText             Tell us about your Insured


Click on Next Button - Insured Details Page 2 MPL

    [Documentation]        Click on Next Button - Insured Details Page 2
    ClickElement           //button[text()\=' Next ']
    Sleep                  40s


Click on Next button on insured details if addrss is present for MPL
    [Documentation]        Click on Next button if addrss is present
    ${Address}=            IsElement                   //input[@id\="addressLine1"]

    IF                     "${Address}" == "True"
        ClickElement       //button[text()\=' Next ']
    ELSE
        ClickElement       //button[text()\=' Back ']
        sleep              5s
        [Arguments]        ${Industry_Cyber}           ${Address1}                 ${Address2}    ${City}              ${State_Province}    ${PostalZip}            ${projected_revenue}

        TypeText           Insured Website URL         choiceip.com
        TypeText           Industry                    ${Industry_Cyber}
        Sleep              2s
        ClickElement       //span[text()\=" ${Industry_Cyber} "]
        ClickElement       //button[text()\=' Next ']
        VerifyText         Tell us about your Insured

        ${currTime}=       Get Current Date            result_format=%-d%-m%Y%-H%f
        ${name1}=          Name Male
        Set Global Variable                            ${name1}
        ${random_email}=                               Set Variable                ${name1}@gmail.com
        Set Global Variable                            ${random_email}
        ${uniqueName}=     Set Variable                ${name1}${currTime}
        Set Global Variable                            ${uniqueName}
        Log To Console     ${uniqueName}
        TypeText           Insured Name                ${uniqueName}

        TypeText           Insured address *           2300 M St NW, Washington, DC 20037, USA
        ClickText          DC 20037, USA

        ClickElement       (//input[@type\="checkbox"])[1]
        TypeText           Address1                    ${Address1}
        TypeText           Address2                    ${Address2}
        TypeText           City                        ${City}
        #TypeText          Country                     ${USA}
        ClickElement       //mat-select
        ClickElement       //span[text()\=" ${State_Province} "]
        TypeText           Postal Zip                  ${PostalZip}

        TypeText           Insured 12-month projected revenue                      ${projected_revenue}

        ClickElement       //button[text()\=' Next ']
        Sleep              40s


    END