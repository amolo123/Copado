*** Settings ***
Library                         QWeb
Library                         QForce
#Library                        QVision
Library                         FakerLibrary
Library                         String
Library                         BuiltIn
Library                         DateTime



*** Keywords ***

Validate elements on coverage question Page for MPL
    [Documentation]             Validate elements on coverage question Page for MPL
    [Arguments]                 ${Industry_MPL_S}


    IF                          "${Industry_MPL_S}" == "Business Services - Billing Services"

        VerifyText              The Insured currently purchases a Miscellaneous Professional Liability (MPL) policy
        VerifyElement           (//button/span[text()\='Yes'])[1]
        ClickElement            (//button/span[text()\='Yes'])[1]
        VerifyElement           (//button/span[text()\='No'])[1]
        Select current Expiration date
        Select current Retroactive date
        Type text               MPL Expiring Limit          2000000

        ClickText               Additional pricing discounts are available, if you can confirm the following statements.
        VerifyText              Tell us about your Insured

        VerifyText              Additional pricing discounts are available, if you can confirm the following statements.
        VerifyText              Principals have an average of at least 10 years relevant industry experience
        VerifyElement           (//button/span[text()\='Yes'])[2]
        VerifyElement           (//button/span[text()\='No'])[2]
        VerifyText              No individual client or contract accounts for more than 25% of annual revenues
        VerifyElement           (//button/span[text()\='Yes'])[3]
        VerifyElement           (//button/span[text()\='No'])[3]
        VerifyText              The Insured uses sub-contractors on less than 25% of projects
        VerifyElement           (//button/span[text()\='Yes'])[4]
        VerifyElement           (//button/span[text()\='No'])[4]
        VerifyText              No client contract value is over $1,000,000
        VerifyElement           (//button/span[text()\='Yes'])[5]
        VerifyElement           (//button/span[text()\='No'])[5]
        VerifyText              Contracts are utilized on all client engagements
        VerifyElement           (//button/span[text()\='Yes'])[6]
        VerifyElement           (//button/span[text()\='No'])[6]
        VerifyText              All client contracts include a limitation of liability and/or indemnity clause that inures to the benefit of the Insured
        VerifyElement           (//button/span[text()\='Yes'])[7]
        VerifyElement           (//button/span[text()\='No'])[7]


        VerifyElement           //button[text()\=' Back ']
        VerifyElement           //button[text()\=' Next ']

    ELSE IF                     "${Industry_MPL_S}" == "Business Services - Accreditation & Certification Services"

        VerifyText              The Insured currently purchases a Miscellaneous Professional Liability (MPL) policy
        VerifyText              Industry Members and Legal Counsel review and approve Applicable Standards before they are published.
        VerifyElement           (//button/span[text()\='Yes'])[1]
        ClickElement            (//button/span[text()\='Yes'])[1]
        VerifyElement           (//button/span[text()\='No'])[1]
        Select current Expiration date
        Select current Retroactive date
        Type text               MPL Expiring Limit          2000000
        ClickText               Additional pricing discounts are available, if you can confirm the following statements.
        VerifyText              Tell us about your Insured

        VerifyText              Additional pricing discounts are available, if you can confirm the following statements.
        VerifyText              Principals have an average of at least 10 years relevant industry experience
        VerifyElement           (//button/span[text()\='Yes'])[2]
        VerifyElement           (//button/span[text()\='No'])[2]
        VerifyText              No individual client or contract accounts for more than 25% of annual revenues
        VerifyElement           (//button/span[text()\='Yes'])[3]
        VerifyElement           (//button/span[text()\='No'])[3]
        VerifyText              The Insured uses sub-contractors on less than 25% of projects
        VerifyElement           (//button/span[text()\='Yes'])[4]
        VerifyElement           (//button/span[text()\='No'])[4]
        VerifyText              No client contract value is over $1,000,000
        VerifyElement           (//button/span[text()\='Yes'])[5]
        VerifyElement           (//button/span[text()\='No'])[5]
        VerifyText              Contracts are utilized on all client engagements
        VerifyElement           (//button/span[text()\='Yes'])[6]
        VerifyElement           (//button/span[text()\='No'])[6]
        VerifyText              All client contracts include a limitation of liability and/or indemnity clause that inures to the benefit of the Insured
        VerifyElement           (//button/span[text()\='Yes'])[7]
        VerifyElement           (//button/span[text()\='No'])[7]

        VerifyElement           //button[text()\=' Back ']
        VerifyElement           //button[text()\=' Next ']

    ELSE IF                     "${Industry_MPL_S}" == "Business Services - Alarm Monitors"

        VerifyText              The Insured currently purchases a Miscellaneous Professional Liability (MPL) policy
        VerifyElement           (//button/span[text()\='Yes'])[1]
        ClickElement            (//button/span[text()\='Yes'])[1]
        VerifyElement           (//button/span[text()\='No'])[1]
        Select current Expiration date
        Select current Retroactive date
        Type text               MPL Expiring Limit          2000000
        ClickText               Additional pricing discounts are available, if you can confirm the following statements.
        VerifyText              Tell us about your Insured

        VerifyText              Additional pricing discounts are available, if you can confirm the following statements.
        VerifyText              Principals have an average of at least 10 years relevant industry experience
        VerifyElement           (//button/span[text()\='Yes'])[2]
        VerifyElement           (//button/span[text()\='No'])[2]
        VerifyText              No individual client or contract accounts for more than 25% of annual revenues
        VerifyElement           (//button/span[text()\='Yes'])[3]
        VerifyElement           (//button/span[text()\='No'])[3]
        VerifyText              The Insured uses sub-contractors on less than 25% of projects
        VerifyElement           (//button/span[text()\='Yes'])[4]
        VerifyElement           (//button/span[text()\='No'])[4]
        VerifyText              No client contract value is over $1,000,000
        VerifyElement           (//button/span[text()\='Yes'])[5]
        VerifyElement           (//button/span[text()\='No'])[5]
        VerifyText              Contracts are utilized on all client engagements
        VerifyElement           (//button/span[text()\='Yes'])[6]
        VerifyElement           (//button/span[text()\='No'])[6]
        VerifyText              All client contracts include a limitation of liability and/or indemnity clause that inures to the benefit of the Insured
        VerifyElement           (//button/span[text()\='Yes'])[7]
        VerifyElement           (//button/span[text()\='No'])[7]
        VerifyElement           //button[text()\=' Back ']
        VerifyElement           //button[text()\=' Next ']

    ELSE IF                     "${Industry_MPL_S}" == "Business Services - Auctioneer"

        VerifyText              The Insured currently purchases a Miscellaneous Professional Liability (MPL) policy
        VerifyElement           (//button/span[text()\='Yes'])[1]
        ClickElement            (//button/span[text()\='Yes'])[1]
        VerifyElement           (//button/span[text()\='No'])[1]
        Select current Expiration date
        Select current Retroactive date
        Type text               MPL Expiring Limit          2000000
        ClickText               Additional pricing discounts are available, if you can confirm the following statements.
        VerifyText              Tell us about your Insured

        VerifyText              Additional pricing discounts are available, if you can confirm the following statements.
        VerifyText              Principals have an average of at least 10 years relevant industry experience
        VerifyElement           (//button/span[text()\='Yes'])[2]
        VerifyElement           (//button/span[text()\='No'])[2]
        VerifyText              No individual client or contract accounts for more than 25% of annual revenues
        VerifyElement           (//button/span[text()\='Yes'])[3]
        VerifyElement           (//button/span[text()\='No'])[3]
        VerifyText              The Insured uses sub-contractors on less than 25% of projects
        VerifyElement           (//button/span[text()\='Yes'])[4]
        VerifyElement           (//button/span[text()\='No'])[4]
        VerifyText              No client contract value is over $1,000,000
        VerifyElement           (//button/span[text()\='Yes'])[5]
        VerifyElement           (//button/span[text()\='No'])[5]
        VerifyText              Contracts are utilized on all client engagements
        VerifyElement           (//button/span[text()\='Yes'])[6]
        VerifyElement           (//button/span[text()\='No'])[6]
        VerifyText              All client contracts include a limitation of liability and/or indemnity clause that inures to the benefit of the Insured
        VerifyElement           (//button/span[text()\='Yes'])[7]
        VerifyElement           (//button/span[text()\='No'])[7]

        VerifyElement           //button[text()\=' Back ']
        VerifyElement           //button[text()\=' Next ']

    ELSE IF                     "${Industry_MPL_S}" == "Business Services - Audio/Video"

        VerifyText              The Insured currently purchases a Miscellaneous Professional Liability (MPL) policy
        VerifyElement           (//button/span[text()\='Yes'])[1]
        ClickElement            (//button/span[text()\='Yes'])[1]
        VerifyElement           (//button/span[text()\='No'])[1]
        Select current Expiration date
        Select current Retroactive date
        Type text               MPL Expiring Limit          2000000
        ClickText               Additional pricing discounts are available, if you can confirm the following statements.
        VerifyText              Tell us about your Insured

        VerifyText              Additional pricing discounts are available, if you can confirm the following statements.
        VerifyText              Principals have an average of at least 10 years relevant industry experience
        VerifyElement           (//button/span[text()\='Yes'])[2]
        VerifyElement           (//button/span[text()\='No'])[2]
        VerifyText              No individual client or contract accounts for more than 25% of annual revenues
        VerifyElement           (//button/span[text()\='Yes'])[3]
        VerifyElement           (//button/span[text()\='No'])[3]
        VerifyText              The Insured uses sub-contractors on less than 25% of projects
        VerifyElement           (//button/span[text()\='Yes'])[4]
        VerifyElement           (//button/span[text()\='No'])[4]
        VerifyText              No client contract value is over $1,000,000
        VerifyElement           (//button/span[text()\='Yes'])[5]
        VerifyElement           (//button/span[text()\='No'])[5]
        VerifyText              Contracts are utilized on all client engagements
        VerifyElement           (//button/span[text()\='Yes'])[6]
        VerifyElement           (//button/span[text()\='No'])[6]
        VerifyText              All client contracts include a limitation of liability and/or indemnity clause that inures to the benefit of the Insured
        VerifyElement           (//button/span[text()\='Yes'])[7]
        VerifyElement           (//button/span[text()\='No'])[7]
        VerifyElement           //button[text()\=' Back ']
        VerifyElement           //button[text()\=' Next ']

    ELSE IF                     "${Industry_MPL_S}" == "Business Services - Bookkeeper & Record Keeper"

        VerifyText              Tell us about your Insured
        VerifyText              The Insured currently purchases a Miscellaneous Professional Liability (MPL) policy
        VerifyElement           (//button/span[text()\='Yes'])[1]
        ClickElement            (//button/span[text()\='Yes'])[1]
        VerifyElement           (//button/span[text()\='No'])[1]
        VerifyText              The Insured does not provide any services to publicly known individuals or any government entity.
        VerifyElement           (//button/span[text()\='Yes'])[2]
        VerifyElement           (//button/span[text()\='No'])[2]
        Select current Expiration date
        Select current Retroactive date
        Type text               MPL Expiring Limit          2000000
        ClickText               Additional pricing discounts are available, if you can confirm the following statements.

        VerifyText              Additional pricing discounts are available, if you can confirm the following statements.
        VerifyText              Principals have an average of at least 10 years relevant industry experience
        VerifyElement           (//button/span[text()\='Yes'])[3]
        VerifyElement           (//button/span[text()\='No'])[3]
        VerifyText              No individual client or contract accounts for more than 25% of annual revenues
        VerifyElement           (//button/span[text()\='Yes'])[4]
        VerifyElement           (//button/span[text()\='No'])[4]
        VerifyText              The Insured uses sub-contractors on less than 25% of projects
        VerifyElement           (//button/span[text()\='Yes'])[5]
        VerifyElement           (//button/span[text()\='No'])[5]
        VerifyText              No client contract value is over $1,000,000
        VerifyElement           (//button/span[text()\='Yes'])[6]
        VerifyElement           (//button/span[text()\='No'])[6]
        VerifyText              Contracts are utilized on all client engagements
        VerifyElement           (//button/span[text()\='Yes'])[7]
        VerifyElement           (//button/span[text()\='No'])[7]
        VerifyText              All client contracts include a limitation of liability and/or indemnity clause that inures to the benefit of the Insured
        VerifyElement           (//button/span[text()\='Yes'])[8]
        VerifyElement           (//button/span[text()\='No'])[8]
        VerifyElement           //button[text()\=' Back ']
        VerifyElement           //button[text()\=' Next ']

    ELSE IF                     "${Industry_MPL_S}" == "Business Services - Business Training & Seminars"

        VerifyText              Tell us about your Insured
        VerifyText              The Insured currently purchases a Miscellaneous Professional Liability (MPL) policy
        VerifyElement           (//button/span[text()\='Yes'])[1]
        ClickElement            (//button/span[text()\='Yes'])[1]
        VerifyElement           (//button/span[text()\='No'])[1]
        Select current Expiration date
        Select current Retroactive date
        Type text               MPL Expiring Limit          2000000
        ClickText               Additional pricing discounts are available, if you can confirm the following statements.

        VerifyText              Additional pricing discounts are available, if you can confirm the following statements.
        VerifyText              Principals have an average of at least 10 years relevant industry experience
        VerifyElement           (//button/span[text()\='Yes'])[2]
        VerifyElement           (//button/span[text()\='No'])[2]
        VerifyText              No individual client or contract accounts for more than 25% of annual revenues
        VerifyElement           (//button/span[text()\='Yes'])[3]
        VerifyElement           (//button/span[text()\='No'])[3]
        VerifyText              The Insured uses sub-contractors on less than 25% of projects
        VerifyElement           (//button/span[text()\='Yes'])[4]
        VerifyElement           (//button/span[text()\='No'])[4]
        VerifyText              No client contract value is over $1,000,000
        VerifyElement           (//button/span[text()\='Yes'])[5]
        VerifyElement           (//button/span[text()\='No'])[5]
        VerifyText              Contracts are utilized on all client engagements
        VerifyElement           (//button/span[text()\='Yes'])[6]
        VerifyElement           (//button/span[text()\='No'])[6]
        VerifyText              All client contracts include a limitation of liability and/or indemnity clause that inures to the benefit of the Insured
        VerifyElement           (//button/span[text()\='Yes'])[7]
        VerifyElement           (//button/span[text()\='No'])[7]

        VerifyElement           //button[text()\=' Back ']
        VerifyElement           //button[text()\=' Next ']

    ELSE IF                     "${Industry_MPL_S}" == "Business Services - Court Reporting"

        VerifyText              Tell us about your Insured
        VerifyText              The Insured currently purchases a Miscellaneous Professional Liability (MPL) policy
        VerifyElement           (//button/span[text()\='Yes'])[1]
        ClickElement            (//button/span[text()\='Yes'])[1]
        VerifyElement           (//button/span[text()\='No'])[1]
        Select current Expiration date
        Select current Retroactive date
        Type text               MPL Expiring Limit          2000000
        ClickText               Additional pricing discounts are available, if you can confirm the following statements.

        VerifyText              Additional pricing discounts are available, if you can confirm the following statements.
        VerifyText              Principals have an average of at least 10 years relevant industry experience
        VerifyElement           (//button/span[text()\='Yes'])[2]
        VerifyElement           (//button/span[text()\='No'])[2]
        VerifyText              No individual client or contract accounts for more than 25% of annual revenues
        VerifyElement           (//button/span[text()\='Yes'])[3]
        VerifyElement           (//button/span[text()\='No'])[3]
        VerifyText              The Insured uses sub-contractors on less than 25% of projects
        VerifyElement           (//button/span[text()\='Yes'])[4]
        VerifyElement           (//button/span[text()\='No'])[4]
        VerifyText              No client contract value is over $1,000,000
        VerifyElement           (//button/span[text()\='Yes'])[5]
        VerifyElement           (//button/span[text()\='No'])[5]
        VerifyText              Contracts are utilized on all client engagements
        VerifyElement           (//button/span[text()\='Yes'])[6]
        VerifyElement           (//button/span[text()\='No'])[6]
        VerifyText              All client contracts include a limitation of liability and/or indemnity clause that inures to the benefit of the Insured
        VerifyElement           (//button/span[text()\='Yes'])[7]
        VerifyElement           (//button/span[text()\='No'])[7]

        VerifyElement           //button[text()\=' Back ']
        VerifyElement           //button[text()\=' Next ']

    ELSE IF                     "${Industry_MPL_S}" == "Business Services - Dispute Resolution"

        VerifyText              Tell us about your Insured
        VerifyText              The Insured currently purchases a Miscellaneous Professional Liability (MPL) policy
        VerifyElement           (//button/span[text()\='Yes'])[1]
        ClickElement            (//button/span[text()\='Yes'])[1]
        VerifyElement           (//button/span[text()\='No'])[1]
        Select current Expiration date
        Select current Retroactive date
        Type text               MPL Expiring Limit          2000000
        ClickText               Additional pricing discounts are available, if you can confirm the following statements.

        VerifyText              Additional pricing discounts are available, if you can confirm the following statements.
        VerifyText              Principals have an average of at least 10 years relevant industry experience
        VerifyElement           (//button/span[text()\='Yes'])[2]
        VerifyElement           (//button/span[text()\='No'])[2]
        VerifyText              No individual client or contract accounts for more than 25% of annual revenues
        VerifyElement           (//button/span[text()\='Yes'])[3]
        VerifyElement           (//button/span[text()\='No'])[3]
        VerifyText              The Insured uses sub-contractors on less than 25% of projects
        VerifyElement           (//button/span[text()\='Yes'])[4]
        VerifyElement           (//button/span[text()\='No'])[4]
        VerifyText              No client contract value is over $1,000,000
        VerifyElement           (//button/span[text()\='Yes'])[5]
        VerifyElement           (//button/span[text()\='No'])[5]
        VerifyText              Contracts are utilized on all client engagements
        VerifyElement           (//button/span[text()\='Yes'])[6]
        VerifyElement           (//button/span[text()\='No'])[6]
        VerifyText              All client contracts include a limitation of liability and/or indemnity clause that inures to the benefit of the Insured
        VerifyElement           (//button/span[text()\='Yes'])[7]
        VerifyElement           (//button/span[text()\='No'])[7]

        VerifyElement           //button[text()\=' Back ']
        VerifyElement           //button[text()\=' Next ']

    ELSE IF                     "${Industry_MPL_S}" == "Business Services - Employment Agencies"

        VerifyText              Tell us about your Insured
        VerifyText              The Insured currently purchases a Miscellaneous Professional Liability (MPL) policy
        VerifyElement           (//button/span[text()\='Yes'])[1]
        ClickElement            (//button/span[text()\='Yes'])[1]
        VerifyElement           (//button/span[text()\='No'])[1]
        Select current Expiration date
        Select current Retroactive date
        Type text               MPL Expiring Limit          2000000
        ClickText               Additional pricing discounts are available, if you can confirm the following statements.

        VerifyText              Additional pricing discounts are available, if you can confirm the following statements.
        VerifyText              Principals have an average of at least 10 years relevant industry experience
        VerifyElement           (//button/span[text()\='Yes'])[2]
        VerifyElement           (//button/span[text()\='No'])[2]
        VerifyText              No individual client or contract accounts for more than 25% of annual revenues
        VerifyElement           (//button/span[text()\='Yes'])[3]
        VerifyElement           (//button/span[text()\='No'])[3]
        VerifyText              The Insured uses sub-contractors on less than 25% of projects
        VerifyElement           (//button/span[text()\='Yes'])[4]
        VerifyElement           (//button/span[text()\='No'])[4]
        VerifyText              No client contract value is over $1,000,000
        VerifyElement           (//button/span[text()\='Yes'])[5]
        VerifyElement           (//button/span[text()\='No'])[5]
        VerifyText              Contracts are utilized on all client engagements
        VerifyElement           (//button/span[text()\='Yes'])[6]
        VerifyElement           (//button/span[text()\='No'])[6]
        VerifyText              All client contracts include a limitation of liability and/or indemnity clause that inures to the benefit of the Insured
        VerifyElement           (//button/span[text()\='Yes'])[7]
        VerifyElement           (//button/span[text()\='No'])[7]

        VerifyElement           //button[text()\=' Back ']
        VerifyElement           //button[text()\=' Next ']

    ELSE IF                     "${Industry_MPL_S}" == "Business Services - Event Planner"

        VerifyText              Tell us about your Insured
        VerifyText              The Insured currently purchases a Miscellaneous Professional Liability (MPL) policy
        VerifyElement           (//button/span[text()\='Yes'])[1]
        ClickElement            (//button/span[text()\='Yes'])[1]
        VerifyElement           (//button/span[text()\='No'])[1]
        Select current Expiration date
        Select current Retroactive date
        Type text               MPL Expiring Limit          2000000
        ClickText               Additional pricing discounts are available, if you can confirm the following statements.

        VerifyText              Additional pricing discounts are available, if you can confirm the following statements.
        VerifyText              Principals have an average of at least 10 years relevant industry experience
        VerifyElement           (//button/span[text()\='Yes'])[2]
        VerifyElement           (//button/span[text()\='No'])[2]
        VerifyText              No individual client or contract accounts for more than 25% of annual revenues
        VerifyElement           (//button/span[text()\='Yes'])[3]
        VerifyElement           (//button/span[text()\='No'])[3]
        VerifyText              The Insured uses sub-contractors on less than 25% of projects
        VerifyElement           (//button/span[text()\='Yes'])[4]
        VerifyElement           (//button/span[text()\='No'])[4]
        VerifyText              No client contract value is over $1,000,000
        VerifyElement           (//button/span[text()\='Yes'])[5]
        VerifyElement           (//button/span[text()\='No'])[5]
        VerifyText              Contracts are utilized on all client engagements
        VerifyElement           (//button/span[text()\='Yes'])[6]
        VerifyElement           (//button/span[text()\='No'])[6]
        VerifyText              All client contracts include a limitation of liability and/or indemnity clause that inures to the benefit of the Insured
        VerifyElement           (//button/span[text()\='Yes'])[7]
        VerifyElement           (//button/span[text()\='No'])[7]

        VerifyElement           //button[text()\=' Back ']
        VerifyElement           //button[text()\=' Next ']

    ELSE IF                     "${Industry_MPL_S}" == "Business Services - Executive Placement"

        VerifyText              Tell us about your Insured
        VerifyText              The Insured currently purchases a Miscellaneous Professional Liability (MPL) policy
        VerifyElement           (//button/span[text()\='Yes'])[1]
        ClickElement            (//button/span[text()\='Yes'])[1]
        VerifyElement           (//button/span[text()\='No'])[1]
        Select current Expiration date
        Select current Retroactive date
        Type text               MPL Expiring Limit          2000000
        ClickText               Additional pricing discounts are available, if you can confirm the following statements.

        VerifyText              Additional pricing discounts are available, if you can confirm the following statements.
        VerifyText              Principals have an average of at least 10 years relevant industry experience
        VerifyElement           (//button/span[text()\='Yes'])[2]
        VerifyElement           (//button/span[text()\='No'])[2]
        VerifyText              No individual client or contract accounts for more than 25% of annual revenues
        VerifyElement           (//button/span[text()\='Yes'])[3]
        VerifyElement           (//button/span[text()\='No'])[3]
        VerifyText              The Insured uses sub-contractors on less than 25% of projects
        VerifyElement           (//button/span[text()\='Yes'])[4]
        VerifyElement           (//button/span[text()\='No'])[4]
        VerifyText              No client contract value is over $1,000,000
        VerifyElement           (//button/span[text()\='Yes'])[5]
        VerifyElement           (//button/span[text()\='No'])[5]
        VerifyText              Contracts are utilized on all client engagements
        VerifyElement           (//button/span[text()\='Yes'])[6]
        VerifyElement           (//button/span[text()\='No'])[6]
        VerifyText              All client contracts include a limitation of liability and/or indemnity clause that inures to the benefit of the Insured
        VerifyElement           (//button/span[text()\='Yes'])[7]
        VerifyElement           (//button/span[text()\='No'])[7]

        VerifyElement           //button[text()\=' Back ']
        VerifyElement           //button[text()\=' Next ']

    ELSE IF                     "${Industry_MPL_S}" == "Business Services - Funeral & Crematories"

        VerifyText              Tell us about your Insured
        VerifyText              The Insured currently purchases a Miscellaneous Professional Liability (MPL) policy
        VerifyElement           (//button/span[text()\='Yes'])[1]
        ClickElement            (//button/span[text()\='Yes'])[1]
        VerifyElement           (//button/span[text()\='No'])[1]
        Select current Expiration date
        Select current Retroactive date
        Type text               MPL Expiring Limit          2000000
        ClickText               Additional pricing discounts are available, if you can confirm the following statements.

        VerifyText              Additional pricing discounts are available, if you can confirm the following statements.
        VerifyText              Principals have an average of at least 10 years relevant industry experience
        VerifyElement           (//button/span[text()\='Yes'])[2]
        VerifyElement           (//button/span[text()\='No'])[2]
        VerifyText              No individual client or contract accounts for more than 25% of annual revenues
        VerifyElement           (//button/span[text()\='Yes'])[3]
        VerifyElement           (//button/span[text()\='No'])[3]
        VerifyText              The Insured uses sub-contractors on less than 25% of projects
        VerifyElement           (//button/span[text()\='Yes'])[4]
        VerifyElement           (//button/span[text()\='No'])[4]
        VerifyText              No client contract value is over $1,000,000
        VerifyElement           (//button/span[text()\='Yes'])[5]
        VerifyElement           (//button/span[text()\='No'])[5]
        VerifyText              Contracts are utilized on all client engagements
        VerifyElement           (//button/span[text()\='Yes'])[6]
        VerifyElement           (//button/span[text()\='No'])[6]
        VerifyText              All client contracts include a limitation of liability and/or indemnity clause that inures to the benefit of the Insured
        VerifyElement           (//button/span[text()\='Yes'])[7]
        VerifyElement           (//button/span[text()\='No'])[7]

        VerifyElement           //button[text()\=' Back ']
        VerifyElement           //button[text()\=' Next ']

    ELSE IF                     "${Industry_MPL_S}" == "Business Services - Interior & Graphic Design"

        VerifyText              Tell us about your Insured
        VerifyText              The Insured currently purchases a Miscellaneous Professional Liability (MPL) policy
        VerifyElement           (//button/span[text()\='Yes'])[1]
        ClickElement            (//button/span[text()\='Yes'])[1]
        VerifyElement           (//button/span[text()\='No'])[1]
        Select current Expiration date
        Select current Retroactive date
        Type text               MPL Expiring Limit          2000000
        ClickText               Additional pricing discounts are available, if you can confirm the following statements.

        VerifyText              Additional pricing discounts are available, if you can confirm the following statements.
        VerifyText              Principals have an average of at least 10 years relevant industry experience
        VerifyElement           (//button/span[text()\='Yes'])[2]
        VerifyElement           (//button/span[text()\='No'])[2]
        VerifyText              No individual client or contract accounts for more than 25% of annual revenues
        VerifyElement           (//button/span[text()\='Yes'])[3]
        VerifyElement           (//button/span[text()\='No'])[3]
        VerifyText              The Insured uses sub-contractors on less than 25% of projects
        VerifyElement           (//button/span[text()\='Yes'])[4]
        VerifyElement           (//button/span[text()\='No'])[4]
        VerifyText              No client contract value is over $1,000,000
        VerifyElement           (//button/span[text()\='Yes'])[5]
        VerifyElement           (//button/span[text()\='No'])[5]
        VerifyText              Contracts are utilized on all client engagements
        VerifyElement           (//button/span[text()\='Yes'])[6]
        VerifyElement           (//button/span[text()\='No'])[6]
        VerifyText              All client contracts include a limitation of liability and/or indemnity clause that inures to the benefit of the Insured
        VerifyElement           (//button/span[text()\='Yes'])[7]
        VerifyElement           (//button/span[text()\='No'])[7]

        VerifyElement           //button[text()\=' Back ']
        VerifyElement           //button[text()\=' Next ']

    ELSE IF                     "${Industry_MPL_S}" == "Business Services - Literary Agents"

        VerifyText              Tell us about your Insured
        VerifyText              The Insured currently purchases a Miscellaneous Professional Liability (MPL) policy
        VerifyElement           (//button/span[text()\='Yes'])[1]
        ClickElement            (//button/span[text()\='Yes'])[1]
        VerifyElement           (//button/span[text()\='No'])[1]
        Select current Expiration date
        Select current Retroactive date
        Type text               MPL Expiring Limit          2000000
        ClickText               Additional pricing discounts are available, if you can confirm the following statements.

        VerifyText              Additional pricing discounts are available, if you can confirm the following statements.
        VerifyText              Principals have an average of at least 10 years relevant industry experience
        VerifyElement           (//button/span[text()\='Yes'])[2]
        VerifyElement           (//button/span[text()\='No'])[2]
        VerifyText              No individual client or contract accounts for more than 25% of annual revenues
        VerifyElement           (//button/span[text()\='Yes'])[3]
        VerifyElement           (//button/span[text()\='No'])[3]
        VerifyText              The Insured uses sub-contractors on less than 25% of projects
        VerifyElement           (//button/span[text()\='Yes'])[4]
        VerifyElement           (//button/span[text()\='No'])[4]
        VerifyText              No client contract value is over $1,000,000
        VerifyElement           (//button/span[text()\='Yes'])[5]
        VerifyElement           (//button/span[text()\='No'])[5]
        VerifyText              Contracts are utilized on all client engagements
        VerifyElement           (//button/span[text()\='Yes'])[6]
        VerifyElement           (//button/span[text()\='No'])[6]
        VerifyText              All client contracts include a limitation of liability and/or indemnity clause that inures to the benefit of the Insured
        VerifyElement           (//button/span[text()\='Yes'])[7]
        VerifyElement           (//button/span[text()\='No'])[7]

        VerifyElement           //button[text()\=' Back ']
        VerifyElement           //button[text()\=' Next ']

    ELSE IF                     "${Industry_MPL_S}" == "Business Services - Management & Business Consulting"

        VerifyText              Tell us about your Insured
        VerifyText              The Insured currently purchases a Miscellaneous Professional Liability (MPL) policy
        VerifyElement           (//button/span[text()\='Yes'])[1]
        ClickElement            (//button/span[text()\='Yes'])[1]
        VerifyElement           (//button/span[text()\='No'])[1]
        Select current Expiration date
        Select current Retroactive date
        Type text               MPL Expiring Limit          2000000
        ClickText               Additional pricing discounts are available, if you can confirm the following statements.

        VerifyText              Additional pricing discounts are available, if you can confirm the following statements.
        VerifyText              Principals have an average of at least 10 years relevant industry experience
        VerifyElement           (//button/span[text()\='Yes'])[2]
        VerifyElement           (//button/span[text()\='No'])[2]
        VerifyText              No individual client or contract accounts for more than 25% of annual revenues
        VerifyElement           (//button/span[text()\='Yes'])[3]
        VerifyElement           (//button/span[text()\='No'])[3]
        VerifyText              The Insured uses sub-contractors on less than 25% of projects
        VerifyElement           (//button/span[text()\='Yes'])[4]
        VerifyElement           (//button/span[text()\='No'])[4]
        VerifyText              No client contract value is over $1,000,000
        VerifyElement           (//button/span[text()\='Yes'])[5]
        VerifyElement           (//button/span[text()\='No'])[5]
        VerifyText              Contracts are utilized on all client engagements
        VerifyElement           (//button/span[text()\='Yes'])[6]
        VerifyElement           (//button/span[text()\='No'])[6]
        VerifyText              All client contracts include a limitation of liability and/or indemnity clause that inures to the benefit of the Insured
        VerifyElement           (//button/span[text()\='Yes'])[7]
        VerifyElement           (//button/span[text()\='No'])[7]

        VerifyElement           //button[text()\=' Back ']
        VerifyElement           //button[text()\=' Next ']

    ELSE IF                     "${Industry_MPL_S}" == "Business Services - Membership Organizations"

        VerifyText              Tell us about your Insured
        VerifyText              The Insured currently purchases a Miscellaneous Professional Liability (MPL) policy
        VerifyElement           (//button/span[text()\='Yes'])[1]
        ClickElement            (//button/span[text()\='Yes'])[1]
        VerifyElement           (//button/span[text()\='No'])[1]
        VerifyText              The Insured provides a referral service, legal aid service or technology to its members or the public.
        VerifyElement           (//button/span[text()\='Yes'])[2]
        VerifyElement           (//button/span[text()\='No'])[2]
        VerifyText              The Insured promotes, sponsors or provide any form of insurance to members or non-members.
        VerifyElement           (//button/span[text()\='Yes'])[3]
        VerifyElement           (//button/span[text()\='No'])[3]
        VerifyText              The Insured develops standards used to evaluate the quality of goods, products manufactured or services rendered.
        VerifyElement           (//button/span[text()\='Yes'])[4]
        VerifyElement           (//button/span[text()\='No'])[4]
        Select current Expiration date
        Select current Retroactive date
        Type text               MPL Expiring Limit          2000000
        ClickText               Additional pricing discounts are available, if you can confirm the following statements.

        VerifyText              Additional pricing discounts are available, if you can confirm the following statements.
        VerifyText              Principals have an average of at least 10 years relevant industry experience
        VerifyElement           (//button/span[text()\='Yes'])[5]
        VerifyElement           (//button/span[text()\='No'])[5]
        VerifyText              No individual client or contract accounts for more than 25% of annual revenues
        VerifyElement           (//button/span[text()\='Yes'])[6]
        VerifyElement           (//button/span[text()\='No'])[6]
        VerifyText              The Insured uses sub-contractors on less than 25% of projects
        VerifyElement           (//button/span[text()\='Yes'])[7]
        VerifyElement           (//button/span[text()\='No'])[7]
        VerifyText              No client contract value is over $1,000,000
        VerifyElement           (//button/span[text()\='Yes'])[8]
        VerifyElement           (//button/span[text()\='No'])[8]
        VerifyText              Contracts are utilized on all client engagements
        VerifyElement           (//button/span[text()\='Yes'])[9]
        VerifyElement           (//button/span[text()\='No'])[9]
        VerifyText              All client contracts include a limitation of liability and/or indemnity clause that inures to the benefit of the Insured
        VerifyElement           (//button/span[text()\='Yes'])[10]
        VerifyElement           (//button/span[text()\='No'])[10]

        VerifyElement           //button[text()\=' Back ']
        VerifyElement           //button[text()\=' Next ']

    ELSE IF                     "${Industry_MPL_S}" == "Business Services - Modeling/Talent Agency"

        VerifyText              Tell us about your Insured
        VerifyText              The Insured currently purchases a Miscellaneous Professional Liability (MPL) policy
        VerifyElement           (//button/span[text()\='Yes'])[1]
        ClickElement            (//button/span[text()\='Yes'])[1]
        VerifyElement           (//button/span[text()\='No'])[1]
        VerifyText              The Insured provides agency services to publicly known individuals/families.
        VerifyElement           (//button/span[text()\='Yes'])[2]
        VerifyElement           (//button/span[text()\='No'])[2]
        Select current Expiration date
        Select current Retroactive date
        Type text               MPL Expiring Limit          2000000
        ClickText               Additional pricing discounts are available, if you can confirm the following statements.

        VerifyText              Additional pricing discounts are available, if you can confirm the following statements.
        VerifyText              Principals have an average of at least 10 years relevant industry experience
        VerifyElement           (//button/span[text()\='Yes'])[3]
        VerifyElement           (//button/span[text()\='No'])[3]
        VerifyText              No individual client or contract accounts for more than 25% of annual revenues
        VerifyElement           (//button/span[text()\='Yes'])[4]
        VerifyElement           (//button/span[text()\='No'])[4]
        VerifyText              The Insured uses sub-contractors on less than 25% of projects
        VerifyElement           (//button/span[text()\='Yes'])[5]
        VerifyElement           (//button/span[text()\='No'])[5]
        VerifyText              No client contract value is over $1,000,000
        VerifyElement           (//button/span[text()\='Yes'])[6]
        VerifyElement           (//button/span[text()\='No'])[6]
        VerifyText              Contracts are utilized on all client engagements
        VerifyElement           (//button/span[text()\='Yes'])[7]
        VerifyElement           (//button/span[text()\='No'])[7]
        VerifyText              All client contracts include a limitation of liability and/or indemnity clause that inures to the benefit of the Insured
        VerifyElement           (//button/span[text()\='Yes'])[8]
        VerifyElement           (//button/span[text()\='No'])[8]

        VerifyElement           //button[text()\=' Back ']
        VerifyElement           //button[text()\=' Next ']

    ELSE IF                     "${Industry_MPL_S}" == "Business Services - Notary Public"

        VerifyText              Tell us about your Insured
        VerifyText              The Insured currently purchases a Miscellaneous Professional Liability (MPL) policy
        VerifyElement           (//button/span[text()\='Yes'])[1]
        ClickElement            (//button/span[text()\='Yes'])[1]
        VerifyElement           (//button/span[text()\='No'])[1]
        Select current Expiration date
        Select current Retroactive date
        Type text               MPL Expiring Limit          2000000
        ClickText               Additional pricing discounts are available, if you can confirm the following statements.

        VerifyText              Additional pricing discounts are available, if you can confirm the following statements.
        VerifyText              Principals have an average of at least 10 years relevant industry experience
        VerifyElement           (//button/span[text()\='Yes'])[2]
        VerifyElement           (//button/span[text()\='No'])[2]
        VerifyText              No individual client or contract accounts for more than 25% of annual revenues
        VerifyElement           (//button/span[text()\='Yes'])[3]
        VerifyElement           (//button/span[text()\='No'])[3]
        VerifyText              The Insured uses sub-contractors on less than 25% of projects
        VerifyElement           (//button/span[text()\='Yes'])[4]
        VerifyElement           (//button/span[text()\='No'])[4]
        VerifyText              No client contract value is over $1,000,000
        VerifyElement           (//button/span[text()\='Yes'])[5]
        VerifyElement           (//button/span[text()\='No'])[5]
        VerifyText              Contracts are utilized on all client engagements
        VerifyElement           (//button/span[text()\='Yes'])[6]
        VerifyElement           (//button/span[text()\='No'])[6]
        VerifyText              All client contracts include a limitation of liability and/or indemnity clause that inures to the benefit of the Insured
        VerifyElement           (//button/span[text()\='Yes'])[7]
        VerifyElement           (//button/span[text()\='No'])[7]

        VerifyElement           //button[text()\=' Back ']
        VerifyElement           //button[text()\=' Next ']

    ELSE IF                     "${Industry_MPL_S}" == "Business Services - Office Management"

        VerifyText              Tell us about your Insured
        VerifyText              The Insured currently purchases a Miscellaneous Professional Liability (MPL) policy
        VerifyText              The Insured handles and provides funds transfer services on behalf of its clients.
        VerifyElement           (//button/span[text()\='Yes'])[1]
        ClickElement            (//button/span[text()\='Yes'])[1]
        VerifyElement           (//button/span[text()\='No'])[1]
        Select current Expiration date
        Select current Retroactive date
        Type text               MPL Expiring Limit          2000000
        ClickText               Additional pricing discounts are available, if you can confirm the following statements.

        VerifyText              Additional pricing discounts are available, if you can confirm the following statements.
        VerifyText              Principals have an average of at least 10 years relevant industry experience
        VerifyElement           (//button/span[text()\='Yes'])[2]
        VerifyElement           (//button/span[text()\='No'])[2]
        VerifyText              No individual client or contract accounts for more than 25% of annual revenues
        VerifyElement           (//button/span[text()\='Yes'])[3]
        VerifyElement           (//button/span[text()\='No'])[3]
        VerifyText              The Insured uses sub-contractors on less than 25% of projects
        VerifyElement           (//button/span[text()\='Yes'])[4]
        VerifyElement           (//button/span[text()\='No'])[4]
        VerifyText              No client contract value is over $1,000,000
        VerifyElement           (//button/span[text()\='Yes'])[5]
        VerifyElement           (//button/span[text()\='No'])[5]
        VerifyText              Contracts are utilized on all client engagements
        VerifyElement           (//button/span[text()\='Yes'])[6]
        VerifyElement           (//button/span[text()\='No'])[6]
        VerifyText              All client contracts include a limitation of liability and/or indemnity clause that inures to the benefit of the Insured
        VerifyElement           (//button/span[text()\='Yes'])[7]
        VerifyElement           (//button/span[text()\='No'])[7]

        VerifyElement           //button[text()\=' Back ']
        VerifyElement           //button[text()\=' Next ']

    ELSE IF                     "${Industry_MPL_S}" == "Business Services - Pet Related Services"

        VerifyText              Tell us about your Insured
        VerifyText              The Insured currently purchases a Miscellaneous Professional Liability (MPL) policy
        VerifyElement           (//button/span[text()\='Yes'])[1]
        ClickElement            (//button/span[text()\='Yes'])[1]
        VerifyElement           (//button/span[text()\='No'])[1]
        Select current Expiration date
        Select current Retroactive date
        Type text               MPL Expiring Limit          2000000
        ClickText               Additional pricing discounts are available, if you can confirm the following statements.

        VerifyText              Additional pricing discounts are available, if you can confirm the following statements.
        VerifyText              Principals have an average of at least 10 years relevant industry experience
        VerifyElement           (//button/span[text()\='Yes'])[2]
        VerifyElement           (//button/span[text()\='No'])[2]
        VerifyText              No individual client or contract accounts for more than 25% of annual revenues
        VerifyElement           (//button/span[text()\='Yes'])[3]
        VerifyElement           (//button/span[text()\='No'])[3]
        VerifyText              The Insured uses sub-contractors on less than 25% of projects
        VerifyElement           (//button/span[text()\='Yes'])[4]
        VerifyElement           (//button/span[text()\='No'])[4]
        VerifyText              No client contract value is over $1,000,000
        VerifyElement           (//button/span[text()\='Yes'])[5]
        VerifyElement           (//button/span[text()\='No'])[5]
        VerifyText              Contracts are utilized on all client engagements
        VerifyElement           (//button/span[text()\='Yes'])[6]
        VerifyElement           (//button/span[text()\='No'])[6]
        VerifyText              All client contracts include a limitation of liability and/or indemnity clause that inures to the benefit of the Insured
        VerifyElement           (//button/span[text()\='Yes'])[7]
        VerifyElement           (//button/span[text()\='No'])[7]

        VerifyElement           //button[text()\=' Back ']
        VerifyElement           //button[text()\=' Next ']

    ELSE IF                     "${Industry_MPL_S}" == "Business Services - Photographic Studios"

        VerifyText              Tell us about your Insured
        VerifyText              The Insured currently purchases a Miscellaneous Professional Liability (MPL) policy
        VerifyElement           (//button/span[text()\='Yes'])[1]
        ClickElement            (//button/span[text()\='Yes'])[1]
        VerifyElement           (//button/span[text()\='No'])[1]
        Select current Expiration date
        Select current Retroactive date
        Type text               MPL Expiring Limit          2000000
        ClickText               Additional pricing discounts are available, if you can confirm the following statements.

        VerifyText              Additional pricing discounts are available, if you can confirm the following statements.
        VerifyText              Principals have an average of at least 10 years relevant industry experience
        VerifyElement           (//button/span[text()\='Yes'])[2]
        VerifyElement           (//button/span[text()\='No'])[2]
        VerifyText              No individual client or contract accounts for more than 25% of annual revenues
        VerifyElement           (//button/span[text()\='Yes'])[3]
        VerifyElement           (//button/span[text()\='No'])[3]
        VerifyText              The Insured uses sub-contractors on less than 25% of projects
        VerifyElement           (//button/span[text()\='Yes'])[4]
        VerifyElement           (//button/span[text()\='No'])[4]
        VerifyText              No client contract value is over $1,000,000
        VerifyElement           (//button/span[text()\='Yes'])[5]
        VerifyElement           (//button/span[text()\='No'])[5]
        VerifyText              Contracts are utilized on all client engagements
        VerifyElement           (//button/span[text()\='Yes'])[6]
        VerifyElement           (//button/span[text()\='No'])[6]
        VerifyText              All client contracts include a limitation of liability and/or indemnity clause that inures to the benefit of the Insured
        VerifyElement           (//button/span[text()\='Yes'])[7]
        VerifyElement           (//button/span[text()\='No'])[7]

        VerifyElement           //button[text()\=' Back ']
        VerifyElement           //button[text()\=' Next ']

    ELSE IF                     "${Industry_MPL_S}" == "Business Services - Printers"

        VerifyText              Tell us about your Insured
        VerifyText              The Insured currently purchases a Miscellaneous Professional Liability (MPL) policy
        VerifyElement           (//button/span[text()\='Yes'])[1]
        ClickElement            (//button/span[text()\='Yes'])[1]
        VerifyElement           (//button/span[text()\='No'])[1]
        Select current Expiration date
        Select current Retroactive date
        Type text               MPL Expiring Limit          2000000
        ClickText               Additional pricing discounts are available, if you can confirm the following statements.

        VerifyText              Additional pricing discounts are available, if you can confirm the following statements.
        VerifyText              Principals have an average of at least 10 years relevant industry experience
        VerifyElement           (//button/span[text()\='Yes'])[2]
        VerifyElement           (//button/span[text()\='No'])[2]
        VerifyText              No individual client or contract accounts for more than 25% of annual revenues
        VerifyElement           (//button/span[text()\='Yes'])[3]
        VerifyElement           (//button/span[text()\='No'])[3]
        VerifyText              The Insured uses sub-contractors on less than 25% of projects
        VerifyElement           (//button/span[text()\='Yes'])[4]
        VerifyElement           (//button/span[text()\='No'])[4]
        VerifyText              No client contract value is over $1,000,000
        VerifyElement           (//button/span[text()\='Yes'])[5]
        VerifyElement           (//button/span[text()\='No'])[5]
        VerifyText              Contracts are utilized on all client engagements
        VerifyElement           (//button/span[text()\='Yes'])[6]
        VerifyElement           (//button/span[text()\='No'])[6]
        VerifyText              All client contracts include a limitation of liability and/or indemnity clause that inures to the benefit of the Insured
        VerifyElement           (//button/span[text()\='Yes'])[7]
        VerifyElement           (//button/span[text()\='No'])[7]

        VerifyElement           //button[text()\=' Back ']
        VerifyElement           //button[text()\=' Next ']

    ELSE IF                     "${Industry_MPL_S}" == "Business Services - Process Server"

        VerifyText              Tell us about your Insured
        VerifyText              The Insured currently purchases a Miscellaneous Professional Liability (MPL) policy
        VerifyElement           (//button/span[text()\='Yes'])[1]
        ClickElement            (//button/span[text()\='Yes'])[1]
        VerifyElement           (//button/span[text()\='No'])[1]
        Select current Expiration date
        Select current Retroactive date
        Type text               MPL Expiring Limit          2000000
        ClickText               Additional pricing discounts are available, if you can confirm the following statements.

        VerifyText              Additional pricing discounts are available, if you can confirm the following statements.
        VerifyText              Principals have an average of at least 10 years relevant industry experience
        VerifyElement           (//button/span[text()\='Yes'])[2]
        VerifyElement           (//button/span[text()\='No'])[2]
        VerifyText              No individual client or contract accounts for more than 25% of annual revenues
        VerifyElement           (//button/span[text()\='Yes'])[3]
        VerifyElement           (//button/span[text()\='No'])[3]
        VerifyText              The Insured uses sub-contractors on less than 25% of projects
        VerifyElement           (//button/span[text()\='Yes'])[4]
        VerifyElement           (//button/span[text()\='No'])[4]
        VerifyText              No client contract value is over $1,000,000
        VerifyElement           (//button/span[text()\='Yes'])[5]
        VerifyElement           (//button/span[text()\='No'])[5]
        VerifyText              Contracts are utilized on all client engagements
        VerifyElement           (//button/span[text()\='Yes'])[6]
        VerifyElement           (//button/span[text()\='No'])[6]
        VerifyText              All client contracts include a limitation of liability and/or indemnity clause that inures to the benefit of the Insured
        VerifyElement           (//button/span[text()\='Yes'])[7]
        VerifyElement           (//button/span[text()\='No'])[7]

        VerifyElement           //button[text()\=' Back ']
        VerifyElement           //button[text()\=' Next ']

    ELSE IF                     "${Industry_MPL_S}" == "Business Services - Tax Preparation (NON-CPA SERVICES)"

        VerifyText              Tell us about your Insured
        VerifyText              The Insured currently purchases a Miscellaneous Professional Liability (MPL) policy
        VerifyElement           (//button/span[text()\='Yes'])[1]
        ClickElement            (//button/span[text()\='Yes'])[1]
        VerifyElement           (//button/span[text()\='No'])[1]
        VerifyText              The Insured does not provide any services to publicly known individuals or any government entities.
        VerifyElement           (//button/span[text()\='Yes'])[2]
        VerifyElement           (//button/span[text()\='No'])[2]
        Select current Expiration date
        Select current Retroactive date
        Type text               MPL Expiring Limit          2000000
        ClickText               Additional pricing discounts are available, if you can confirm the following statements.

        VerifyText              Additional pricing discounts are available, if you can confirm the following statements.
        VerifyText              Principals have an average of at least 10 years relevant industry experience
        VerifyElement           (//button/span[text()\='Yes'])[3]
        VerifyElement           (//button/span[text()\='No'])[3]
        VerifyText              No individual client or contract accounts for more than 25% of annual revenues
        VerifyElement           (//button/span[text()\='Yes'])[4]
        VerifyElement           (//button/span[text()\='No'])[4]
        VerifyText              The Insured uses sub-contractors on less than 25% of projects
        VerifyElement           (//button/span[text()\='Yes'])[5]
        VerifyElement           (//button/span[text()\='No'])[5]
        VerifyText              No client contract value is over $1,000,000
        VerifyElement           (//button/span[text()\='Yes'])[6]
        VerifyElement           (//button/span[text()\='No'])[6]
        VerifyText              Contracts are utilized on all client engagements
        VerifyElement           (//button/span[text()\='Yes'])[7]
        VerifyElement           (//button/span[text()\='No'])[7]
        VerifyText              All client contracts include a limitation of liability and/or indemnity clause that inures to the benefit of the Insured
        VerifyElement           (//button/span[text()\='Yes'])[8]
        VerifyElement           (//button/span[text()\='No'])[8]

        VerifyElement           //button[text()\=' Back ']
        VerifyElement           //button[text()\=' Next ']

    ELSE IF                     "${Industry_MPL_S}" == "Business Services - Translation & Interpretation Services"

        VerifyText              Tell us about your Insured
        VerifyText              The Insured currently purchases a Miscellaneous Professional Liability (MPL) policy
        VerifyElement           (//button/span[text()\='Yes'])[1]
        ClickElement            (//button/span[text()\='Yes'])[1]
        VerifyElement           (//button/span[text()\='No'])[1]
        Select current Expiration date
        Select current Retroactive date
        Type text               MPL Expiring Limit          2000000
        ClickText               Additional pricing discounts are available, if you can confirm the following statements.

        VerifyText              Additional pricing discounts are available, if you can confirm the following statements.
        VerifyText              Principals have an average of at least 10 years relevant industry experience
        VerifyElement           (//button/span[text()\='Yes'])[2]
        VerifyElement           (//button/span[text()\='No'])[2]
        VerifyText              No individual client or contract accounts for more than 25% of annual revenues
        VerifyElement           (//button/span[text()\='Yes'])[3]
        VerifyElement           (//button/span[text()\='No'])[3]
        VerifyText              The Insured uses sub-contractors on less than 25% of projects
        VerifyElement           (//button/span[text()\='Yes'])[4]
        VerifyElement           (//button/span[text()\='No'])[4]
        VerifyText              No client contract value is over $1,000,000
        VerifyElement           (//button/span[text()\='Yes'])[5]
        VerifyElement           (//button/span[text()\='No'])[5]
        VerifyText              Contracts are utilized on all client engagements
        VerifyElement           (//button/span[text()\='Yes'])[6]
        VerifyElement           (//button/span[text()\='No'])[6]
        VerifyText              All client contracts include a limitation of liability and/or indemnity clause that inures to the benefit of the Insured
        VerifyElement           (//button/span[text()\='Yes'])[7]
        VerifyElement           (//button/span[text()\='No'])[7]

        VerifyElement           //button[text()\=' Back ']
        VerifyElement           //button[text()\=' Next ']

    ELSE IF                     "${Industry_MPL_S}" == "Education - Exam Preparation and Tutoring"

        VerifyText              Tell us about your Insured
        VerifyText              The Insured currently purchases a Miscellaneous Professional Liability (MPL) policy
        VerifyElement           (//button/span[text()\='Yes'])[1]
        ClickElement            (//button/span[text()\='Yes'])[1]
        VerifyElement           (//button/span[text()\='No'])[1]
        VerifyText              TThe Insured clearly states the ownership rights, licensing, and use of any materials or intellectual property created for or during an engagement.
        VerifyElement           (//button/span[text()\='Yes'])[2]
        VerifyElement           (//button/span[text()\='No'])[2]
        Select current Expiration date
        Select current Retroactive date
        Type text               MPL Expiring Limit          2000000
        ClickText               Additional pricing discounts are available, if you can confirm the following statements.

        VerifyText              Additional pricing discounts are available, if you can confirm the following statements.
        VerifyText              Principals have an average of at least 10 years relevant industry experience
        VerifyElement           (//button/span[text()\='Yes'])[3]
        VerifyElement           (//button/span[text()\='No'])[3]
        VerifyText              No individual client or contract accounts for more than 25% of annual revenues
        VerifyElement           (//button/span[text()\='Yes'])[4]
        VerifyElement           (//button/span[text()\='No'])[4]
        VerifyText              The Insured uses sub-contractors on less than 25% of projects
        VerifyElement           (//button/span[text()\='Yes'])[5]
        VerifyElement           (//button/span[text()\='No'])[5]
        VerifyText              No client contract value is over $1,000,000
        VerifyElement           (//button/span[text()\='Yes'])[6]
        VerifyElement           (//button/span[text()\='No'])[6]
        VerifyText              Contracts are utilized on all client engagements
        VerifyElement           (//button/span[text()\='Yes'])[7]
        VerifyElement           (//button/span[text()\='No'])[7]
        VerifyText              All client contracts include a limitation of liability and/or indemnity clause that inures to the benefit of the Insured
        VerifyElement           (//button/span[text()\='Yes'])[8]
        VerifyElement           (//button/span[text()\='No'])[8]

        VerifyElement           //button[text()\=' Back ']
        VerifyElement           //button[text()\=' Next ']

    ELSE IF                     "${Industry_MPL_S}" == "Media - Public Relations"

        VerifyText              Tell us about your Insured
        VerifyText              The Insured currently purchases a Miscellaneous Professional Liability (MPL) policy
        VerifyElement           (//button/span[text()\='Yes'])[1]
        ClickElement            (//button/span[text()\='Yes'])[1]
        VerifyElement           (//button/span[text()\='No'])[1]
        Select current Expiration date
        Select current Retroactive date
        Type text               MPL Expiring Limit          2000000
        ClickText               Additional pricing discounts are available, if you can confirm the following statements.

        VerifyText              Additional pricing discounts are available, if you can confirm the following statements.
        VerifyText              Principals have an average of at least 10 years relevant industry experience
        VerifyElement           (//button/span[text()\='Yes'])[2]
        VerifyElement           (//button/span[text()\='No'])[2]
        VerifyText              No individual client or contract accounts for more than 25% of annual revenues
        VerifyElement           (//button/span[text()\='Yes'])[3]
        VerifyElement           (//button/span[text()\='No'])[3]
        VerifyText              The Insured uses sub-contractors on less than 25% of projects
        VerifyElement           (//button/span[text()\='Yes'])[4]
        VerifyElement           (//button/span[text()\='No'])[4]
        VerifyText              No client contract value is over $1,000,000
        VerifyElement           (//button/span[text()\='Yes'])[5]
        VerifyElement           (//button/span[text()\='No'])[5]
        VerifyText              Contracts are utilized on all client engagements
        VerifyElement           (//button/span[text()\='Yes'])[6]
        VerifyElement           (//button/span[text()\='No'])[6]
        VerifyText              All client contracts include a limitation of liability and/or indemnity clause that inures to the benefit of the Insured
        VerifyElement           (//button/span[text()\='Yes'])[7]
        VerifyElement           (//button/span[text()\='No'])[7]

        VerifyElement           //button[text()\=' Back ']
        VerifyElement           //button[text()\=' Next ']

    ELSE IF                     "${Industry_MPL_S}" == "Real Estate - Residential Appraisers"

        VerifyText              Tell us about your Insured
        VerifyText              The Insured currently purchases a Miscellaneous Professional Liability (MPL) policy
        VerifyElement           (//button/span[text()\='Yes'])[1]
        ClickElement            (//button/span[text()\='Yes'])[1]
        VerifyElement           (//button/span[text()\='No'])[1]
        Verifytext              In the past year, the Insured has performed appraisals with property values in excess of $2,000,000.
        VerifyElement           (//button/span[text()\='Yes'])[2]
        VerifyElement           (//button/span[text()\='No'])[2]
        VerifyText              The Insured utilizes MLS/Trend, NDC or public records to verify information for accuracy and maintaining quality control over all appraisals produced by their office.
        VerifyElement           (//button/span[text()\='Yes'])[3]
        VerifyElement           (//button/span[text()\='No'])[3]
        Select current Expiration date
        Select current Retroactive date
        Type text               MPL Expiring Limit          2000000
        ClickText               Additional pricing discounts are available, if you can confirm the following statements.

        VerifyText              Additional pricing discounts are available, if you can confirm the following statements.
        VerifyText              Principals have an average of at least 10 years relevant industry experience
        VerifyElement           (//button/span[text()\='Yes'])[4]
        VerifyElement           (//button/span[text()\='No'])[4]
        VerifyText              No individual client or contract accounts for more than 25% of annual revenues
        VerifyElement           (//button/span[text()\='Yes'])[5]
        VerifyElement           (//button/span[text()\='No'])[5]
        VerifyText              The Insured uses sub-contractors on less than 25% of projects
        VerifyElement           (//button/span[text()\='Yes'])[6]
        VerifyElement           (//button/span[text()\='No'])[6]
        VerifyText              No client contract value is over $1,000,000
        VerifyElement           (//button/span[text()\='Yes'])[7]
        VerifyElement           (//button/span[text()\='No'])[7]
        VerifyText              Contracts are utilized on all client engagements
        VerifyElement           (//button/span[text()\='Yes'])[8]
        VerifyElement           (//button/span[text()\='No'])[8]
        VerifyText              All client contracts include a limitation of liability and/or indemnity clause that inures to the benefit of the Insured
        VerifyElement           (//button/span[text()\='Yes'])[9]
        VerifyElement           (//button/span[text()\='No'])[9]

        VerifyElement           //button[text()\=' Back ']
        VerifyElement           //button[text()\=' Next ']

    ELSE IF                     "${Industry_MPL_S}" == "Real Estate - Relocation Agent"

        VerifyText              Tell us about your Insured
        VerifyText              The Insured currently purchases a Miscellaneous Professional Liability (MPL) policy
        VerifyElement           (//button/span[text()\='Yes'])[1]
        ClickElement            (//button/span[text()\='Yes'])[1]
        VerifyElement           (//button/span[text()\='No'])[1]
        Select current Expiration date
        Select current Retroactive date
        Type text               MPL Expiring Limit          2000000
        ClickText               Additional pricing discounts are available, if you can confirm the following statements.

        VerifyText              Additional pricing discounts are available, if you can confirm the following statements.
        VerifyText              Principals have an average of at least 10 years relevant industry experience
        VerifyElement           (//button/span[text()\='Yes'])[2]
        VerifyElement           (//button/span[text()\='No'])[2]
        VerifyText              No individual client or contract accounts for more than 25% of annual revenues
        VerifyElement           (//button/span[text()\='Yes'])[3]
        VerifyElement           (//button/span[text()\='No'])[3]
        VerifyText              The Insured uses sub-contractors on less than 25% of projects
        VerifyElement           (//button/span[text()\='Yes'])[4]
        VerifyElement           (//button/span[text()\='No'])[4]
        VerifyText              No client contract value is over $1,000,000
        VerifyElement           (//button/span[text()\='Yes'])[5]
        VerifyElement           (//button/span[text()\='No'])[5]
        VerifyText              Contracts are utilized on all client engagements
        VerifyElement           (//button/span[text()\='Yes'])[6]
        VerifyElement           (//button/span[text()\='No'])[6]
        VerifyText              All client contracts include a limitation of liability and/or indemnity clause that inures to the benefit of the Insured
        VerifyElement           (//button/span[text()\='Yes'])[7]
        VerifyElement           (//button/span[text()\='No'])[7]

        VerifyElement           //button[text()\=' Back ']
        VerifyElement           //button[text()\=' Next ']

    ELSE IF                     "${Industry_MPL_S}" == "Transportation - Travel Agencies/Tour Operators"

        VerifyText              Tell us about your Insured
        VerifyText              The Insured currently purchases a Miscellaneous Professional Liability (MPL) policy
        VerifyElement           (//button/span[text()\='Yes'])[1]
        ClickElement            (//button/span[text()\='Yes'])[1]
        VerifyElement           (//button/span[text()\='No'])[1]
        Select current Expiration date
        Select current Retroactive date
        Type text               MPL Expiring Limit          2000000
        ClickText               Additional pricing discounts are available, if you can confirm the following statements.

        VerifyText              Additional pricing discounts are available, if you can confirm the following statements.
        VerifyText              Principals have an average of at least 10 years relevant industry experience
        VerifyElement           (//button/span[text()\='Yes'])[2]
        VerifyElement           (//button/span[text()\='No'])[2]
        VerifyText              No individual client or contract accounts for more than 25% of annual revenues
        VerifyElement           (//button/span[text()\='Yes'])[3]
        VerifyElement           (//button/span[text()\='No'])[3]
        VerifyText              The Insured uses sub-contractors on less than 25% of projects
        VerifyElement           (//button/span[text()\='Yes'])[4]
        VerifyElement           (//button/span[text()\='No'])[4]
        VerifyText              No client contract value is over $1,000,000
        VerifyElement           (//button/span[text()\='Yes'])[5]
        VerifyElement           (//button/span[text()\='No'])[5]
        VerifyText              Contracts are utilized on all client engagements
        VerifyElement           (//button/span[text()\='Yes'])[6]
        VerifyElement           (//button/span[text()\='No'])[6]
        VerifyText              All client contracts include a limitation of liability and/or indemnity clause that inures to the benefit of the Insured
        VerifyElement           (//button/span[text()\='Yes'])[7]
        VerifyElement           (//button/span[text()\='No'])[7]

        VerifyElement           //button[text()\=' Back ']
        VerifyElement           //button[text()\=' Next ']


















    END
    Log To Console              ------elements on Coverage question Page for MPL Validated Successfully-------




Verify actions performed on Coverage question page select - Yes
    [Documentation]             Verify actions performed on Coverage question page select Yes

    [Arguments]                 ${Industry_MPL_S}


    IF                          "${Industry_MPL_S}" == "Business Services - Billing Services"

    VerifyText              The Insured currently purchases a Miscellaneous Professional Liability (MPL) policy
    VerifyElement               (//button/span[text()\='Yes'])[1]
    ClickElement                (//button/span[text()\='Yes'])[1]
    VerifyElement               (//button/span[text()\='No'])[1]
    Select current Expiration date
    Select current Retroactive date
    Type text                   MPL Expiring Limit          2000000

    ClickText                   Additional pricing discounts are available, if you can confirm the following statements.
    VerifyText                  Tell us about your Insured

    VerifyText                  Additional pricing discounts are available, if you can confirm the following statements.
    VerifyText                  Principals have an average of at least 10 years relevant industry experience
    VerifyElement               (//button/span[text()\='Yes'])[2]
    ClickElement                (//button/span[text()\='Yes'])[2]
    VerifyElement               (//button/span[text()\='No'])[2]
    VerifyText                  No individual client or contract accounts for more than 25% of annual revenues
    VerifyElement               (//button/span[text()\='Yes'])[3]
    ClickElement                (//button/span[text()\='Yes'])[3]
    VerifyElement               (//button/span[text()\='No'])[3]
    VerifyText                  The Insured uses sub-contractors on less than 25% of projects
    VerifyElement               (//button/span[text()\='Yes'])[4]
    ClickElement                (//button/span[text()\='Yes'])[4]
    VerifyElement               (//button/span[text()\='No'])[4]
    VerifyText                  No client contract value is over $1,000,000
    VerifyElement               (//button/span[text()\='Yes'])[5]
    ClickElement                (//button/span[text()\='Yes'])[5]
    VerifyElement               (//button/span[text()\='No'])[5]
    VerifyText                  Contracts are utilized on all client engagements
    VerifyElement               (//button/span[text()\='Yes'])[6]
    ClickElement                (//button/span[text()\='Yes'])[6]
    VerifyElement               (//button/span[text()\='No'])[6]
    VerifyText                  All client contracts include a limitation of liability and/or indemnity clause that inures to the benefit of the Insured
    VerifyElement               (//button/span[text()\='Yes'])[7]
    ClickElement                (//button/span[text()\='Yes'])[7]
    VerifyElement               (//button/span[text()\='No'])[7]


        VerifyElement           //button[text()\=' Back ']
        VerifyElement           //button[text()\=' Next ']

    ELSE IF                     "${Industry_MPL_S}" == "Business Services - Accreditation & Certification Services"

        VerifyText              The Insured currently purchases a Miscellaneous Professional Liability (MPL) policy
        VerifyText              Industry Members and Legal Counsel review and approve Applicable Standards before they are published.
        VerifyElement           (//button/span[text()\='Yes'])[1]
        ClickElement            (//button/span[text()\='Yes'])[1]
        VerifyElement           (//button/span[text()\='No'])[1]
        Select current Expiration date
        Select current Retroactive date
        Type text               MPL Expiring Limit          2000000
        ClickText               Additional pricing discounts are available, if you can confirm the following statements.
        VerifyText              Tell us about your Insured

        VerifyText              Additional pricing discounts are available, if you can confirm the following statements.
        VerifyText              Principals have an average of at least 10 years relevant industry experience
        VerifyElement           (//button/span[text()\='Yes'])[2]
        ClickElement            (//button/span[text()\='Yes'])[2]
        VerifyElement           (//button/span[text()\='No'])[2]
        VerifyText              No individual client or contract accounts for more than 25% of annual revenues
        VerifyElement           (//button/span[text()\='Yes'])[3]
        ClickElement            (//button/span[text()\='Yes'])[3]
        VerifyElement           (//button/span[text()\='No'])[3]
        VerifyText              The Insured uses sub-contractors on less than 25% of projects
        VerifyElement           (//button/span[text()\='Yes'])[4]
        ClickElement            (//button/span[text()\='Yes'])[4]
        VerifyElement           (//button/span[text()\='No'])[4]
        VerifyText              No client contract value is over $1,000,000
        VerifyElement           (//button/span[text()\='Yes'])[5]
        ClickElement            (//button/span[text()\='Yes'])[5]
        VerifyElement           (//button/span[text()\='No'])[5]
        VerifyText              Contracts are utilized on all client engagements
        VerifyElement           (//button/span[text()\='Yes'])[6]
        ClickElement            (//button/span[text()\='Yes'])[6]
        VerifyElement           (//button/span[text()\='No'])[6]
        VerifyText              All client contracts include a limitation of liability and/or indemnity clause that inures to the benefit of the Insured
        VerifyElement           (//button/span[text()\='Yes'])[7]
        ClickElement            (//button/span[text()\='Yes'])[7]
        VerifyElement           (//button/span[text()\='No'])[7]

        VerifyElement           //button[text()\=' Back ']
        VerifyElement           //button[text()\=' Next ']

    ELSE IF                     "${Industry_MPL_S}" == "Business Services - Alarm Monitors"

        VerifyText              The Insured currently purchases a Miscellaneous Professional Liability (MPL) policy
        VerifyElement           (//button/span[text()\='Yes'])[1]
        ClickElement            (//button/span[text()\='Yes'])[1]
        VerifyElement           (//button/span[text()\='No'])[1]
        Select current Expiration date
        Select current Retroactive date
        Type text               MPL Expiring Limit          2000000
        ClickText               Additional pricing discounts are available, if you can confirm the following statements.
        VerifyText              Tell us about your Insured

        VerifyText              Additional pricing discounts are available, if you can confirm the following statements.
        VerifyText              Principals have an average of at least 10 years relevant industry experience
        VerifyElement           (//button/span[text()\='Yes'])[2]
        ClickElement            (//button/span[text()\='Yes'])[2]
        VerifyElement           (//button/span[text()\='No'])[2]
        VerifyText              No individual client or contract accounts for more than 25% of annual revenues
        VerifyElement           (//button/span[text()\='Yes'])[3]
        ClickElement            (//button/span[text()\='Yes'])[3]
        VerifyElement           (//button/span[text()\='No'])[3]
        VerifyText              The Insured uses sub-contractors on less than 25% of projects
        VerifyElement           (//button/span[text()\='Yes'])[4]
        ClickElement            (//button/span[text()\='Yes'])[4]
        VerifyElement           (//button/span[text()\='No'])[4]
        VerifyText              No client contract value is over $1,000,000
        VerifyElement           (//button/span[text()\='Yes'])[5]
        ClickElement            (//button/span[text()\='Yes'])[5]
        VerifyElement           (//button/span[text()\='No'])[5]
        VerifyText              Contracts are utilized on all client engagements
        VerifyElement           (//button/span[text()\='Yes'])[6]
        ClickElement            (//button/span[text()\='Yes'])[6]
        VerifyElement           (//button/span[text()\='No'])[6]
        VerifyText              All client contracts include a limitation of liability and/or indemnity clause that inures to the benefit of the Insured
        VerifyElement           (//button/span[text()\='Yes'])[7]
        ClickElement            (//button/span[text()\='Yes'])[7]
        VerifyElement           (//button/span[text()\='No'])[7]
        VerifyElement           //button[text()\=' Back ']
        VerifyElement           //button[text()\=' Next ']

    ELSE IF                     "${Industry_MPL_S}" == "Business Services - Auctioneer"

        VerifyText              The Insured currently purchases a Miscellaneous Professional Liability (MPL) policy
        VerifyElement           (//button/span[text()\='Yes'])[1]
        ClickElement            (//button/span[text()\='Yes'])[1]
        VerifyElement           (//button/span[text()\='No'])[1]
        Select current Expiration date
        Select current Retroactive date
        Type text               MPL Expiring Limit          2000000
        ClickText               Additional pricing discounts are available, if you can confirm the following statements.
        VerifyText              Tell us about your Insured

        VerifyText              Additional pricing discounts are available, if you can confirm the following statements.
        VerifyText              Principals have an average of at least 10 years relevant industry experience
        VerifyElement           (//button/span[text()\='Yes'])[2]
        ClickElement            (//button/span[text()\='Yes'])[2]
        VerifyElement           (//button/span[text()\='No'])[2]
        VerifyText              No individual client or contract accounts for more than 25% of annual revenues
        VerifyElement           (//button/span[text()\='Yes'])[3]
        ClickElement            (//button/span[text()\='Yes'])[3]
        VerifyElement           (//button/span[text()\='No'])[3]
        VerifyText              The Insured uses sub-contractors on less than 25% of projects
        VerifyElement           (//button/span[text()\='Yes'])[4]
        ClickElement            (//button/span[text()\='Yes'])[4]
        VerifyElement           (//button/span[text()\='No'])[4]
        VerifyText              No client contract value is over $1,000,000
        VerifyElement           (//button/span[text()\='Yes'])[5]
        ClickElement            (//button/span[text()\='Yes'])[5]
        VerifyElement           (//button/span[text()\='No'])[5]
        VerifyText              Contracts are utilized on all client engagements
        VerifyElement           (//button/span[text()\='Yes'])[6]
        ClickElement            (//button/span[text()\='Yes'])[6]
        VerifyElement           (//button/span[text()\='No'])[6]
        VerifyText              All client contracts include a limitation of liability and/or indemnity clause that inures to the benefit of the Insured
        VerifyElement           (//button/span[text()\='Yes'])[7]
        ClickElement            (//button/span[text()\='Yes'])[7]
        VerifyElement           (//button/span[text()\='No'])[7]

        VerifyElement           //button[text()\=' Back ']
        VerifyElement           //button[text()\=' Next ']

    ELSE IF                     "${Industry_MPL_S}" == "Business Services - Audio/Video"

        VerifyText              The Insured currently purchases a Miscellaneous Professional Liability (MPL) policy
        VerifyElement           (//button/span[text()\='Yes'])[1]
        ClickElement            (//button/span[text()\='Yes'])[1]
        VerifyElement           (//button/span[text()\='No'])[1]
        Select current Expiration date
        Select current Retroactive date
        Type text               MPL Expiring Limit          2000000
        ClickText               Additional pricing discounts are available, if you can confirm the following statements.
        VerifyText              Tell us about your Insured

        VerifyText              Additional pricing discounts are available, if you can confirm the following statements.
        VerifyText              Principals have an average of at least 10 years relevant industry experience
        VerifyElement           (//button/span[text()\='Yes'])[2]
        ClickElement            (//button/span[text()\='Yes'])[2]
        VerifyElement           (//button/span[text()\='No'])[2]
        VerifyText              No individual client or contract accounts for more than 25% of annual revenues
        VerifyElement           (//button/span[text()\='Yes'])[3]
        ClickElement            (//button/span[text()\='Yes'])[3]
        VerifyElement           (//button/span[text()\='No'])[3]
        VerifyText              The Insured uses sub-contractors on less than 25% of projects
        VerifyElement           (//button/span[text()\='Yes'])[4]
        ClickElement            (//button/span[text()\='Yes'])[4]
        VerifyElement           (//button/span[text()\='No'])[4]
        VerifyText              No client contract value is over $1,000,000
        VerifyElement           (//button/span[text()\='Yes'])[5]
        ClickElement            (//button/span[text()\='Yes'])[5]
        VerifyElement           (//button/span[text()\='No'])[5]
        VerifyText              Contracts are utilized on all client engagements
        VerifyElement           (//button/span[text()\='Yes'])[6]
        ClickElement            (//button/span[text()\='Yes'])[6]
        VerifyElement           (//button/span[text()\='No'])[6]
        VerifyText              All client contracts include a limitation of liability and/or indemnity clause that inures to the benefit of the Insured
        VerifyElement           (//button/span[text()\='Yes'])[7]
        ClickElement            (//button/span[text()\='Yes'])[7]
        VerifyElement           (//button/span[text()\='No'])[7]
        VerifyElement           //button[text()\=' Back ']
        VerifyElement           //button[text()\=' Next ']

    ELSE IF                     "${Industry_MPL_S}" == "Business Services - Bookkeeper & Record Keeper"

        VerifyText              Tell us about your Insured
        VerifyText              The Insured currently purchases a Miscellaneous Professional Liability (MPL) policy
        VerifyElement           (//button/span[text()\='Yes'])[1]
        ClickElement            (//button/span[text()\='Yes'])[1]
        VerifyElement           (//button/span[text()\='No'])[1]
        VerifyText              The Insured does not provide any services to publicly known individuals or any government entity.
        VerifyElement           (//button/span[text()\='Yes'])[2]
        ClickElement            (//button/span[text()\='Yes'])[1]
        VerifyElement           (//button/span[text()\='No'])[2]
        Select current Expiration date
        Select current Retroactive date
        Type text               MPL Expiring Limit          2000000
        ClickText               Additional pricing discounts are available, if you can confirm the following statements.

        VerifyText              Additional pricing discounts are available, if you can confirm the following statements.
        VerifyText              Principals have an average of at least 10 years relevant industry experience
        VerifyElement           (//button/span[text()\='Yes'])[3]
        ClickElement            (//button/span[text()\='Yes'])[3]
        VerifyElement           (//button/span[text()\='No'])[3]
        VerifyText              No individual client or contract accounts for more than 25% of annual revenues
        VerifyElement           (//button/span[text()\='Yes'])[4]
        ClickElement            (//button/span[text()\='Yes'])[4]
        VerifyElement           (//button/span[text()\='No'])[4]
        VerifyText              The Insured uses sub-contractors on less than 25% of projects
        VerifyElement           (//button/span[text()\='Yes'])[5]
        ClickElement            (//button/span[text()\='Yes'])[5]
        VerifyElement           (//button/span[text()\='No'])[5]
        VerifyText              No client contract value is over $1,000,000
        VerifyElement           (//button/span[text()\='Yes'])[6]
        ClickElement            (//button/span[text()\='Yes'])[6]
        VerifyElement           (//button/span[text()\='No'])[6]
        VerifyText              Contracts are utilized on all client engagements
        VerifyElement           (//button/span[text()\='Yes'])[7]
        ClickElement            (//button/span[text()\='Yes'])[7]
        VerifyElement           (//button/span[text()\='No'])[7]
        VerifyText              All client contracts include a limitation of liability and/or indemnity clause that inures to the benefit of the Insured
        VerifyElement           (//button/span[text()\='Yes'])[8]
        ClickElement            (//button/span[text()\='Yes'])[8]
        VerifyElement           (//button/span[text()\='No'])[8]
        VerifyElement           //button[text()\=' Back ']
        VerifyElement           //button[text()\=' Next ']

    ELSE IF                     "${Industry_MPL_S}" == "Business Services - Business Training & Seminars"

        VerifyText              Tell us about your Insured
        VerifyText              The Insured currently purchases a Miscellaneous Professional Liability (MPL) policy
        VerifyElement           (//button/span[text()\='Yes'])[1]
        ClickElement            (//button/span[text()\='Yes'])[1]
        VerifyElement           (//button/span[text()\='No'])[1]
        Select current Expiration date
        Select current Retroactive date
        Type text               MPL Expiring Limit          2000000
        ClickText               Additional pricing discounts are available, if you can confirm the following statements.

        VerifyText              Additional pricing discounts are available, if you can confirm the following statements.
        VerifyText              Principals have an average of at least 10 years relevant industry experience
        VerifyElement           (//button/span[text()\='Yes'])[2]
        ClickElement            (//button/span[text()\='Yes'])[2]
        VerifyElement           (//button/span[text()\='No'])[2]
        VerifyText              No individual client or contract accounts for more than 25% of annual revenues
        VerifyElement           (//button/span[text()\='Yes'])[3]
        ClickElement            (//button/span[text()\='Yes'])[3]
        VerifyElement           (//button/span[text()\='No'])[3]
        VerifyText              The Insured uses sub-contractors on less than 25% of projects
        VerifyElement           (//button/span[text()\='Yes'])[4]
        ClickElement            (//button/span[text()\='Yes'])[4]
        VerifyElement           (//button/span[text()\='No'])[4]
        VerifyText              No client contract value is over $1,000,000
        VerifyElement           (//button/span[text()\='Yes'])[5]
        ClickElement            (//button/span[text()\='Yes'])[5]
        VerifyElement           (//button/span[text()\='No'])[5]
        VerifyText              Contracts are utilized on all client engagements
        VerifyElement           (//button/span[text()\='Yes'])[6]
        ClickElement            (//button/span[text()\='Yes'])[6]
        VerifyElement           (//button/span[text()\='No'])[6]
        VerifyText              All client contracts include a limitation of liability and/or indemnity clause that inures to the benefit of the Insured
        VerifyElement           (//button/span[text()\='Yes'])[7]
        ClickElement            (//button/span[text()\='Yes'])[7]
        VerifyElement           (//button/span[text()\='No'])[7]

        VerifyElement           //button[text()\=' Back ']
        VerifyElement           //button[text()\=' Next ']

    ELSE IF                     "${Industry_MPL_S}" == "Business Services - Court Reporting"

        VerifyText              Tell us about your Insured
        VerifyText              The Insured currently purchases a Miscellaneous Professional Liability (MPL) policy
        VerifyElement           (//button/span[text()\='Yes'])[1]
        ClickElement            (//button/span[text()\='Yes'])[1]
        VerifyElement           (//button/span[text()\='No'])[1]
        Select current Expiration date
        Select current Retroactive date
        Type text               MPL Expiring Limit          2000000
        ClickText               Additional pricing discounts are available, if you can confirm the following statements.

        VerifyText              Additional pricing discounts are available, if you can confirm the following statements.
        VerifyText              Principals have an average of at least 10 years relevant industry experience
        VerifyElement           (//button/span[text()\='Yes'])[2]
        ClickElement            (//button/span[text()\='Yes'])[2]
        VerifyElement           (//button/span[text()\='No'])[2]
        VerifyText              No individual client or contract accounts for more than 25% of annual revenues
        VerifyElement           (//button/span[text()\='Yes'])[3]
        ClickElement            (//button/span[text()\='Yes'])[3]
        VerifyElement           (//button/span[text()\='No'])[3]
        VerifyText              The Insured uses sub-contractors on less than 25% of projects
        VerifyElement           (//button/span[text()\='Yes'])[4]
        ClickElement            (//button/span[text()\='Yes'])[4]
        VerifyElement           (//button/span[text()\='No'])[4]
        VerifyText              No client contract value is over $1,000,000
        VerifyElement           (//button/span[text()\='Yes'])[5]
        ClickElement            (//button/span[text()\='Yes'])[5]
        VerifyElement           (//button/span[text()\='No'])[5]
        VerifyText              Contracts are utilized on all client engagements
        VerifyElement           (//button/span[text()\='Yes'])[6]
        ClickElement            (//button/span[text()\='Yes'])[6]
        VerifyElement           (//button/span[text()\='No'])[6]
        VerifyText              All client contracts include a limitation of liability and/or indemnity clause that inures to the benefit of the Insured
        VerifyElement           (//button/span[text()\='Yes'])[7]
        ClickElement            (//button/span[text()\='Yes'])[7]
        VerifyElement           (//button/span[text()\='No'])[7]

        VerifyElement           //button[text()\=' Back ']
        VerifyElement           //button[text()\=' Next ']

    ELSE IF                     "${Industry_MPL_S}" == "Business Services - Dispute Resolution"

        VerifyText              Tell us about your Insured
        VerifyText              The Insured currently purchases a Miscellaneous Professional Liability (MPL) policy
        VerifyElement           (//button/span[text()\='Yes'])[1]
        ClickElement            (//button/span[text()\='Yes'])[1]
        VerifyElement           (//button/span[text()\='No'])[1]
        Select current Expiration date
        Select current Retroactive date
        Type text               MPL Expiring Limit          2000000
        ClickText               Additional pricing discounts are available, if you can confirm the following statements.

        VerifyText              Additional pricing discounts are available, if you can confirm the following statements.
        VerifyText              Principals have an average of at least 10 years relevant industry experience
        VerifyElement           (//button/span[text()\='Yes'])[2]
        ClickElement            (//button/span[text()\='Yes'])[2]
        VerifyElement           (//button/span[text()\='No'])[2]
        VerifyText              No individual client or contract accounts for more than 25% of annual revenues
        VerifyElement           (//button/span[text()\='Yes'])[3]
        ClickElement            (//button/span[text()\='Yes'])[3]
        VerifyElement           (//button/span[text()\='No'])[3]
        VerifyText              The Insured uses sub-contractors on less than 25% of projects
        VerifyElement           (//button/span[text()\='Yes'])[4]
        ClickElement            (//button/span[text()\='Yes'])[4]
        VerifyElement           (//button/span[text()\='No'])[4]
        VerifyText              No client contract value is over $1,000,000
        VerifyElement           (//button/span[text()\='Yes'])[5]
        ClickElement            (//button/span[text()\='Yes'])[5]
        VerifyElement           (//button/span[text()\='No'])[5]
        VerifyText              Contracts are utilized on all client engagements
        VerifyElement           (//button/span[text()\='Yes'])[6]
        ClickElement            (//button/span[text()\='Yes'])[6]
        VerifyElement           (//button/span[text()\='No'])[6]
        VerifyText              All client contracts include a limitation of liability and/or indemnity clause that inures to the benefit of the Insured
        VerifyElement           (//button/span[text()\='Yes'])[7]
        ClickElement            (//button/span[text()\='Yes'])[7]
        VerifyElement           (//button/span[text()\='No'])[7]

        VerifyElement           //button[text()\=' Back ']
        VerifyElement           //button[text()\=' Next ']

    ELSE IF                     "${Industry_MPL_S}" == "Business Services - Employment Agencies"

        VerifyText              Tell us about your Insured
        VerifyText              The Insured currently purchases a Miscellaneous Professional Liability (MPL) policy
        VerifyElement           (//button/span[text()\='Yes'])[1]
        ClickElement            (//button/span[text()\='Yes'])[1]
        VerifyElement           (//button/span[text()\='No'])[1]
        Select current Expiration date
        Select current Retroactive date
        Type text               MPL Expiring Limit          2000000
        ClickText               Additional pricing discounts are available, if you can confirm the following statements.

        VerifyText              Additional pricing discounts are available, if you can confirm the following statements.
        VerifyText              Principals have an average of at least 10 years relevant industry experience
        VerifyElement           (//button/span[text()\='Yes'])[2]
        ClickElement            (//button/span[text()\='Yes'])[2]
        VerifyElement           (//button/span[text()\='No'])[2]
        VerifyText              No individual client or contract accounts for more than 25% of annual revenues
        VerifyElement           (//button/span[text()\='Yes'])[3]
        ClickElement            (//button/span[text()\='Yes'])[3]
        VerifyElement           (//button/span[text()\='No'])[3]
        VerifyText              The Insured uses sub-contractors on less than 25% of projects
        VerifyElement           (//button/span[text()\='Yes'])[4]
        ClickElement            (//button/span[text()\='Yes'])[4]
        VerifyElement           (//button/span[text()\='No'])[4]
        VerifyText              No client contract value is over $1,000,000
        VerifyElement           (//button/span[text()\='Yes'])[5]
        ClickElement            (//button/span[text()\='Yes'])[5]
        VerifyElement           (//button/span[text()\='No'])[5]
        VerifyText              Contracts are utilized on all client engagements
        VerifyElement           (//button/span[text()\='Yes'])[6]
        ClickElement            (//button/span[text()\='Yes'])[6]
        VerifyElement           (//button/span[text()\='No'])[6]
        VerifyText              All client contracts include a limitation of liability and/or indemnity clause that inures to the benefit of the Insured
        VerifyElement           (//button/span[text()\='Yes'])[7]
        ClickElement            (//button/span[text()\='Yes'])[7]
        VerifyElement           (//button/span[text()\='No'])[7]

        VerifyElement           //button[text()\=' Back ']
        VerifyElement           //button[text()\=' Next ']

    ELSE IF                     "${Industry_MPL_S}" == "Business Services - Event Planner"

        VerifyText              Tell us about your Insured
        VerifyText              The Insured currently purchases a Miscellaneous Professional Liability (MPL) policy
        VerifyElement           (//button/span[text()\='Yes'])[1]
        ClickElement            (//button/span[text()\='Yes'])[1]
        VerifyElement           (//button/span[text()\='No'])[1]
        Select current Expiration date
        Select current Retroactive date
        Type text               MPL Expiring Limit          2000000
        ClickText               Additional pricing discounts are available, if you can confirm the following statements.

        VerifyText              Additional pricing discounts are available, if you can confirm the following statements.
        VerifyText              Principals have an average of at least 10 years relevant industry experience
        VerifyElement           (//button/span[text()\='Yes'])[2]
        ClickElement            (//button/span[text()\='Yes'])[2]
        VerifyElement           (//button/span[text()\='No'])[2]
        VerifyText              No individual client or contract accounts for more than 25% of annual revenues
        VerifyElement           (//button/span[text()\='Yes'])[3]
        ClickElement            (//button/span[text()\='Yes'])[3]
        VerifyElement           (//button/span[text()\='No'])[3]
        VerifyText              The Insured uses sub-contractors on less than 25% of projects
        VerifyElement           (//button/span[text()\='Yes'])[4]
        ClickElement            (//button/span[text()\='Yes'])[4]
        VerifyElement           (//button/span[text()\='No'])[4]
        VerifyText              No client contract value is over $1,000,000
        VerifyElement           (//button/span[text()\='Yes'])[5]
        ClickElement            (//button/span[text()\='Yes'])[5]
        VerifyElement           (//button/span[text()\='No'])[5]
        VerifyText              Contracts are utilized on all client engagements
        VerifyElement           (//button/span[text()\='Yes'])[6]
        ClickElement            (//button/span[text()\='Yes'])[6]
        VerifyElement           (//button/span[text()\='No'])[6]
        VerifyText              All client contracts include a limitation of liability and/or indemnity clause that inures to the benefit of the Insured
        VerifyElement           (//button/span[text()\='Yes'])[7]
        ClickElement            (//button/span[text()\='Yes'])[7]
        VerifyElement           (//button/span[text()\='No'])[7]

        VerifyElement           //button[text()\=' Back ']
        VerifyElement           //button[text()\=' Next ']

    ELSE IF                     "${Industry_MPL_S}" == "Business Services - Executive Placement"

        VerifyText              Tell us about your Insured
        VerifyText              The Insured currently purchases a Miscellaneous Professional Liability (MPL) policy
        VerifyElement           (//button/span[text()\='Yes'])[1]
        ClickElement            (//button/span[text()\='Yes'])[1]
        VerifyElement           (//button/span[text()\='No'])[1]
        Select current Expiration date
        Select current Retroactive date
        Type text               MPL Expiring Limit          2000000
        ClickText               Additional pricing discounts are available, if you can confirm the following statements.

        VerifyText              Additional pricing discounts are available, if you can confirm the following statements.
        VerifyText              Principals have an average of at least 10 years relevant industry experience
        VerifyElement           (//button/span[text()\='Yes'])[2]
        ClickElement            (//button/span[text()\='Yes'])[2]
        VerifyElement           (//button/span[text()\='No'])[2]
        VerifyText              No individual client or contract accounts for more than 25% of annual revenues
        VerifyElement           (//button/span[text()\='Yes'])[3]
        ClickElement            (//button/span[text()\='Yes'])[3]
        VerifyElement           (//button/span[text()\='No'])[3]
        VerifyText              The Insured uses sub-contractors on less than 25% of projects
        VerifyElement           (//button/span[text()\='Yes'])[4]
        ClickElement            (//button/span[text()\='Yes'])[4]
        VerifyElement           (//button/span[text()\='No'])[4]
        VerifyText              No client contract value is over $1,000,000
        VerifyElement           (//button/span[text()\='Yes'])[5]
        ClickElement            (//button/span[text()\='Yes'])[5]
        VerifyElement           (//button/span[text()\='No'])[5]
        VerifyText              Contracts are utilized on all client engagements
        VerifyElement           (//button/span[text()\='Yes'])[6]
        ClickElement            (//button/span[text()\='Yes'])[6]
        VerifyElement           (//button/span[text()\='No'])[6]
        VerifyText              All client contracts include a limitation of liability and/or indemnity clause that inures to the benefit of the Insured
        VerifyElement           (//button/span[text()\='Yes'])[7]
        ClickElement            (//button/span[text()\='Yes'])[7]
        VerifyElement           (//button/span[text()\='No'])[7]

        VerifyElement           //button[text()\=' Back ']
        VerifyElement           //button[text()\=' Next ']

    ELSE IF                     "${Industry_MPL_S}" == "Business Services - Funeral & Crematories"

        VerifyText              Tell us about your Insured
        VerifyText              The Insured currently purchases a Miscellaneous Professional Liability (MPL) policy
        VerifyElement           (//button/span[text()\='Yes'])[1]
        ClickElement            (//button/span[text()\='Yes'])[1]
        VerifyElement           (//button/span[text()\='No'])[1]
        Select current Expiration date
        Select current Retroactive date
        Type text               MPL Expiring Limit          2000000
        ClickText               Additional pricing discounts are available, if you can confirm the following statements.

        VerifyText              Additional pricing discounts are available, if you can confirm the following statements.
        VerifyText              Principals have an average of at least 10 years relevant industry experience
        VerifyElement           (//button/span[text()\='Yes'])[2]
        ClickElement            (//button/span[text()\='Yes'])[2]
        VerifyElement           (//button/span[text()\='No'])[2]
        VerifyText              No individual client or contract accounts for more than 25% of annual revenues
        VerifyElement           (//button/span[text()\='Yes'])[3]
        ClickElement            (//button/span[text()\='Yes'])[3]
        VerifyElement           (//button/span[text()\='No'])[3]
        VerifyText              The Insured uses sub-contractors on less than 25% of projects
        VerifyElement           (//button/span[text()\='Yes'])[4]
        ClickElement            (//button/span[text()\='Yes'])[4]
        VerifyElement           (//button/span[text()\='No'])[4]
        VerifyText              No client contract value is over $1,000,000
        VerifyElement           (//button/span[text()\='Yes'])[5]
        ClickElement            (//button/span[text()\='Yes'])[5]
        VerifyElement           (//button/span[text()\='No'])[5]
        VerifyText              Contracts are utilized on all client engagements
        VerifyElement           (//button/span[text()\='Yes'])[6]
        ClickElement            (//button/span[text()\='Yes'])[6]
        VerifyElement           (//button/span[text()\='No'])[6]
        VerifyText              All client contracts include a limitation of liability and/or indemnity clause that inures to the benefit of the Insured
        VerifyElement           (//button/span[text()\='Yes'])[7]
        ClickElement            (//button/span[text()\='Yes'])[7]
        VerifyElement           (//button/span[text()\='No'])[7]

        VerifyElement           //button[text()\=' Back ']
        VerifyElement           //button[text()\=' Next ']

    ELSE IF                     "${Industry_MPL_S}" == "Business Services - Interior & Graphic Design"

        VerifyText              Tell us about your Insured
        VerifyText              The Insured currently purchases a Miscellaneous Professional Liability (MPL) policy
        VerifyElement           (//button/span[text()\='Yes'])[1]
        ClickElement            (//button/span[text()\='Yes'])[1]
        VerifyElement           (//button/span[text()\='No'])[1]
        Select current Expiration date
        Select current Retroactive date
        Type text               MPL Expiring Limit          2000000
        ClickText               Additional pricing discounts are available, if you can confirm the following statements.

        VerifyText              Additional pricing discounts are available, if you can confirm the following statements.
        VerifyText              Principals have an average of at least 10 years relevant industry experience
        VerifyElement           (//button/span[text()\='Yes'])[2]
        ClickElement            (//button/span[text()\='Yes'])[2]
        VerifyElement           (//button/span[text()\='No'])[2]
        VerifyText              No individual client or contract accounts for more than 25% of annual revenues
        VerifyElement           (//button/span[text()\='Yes'])[3]
        ClickElement            (//button/span[text()\='Yes'])[3]
        VerifyElement           (//button/span[text()\='No'])[3]
        VerifyText              The Insured uses sub-contractors on less than 25% of projects
        VerifyElement           (//button/span[text()\='Yes'])[4]
        ClickElement            (//button/span[text()\='Yes'])[4]
        VerifyElement           (//button/span[text()\='No'])[4]
        VerifyText              No client contract value is over $1,000,000
        VerifyElement           (//button/span[text()\='Yes'])[5]
        ClickElement            (//button/span[text()\='Yes'])[5]
        VerifyElement           (//button/span[text()\='No'])[5]
        VerifyText              Contracts are utilized on all client engagements
        VerifyElement           (//button/span[text()\='Yes'])[6]
        ClickElement            (//button/span[text()\='Yes'])[6]
        VerifyElement           (//button/span[text()\='No'])[6]
        VerifyText              All client contracts include a limitation of liability and/or indemnity clause that inures to the benefit of the Insured
        VerifyElement           (//button/span[text()\='Yes'])[7]
        ClickElement            (//button/span[text()\='Yes'])[7]
        VerifyElement           (//button/span[text()\='No'])[7]

        VerifyElement           //button[text()\=' Back ']
        VerifyElement           //button[text()\=' Next ']

    ELSE IF                     "${Industry_MPL_S}" == "Business Services - Literary Agents"

        VerifyText              Tell us about your Insured
        VerifyText              The Insured currently purchases a Miscellaneous Professional Liability (MPL) policy
        VerifyElement           (//button/span[text()\='Yes'])[1]
        ClickElement            (//button/span[text()\='Yes'])[1]
        VerifyElement           (//button/span[text()\='No'])[1]
        Select current Expiration date
        Select current Retroactive date
        Type text               MPL Expiring Limit          2000000
        ClickText               Additional pricing discounts are available, if you can confirm the following statements.

        VerifyText              Additional pricing discounts are available, if you can confirm the following statements.
        VerifyText              Principals have an average of at least 10 years relevant industry experience
        VerifyElement           (//button/span[text()\='Yes'])[2]
        ClickElement            (//button/span[text()\='Yes'])[2]
        VerifyElement           (//button/span[text()\='No'])[2]
        VerifyText              No individual client or contract accounts for more than 25% of annual revenues
        VerifyElement           (//button/span[text()\='Yes'])[3]
        ClickElement            (//button/span[text()\='Yes'])[3]
        VerifyElement           (//button/span[text()\='No'])[3]
        VerifyText              The Insured uses sub-contractors on less than 25% of projects
        VerifyElement           (//button/span[text()\='Yes'])[4]
        ClickElement            (//button/span[text()\='Yes'])[4]
        VerifyElement           (//button/span[text()\='No'])[4]
        VerifyText              No client contract value is over $1,000,000
        VerifyElement           (//button/span[text()\='Yes'])[5]
        ClickElement            (//button/span[text()\='Yes'])[5]
        VerifyElement           (//button/span[text()\='No'])[5]
        VerifyText              Contracts are utilized on all client engagements
        VerifyElement           (//button/span[text()\='Yes'])[6]
        ClickElement            (//button/span[text()\='Yes'])[6]
        VerifyElement           (//button/span[text()\='No'])[6]
        VerifyText              All client contracts include a limitation of liability and/or indemnity clause that inures to the benefit of the Insured
        VerifyElement           (//button/span[text()\='Yes'])[7]
        ClickElement            (//button/span[text()\='Yes'])[7]
        VerifyElement           (//button/span[text()\='No'])[7]

        VerifyElement           //button[text()\=' Back ']
        VerifyElement           //button[text()\=' Next ']

    ELSE IF                     "${Industry_MPL_S}" == "Business Services - Management & Business Consulting"

        VerifyText              Tell us about your Insured
        VerifyText              The Insured currently purchases a Miscellaneous Professional Liability (MPL) policy
        VerifyElement           (//button/span[text()\='Yes'])[1]
        ClickElement            (//button/span[text()\='Yes'])[1]
        VerifyElement           (//button/span[text()\='No'])[1]
        Select current Expiration date
        Select current Retroactive date
        Type text               MPL Expiring Limit          2000000
        ClickText               Additional pricing discounts are available, if you can confirm the following statements.

        VerifyText              Additional pricing discounts are available, if you can confirm the following statements.
        VerifyText              Principals have an average of at least 10 years relevant industry experience
        VerifyElement           (//button/span[text()\='Yes'])[2]
        ClickElement            (//button/span[text()\='Yes'])[2]
        VerifyElement           (//button/span[text()\='No'])[2]
        VerifyText              No individual client or contract accounts for more than 25% of annual revenues
        VerifyElement           (//button/span[text()\='Yes'])[3]
        ClickElement            (//button/span[text()\='Yes'])[3]
        VerifyElement           (//button/span[text()\='No'])[3]
        VerifyText              The Insured uses sub-contractors on less than 25% of projects
        VerifyElement           (//button/span[text()\='Yes'])[4]
        ClickElement            (//button/span[text()\='Yes'])[4]
        VerifyElement           (//button/span[text()\='No'])[4]
        VerifyText              No client contract value is over $1,000,000
        VerifyElement           (//button/span[text()\='Yes'])[5]
        ClickElement            (//button/span[text()\='Yes'])[5]
        VerifyElement           (//button/span[text()\='No'])[5]
        VerifyText              Contracts are utilized on all client engagements
        VerifyElement           (//button/span[text()\='Yes'])[6]
        ClickElement            (//button/span[text()\='Yes'])[6]
        VerifyElement           (//button/span[text()\='No'])[6]
        VerifyText              All client contracts include a limitation of liability and/or indemnity clause that inures to the benefit of the Insured
        VerifyElement           (//button/span[text()\='Yes'])[7]
        ClickElement            (//button/span[text()\='Yes'])[7]
        VerifyElement           (//button/span[text()\='No'])[7]

        VerifyElement           //button[text()\=' Back ']
        VerifyElement           //button[text()\=' Next ']

    ELSE IF                     "${Industry_MPL_S}" == "Business Services - Membership Organizations"

        VerifyText              Tell us about your Insured
        VerifyText              The Insured currently purchases a Miscellaneous Professional Liability (MPL) policy
        VerifyElement           (//button/span[text()\='Yes'])[1]
        ClickElement            (//button/span[text()\='Yes'])[1]
        VerifyElement           (//button/span[text()\='No'])[1]
        VerifyText              The Insured provides a referral service, legal aid service or technology to its members or the public.
        VerifyElement           (//button/span[text()\='Yes'])[2]
        ClickElement            (//button/span[text()\='Yes'])[2]
        VerifyElement           (//button/span[text()\='No'])[2]
        VerifyText              The Insured promotes, sponsors or provide any form of insurance to members or non-members.
        VerifyElement           (//button/span[text()\='Yes'])[3]
        ClickElement            (//button/span[text()\='Yes'])[3]
        VerifyElement           (//button/span[text()\='No'])[3]
        VerifyText              The Insured develops standards used to evaluate the quality of goods, products manufactured or services rendered.
        VerifyElement           (//button/span[text()\='Yes'])[4]
        ClickElement            (//button/span[text()\='Yes'])[4]
        VerifyElement           (//button/span[text()\='No'])[4]
        Select current Expiration date
        Select current Retroactive date
        Type text               MPL Expiring Limit          2000000
        ClickText               Additional pricing discounts are available, if you can confirm the following statements.

        VerifyText              Additional pricing discounts are available, if you can confirm the following statements.
        VerifyText              Principals have an average of at least 10 years relevant industry experience
        VerifyElement           (//button/span[text()\='Yes'])[5]
        ClickElement            (//button/span[text()\='Yes'])[5]
        VerifyElement           (//button/span[text()\='No'])[5]
        VerifyText              No individual client or contract accounts for more than 25% of annual revenues
        VerifyElement           (//button/span[text()\='Yes'])[6]
        ClickElement            (//button/span[text()\='Yes'])[6]
        VerifyElement           (//button/span[text()\='No'])[6]
        VerifyText              The Insured uses sub-contractors on less than 25% of projects
        VerifyElement           (//button/span[text()\='Yes'])[7]
        ClickElement            (//button/span[text()\='Yes'])[7]
        VerifyElement           (//button/span[text()\='No'])[7]
        VerifyText              No client contract value is over $1,000,000
        VerifyElement           (//button/span[text()\='Yes'])[8]
        ClickElement            (//button/span[text()\='Yes'])[8]
        VerifyElement           (//button/span[text()\='No'])[8]
        VerifyText              Contracts are utilized on all client engagements
        VerifyElement           (//button/span[text()\='Yes'])[9]
        ClickElement            (//button/span[text()\='Yes'])[9]
        VerifyElement           (//button/span[text()\='No'])[9]
        VerifyText              All client contracts include a limitation of liability and/or indemnity clause that inures to the benefit of the Insured
        VerifyElement           (//button/span[text()\='Yes'])[10]
        ClickElement            (//button/span[text()\='Yes'])[10]
        VerifyElement           (//button/span[text()\='No'])[10]

        VerifyElement           //button[text()\=' Back ']
        VerifyElement           //button[text()\=' Next ']

    ELSE IF                     "${Industry_MPL_S}" == "Business Services - Modeling/Talent Agency"

        VerifyText              Tell us about your Insured
        VerifyText              The Insured currently purchases a Miscellaneous Professional Liability (MPL) policy
        VerifyElement           (//button/span[text()\='Yes'])[1]
        ClickElement            (//button/span[text()\='Yes'])[1]
        VerifyElement           (//button/span[text()\='No'])[1]
        VerifyText              The Insured provides agency services to publicly known individuals/families.
        VerifyElement           (//button/span[text()\='Yes'])[2]
        ClickElement            (//button/span[text()\='Yes'])[2]
        VerifyElement           (//button/span[text()\='No'])[2]
        Select current Expiration date
        Select current Retroactive date
        Type text               MPL Expiring Limit          2000000
        ClickText               Additional pricing discounts are available, if you can confirm the following statements.

        VerifyText              Additional pricing discounts are available, if you can confirm the following statements.
        VerifyText              Principals have an average of at least 10 years relevant industry experience
        VerifyElement           (//button/span[text()\='Yes'])[3]
        ClickElement            (//button/span[text()\='Yes'])[3]
        VerifyElement           (//button/span[text()\='No'])[3]
        VerifyText              No individual client or contract accounts for more than 25% of annual revenues
        VerifyElement           (//button/span[text()\='Yes'])[4]
        ClickElement            (//button/span[text()\='Yes'])[4]
        VerifyElement           (//button/span[text()\='No'])[4]
        VerifyText              The Insured uses sub-contractors on less than 25% of projects
        VerifyElement           (//button/span[text()\='Yes'])[5]
        ClickElement            (//button/span[text()\='Yes'])[5]
        VerifyElement           (//button/span[text()\='No'])[5]
        VerifyText              No client contract value is over $1,000,000
        VerifyElement           (//button/span[text()\='Yes'])[6]
        ClickElement            (//button/span[text()\='Yes'])[6]
        VerifyElement           (//button/span[text()\='No'])[6]
        VerifyText              Contracts are utilized on all client engagements
        VerifyElement           (//button/span[text()\='Yes'])[7]
        ClickElement            (//button/span[text()\='Yes'])[7]
        VerifyElement           (//button/span[text()\='No'])[7]
        VerifyText              All client contracts include a limitation of liability and/or indemnity clause that inures to the benefit of the Insured
        VerifyElement           (//button/span[text()\='Yes'])[8]
        ClickElement            (//button/span[text()\='Yes'])[8]
        VerifyElement           (//button/span[text()\='No'])[8]

        VerifyElement           //button[text()\=' Back ']
        VerifyElement           //button[text()\=' Next ']

    ELSE IF                     "${Industry_MPL_S}" == "Business Services - Notary Public"

        VerifyText              Tell us about your Insured
        VerifyText              The Insured currently purchases a Miscellaneous Professional Liability (MPL) policy
        VerifyElement           (//button/span[text()\='Yes'])[1]
        ClickElement            (//button/span[text()\='Yes'])[1]
        VerifyElement           (//button/span[text()\='No'])[1]
        Select current Expiration date
        Select current Retroactive date
        Type text               MPL Expiring Limit          2000000
        ClickText               Additional pricing discounts are available, if you can confirm the following statements.

        VerifyText              Additional pricing discounts are available, if you can confirm the following statements.
        VerifyText              Principals have an average of at least 10 years relevant industry experience
        VerifyElement           (//button/span[text()\='Yes'])[2]
        ClickElement            (//button/span[text()\='Yes'])[2]
        VerifyElement           (//button/span[text()\='No'])[2]
        VerifyText              No individual client or contract accounts for more than 25% of annual revenues
        VerifyElement           (//button/span[text()\='Yes'])[3]
        ClickElement            (//button/span[text()\='Yes'])[3]
        VerifyElement           (//button/span[text()\='No'])[3]
        VerifyText              The Insured uses sub-contractors on less than 25% of projects
        VerifyElement           (//button/span[text()\='Yes'])[4]
        ClickElement            (//button/span[text()\='Yes'])[4]
        VerifyElement           (//button/span[text()\='No'])[4]
        VerifyText              No client contract value is over $1,000,000
        VerifyElement           (//button/span[text()\='Yes'])[5]
        ClickElement            (//button/span[text()\='Yes'])[6]
        VerifyElement           (//button/span[text()\='No'])[5]
        VerifyText              Contracts are utilized on all client engagements
        VerifyElement           (//button/span[text()\='Yes'])[6]
        ClickElement            (//button/span[text()\='Yes'])[6]
        VerifyElement           (//button/span[text()\='No'])[6]
        VerifyText              All client contracts include a limitation of liability and/or indemnity clause that inures to the benefit of the Insured
        VerifyElement           (//button/span[text()\='Yes'])[7]
        ClickElement            (//button/span[text()\='Yes'])[7]
        VerifyElement           (//button/span[text()\='No'])[7]

        VerifyElement           //button[text()\=' Back ']
        VerifyElement           //button[text()\=' Next ']

    ELSE IF                     "${Industry_MPL_S}" == "Business Services - Office Management"

        VerifyText              Tell us about your Insured
        VerifyText              The Insured currently purchases a Miscellaneous Professional Liability (MPL) policy
        VerifyText              The Insured handles and provides funds transfer services on behalf of its clients.
        VerifyElement           (//button/span[text()\='Yes'])[1]
        ClickElement            (//button/span[text()\='Yes'])[1]
        VerifyElement           (//button/span[text()\='No'])[1]
        Select current Expiration date
        Select current Retroactive date
        Type text               MPL Expiring Limit          2000000
        ClickText               Additional pricing discounts are available, if you can confirm the following statements.

        VerifyText              Additional pricing discounts are available, if you can confirm the following statements.
        VerifyText              Principals have an average of at least 10 years relevant industry experience
        VerifyElement           (//button/span[text()\='Yes'])[2]
        ClickElement            (//button/span[text()\='Yes'])[2]
        VerifyElement           (//button/span[text()\='No'])[2]
        VerifyText              No individual client or contract accounts for more than 25% of annual revenues
        VerifyElement           (//button/span[text()\='Yes'])[3]
        ClickElement            (//button/span[text()\='Yes'])[3]
        VerifyElement           (//button/span[text()\='No'])[3]
        VerifyText              The Insured uses sub-contractors on less than 25% of projects
        VerifyElement           (//button/span[text()\='Yes'])[4]
        ClickElement            (//button/span[text()\='Yes'])[4]
        VerifyElement           (//button/span[text()\='No'])[4]
        VerifyText              No client contract value is over $1,000,000
        VerifyElement           (//button/span[text()\='Yes'])[5]
        ClickElement            (//button/span[text()\='Yes'])[5]
        VerifyElement           (//button/span[text()\='No'])[5]
        VerifyText              Contracts are utilized on all client engagements
        VerifyElement           (//button/span[text()\='Yes'])[6]
        ClickElement            (//button/span[text()\='Yes'])[6]
        VerifyElement           (//button/span[text()\='No'])[6]
        VerifyText              All client contracts include a limitation of liability and/or indemnity clause that inures to the benefit of the Insured
        VerifyElement           (//button/span[text()\='Yes'])[7]
        ClickElement            (//button/span[text()\='Yes'])[7]
        VerifyElement           (//button/span[text()\='No'])[7]

        VerifyElement           //button[text()\=' Back ']
        VerifyElement           //button[text()\=' Next ']

    ELSE IF                     "${Industry_MPL_S}" == "Business Services - Pet Related Services"

        VerifyText              Tell us about your Insured
        VerifyText              The Insured currently purchases a Miscellaneous Professional Liability (MPL) policy
        VerifyElement           (//button/span[text()\='Yes'])[1]
        ClickElement            (//button/span[text()\='Yes'])[1]
        VerifyElement           (//button/span[text()\='No'])[1]
        Select current Expiration date
        Select current Retroactive date
        Type text               MPL Expiring Limit          2000000
        ClickText               Additional pricing discounts are available, if you can confirm the following statements.

        VerifyText              Additional pricing discounts are available, if you can confirm the following statements.
        VerifyText              Principals have an average of at least 10 years relevant industry experience
        VerifyElement           (//button/span[text()\='Yes'])[2]
        ClickElement            (//button/span[text()\='Yes'])[2]
        VerifyElement           (//button/span[text()\='No'])[2]
        VerifyText              No individual client or contract accounts for more than 25% of annual revenues
        VerifyElement           (//button/span[text()\='Yes'])[3]
        ClickElement            (//button/span[text()\='Yes'])[1]
        VerifyElement           (//button/span[text()\='No'])[3]
        VerifyText              The Insured uses sub-contractors on less than 25% of projects
        VerifyElement           (//button/span[text()\='Yes'])[4]
        ClickElement            (//button/span[text()\='Yes'])[4]
        VerifyElement           (//button/span[text()\='No'])[4]
        VerifyText              No client contract value is over $1,000,000
        VerifyElement           (//button/span[text()\='Yes'])[5]
        ClickElement            (//button/span[text()\='Yes'])[5]
        VerifyElement           (//button/span[text()\='No'])[5]
        VerifyText              Contracts are utilized on all client engagements
        VerifyElement           (//button/span[text()\='Yes'])[6]
        ClickElement            (//button/span[text()\='Yes'])[6]
        VerifyElement           (//button/span[text()\='No'])[6]
        VerifyText              All client contracts include a limitation of liability and/or indemnity clause that inures to the benefit of the Insured
        VerifyElement           (//button/span[text()\='Yes'])[7]
        ClickElement            (//button/span[text()\='Yes'])[7]
        VerifyElement           (//button/span[text()\='No'])[7]

        VerifyElement           //button[text()\=' Back ']
        VerifyElement           //button[text()\=' Next ']

    ELSE IF                     "${Industry_MPL_S}" == "Business Services - Photographic Studios"

        VerifyText              Tell us about your Insured
        VerifyText              The Insured currently purchases a Miscellaneous Professional Liability (MPL) policy
        VerifyElement           (//button/span[text()\='Yes'])[1]
        ClickElement            (//button/span[text()\='Yes'])[1]
        VerifyElement           (//button/span[text()\='No'])[1]
        Select current Expiration date
        Select current Retroactive date
        Type text               MPL Expiring Limit          2000000
        ClickText               Additional pricing discounts are available, if you can confirm the following statements.

        VerifyText              Additional pricing discounts are available, if you can confirm the following statements.
        VerifyText              Principals have an average of at least 10 years relevant industry experience
        VerifyElement           (//button/span[text()\='Yes'])[2]
        ClickElement            (//button/span[text()\='Yes'])[2]
        VerifyElement           (//button/span[text()\='No'])[2]
        VerifyText              No individual client or contract accounts for more than 25% of annual revenues
        VerifyElement           (//button/span[text()\='Yes'])[3]
        ClickElement            (//button/span[text()\='Yes'])[3]
        VerifyElement           (//button/span[text()\='No'])[3]
        VerifyText              The Insured uses sub-contractors on less than 25% of projects
        VerifyElement           (//button/span[text()\='Yes'])[4]
        ClickElement            (//button/span[text()\='Yes'])[4]
        VerifyElement           (//button/span[text()\='No'])[4]
        VerifyText              No client contract value is over $1,000,000
        VerifyElement           (//button/span[text()\='Yes'])[5]
        ClickElement            (//button/span[text()\='Yes'])[5]
        VerifyElement           (//button/span[text()\='No'])[5]
        VerifyText              Contracts are utilized on all client engagements
        VerifyElement           (//button/span[text()\='Yes'])[6]
        ClickElement            (//button/span[text()\='Yes'])[6]
        VerifyElement           (//button/span[text()\='No'])[6]
        VerifyText              All client contracts include a limitation of liability and/or indemnity clause that inures to the benefit of the Insured
        VerifyElement           (//button/span[text()\='Yes'])[7]
        ClickElement            (//button/span[text()\='Yes'])[7]
        VerifyElement           (//button/span[text()\='No'])[7]

        VerifyElement           //button[text()\=' Back ']
        VerifyElement           //button[text()\=' Next ']

    ELSE IF                     "${Industry_MPL_S}" == "Business Services - Printers"

        VerifyText              Tell us about your Insured
        VerifyText              The Insured currently purchases a Miscellaneous Professional Liability (MPL) policy
        VerifyElement           (//button/span[text()\='Yes'])[1]
        ClickElement            (//button/span[text()\='Yes'])[1]
        VerifyElement           (//button/span[text()\='No'])[1]
        Select current Expiration date
        Select current Retroactive date
        Type text               MPL Expiring Limit          2000000
        ClickText               Additional pricing discounts are available, if you can confirm the following statements.

        VerifyText              Additional pricing discounts are available, if you can confirm the following statements.
        VerifyText              Principals have an average of at least 10 years relevant industry experience
        VerifyElement           (//button/span[text()\='Yes'])[2]
        ClickElement            (//button/span[text()\='Yes'])[2]
        VerifyElement           (//button/span[text()\='No'])[2]
        VerifyText              No individual client or contract accounts for more than 25% of annual revenues
        VerifyElement           (//button/span[text()\='Yes'])[3]
        ClickElement            (//button/span[text()\='Yes'])[3]
        VerifyElement           (//button/span[text()\='No'])[3]
        VerifyText              The Insured uses sub-contractors on less than 25% of projects
        VerifyElement           (//button/span[text()\='Yes'])[4]
        ClickElement            (//button/span[text()\='Yes'])[4]
        VerifyElement           (//button/span[text()\='No'])[4]
        VerifyText              No client contract value is over $1,000,000
        VerifyElement           (//button/span[text()\='Yes'])[5]
        ClickElement            (//button/span[text()\='Yes'])[5]
        VerifyElement           (//button/span[text()\='No'])[5]
        VerifyText              Contracts are utilized on all client engagements
        VerifyElement           (//button/span[text()\='Yes'])[6]
        ClickElement            (//button/span[text()\='Yes'])[6]
        VerifyElement           (//button/span[text()\='No'])[6]
        VerifyText              All client contracts include a limitation of liability and/or indemnity clause that inures to the benefit of the Insured
        VerifyElement           (//button/span[text()\='Yes'])[7]
        ClickElement            (//button/span[text()\='Yes'])[7]
        VerifyElement           (//button/span[text()\='No'])[7]

        VerifyElement           //button[text()\=' Back ']
        VerifyElement           //button[text()\=' Next ']

    ELSE IF                     "${Industry_MPL_S}" == "Business Services - Process Server"

        VerifyText              Tell us about your Insured
        VerifyText              The Insured currently purchases a Miscellaneous Professional Liability (MPL) policy
        VerifyElement           (//button/span[text()\='Yes'])[1]
        ClickElement            (//button/span[text()\='Yes'])[1]
        VerifyElement           (//button/span[text()\='No'])[1]
        Select current Expiration date
        Select current Retroactive date
        Type text               MPL Expiring Limit          2000000
        ClickText               Additional pricing discounts are available, if you can confirm the following statements.

        VerifyText              Additional pricing discounts are available, if you can confirm the following statements.
        VerifyText              Principals have an average of at least 10 years relevant industry experience
        VerifyElement           (//button/span[text()\='Yes'])[2]
        ClickElement            (//button/span[text()\='Yes'])[2]
        VerifyElement           (//button/span[text()\='No'])[2]
        VerifyText              No individual client or contract accounts for more than 25% of annual revenues
        VerifyElement           (//button/span[text()\='Yes'])[3]
        ClickElement            (//button/span[text()\='Yes'])[3]
        VerifyElement           (//button/span[text()\='No'])[3]
        VerifyText              The Insured uses sub-contractors on less than 25% of projects
        VerifyElement           (//button/span[text()\='Yes'])[4]
        ClickElement            (//button/span[text()\='Yes'])[4]
        VerifyElement           (//button/span[text()\='No'])[4]
        VerifyText              No client contract value is over $1,000,000
        VerifyElement           (//button/span[text()\='Yes'])[5]
        ClickElement            (//button/span[text()\='Yes'])[5]
        VerifyElement           (//button/span[text()\='No'])[5]
        VerifyText              Contracts are utilized on all client engagements
        VerifyElement           (//button/span[text()\='Yes'])[6]
        ClickElement            (//button/span[text()\='Yes'])[6]
        VerifyElement           (//button/span[text()\='No'])[6]
        VerifyText              All client contracts include a limitation of liability and/or indemnity clause that inures to the benefit of the Insured
        VerifyElement           (//button/span[text()\='Yes'])[7]
        ClickElement            (//button/span[text()\='Yes'])[7]
        VerifyElement           (//button/span[text()\='No'])[7]

        VerifyElement           //button[text()\=' Back ']
        VerifyElement           //button[text()\=' Next ']

    ELSE IF                     "${Industry_MPL_S}" == "Business Services - Tax Preparation (NON-CPA SERVICES)"

        VerifyText              Tell us about your Insured
        VerifyText              The Insured currently purchases a Miscellaneous Professional Liability (MPL) policy
        VerifyElement           (//button/span[text()\='Yes'])[1]
        ClickElement            (//button/span[text()\='Yes'])[1]
        VerifyElement           (//button/span[text()\='No'])[1]
        VerifyText              The Insured does not provide any services to publicly known individuals or any government entities.
        VerifyElement           (//button/span[text()\='Yes'])[2]
        ClickElement            (//button/span[text()\='Yes'])[2]
        VerifyElement           (//button/span[text()\='No'])[2]
        Select current Expiration date
        Select current Retroactive date
        Type text               MPL Expiring Limit          2000000
        ClickText               Additional pricing discounts are available, if you can confirm the following statements.

        VerifyText              Additional pricing discounts are available, if you can confirm the following statements.
        VerifyText              Principals have an average of at least 10 years relevant industry experience
        VerifyElement           (//button/span[text()\='Yes'])[3]
        ClickElement            (//button/span[text()\='Yes'])[3]
        VerifyElement           (//button/span[text()\='No'])[3]
        VerifyText              No individual client or contract accounts for more than 25% of annual revenues
        VerifyElement           (//button/span[text()\='Yes'])[4]
        ClickElement            (//button/span[text()\='Yes'])[4]
        VerifyElement           (//button/span[text()\='No'])[4]
        VerifyText              The Insured uses sub-contractors on less than 25% of projects
        VerifyElement           (//button/span[text()\='Yes'])[5]
        ClickElement            (//button/span[text()\='Yes'])[5]
        VerifyElement           (//button/span[text()\='No'])[5]
        VerifyText              No client contract value is over $1,000,000
        VerifyElement           (//button/span[text()\='Yes'])[6]
        ClickElement            (//button/span[text()\='Yes'])[6]
        VerifyElement           (//button/span[text()\='No'])[6]
        VerifyText              Contracts are utilized on all client engagements
        VerifyElement           (//button/span[text()\='Yes'])[7]
        ClickElement            (//button/span[text()\='Yes'])[7]
        VerifyElement           (//button/span[text()\='No'])[7]
        VerifyText              All client contracts include a limitation of liability and/or indemnity clause that inures to the benefit of the Insured
        VerifyElement           (//button/span[text()\='Yes'])[8]
        ClickElement            (//button/span[text()\='Yes'])[8]
        VerifyElement           (//button/span[text()\='No'])[8]

        VerifyElement           //button[text()\=' Back ']
        VerifyElement           //button[text()\=' Next ']

    ELSE IF                     "${Industry_MPL_S}" == "Business Services - Translation & Interpretation Services"

        VerifyText              Tell us about your Insured
        VerifyText              The Insured currently purchases a Miscellaneous Professional Liability (MPL) policy
        VerifyElement           (//button/span[text()\='Yes'])[1]
        ClickElement            (//button/span[text()\='Yes'])[1]
        VerifyElement           (//button/span[text()\='No'])[1]
        Select current Expiration date
        Select current Retroactive date
        Type text               MPL Expiring Limit          2000000
        ClickText               Additional pricing discounts are available, if you can confirm the following statements.

        VerifyText              Additional pricing discounts are available, if you can confirm the following statements.
        VerifyText              Principals have an average of at least 10 years relevant industry experience
        VerifyElement           (//button/span[text()\='Yes'])[2]
        ClickElement            (//button/span[text()\='Yes'])[2]
        VerifyElement           (//button/span[text()\='No'])[2]
        VerifyText              No individual client or contract accounts for more than 25% of annual revenues
        VerifyElement           (//button/span[text()\='Yes'])[3]
        ClickElement            (//button/span[text()\='Yes'])[3]
        VerifyElement           (//button/span[text()\='No'])[3]
        VerifyText              The Insured uses sub-contractors on less than 25% of projects
        VerifyElement           (//button/span[text()\='Yes'])[4]
        ClickElement            (//button/span[text()\='Yes'])[4]
        VerifyElement           (//button/span[text()\='No'])[4]
        VerifyText              No client contract value is over $1,000,000
        VerifyElement           (//button/span[text()\='Yes'])[5]
        ClickElement            (//button/span[text()\='Yes'])[5]
        VerifyElement           (//button/span[text()\='No'])[5]
        VerifyText              Contracts are utilized on all client engagements
        VerifyElement           (//button/span[text()\='Yes'])[6]
        ClickElement            (//button/span[text()\='Yes'])[6]
        VerifyElement           (//button/span[text()\='No'])[6]
        VerifyText              All client contracts include a limitation of liability and/or indemnity clause that inures to the benefit of the Insured
        VerifyElement           (//button/span[text()\='Yes'])[7]
        ClickElement            (//button/span[text()\='Yes'])[7]
        VerifyElement           (//button/span[text()\='No'])[7]

        VerifyElement           //button[text()\=' Back ']
        VerifyElement           //button[text()\=' Next ']

    ELSE IF                     "${Industry_MPL_S}" == "Education - Exam Preparation and Tutoring"

        VerifyText              Tell us about your Insured
        VerifyText              The Insured currently purchases a Miscellaneous Professional Liability (MPL) policy
        VerifyElement           (//button/span[text()\='Yes'])[1]
        ClickElement            (//button/span[text()\='Yes'])[1]
        VerifyElement           (//button/span[text()\='No'])[1]
        VerifyText              TThe Insured clearly states the ownership rights, licensing, and use of any materials or intellectual property created for or during an engagement.
        VerifyElement           (//button/span[text()\='Yes'])[2]
        ClickElement            (//button/span[text()\='Yes'])[2]
        VerifyElement           (//button/span[text()\='No'])[2]
        Select current Expiration date
        Select current Retroactive date
        Type text               MPL Expiring Limit          2000000
        ClickText               Additional pricing discounts are available, if you can confirm the following statements.

        VerifyText              Additional pricing discounts are available, if you can confirm the following statements.
        VerifyText              Principals have an average of at least 10 years relevant industry experience
        VerifyElement           (//button/span[text()\='Yes'])[3]
        ClickElement            (//button/span[text()\='Yes'])[3]
        VerifyElement           (//button/span[text()\='No'])[3]
        VerifyText              No individual client or contract accounts for more than 25% of annual revenues
        VerifyElement           (//button/span[text()\='Yes'])[4]
        ClickElement            (//button/span[text()\='Yes'])[4]
        VerifyElement           (//button/span[text()\='No'])[4]
        VerifyText              The Insured uses sub-contractors on less than 25% of projects
        VerifyElement           (//button/span[text()\='Yes'])[5]
        ClickElement            (//button/span[text()\='Yes'])[5]
        VerifyElement           (//button/span[text()\='No'])[5]
        VerifyText              No client contract value is over $1,000,000
        VerifyElement           (//button/span[text()\='Yes'])[6]
        ClickElement            (//button/span[text()\='Yes'])[6]
        VerifyElement           (//button/span[text()\='No'])[6]
        VerifyText              Contracts are utilized on all client engagements
        VerifyElement           (//button/span[text()\='Yes'])[7]
        ClickElement            (//button/span[text()\='Yes'])[7]
        VerifyElement           (//button/span[text()\='No'])[7]
        VerifyText              All client contracts include a limitation of liability and/or indemnity clause that inures to the benefit of the Insured
        VerifyElement           (//button/span[text()\='Yes'])[8]
        ClickElement            (//button/span[text()\='Yes'])[1]
        VerifyElement           (//button/span[text()\='No'])[8]

        VerifyElement           //button[text()\=' Back ']
        VerifyElement           //button[text()\=' Next ']

    ELSE IF                     "${Industry_MPL_S}" == "Media - Public Relations"

        VerifyText              Tell us about your Insured
        VerifyText              The Insured currently purchases a Miscellaneous Professional Liability (MPL) policy
        VerifyElement           (//button/span[text()\='Yes'])[1]
        ClickElement            (//button/span[text()\='Yes'])[1]
        VerifyElement           (//button/span[text()\='No'])[1]
        Select current Expiration date
        Select current Retroactive date
        Type text               MPL Expiring Limit          2000000
        ClickText               Additional pricing discounts are available, if you can confirm the following statements.

        VerifyText              Additional pricing discounts are available, if you can confirm the following statements.
        VerifyText              Principals have an average of at least 10 years relevant industry experience
        VerifyElement           (//button/span[text()\='Yes'])[2]
        ClickElement            (//button/span[text()\='Yes'])[2]
        VerifyElement           (//button/span[text()\='No'])[2]
        VerifyText              No individual client or contract accounts for more than 25% of annual revenues
        VerifyElement           (//button/span[text()\='Yes'])[3]
        ClickElement            (//button/span[text()\='Yes'])[3]
        VerifyElement           (//button/span[text()\='No'])[3]
        VerifyText              The Insured uses sub-contractors on less than 25% of projects
        VerifyElement           (//button/span[text()\='Yes'])[4]
        ClickElement            (//button/span[text()\='Yes'])[4]
        VerifyElement           (//button/span[text()\='No'])[4]
        VerifyText              No client contract value is over $1,000,000
        VerifyElement           (//button/span[text()\='Yes'])[5]
        ClickElement            (//button/span[text()\='Yes'])[5]
        VerifyElement           (//button/span[text()\='No'])[5]
        VerifyText              Contracts are utilized on all client engagements
        VerifyElement           (//button/span[text()\='Yes'])[6]
        ClickElement            (//button/span[text()\='Yes'])[16
        VerifyElement           (//button/span[text()\='No'])[6]
        VerifyText              All client contracts include a limitation of liability and/or indemnity clause that inures to the benefit of the Insured
        VerifyElement           (//button/span[text()\='Yes'])[7]
        ClickElement            (//button/span[text()\='Yes'])[7]
        VerifyElement           (//button/span[text()\='No'])[7]

        VerifyElement           //button[text()\=' Back ']
        VerifyElement           //button[text()\=' Next ']

    ELSE IF                     "${Industry_MPL_S}" == "Real Estate - Residential Appraisers"

        VerifyText              Tell us about your Insured
        VerifyText              The Insured currently purchases a Miscellaneous Professional Liability (MPL) policy
        VerifyElement           (//button/span[text()\='Yes'])[1]
        ClickElement            (//button/span[text()\='Yes'])[1]
        VerifyElement           (//button/span[text()\='No'])[1]
        Verifytext              In the past year, the Insured has performed appraisals with property values in excess of $2,000,000.
        VerifyElement           (//button/span[text()\='Yes'])[2]
        ClickElement            (//button/span[text()\='Yes'])[2]
        VerifyElement           (//button/span[text()\='No'])[2]
        VerifyText              The Insured utilizes MLS/Trend, NDC or public records to verify information for accuracy and maintaining quality control over all appraisals produced by their office.
        VerifyElement           (//button/span[text()\='Yes'])[3]
        ClickElement            (//button/span[text()\='Yes'])[3]
        VerifyElement           (//button/span[text()\='No'])[3]
        Select current Expiration date
        Select current Retroactive date
        Type text               MPL Expiring Limit          2000000
        ClickText               Additional pricing discounts are available, if you can confirm the following statements.

        VerifyText              Additional pricing discounts are available, if you can confirm the following statements.
        VerifyText              Principals have an average of at least 10 years relevant industry experience
        VerifyElement           (//button/span[text()\='Yes'])[4]
        ClickElement            (//button/span[text()\='Yes'])[4]
        VerifyElement           (//button/span[text()\='No'])[4]
        VerifyText              No individual client or contract accounts for more than 25% of annual revenues
        VerifyElement           (//button/span[text()\='Yes'])[5]
        ClickElement            (//button/span[text()\='Yes'])[5]
        VerifyElement           (//button/span[text()\='No'])[5]
        VerifyText              The Insured uses sub-contractors on less than 25% of projects
        VerifyElement           (//button/span[text()\='Yes'])[6]
        ClickElement            (//button/span[text()\='Yes'])[6]
        VerifyElement           (//button/span[text()\='No'])[6]
        VerifyText              No client contract value is over $1,000,000
        VerifyElement           (//button/span[text()\='Yes'])[7]
        ClickElement            (//button/span[text()\='Yes'])[7]
        VerifyElement           (//button/span[text()\='No'])[7]
        VerifyText              Contracts are utilized on all client engagements
        VerifyElement           (//button/span[text()\='Yes'])[8]
        ClickElement            (//button/span[text()\='Yes'])[8]
        VerifyElement           (//button/span[text()\='No'])[8]
        VerifyText              All client contracts include a limitation of liability and/or indemnity clause that inures to the benefit of the Insured
        VerifyElement           (//button/span[text()\='Yes'])[9]
        ClickElement            (//button/span[text()\='Yes'])[1]
        VerifyElement           (//button/span[text()\='No'])[9]

        VerifyElement           //button[text()\=' Back ']
        VerifyElement           //button[text()\=' Next ']

    ELSE IF                     "${Industry_MPL_S}" == "Real Estate - Relocation Agent"

        VerifyText              Tell us about your Insured
        VerifyText              The Insured currently purchases a Miscellaneous Professional Liability (MPL) policy
        VerifyElement           (//button/span[text()\='Yes'])[1]
        ClickElement            (//button/span[text()\='Yes'])[1]
        VerifyElement           (//button/span[text()\='No'])[1]
        Select current Expiration date
        Select current Retroactive date
        Type text               MPL Expiring Limit          2000000
        ClickText               Additional pricing discounts are available, if you can confirm the following statements.

        VerifyText              Additional pricing discounts are available, if you can confirm the following statements.
        VerifyText              Principals have an average of at least 10 years relevant industry experience
        VerifyElement           (//button/span[text()\='Yes'])[2]
        ClickElement            (//button/span[text()\='Yes'])[2]
        VerifyElement           (//button/span[text()\='No'])[2]
        VerifyText              No individual client or contract accounts for more than 25% of annual revenues
        VerifyElement           (//button/span[text()\='Yes'])[3]
        ClickElement            (//button/span[text()\='Yes'])[3]
        VerifyElement           (//button/span[text()\='No'])[3]
        VerifyText              The Insured uses sub-contractors on less than 25% of projects
        VerifyElement           (//button/span[text()\='Yes'])[4]
        ClickElement            (//button/span[text()\='Yes'])[4]
        VerifyElement           (//button/span[text()\='No'])[4]
        VerifyText              No client contract value is over $1,000,000
        VerifyElement           (//button/span[text()\='Yes'])[5]
        ClickElement            (//button/span[text()\='Yes'])[5]
        VerifyElement           (//button/span[text()\='No'])[5]
        VerifyText              Contracts are utilized on all client engagements
        VerifyElement           (//button/span[text()\='Yes'])[6]
        ClickElement            (//button/span[text()\=ClickElement            (//button/span[text()\='Yes'])[1]
        VerifyElement           (//button/span[text()\='No'])[6]
        VerifyText              All client contracts include a limitation of liability and/or indemnity clause that inures to the benefit of the Insured
        VerifyElement           (//button/span[text()\='Yes'])[7]
        ClickElement            (//button/span[text()\='Yes'])[1]
        VerifyElement           (//button/span[text()\='No'])[7]

        VerifyElement           //button[text()\=' Back ']
        VerifyElement           //button[text()\=' Next ']

    ELSE IF                     "${Industry_MPL_S}" == "Transportation - Travel Agencies/Tour Operators"

        VerifyText              Tell us about your Insured
        VerifyText              The Insured currently purchases a Miscellaneous Professional Liability (MPL) policy
        VerifyElement           (//button/span[text()\='Yes'])[1]
        ClickElement            (//button/span[text()\='Yes'])[1]
        VerifyElement           (//button/span[text()\='No'])[1]
        Select current Expiration date
        Select current Retroactive date
        Type text               MPL Expiring Limit          2000000
        ClickText               Additional pricing discounts are available, if you can confirm the following statements.

        VerifyText              Additional pricing discounts are available, if you can confirm the following statements.
        VerifyText              Principals have an average of at least 10 years relevant industry experience
        VerifyElement           (//button/span[text()\='Yes'])[2]
        ClickElement            (//button/span[text()\='Yes'])[2]
        VerifyElement           (//button/span[text()\='No'])[2]
        VerifyText              No individual client or contract accounts for more than 25% of annual revenues
        VerifyElement           (//button/span[text()\='Yes'])[3]
        ClickElement            (//button/span[text()\='Yes'])[3]
        VerifyElement           (//button/span[text()\='No'])[3]
        VerifyText              The Insured uses sub-contractors on less than 25% of projects
        VerifyElement           (//button/span[text()\='Yes'])[4]
        ClickElement            (//button/span[text()\='Yes'])[4]
        VerifyElement           (//button/span[text()\='No'])[4]
        VerifyText              No client contract value is over $1,000,000
        VerifyElement           (//button/span[text()\='Yes'])[5]
        ClickElement            (//button/span[text()\='Yes'])[5]
        VerifyElement           (//button/span[text()\='No'])[5]
        VerifyText              Contracts are utilized on all client engagements
        VerifyElement           (//button/span[text()\='Yes'])[6]
        ClickElement            (//button/span[text()\='Yes'])[6]
        VerifyElement           (//button/span[text()\='No'])[6]
        VerifyText              All client contracts include a limitation of liability and/or indemnity clause that inures to the benefit of the Insured
        VerifyElement           (//button/span[text()\='Yes'])[7]
        ClickElement            (//button/span[text()\='Yes'])[7]
        VerifyElement           (//button/span[text()\='No'])[7]

        VerifyElement           //button[text()\=' Back ']
        VerifyElement           //button[text()\=' Next ']


















    END
    Log To Console              ------Action elements on Coverage question Page for MPL Validated Successfully-------

Click on No and Next Button - Coverage question page
    [Documentation]             Click on No and Next Button - Coverage question page
    VerifyElement               //button/span[text()\='No']
    ClickElement                //button/span[text()\='No']
    ClickElement                //button[text()\=' Next ']
    VerifyText                  Review My Quote             timeout=120s

Click on Next Button - Coverage question Page

    [Documentation]             Click on Next Button - Coverage question Page

    ClickElement                //button[text()\=' Next ']
    Sleep                       30s


Click on Back Button - Coverage question Page 1
    [Documentation]             Click on Back Button - Coverage question Page
    ClickElement                //button[text()\=' Back ']
    VerifyText                  Home


Click on Back Button - Review my quote Page
    [Documentation]             Click on Back Button - Coverage question Page
    ClickElement                //button[text()\=' Back ']
    VerifyText                  Home


Select current Expiration date 
    [Documentation]             Select current Expiration date

    ${currDate}=                Get Current Date            result_format=%-d

    ClickElement                (//input[@formcontrolname\='expDate']/parent::*/following::div/mat-datepicker-toggle)[1]
    ClickText                   ${currDate}

Select current Retroactive date 
    [Documentation]             Select current Retroactive date

    ${currDate}=                Get Current Date            result_format=%-d

    ClickElement                (//input[@formcontrolname\='retroactiveDate']/parent::*/following::div/mat-datepicker-toggle)[1]
    ClickText                   ${currDate}