*** Settings ***
Library                         QWeb
Library                         QForce
#Library                        QVision
Library                         FakerLibrary
Library                         String
Library                         BuiltIn
Library                         DateTime



*** Keywords ***

Verify Element on PCC Fiduciary page
    [Documentation]             Verify Element on PCC Fiduciary page
    VerifyText                  Your time is our priority. Please check our Fiduciary Guidelines below for portal eligibility.
    VerifyText                  Our Eligibility Guidelines
    VerifyText                  The Insured does not offer any Defined Benefit plans or Employee Stock Ownership Plans
    VerifyText                  The Insured has not terminated, converted or merged any benefit plan in the past 12 months


    VerifyText                  Yes, the Insured meets each of the Guidelines and I would like an instant quote
    VerifyText                  No, the Insured doesn't meet some of the Guidelines

    Click Element               //input[@value\='remove']
    VerifyText                  I would like to remove Fiduciary from the Private Company Combo package
    VerifyText                  I would like to send my submission to underwriters@celeritypro.com

    Click Element               //input[@value\='confirm']

    VerifyElement               //input[@value\='confirm']
    VerifyElement               //input[@value\='remove']
    VerifyElement               //button[text()\=' Back ']
    VerifyElement               //button[text()\=' Next ']

Verify clicking Yes and continue on Fiduciary Elegibility page
    [Documentation]             Verify clicking Yes and continue on Fiduciary Elegibility page

    ClickElement                //input[@value\='confirm']
    ClickElement                //button[text()\=' Next ']


Verify Elements on Tell us more about your Fiduciary Exposure page click yes and next
    [Documentation]             Verify Elements on Tell us more about your Fiduciary Exposure page click yes and next

    TypeText                    Total Plan Assets           2000000
    VerifyText                  Does the Insured currently have a Fiduciary Liability Policy In-Force?
    VerifyElement               (//button/span[text()\='Yes'])[1]
    ClickElement                (//button/span[text()\='Yes'])[1]
    VerifyElement               (//button/span[text()\='No'])[1]

    VerifyElement               (//input[@formcontrolname\='expDate']/parent::*/following::div/mat-datepicker-toggle)[1]
    VerifyElement               (//input[@formcontrolname\='priorLitiDate']/parent::*/following::div/mat-datepicker-toggle)[1]
    VerifyElement               (//input[@formcontrolname\='priorActsDate']/parent::*/following::div/mat-datepicker-toggle)[1]
    Select Expiration date for Fiduciary
    Select prior and pending Litigation date for Fiduciary
    Select prior acts Retroactive date for Fiduciary
    TypeText                    Fiduciary Expiring Limit    2000000
    ClickElement                //button[text()\=' Next ']

Verify Elements on Tell us more about your Fiduciary Exposure page click No and Next
    [Documentation]             Verify Elements on Tell us more about your Fiduciary Exposure page click No and Next

    TypeText                    Total Plan Assets           2000000
    VerifyText                  Does the Insured currently have a Fiduciary Liability Policy In-Force?
    VerifyElement               (//button/span[text()\='Yes'])[1]
    ClickElement                (//button/span[text()\='No'])[1]
    VerifyElement               (//button/span[text()\='No'])[1]
    ClickElement                //button[text()\=' Next ']

Select Expiration date for Fiduciary
    [Documentation]             Select Expiration date

    ${currDate}=                Get Current Date            result_format=%-d

    ClickElement                (//input[@formcontrolname\='expDate']/parent::*/following::div/mat-datepicker-toggle)[1]
    ClickText                   ${currDate}



Select prior and pending Litigation date for Fiduciary
    [Documentation]             Select prior and pending Litigation date

    ${currDate}=                Get Current Date            result_format=%-d

    ClickElement                (//input[@formcontrolname\='priorLitiDate']/parent::*/following::div/mat-datepicker-toggle)[1]
    ClickText                   ${currDate}



Select prior acts Retroactive date for Fiduciary
    [Documentation]             Select prior acts Retroactive date

    ${currDate}=                Get Current Date            result_format=%-d

    ClickElement                (//input[@formcontrolname\='priorActsDate']/parent::*/following::div/mat-datepicker-toggle)[1]
    ClickText                   ${currDate}


Select Back on Fiduciary page
    [Documentation]             Select Back on Fiduciary page

    VerifyElement               //button[text()\=' Back ']
    ClickElement                //button[text()\=' Back ']


Select Next on Fiduciary page
    [Documentation]             Select Next on Fiduciary page

    VerifyElement               //button[text()\=' Next ']
    ClickElement                //button[text()\=' Next ']