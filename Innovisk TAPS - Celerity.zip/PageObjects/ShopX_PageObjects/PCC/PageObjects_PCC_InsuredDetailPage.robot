*** Settings ***
Library                    QWeb
Library                    QForce
#Library                   QVision
Library                    FakerLibrary
Library                    String
Library                    BuiltIn
Library                    DateTime



*** Keywords ***

Verify Actions performed on Insured details Page for PCC

    [Documentation]        Verify Actions performed on Insured details Page for PCC
    [Arguments]            ${Industry_PCC}             ${Address1}                 ${Address2}    ${City}    ${State_Province}    ${PostalZip}    ${Annual_revenue}    ${Total_Assets}

    TypeText               Industry                    ${Industry_PCC}
    ClickElement           //span[text()\=" ${Industry_PCC} "]
    Sleep                  2s

    ${currTime}=           Get Current Date            result_format=%-d%-m%Y%-H%f
    ${name1}=              Name Male
    Set Global Variable    ${name1}
    ${random_email}=       Set Variable                ${name1}@gmail.com
    Set Global Variable    ${random_email}
    ${uniqueName}=         Set Variable                ${name1}${currTime}
    Set Global Variable    ${uniqueName}
    Log To Console         ${uniqueName}
    TypeText               Insured Name                ${uniqueName}

    TypeText               Insured address *           2300 M St NW, Washington, DC 20037, USA
    ClickText              DC 20037, USA

    ClickElement           (//input[@type\="checkbox"])[1]
    TypeText               Address1                    ${Address1}
    TypeText               Address2                    ${Address2}
    TypeText               City                        ${City}
    #TypeText              Country                     ${USA}
    ClickElement           //mat-select
    ClickElement           //span[text()\=" ${State_Province} "]
    TypeText               Postal Zip                  ${PostalZip}

    TypeText               Latest Annual revenue       ${Annual_revenue}
    TypeText               Total Assets                ${Total_Assets}

    VerifyText             M&A Activity in last 12 months
    ClickText              No
    

    ClickElement           //button[text()\=' Next ']
    VerifyText             Choose your coverages


Enter PCC Industry for validating eligibility    
    [Documentation]      Enter PCC Industry for validating eligibility        
    [Arguments]            ${Industryarg1}

    TypeText               Industry                    ${Industryarg1}
    ClickElement           //span[text()\=" ${Industryarg1} "]
    Sleep                  2s

    ClickElement           //button[text()\=' Next ']
    VerifyText             Your time is our priority. Please check our PCC Guidelines below for portal eligibility.

Click on Next Button - Insured Details Page

    [Documentation]    Click on Next Button - Insured Details Page
    [Arguments]        ${Industry}


    TypeText           Insured Website URL         choiceip.com
    TypeText           Industry                    ${Industry}
    Sleep              2s
    ClickElement       //span[text()\=" ${Industry} "]
    ClickElement       //button[text()\=' Next ']
    VerifyText         Tell us about your Insured

Click on Back Button - Insured Details Page

    [Documentation]    Click on Back Button - Insured Details Page
    
    ClickElement       //button[text()\=' Back ']
    VerifyText         Your time is our priority. Our upfront Eligibility Guidelines ensure a hassle-free experience.