*** Settings ***
Library                QWeb
Library                QForce
#Library               QVision
Library                FakerLibrary
Library                String
Library                BuiltIn
Library                DateTime



*** Keywords ***

Verify Element on PCC Crime page
    [Documentation]    Verify Element on PCC Crime page
    VerifyText         Your time is our priority. Please check our Crime Guidelines below for portal eligibility.
    VerifyText         Our Eligibility Guidelines
    VerifyText         The Insured does not have more than 25% of employees in foreign locations
    VerifyText         The Insured performs background checks on all new hires
    VerifyText         The Insured segregates duties for bank accounts, deposits, withdrawals and reconciliations
    VerifyText         The Insured does not have any custody or control of any funds, accounts or materials of any of its clients
    VerifyText         The Insured has written procedures for wire transfers


    VerifyText         Yes, the Insured meets each of the Guidelines and I would like an instant quote
    VerifyText         No, the Insured doesn't meet some of the Guidelines

    Click Element      //input[@value\='remove']
    VerifyText         I would like to remove Crime from the Private Company Combo package
    VerifyText         I would like to send my submission to underwriters@celeritypro.com

    Click Element      //input[@value\='confirm']
    VerifyElement      //input[@value\='confirm']
    VerifyElement      //input[@value\='remove']
    VerifyElement      //button[text()\=' Back ']
    VerifyElement      //button[text()\=' Next ']

Verify clicking Yes and continue on Crime Elegibility page
    [Documentation]    Verify clicking Yes and continue on Fiduciary Elegibility page

    ClickElement       //input[@value\='confirm']
    ClickElement       //button[text()\=' Next ']


Verify element on Tell us more about your Crime Exposure page
    [Documentation]    Verify element on Tell us more about your Crime Exposure page
    VerifyText         Does The Insured Have Call Back Verification Procedures In Place For Any Outgoing Wire Transfer?
    VerifyText         Yes
    VerifyText         No
    VerifyText         Unknown

Verify actions performed on Tell us more about your Crime Exposure page
    [Documentation]    Verify actions performed on Tell us more about your Crime Exposure page
    [Arguments]        ${action}

    IF                 "${action}" == "Yes"

        ClickText      Yes

    ELSE IF            "${action}" == "No"

        ClickText      No


    ELSE IF            "${action}" == "Unknown"

        ClickText      Unknown


    END

    ClickText          Next

    VerifyText         Review My Quote             timeout=45s
