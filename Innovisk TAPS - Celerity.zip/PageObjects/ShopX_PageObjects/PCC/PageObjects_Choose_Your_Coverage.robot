*** Settings ***
Library             QWeb
Library             QForce
#Library            QVision
Library             FakerLibrary
Library             String
Library             BuiltIn
Library             DateTime



*** Keywords ***

Select all PCC Coverage

    Verify text     Choose your coverages

    ClickElement    (//app-select-coverages//span)[2]
    ClickElement    (//app-select-coverages//span)[3]
    ClickElement    (//app-select-coverages//span)[4]
    
    ClickText       Next
    VerifyText      Your time is our priority. Please check our D&O Guidelines below for portal eligibility.