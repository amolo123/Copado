*** Settings ***
Library                QWeb
Library                QForce
#Library               QVision
Library                FakerLibrary
Library                String
Library                BuiltIn
Library                DateTime



*** Keywords ***

Verify Element on Review My quote
    [Documentation]    Verify Element on Review My quote

    Verifytext         Review My Quote
    VerifyText         COMBINED MAXIMUM AGGREGATE LIMIT
    VerifyText         D&O
    VerifyText         EPL
    VerifyText         Fiduciary
    VerifyText         Crime
    VerifyText         $1,000,000                  anchor=D&O
    VerifyText         $1,000,000                  anchor=EPL
    VerifyText         $1,000,000                  anchor=Fiduciary
    VerifyText         $1,000,000                  anchor=Crime
