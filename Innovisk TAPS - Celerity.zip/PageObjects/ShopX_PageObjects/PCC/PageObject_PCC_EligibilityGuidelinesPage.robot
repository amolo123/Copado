*** Settings ***
Library                QWeb
Library                QForce
#Library               QVision
Library                FakerLibrary
Library                String
Library                BuiltIn
Library                DateTime



*** Keywords ***

Validate elements on Eligibility Guidelines Page for PCC
    [Documentation]    Validate elements on Eligibility Guidelines Page for PCC


    VerifyText         The Insured has been in business for longer than three years.
    VerifyText         The Insured's corporate structure is not a Partnership, Not-For Profit firm or Publicly Traded Company.
    VerifyText         The Insured is not domiciled in California.
    VerifyText         The coverages being applied for have not been cancelled or non renewed in the last three years.
    VerifyText         The Insured has not been subject to any Company Litigation in the last three years.
    VerifyText         The Insured is not aware of an issue or circumstance which could lead to a claim. (New buyer only).
    VerifyText         The Insured’s business does not include ammunition/firearms, auto-dealer, cannabis, cryptocurrency, opioid, real estate broker, tobacco or financial services activities, either directly or indirectly.
    VerifyText         The Insured has made no more than 3 claims in the past three years, paid or unpaid.
    VerifyText         The Insured has had no paid claim(s) over $50,000, total for all such claims combined, in the past three years.

    VerifyText         Yes, the Insured meets each of the Guidelines and I would like an instant quote
    VerifyText         No, the Insured doesn't meet some of the Guidelines and I would like to send my submission to

    VerifyElement      //input[@value\='confirm']
    VerifyElement      //input[@value\='remove']
    VerifyElement      //button[text()\=' Back ']
    VerifyElement      //button[text()\=' Next ']

Click on Next Button - Eligibility Guidelines Page

    [Documentation]    Click on Next Button - Eligibility Guidelines Page


    ClickElement       //input[@value\='confirm']
    ClickElement       //button[text()\=' Next ']

    #VerifyText         Let's get you started...

Click on Back Button - Eligibility Guidelines Page

    ClickElement       //input[@value\='remove']
    ClickElement       //button[text()\=' Back ']
    ${Skip}=           IsText                      Skip

    IF                 "${Skip}" == "True"
        ClickText      Skip
    END

    VerifyText         Home
