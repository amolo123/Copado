*** Settings ***
Library                         QWeb
Library                         QForce
#Library                        QVision
Library                         FakerLibrary
Library                         String
Library                         BuiltIn
Library                         DateTime



*** Keywords ***

Verify Element on PCC EPL page
    [Documentation]             Verify Element on PCC EPL page
    VerifyText                  Your time is our priority. Please check our EPL Guidelines below for portal eligibility.
    VerifyText                  Our Eligibility Guidelines
    VerifyText                  There has not been a reduction in force in the past 12 months
    VerifyText                  The majority of employees don't earn more than $150,000 annual compensation
    Verifytext                  The Insured has written procedures addressing discrimination and harassment, including sexual harassment


    VerifyElement               //button[text()\=' Back ']
    VerifyElement               //button[text()\=' Next ']


Verify elements on Tell us more about your EPL Exposure click YES
    [Documentation]             Verify elements on Tell us more about your EPL Exposure click YES

    VerifyText                  Tell us more about your EPL Exposure
    TypeText                    Full Time Employees         30
    TypeText                    Part Time Employees         12
    TypeText                    % California Employees      5
    TypeText                    Foreign Employees           8
    VerifyText                  Does the Insured currently have an EPL Policy In-Force?
    VerifyElement               (//button/span[text()\='Yes'])[1]
    ClickElement                (//button/span[text()\='Yes'])[1]
    VerifyElement               (//button/span[text()\='No'])[1]
    VerifyElement               (//input[@formcontrolname\='expDate']/parent::*/following::div/mat-datepicker-toggle)[1]
    VerifyElement               (//input[@formcontrolname\='priorLitiDate']/parent::*/following::div/mat-datepicker-toggle)[1]
    VerifyElement               (//input[@formcontrolname\='priorActsDate']/parent::*/following::div/mat-datepicker-toggle)[1]
    Select Expiration date for EPL
    Select prior and pending Litigation date for EPL
    Select prior acts Retroactive date for EPL
    TypeText                    EPL Expiring Limit          2000000
    ClickText                   Next



Verify elements on Tell us more about your EPL Exposure click NO
    [Documentation]             Verify elements on Tell us more about your EPL Exposure click NO

    VerifyText                  Tell us more about your EPL Exposure
    TypeText                    Full Time Employees         30
    TypeText                    Part Time Employees         12
    TypeText                    % California Employees      5
    TypeText                    Foreign Employees           8
    VerifyText                  Does the Insured currently have an EPL Policy In-Force?
    VerifyElement               (//button/span[text()\='Yes'])[1]
    ClickElement                (//button/span[text()\='No'])[1]
    VerifyElement               (//button/span[text()\='No'])[1]



Select Back on EPL page
    [Documentation]             Select Back on EPL page

    VerifyElement               //button[text()\=' Back ']
    ClickElement                //button[text()\=' Back ']


Select Next on EPL page
    [Documentation]             Select Next on EPL page

    ClickElement                //input[@value\='confirm']
    ClickElement                //button[text()\=' Next ']



Select Expiration date for EPL
    [Documentation]             Select Expiration date for EPL

    ${currDate}=                Get Current Date            result_format=%-d

    ClickElement                (//input[@formcontrolname\='expDate']/parent::*/following::div/mat-datepicker-toggle)[1]
    ClickText                   ${currDate}



Select prior and pending Litigation date for EPL
    [Documentation]             Select prior and pending Litigation date for EPL

    ${currDate}=                Get Current Date            result_format=%-d

    ClickElement                (//input[@formcontrolname\='priorLitiDate']/parent::*/following::div/mat-datepicker-toggle)[1]
    ClickText                   ${currDate}



Select prior acts Retroactive date for EPL
    [Documentation]             Select prior acts Retroactive date for EPL

    ${currDate}=                Get Current Date            result_format=%-d

    ClickElement                (//input[@formcontrolname\='priorActsDate']/parent::*/following::div/mat-datepicker-toggle)[1]
    ClickText                   ${currDate}
