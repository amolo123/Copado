*** Settings ***
Library                QWeb
Library                QForce
#Library               QVision
Library                FakerLibrary
Library                String
Library                BuiltIn
Library                DateTime



*** Keywords ***
Verify Element on PCC D&O page
    [Documentation]    Verify Element on PCC D&O page
    VerifyText         Your time is our priority. Please check our D&O Guidelines below for portal eligibility.
    VerifyText         Our Eligibility Guidelines
    VerifyText         The Insured does not anticipate a public offering of securities or any M&A activity in next twelve months
    VerifyText         The Insured has not experienced a lawsuit alleging any violation of federal or state laws in the past three years
    Verifytext         The Insured does not expect to file for bankruptcy in the next 12-16 months
    VerifyText         Total Assets exceed Total Liabilities for the most recent year-end
    VerifyText         Current Assets exceed Current Liabilities for the most recent year-end

    VerifyText         Yes, the Insured meets each of the Guidelines and I would like an instant quote
    VerifyText         No, the Insured doesn't meet some of the Guidelines and I would like to send my submission to underwriters@celeritypro.com

    VerifyElement      //input[@value\='confirm']
    VerifyElement      //input[@value\='remove']
    VerifyElement      //button[text()\=' Back ']
    VerifyElement      //button[text()\=' Next ']

    


Verify elements on Tell us more about your D&O Exposure click YES
    [Documentation]    Verify elements on Tell us more about your D&O Exposure click YES

    VerifyText         Tell us more about your D&O Exposure
    # VerifyElement      (//button/span[text()\='Yes'])[1]
    # ClickElement       (//button/span[text()\='Yes'])[1]
    # VerifyElement      (//button/span[text()\='No'])[1]
    VerifyText         Are any Shareholders related by Family to a Director Or Officer?
    VerifyElement      (//button/span[text()\='Yes'])[1]
    ClickElement       (//button/span[text()\='Yes'])[1]
    VerifyElement      (//button/span[text()\='No'])[1]
    VerifyText         Is The Insured more than 50% Owned by a Parent Entity?
    VerifyElement      (//button/span[text()\='Yes'])[2]
    ClickElement       (//button/span[text()\='Yes'])[2]
    VerifyElement      (//button/span[text()\='No'])[2]
    VerifyText         Do any Shareholders (other than Directors or Officers) Own more than 10% of the Outstanding Voting Shares?
    VerifyElement      (//button/span[text()\='Yes'])[3]
    ClickElement       (//button/span[text()\='Yes'])[3]
    VerifyElement      (//button/span[text()\='No'])[3]
    VerifyText         Has the Insured offered a Private Placement of Securities in the last 12 Months, or is a Private Placement anticipated in the next 12 Months?
    VerifyElement      (//button/span[text()\='Yes'])[4]
    ClickElement       (//button/span[text()\='Yes'])[4]
    VerifyElement      (//button/span[text()\='No'])[4]
    VerifyText         Has the Insured raised Capital via Crowdfunding (See Jobs Act 2012) in the last 12 Months, or is such an Offering anticipated in the next 12 Months?
    VerifyElement      (//button/span[text()\='Yes'])[5]
    ClickElement       (//button/span[text()\='Yes'])[5]
    VerifyElement      (//button/span[text()\='No'])[5]
    VerifyText         Does the Insured currently have a D&O Policy In-Force?
    VerifyElement      (//button/span[text()\='Yes'])[6]
    ClickElement       (//button/span[text()\='Yes'])[6]
    VerifyElement      (//button/span[text()\='No'])[6]
    VerifyElement      (//input[@formcontrolname\='expDate']/parent::*/following::div/mat-datepicker-toggle)[1]   
    VerifyElement      (//input[@formcontrolname\='priorLitiDate']/parent::*/following::div/mat-datepicker-toggle)[1] 
    VerifyElement      (//input[@formcontrolname\='priorActsDate']/parent::*/following::div/mat-datepicker-toggle)[1]
    Select Expiration date for D&O
    Select prior and pending Litigation date for D&O
    Select prior acts Retroactive date for D&O
    TypeText           D&O Expiring Limit    2000000    
    Click text                  Next

Verify elements on Tell us more about your D&O Exposure click NO
    [Documentation]    Verify elements on Tell us more about your D&O Exposure click NO

    VerifyText         Tell us more about your D&O Exposure
    # VerifyElement      (//button/span[text()\='Yes'])[1]
    # ClickElement       (//button/span[text()\='No'])[1]
    # VerifyElement      (//button/span[text()\='No'])[1]
    VerifyText         Are any Shareholders related by Family to a Director Or Officer?
    VerifyElement      (//button/span[text()\='Yes'])[1]
    ClickElement       (//button/span[text()\='No'])[1]
    VerifyElement      (//button/span[text()\='No'])[1]
    VerifyText         Is The Insured more than 50% Owned by a Parent Entity?
    VerifyElement      (//button/span[text()\='Yes'])[2]
    ClickElement       (//button/span[text()\='No'])[2]
    VerifyElement      (//button/span[text()\='No'])[2]
    VerifyText         Do any Shareholders (other than Directors or Officers) Own more than 10% of the Outstanding Voting Shares?
    VerifyElement      (//button/span[text()\='Yes'])[3]
    ClickElement       (//button/span[text()\='No'])[3]
    VerifyElement      (//button/span[text()\='No'])[3]
    VerifyText         Has the Insured offered a Private Placement of Securities in the last 12 Months, or is a Private Placement anticipated in the next 12 Months?
    VerifyElement      (//button/span[text()\='Yes'])[4]
    ClickElement       (//button/span[text()\='No'])[4]
    VerifyElement      (//button/span[text()\='No'])[4]
    VerifyText         Has the Insured raised Capital via Crowdfunding (See Jobs Act 2012) in the last 12 Months, or is such an Offering anticipated in the next 12 Months?
    VerifyElement      (//button/span[text()\='Yes'])[5]
    ClickElement       (//button/span[text()\='No'])[5]
    VerifyElement      (//button/span[text()\='No'])[5]
    VerifyText         Does the Insured currently have a D&O Policy In-Force?
    VerifyElement      (//button/span[text()\='Yes'])[6]
    ClickElement       (//button/span[text()\='No'])[6]
    VerifyElement      (//button/span[text()\='No'])[6]



Select Back on D&O page
    [Documentation]    Select Back on D&O page

    VerifyElement      //button[text()\=' Back ']
    ClickElement       //button[text()\=' Back ']


Select Next on D&O page
    [Documentation]    Select Next on D&O page

    ClickElement       //input[@value\='confirm']
    ClickElement       //button[text()\=' Next ']



Select Expiration date for D&O
    [Documentation]    Select Expiration date for D&O

    ${currDate}=       Get Current Date            result_format=%-d

    ClickElement       (//input[@formcontrolname\='expDate']/parent::*/following::div/mat-datepicker-toggle)[1]
    ClickText          ${currDate}



Select prior and pending Litigation date for D&O
    [Documentation]    Select prior and pending Litigation date for D&O

    ${currDate}=       Get Current Date            result_format=%-d

    ClickElement       (//input[@formcontrolname\='priorLitiDate']/parent::*/following::div/mat-datepicker-toggle)[1]
    ClickText          ${currDate}



Select prior acts Retroactive date for D&O
    [Documentation]    Select prior acts Retroactive date for D&O

    ${currDate}=       Get Current Date            result_format=%-d

    ClickElement       (//input[@formcontrolname\='priorActsDate']/parent::*/following::div/mat-datepicker-toggle)[1]
    ClickText          ${currDate}