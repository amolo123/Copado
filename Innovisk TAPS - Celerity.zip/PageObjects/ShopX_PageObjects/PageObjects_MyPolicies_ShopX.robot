*** Settings ***
Library                QWeb
Library                QForce
#Library               QVision
Library                FakerLibrary
Library                String
Library                BuiltIn
Library                DateTime



*** Keywords ***
Validate all the elements on My Policies page

    [Documentation]    Validate all the elements on My Policies page
    VerifyElement      //*[contains(@class, 'hero-heading mb-0')]
    VerifyText         My Policies
    #VerifyText        Select A search Filter
    VerifyText         SEARCH
    VerifyText         RESET
    ClickElement       //mat-label[text()\='Select a search filter']
    VerifyText         Account Name
    VerifyText         Policy Number
    VerifyText         Expiration Date
    VerifyText         Product
    #ClickText         Account Name
    VerifyElement      //span[@class\='mat-option-text' and text()\='Product']
    ClickElement       //span[@class\='mat-option-text' and text()\='Account Name']
    VerifyText         PRODUCT
    VerifyText         PREMIUM
    VerifyText         COMMISSION
    VerifyText         EFFECTIVE DATE
    VerifyText         EXPIRATION DATE
    VerifyText         ACTION
    VerifyText         Load More
    ClickElement       //*[contains(@class, 'ellipsis d-flex align-items-center justify-content-center mx-auto')]
    VerifyText         Policy Document
    VerifyText         Signature Pack
    RefreshPage


    VerifyElement      //button[text()\='SEARCH']
    VerifyElement      //button[text()\='RESET']
    Log To Console     ------Celerity ShopX My Policies page Validated Successfully-------



Validate Clicking on Search button on my policies page
    [Documentation]    Validate Clicking on Search button on my policies page
    ClickElement       //button[text()\='SEARCH']
    Sleep              10s

Validate clicking on Reset button on my policies page
    [Documentation]    Validate clicking on Reset button on my policies page

    ClickElement       //button[text()\='RESET']
    Sleep              10s


Validate searching with Product name MPL on my policies page
    [Documentation]        Validate searching with Product name MPL

    ClickElement       //mat-label[text()\='Select a search filter']
    VerifyText         Product
    ClickElement       //span[@class\='mat-option-text' and text()\='Product']
    ClickElement       //mat-label[text()\='SELECT A PRODUCT']
    ClickElement       //span[text()\='MPL']


Validate searching with Product name Cyber on my policies page
    [Documentation]        Validate searching with Product name Cyber

    ClickElement       //mat-label[text()\='Select a search filter']
    VerifyText         Product
    ClickElement       //span[@class\='mat-option-text' and text()\='Product']
    ClickElement       //mat-label[text()\='SELECT A PRODUCT']
    ClickElement       //span[text()\='Cyber']


Validate searching with Product name PCC on my policies page
    [Documentation]        Validate searching with Product name PCC

    ClickElement       //mat-label[text()\='Select a search filter']
    VerifyText         Product
    ClickElement       //span[@class\='mat-option-text' and text()\='Product']
    ClickElement       //mat-label[text()\='SELECT A PRODUCT']
    ClickElement       //span[text()\='PCC']

Validate Download Policy document on my policies page
    [Documentation]    Validate Download quote letter button

    ClickElement       //*[contains(@class, 'ellipsis d-flex align-items-center justify-content-center mx-auto')]
    ClickText          Policy Document
    sleep              10s


Validate Download signature pack button on my policies page
    [Documentation]    Validate Download signature pack button 

    ClickElement       //*[contains(@class, 'ellipsis d-flex align-items-center justify-content-center mx-auto')]
    ClickText          Signature Pack
    sleep              10s

