*** Settings ***

Resource               ../../resources/common.robot

Library                RetryFailed                 global_retries=${retry_count}

Library                DateTime
Library                OperatingSystem

Test Setup             Setup Browser
Suite Teardown         CloseAllBrowsers

*** Test Cases ***

Login to RiskX
    [Documentation]    Login to RiskX
    [Tags]             Smoke_Test

    Login to RiskX
    VerifyText         Celerity Underwriting        anchor=Home
    ClickText          Home
