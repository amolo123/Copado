*** Settings ***
Resource                        ../../../resources/common.robot
Resource                        ../../../PageObjects/RiskX_PageObjects/PageObjects_Accounts.robot
Resource                        ../../../PageObjects/RiskX_PageObjects/PageObjects_HomePage.robot
Resource                        ../../../PageObjects/RiskX_PageObjects/PCC/PageObjects_PCC_InsuredInfo.robot
Resource                        ../../../PageObjects/RiskX_PageObjects/PCC/PageObjects_PCC_UnderwrittingConsole.robot

Library                         RetryFailed                 global_retries=${retry_count}

Suite Setup                     Setup Browser
Suite Teardown                  CloseAllBrowsers


*** Test Cases ***

Verify elements on Underwriting console page for PCC
    # Author = Amol Gaymukhe
    #TC=111472,111471
    [Documentation]             Field on Insured Info for PCC
    [Tags]                      Smoke_Test_PCC              Smoke_Test

    Creating a new Account
    Enter data on Insured info Page for PCC
    Select Broker
    Select Industry             Basic Materials
    Select Classification       Precious Metals
    Select Product              EPL
    Select Product              Fiduciary
    Select Product              Crime
    ClickText                   NEXT:Underwriting Console >                             anchor=Save
    Verify Underwriter Analysis Page Elements
    Enter Data In D&O
    Enter Data In EPL
    Enter EPL Underwritting Input Fields
    Enter Data In Fiduciary
    Enter Fiduciary Underwritting Input Fields
    Enter Data In Crime
    ClickText                   New Primary Quote


Verify actions performed Underwriting console page for PCC Excess
    # Author = Amol Gaymukhe
    #TC=111472,111471
    [Documentation]             Field on Insured Info for PCC
    [Tags]                      Smoke_Test_PCC              Smoke_Test

    Creating a new Account
    Enter data on Insured info Page for PCC
    Select Broker
    Select Industry             Basic Materials
    Select Classification       Precious Metals
    Select Product              EPL
    Select Product              Fiduciary
    Select Product              Crime
    ClickText                   NEXT:Underwriting Console >                             anchor=Save
    Verify Underwriter Analysis Page Elements
    Enter Data In D&O
    Enter Data In EPL
    Enter EPL Underwritting Input Fields
    Enter Data In Fiduciary
    Enter Fiduciary Underwritting Input Fields
    Enter Data In Crime
    ClickText                   New Excess Quote
