*** Settings ***
Resource                        ../../../resources/common.robot
Resource                        ../../../PageObjects/RiskX_PageObjects/PageObjects_Accounts.robot
Resource                        ../../../PageObjects/RiskX_PageObjects/PageObjects_HomePage.robot
Resource                        ../../../PageObjects/RiskX_PageObjects/PCC/PageObjects_PCC_InsuredInfo.robot
Resource                        ../../../PageObjects/RiskX_PageObjects/PCC/PageObjects_PCC_UnderwrittingConsole.robot
Resource                        ../../../PageObjects/RiskX_PageObjects/PCC/PageObjects_PCC_QuoteConsole.robot

Resource                        ../../../resources/ReadPDF.robot
Resource                        ../../../PageObjects/RiskX_PageObjects/PCC/PageObjects_ReadPDF_PCC.robot
Resource                        ../../../PageObjects/RiskX_PageObjects/PageObjects_PolicyPage.robot
Library                         RetryFailed                 global_retries=${retry_count}

Suite Setup                     Setup Browser
Suite Teardown                  CloseAllBrowsers


*** Test Cases ***

Verify elements on Quote Console Page for Primary PCC
    # Author = Amol Gaymukhe
    #TC=111426,111428
    [Documentation]             Field on Insured Info for PCC
    [Tags]                      Smoke_Test_PCC              Smoke_Test
    Creating a new Account
    Enter data on Insured info Page for PCC
    Select Broker
    Select Industry             Basic Materials
    Select Classification       Precious Metals
    Select Product              EPL
    Select Product              Fiduciary
    Select Product              Crime
    ClickText                   Save
    ClickText                   NEXT:Underwriting Console >                             anchor=Save
    Enter Data In D&O
    Enter Data In EPL
    Enter EPL Underwritting Input Fields
    Enter Data In Fiduciary
    Enter Fiduciary Underwritting Input Fields
    Enter Data In Crime
    ClickText                   New Primary Quote
    Sleep                       30s
    Verify elements on Quote Console Page for Primary
    Click On Rate
    Click On Clone
    Click On Close Quote
    Sleep                       5s
    Click On Endorsement and Subjectivity
    VerifyText                  Endorsement and Subjectivity
    ClickText                   Return Quote Process
    Click On Rate
    Verify elements on Quote Console Page for Primary

Verify elements on Quote Console Page for Excess PCC
    # Author = Amol Gaymukhe
    #TC=111427,111429
    [Documentation]             Field on Insured Info for PCC
    [Tags]                      Smoke_Test_PCC              Smoke_Test
    Creating a new Account
    Enter data on Insured info Page for PCC
    Select Broker
    Select Industry             Basic Materials
    Select Classification       Precious Metals
    Select Product              EPL
    Select Product              Fiduciary
    Select Product              Crime
    ClickText                   NEXT:Underwriting Console >                             anchor=Save
    Enter Data In D&O
    Enter Data In EPL
    Enter EPL Underwritting Input Fields
    Enter Data In Fiduciary
    Enter Fiduciary Underwritting Input Fields
    Enter Data In Crime
    ClickText                   New Excess Quote
    Sleep                       30s
    Verify elements on Quote Console Page for Excess
    Click On Rate
    Verify elements on Quote Console Page for Excess