*** Settings ***
Resource                        ../../../resources/common.robot
Resource                        ../../../PageObjects/RiskX_PageObjects/PageObjects_Accounts.robot
Resource                        ../../../PageObjects/RiskX_PageObjects/PageObjects_HomePage.robot
Resource                        ../../../PageObjects/RiskX_PageObjects/PCC/PageObjects_PCC_InsuredInfo.robot
Resource                        ../../../PageObjects/RiskX_PageObjects/PCC/PageObjects_PCC_UnderwrittingConsole.robot
Resource                        ../../../PageObjects/RiskX_PageObjects/PCC/PageObjects_PCC_QuoteConsole.robot

Resource                        ../../../resources/ReadPDF.robot
Resource                        ../../../PageObjects/RiskX_PageObjects/PCC/PageObjects_ReadPDF_PCC.robot
Resource                        ../../../PageObjects/RiskX_PageObjects/PageObjects_PolicyPage.robot

Library                         RetryFailed                 global_retries=${retry_count}

Suite Setup                     Setup Browser
Suite Teardown                  CloseAllBrowsers


*** Test Cases ***

Verify Policy document for PCC - Primary
    # Author = Amol Gaymukhe
    #TC=111681
    [Documentation]             field on Submission_Info for PCC
    [Tags]                      Smoke_Test_PCC              Smoke_Test
    Creating a new Account
    Enter data on Insured info Page for PCC
    Select Broker
    Select Industry             Basic Materials
    Select Classification       Precious Metals
    Select Product              EPL
    Select Product              Fiduciary
    Select Product              Crime
    ClickText                   NEXT:Underwriting Console >                             anchor=Save
    Enter Data In D&O
    Enter Data In EPL
    Enter EPL Underwritting Input Fields
    Enter Data In Fiduciary
    Enter Fiduciary Underwritting Input Fields
    Enter Data In Crime
    ClickText                   New Primary Quote
    Sleep                       30s
    Get Quote Letter Dynamic Document PCC
    Click On Finalize
    Click On Bind Button
    Generate Document on Policy                             PolicyForm
    Sleep                       15s
    ClickElement                //article[contains(@aria-label,'CelerityRiskPolicyForm')]//a
    ClickText                   View Document
    VerifyText                  Success                     anchor=Document has been downloaded sucessfully!                  timeout=45s    partial_match=false
    Sleep                       15s
    Move to outputdir
    Read Policy Letter Static Document PCC
    Read Policy Letter Dynamic Document PCC


Verify Policy document for PCC - Excess
    # Author = Amol Gaymukhe
    #TC=111682
    [Documentation]             field on Submission_Info for PCC
    [Tags]                      Smoke_Test_PCC              Smoke_Test
    Creating a new Account
    Enter data on Insured info Page for PCC
    Select Broker
    Select Industry             Basic Materials
    Select Classification       Precious Metals
    Select Product              EPL
    Select Product              Fiduciary
    Select Product              Crime
    ClickText                   NEXT:Underwriting Console >                             anchor=Save
    Enter Data In D&O
    Enter Data In EPL
    Enter EPL Underwritting Input Fields
    Enter Data In Fiduciary
    Enter Fiduciary Underwritting Input Fields
    Enter Data In Crime
    ClickText                   New Excess Quote
    Sleep                       30s
    Click On Finalize
    Click On Bind Button
    Generate Document on Policy                             PolicyForm
    Sleep                       15s
    ClickElement                //article[contains(@aria-label,'CelerityRiskExcessPolicy')]//a
    ClickText                   View Document
    VerifyText                  Success                     anchor=Document has been downloaded sucessfully!                  timeout=45s    partial_match=false
    Sleep                       15s
    Move to outputdir
    Read Policy Letter Static Document PCC Excess
    Read Policy Letter Dynamic Document PCC