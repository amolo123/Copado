*** Settings ***
Resource                        ../../../../resources/common.robot
Resource                        ../../../../PageObjects/RiskX_PageObjects/PageObjects_Accounts.robot
Resource                        ../../../../PageObjects/RiskX_PageObjects/PageObjects_HomePage.robot
Resource                        ../../../../PageObjects/RiskX_PageObjects/PCC/PageObjects_PCC_InsuredInfo.robot
Resource                        ../../../../PageObjects/RiskX_PageObjects/PCC/PageObjects_PCC_UnderwrittingConsole.robot
Resource                        ../../../../PageObjects/RiskX_PageObjects/PCC/PageObjects_PCC_QuoteConsole.robot
Resource                        ../../../../PageObjects/RiskX_PageObjects/PageObjects_PolicyPage.robot

Library                         RetryFailed                 global_retries=${retry_count}

Suite Setup                     Setup Browser
Suite Teardown                  CloseAllBrowsers


*** Test Cases ***
Verify Broker on Record Change on PCC Primary
    # Author = Amol Gaymukhe
    #TC=111281
    [Documentation]             field on Submission_Info for PCC
    [Tags]                      Regression_Test_PCC         Regression_Test
    Creating a new Account
    Enter data on Insured info Page for PCC
    Select Broker
    Select Industry             Basic Materials
    Select Classification       Precious Metals
    # Select Product            EPL
    # Select Product            Fiduciary
    # Select Product            Crime
    ClickText                   NEXT:Underwriting Console >                             anchor=Save
    Enter Data In D&O
    # Enter Data In EPL
    # Enter EPL Underwritting Input Fields
    # Enter Data In Fiduciary
    # Enter Fiduciary Underwritting Input Fields
    # Enter Data In Crime
    ClickText                   New Primary Quote
    Sleep                       30s
    Click On Rate
    Sleep                       5s
    Click On Finalize
    Click On Generate Document
    Click On Bind Button
    # Midterm Cancellation Input and select
    # Midterm Cancellation Input
    # Sleep                       45s
    # Midterm Cancellation Flow Complete
    # Change Policy               Reinstatement
    # Reinstatement Input
    # Sleep                       20s
    # ClickText                   Related                     anchor=Details
    # VerifyText                  Reinstatement               anchor=Quote Type
    Broker on Record Change and select
    Broker on Record Change Input
    Update Insured Name and Address Change complete
    Sleep                       20s
    ClickText                   Related                     anchor=Details
    VerifyText                  Broker on Record Change     anchor=Quote Type





Verify Broker on Record Change on PCC Excess
    # Author = Amol Gaymukhe
    #TC=111281
    [Documentation]             field on Submission_Info for PCC
    [Tags]                      Regression_Test_PCC         Regression_Test
    Creating a new Account
    Enter data on Insured info Page for PCC
    Select Broker
    Select Industry             Basic Materials
    Select Classification       Precious Metals
    # Select Product            EPL
    # Select Product            Fiduciary
    # Select Product            Crime
    ClickText                   NEXT:Underwriting Console >                             anchor=Save
    Enter Data In D&O
    # Enter Data In EPL
    # Enter EPL Underwritting Input Fields
    # Enter Data In Fiduciary
    # Enter Fiduciary Underwritting Input Fields
    # Enter Data In Crime
    ClickText                   New Excess Quote
    Sleep                       30s
    Click On Rate
    Sleep                       5s
    Click On Finalize
    Click On Generate Document
    Click On Bind Button
    Broker on Record Change and select
    Broker on Record Change Input
    Update Insured Name and Address Change complete
    Sleep                       20s
    ClickText                   Related                     anchor=Details
    VerifyText                  Broker on Record Change     anchor=Quote Type



Verify ERP on PCC Primary
    # Author = Amol Gaymukhe
    #TC=111281
    [Documentation]             field on Submission_Info for PCC
    [Tags]                      Regression_Test_PCC         Regression_Test
    Creating a new Account
    Enter data on Insured info Page for PCC
    Select Broker
    Select Industry             Basic Materials
    Select Classification       Precious Metals
    # Select Product            EPL
    # Select Product            Fiduciary
    # Select Product            Crime
    ClickText                   NEXT:Underwriting Console >                             anchor=Save
    Enter Data In D&O
    # Enter Data In EPL
    # Enter EPL Underwritting Input Fields
    # Enter Data In Fiduciary
    # Enter Fiduciary Underwritting Input Fields
    # Enter Data In Crime
    ClickText                   New Primary Quote
    Sleep                       30s
    Click On Rate
    Sleep                       5s
    Click On Finalize
    Click On Generate Document
    Click On Bind Button
    Midterm Cancellation Input and select
    Midterm Cancellation Input
    Sleep                       20s
    Midterm Cancellation Flow Complete
    #Change Policy               Extended Reporting Period (ERP)
    Change Policy ERP
    ClickText                   Confirm                     anchor=Back
    Sleep                       20s
    ERP flow Complete
    ClickText                   Related                     anchor=Details
    Sleep                       20s
    VerifyText                  Extended Reporting Period                               anchor=Quote Type




Verify ERP on PCC Excess
    # Author = Amol Gaymukhe
    #TC=111281
    [Documentation]             field on Submission_Info for PCC
    [Tags]                      Regression_Test_PCC         Regression_Test
    Creating a new Account
    Enter data on Insured info Page for PCC
    Select Broker
    Select Industry             Basic Materials
    Select Classification       Precious Metals
    # Select Product            EPL
    # Select Product            Fiduciary
    # Select Product            Crime
    ClickText                   NEXT:Underwriting Console >                             anchor=Save
    Enter Data In D&O
    # Enter Data In EPL
    # Enter EPL Underwritting Input Fields
    # Enter Data In Fiduciary
    # Enter Fiduciary Underwritting Input Fields
    # Enter Data In Crime
    ClickText                   New Excess Quote
    Sleep                       30s
    Click On Rate
    Sleep                       5s
    Click On Finalize
    Click On Generate Document
    Click On Bind Button
    Midterm Cancellation Input and select
    Midterm Cancellation Input
    Sleep                       45s
    Midterm Cancellation Flow Complete
    #Change Policy               Extended Reporting Period (ERP)
    Change Policy ERP
    ClickText                   Confirm                     anchor=Back
    Sleep                       20s
    ERP flow Complete
    ClickText                   Related                     anchor=Details
    VerifyText                  Extended Reporting Period                               anchor=Quote Type




Verify Policy Duration Change on PCC Primary
    # Author = Amol Gaymukhe
    #TC=111281
    [Documentation]             field on Submission_Info for PCC
    [Tags]                      Regression_Test_PCC         Regression_Test
    Creating a new Account
    Enter data on Insured info Page for PCC
    Select Broker
    Select Industry             Basic Materials
    Select Classification       Precious Metals
    # Select Product            EPL
    # Select Product            Fiduciary
    # Select Product            Crime
    ClickText                   NEXT:Underwriting Console >                             anchor=Save
    Enter Data In D&O
    # Enter Data In EPL
    # Enter EPL Underwritting Input Fields
    # Enter Data In Fiduciary
    # Enter Fiduciary Underwritting Input Fields
    # Enter Data In Crime
    ClickText                   New Primary Quote
    Sleep                       30s
    Click On Rate
    Sleep                       5s
    Click On Finalize
    Click On Generate Document
    Click On Bind Button
    Policy Duration Change Input and select
    Policy Duration Change Flow Complete
    Sleep                       20s
    ClickText                   Related                     anchor=Details
    VerifyText                  Policy Duration Change      anchor=Quote Type



Verify Policy Duration Change on PCC Excess
    # Author = Amol Gaymukhe
    #TC=111281
    [Documentation]             field on Submission_Info for PCC
    [Tags]                      Regression_Test_PCC         Regression_Test
    Creating a new Account
    Enter data on Insured info Page for PCC
    Select Broker
    Select Industry             Basic Materials
    Select Classification       Precious Metals
    # Select Product            EPL
    # Select Product            Fiduciary
    # Select Product            Crime
    ClickText                   NEXT:Underwriting Console >                             anchor=Save
    Enter Data In D&O
    # Enter Data In EPL
    # Enter EPL Underwritting Input Fields
    # Enter Data In Fiduciary
    # Enter Fiduciary Underwritting Input Fields
    # Enter Data In Crime
    ClickText                   New Excess Quote
    Sleep                       30s
    Click On Rate
    Sleep                       5s
    Click On Finalize
    Click On Generate Document
    Click On Bind Button
    Policy Duration Change Input and select
    Policy Duration Change Flow Complete
    Sleep                       20s
    ClickText                   Related                     anchor=Details
    VerifyText                  Policy Duration Change      anchor=Quote Type
