*** Settings ***
Resource                        ../../../../resources/common.robot
Resource                        ../../../../PageObjects/RiskX_PageObjects/PageObjects_Accounts.robot
Resource                        ../../../../PageObjects/RiskX_PageObjects/PageObjects_HomePage.robot
Resource                        ../../../../PageObjects/RiskX_PageObjects/PCC/PageObjects_PCC_InsuredInfo.robot
Resource                        ../../../../PageObjects/RiskX_PageObjects/PCC/PageObjects_PCC_UnderwrittingConsole.robot
Resource                        ../../../../PageObjects/RiskX_PageObjects/PCC/PageObjects_PCC_QuoteConsole.robot
Resource                        ../../../../PageObjects/RiskX_PageObjects/PageObjects_PolicyPage.robot

Library                         RetryFailed                 global_retries=${retry_count}

Suite Setup                     Setup Browser
Suite Teardown                  CloseAllBrowsers


*** Test Cases ***
Verify Amendments on PCC Primary
    # Author = Amol Gaymukhe
    #TC=111663
    [Documentation]             field on Submission_Info for PCC
    [Tags]                      Regression_Test_PCC         Regression_Test
    Creating a new Account
    Enter data on Insured info Page for PCC
    Select Broker
    Select Industry             Basic Materials
    Select Classification       Precious Metals
    # Select Product            EPL
    # Select Product            Fiduciary
    # Select Product            Crime
    ClickText                   NEXT:Underwriting Console >                             anchor=Save
    Enter Data In D&O
    # Enter Data In EPL
    # Enter EPL Underwritting Input Fields
    # Enter Data In Fiduciary
    # Enter Fiduciary Underwritting Input Fields
    # Enter Data In Crime
    ClickText                   New Primary Quote
    Sleep                       30s
    Click On Rate
    Sleep                       5s
    Click On Finalize
    Click On Generate Document
    Click On Bind Button
    Change Policy               Amendment
    Amendment Input
    Amendment Flow Complete
    Sleep                       55s
    ClickText                   Related                     anchor=Details
    VerifyText                  Amendment                   anchor=Quote Type


Verify Amendments on PCC Excess 
    # Author = Amol Gaymukhe
    #TC=111663
    [Documentation]             field on Submission_Info for PCC
    [Tags]                      Regression_Test_PCC         Regression_Test
    Creating a new Account
    Enter data on Insured info Page for PCC
    Select Broker
    Select Industry             Basic Materials
    Select Classification       Precious Metals
    # Select Product            EPL
    # Select Product            Fiduciary
    # Select Product            Crime
    ClickText                   NEXT:Underwriting Console >                             anchor=Save
    Enter Data In D&O
    # Enter Data In EPL
    # Enter EPL Underwritting Input Fields
    # Enter Data In Fiduciary
    # Enter Fiduciary Underwritting Input Fields
    # Enter Data In Crime
    ClickText                   New Excess Quote
    Sleep                       30s
    Click On Rate
    Sleep                       5s
    Click On Finalize
    Click On Generate Document
    Click On Bind Button
    Change Policy               Amendment
    Amendment Input
    Amendment Flow Complete
    Sleep                       55s
    ClickText                   Related                     anchor=Details
    VerifyText                  Amendment                   anchor=Quote Type

Verify Name and Address change on PCC Primary
    # Author = Amol Gaymukhe
    #TC=111663
    [Documentation]             field on Submission_Info for PCC
    [Tags]                      Regression_Test_PCC         Regression_Test
    Creating a new Account
    Enter data on Insured info Page for PCC
    Select Broker
    Select Industry             Basic Materials
    Select Classification       Precious Metals
    # Select Product            EPL
    # Select Product            Fiduciary
    # Select Product            Crime
    ClickText                   NEXT:Underwriting Console >                             anchor=Save
    Enter Data In D&O
    # Enter Data In EPL
    # Enter EPL Underwritting Input Fields
    # Enter Data In Fiduciary
    # Enter Fiduciary Underwritting Input Fields
    # Enter Data In Crime
    ClickText                   New Primary Quote
    Sleep                       30s
    Click On Rate
    Sleep                       5s
    Click On Finalize
    Click On Generate Document
    Click On Bind Button
    Change Policy               Update Insured Name or Address
    Update Name and Insured Input
    Sleep                       20s
    Update Name and Insured Address Change Complete
    Sleep                       35s
    ClickText                   Related                     anchor=Details
    VerifyText                  Update Insured Name or Address                          anchor=Quote Type

Verify Name and Address change on PCC Excess
    # Author = Amol Gaymukhe
    #TC=111663
    [Documentation]             field on Submission_Info for PCC
    [Tags]                      Regression_Test_PCC         Regression_Test
    Creating a new Account
    Enter data on Insured info Page for PCC
    Select Broker
    Select Industry             Basic Materials
    Select Classification       Precious Metals
    # Select Product            EPL
    # Select Product            Fiduciary
    # Select Product            Crime
    ClickText                   NEXT:Underwriting Console >                             anchor=Save
    Enter Data In D&O
    # Enter Data In EPL
    # Enter EPL Underwritting Input Fields
    # Enter Data In Fiduciary
    # Enter Fiduciary Underwritting Input Fields
    # Enter Data In Crime
    ClickText                   New Excess Quote
    Sleep                       30s
    Click On Rate
    Sleep                       5s
    Click On Finalize
    Click On Generate Document
    Click On Bind Button
    Change Policy               Update Insured Name or Address
    Update Name and Insured Input
    Sleep                       20s
    Update Name and Insured Address Change Complete
    Sleep                       35s
    ClickText                   Related                     anchor=Details
    VerifyText                  Update Insured Name or Address                          anchor=Quote Type