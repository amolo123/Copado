*** Settings ***
Resource                        ../../../../resources/common.robot
Resource                        ../../../../PageObjects/RiskX_PageObjects/PageObjects_Accounts.robot
Resource                        ../../../../PageObjects/RiskX_PageObjects/PageObjects_HomePage.robot
Resource                        ../../../../PageObjects/RiskX_PageObjects/PCC/PageObjects_PCC_InsuredInfo.robot
Resource                        ../../../../PageObjects/RiskX_PageObjects/PCC/PageObjects_PCC_UnderwrittingConsole.robot
Resource                        ../../../../PageObjects/RiskX_PageObjects/PCC/PageObjects_PCC_QuoteConsole.robot
Resource                        ../../../../PageObjects/RiskX_PageObjects/PageObjects_PolicyPage.robot

Library                         RetryFailed                 global_retries=${retry_count}

Suite Setup                     Setup Browser
Suite Teardown                  CloseAllBrowsers


*** Test Cases ***
Verify PCC Primary E2E NB Flow - RiskX
    # Author = Amol Gaymukhe
    #TC=111663
    [Documentation]             field on Submission_Info for PCC
    [Tags]                      Regression_Test_PCC         Regression_Test
    Creating a new Account
    Enter data on Insured info Page for PCC
    Select Broker
    Select Industry             Basic Materials
    Select Classification       Precious Metals
    Select Product              EPL
    Select Product              Fiduciary
    Select Product              Crime
    ClickText                   NEXT:Underwriting Console >                             anchor=Save
    Enter Data In D&O
    Enter Data In EPL
    Enter EPL Underwritting Input Fields
    Enter Data In Fiduciary
    Enter Fiduciary Underwritting Input Fields
    Enter Data In Crime
    ClickText                   New Primary Quote
    Sleep                       30s
    Click On Rate
    Sleep                       5s
    Click On Finalize
    Click On Generate Document
    Click On Bind Button
    Generate Document on Policy                             PolicyForm


Verify PCC Excess E2E NB Flow - RiskX 
    # Author = Amol Gaymukhe
    #TC=111663
    [Documentation]             field on Submission_Info for PCC
    [Tags]                      Regression_Test_PCC         Regression_Test
    Creating a new Account
    Enter data on Insured info Page for PCC
    Select Broker
    Select Industry             Basic Materials
    Select Classification       Precious Metals
    Select Product              EPL
    Select Product              Fiduciary
    Select Product              Crime
    ClickText                   NEXT:Underwriting Console >                             anchor=Save
    Enter Data In D&O
    Enter Data In EPL
    Enter EPL Underwritting Input Fields
    Enter Data In Fiduciary
    Enter Fiduciary Underwritting Input Fields
    Enter Data In Crime
    ClickText                   New Primary Quote
    Sleep                       30s
    Click On Rate
    Sleep                       5s
    Click On Finalize
    Click On Generate Document
    Click On Bind Button
    Generate Document on Policy                             PolicyForm

Verify Renewals RiskX PCC Primary  
    # Author = Amol Gaymukhe
    #TC=111663
    [Documentation]             field on Submission_Info for Cyber
    [Tags]                      Regression_Test_PCC         Regression_Test
    Creating a new Account
    Enter data on Insured info Page for PCC
    Select Broker
    Select Industry             Basic Materials
    Select Classification       Precious Metals
    # Select Product            EPL
    # Select Product            Fiduciary
    # Select Product            Crime
    ClickText                   NEXT:Underwriting Console >                             anchor=Save
    Enter Data In D&O
    # Enter Data In EPL
    # Enter EPL Underwritting Input Fields
    # Enter Data In Fiduciary
    # Enter Fiduciary Underwritting Input Fields
    # Enter Data In Crime
    ClickText                   New Primary Quote
    Sleep                       30s
    Click On Rate
    Sleep                       5s
    Click On Finalize
    Click On Generate Document
    Click On Bind Button
    Show More Actions
    Sleep                       10s
    ClickText                   Renewal                     anchor=Send Mail
    Sleep                       30s
    VerifyText                  Account Information
    ClickText                   NEXT:Underwriting Console
    VerifyText                  D&O
    ClickText                   Quote Console
    Click On Rate
    Click On Finalize
    Click On Bind Button
    Sleep                       5s
    ClickText                   Related                     anchor=Details
    VerifyText                  Renewal                     anchor=Quote Type


Verify Renewals RiskX PCC Excess   
    # Author = Amol Gaymukhe
    #TC=111663
    [Documentation]             field on Submission_Info for PCC
    [Tags]                      Regression_Test_PCC         Regression_Test
    Creating a new Account
    Enter data on Insured info Page for PCC
    Select Broker
    Select Industry             Basic Materials
    Select Classification       Precious Metals
    # Select Product            EPL
    # Select Product            Fiduciary
    # Select Product            Crime
    ClickText                   NEXT:Underwriting Console >                             anchor=Save
    Enter Data In D&O
    # Enter Data In EPL
    # Enter EPL Underwritting Input Fields
    # Enter Data In Fiduciary
    # Enter Fiduciary Underwritting Input Fields
    # Enter Data In Crime
    ClickText                   New Primary Quote
    Sleep                       30s
    Click On Rate
    Sleep                       5s
    Click On Finalize
    Click On Generate Document
    Click On Bind Button
    Show More Actions
    Sleep                       10s
    ClickText                   Renewal                     anchor=Send Mail
    Sleep                       30s
    VerifyText                  Account Information
    ClickText                   NEXT:Underwriting Console
    VerifyText                  D&O
    ClickText                   Quote Console
    Click On Rate
    Click On Finalize
    Click On Bind Button
    Sleep                       10s
    ClickText                   Related                     anchor=Details
    VerifyText                  Renewal                     anchor=Quote Type
