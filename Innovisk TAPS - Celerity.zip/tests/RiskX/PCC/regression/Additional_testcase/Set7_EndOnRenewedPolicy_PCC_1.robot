*** Settings ***
Resource                        ../../../../../resources/common.robot
Resource                        ../../../../../PageObjects/RiskX_PageObjects/PageObjects_Accounts.robot
Resource                        ../../../../../PageObjects/RiskX_PageObjects/PageObjects_HomePage.robot
Resource                        ../../../../../PageObjects/RiskX_PageObjects/PCC/PageObjects_PCC_InsuredInfo.robot
Resource                        ../../../../../PageObjects/RiskX_PageObjects/PCC/PageObjects_PCC_UnderwrittingConsole.robot
Resource                        ../../../../../PageObjects/RiskX_PageObjects/PCC/PageObjects_PCC_QuoteConsole.robot
Resource                        ../../../../../PageObjects/RiskX_PageObjects/PageObjects_PolicyPage.robot

Library                         RetryFailed                 global_retries=${retry_count}

Suite Setup                     Setup Browser
Suite Teardown                  CloseAllBrowsers


*** Test Cases ***
To verify Amendment transaction on renewed policy PCC Primary
    # Author = Pinki Lubana
    #TC=122528
    [Documentation]             Change endorsement on Renewed policy
    [Tags]                      Regression_Test_PCC         Regression_Test
    Creating a new Account
    Enter data on Insured info Page for PCC
    Select Broker
    Select Industry             Basic Materials
    Select Classification       Precious Metals
    # Select Product            EPL
    # Select Product            Fiduciary
    # Select Product            Crime
    ClickText                   NEXT:Underwriting Console >                             anchor=Save
    Enter Data In D&O
    # Enter Data In EPL
    # Enter EPL Underwritting Input Fields
    # Enter Data In Fiduciary
    # Enter Fiduciary Underwritting Input Fields
    # Enter Data In Crime
    ClickText                   New Primary Quote
    Sleep                       30s
    Click On Rate
    Sleep                       5s
    Click On Finalize
    Click On Generate Document
    Click On Bind Button
    Show More Actions
    Sleep                       10s
    ClickText                   Renewal                     anchor=Send Mail
    Sleep                       30s
    VerifyText                  Account Information
    ClickText                   NEXT:Underwriting Console
    VerifyText                  D&O
    ClickText                   Quote Console
    Click On Rate
    Click On Finalize
    Click On Bind Button
    Sleep                       5s
    ClickText                   Related                     anchor=Details
    VerifyText                  Renewal                     anchor=Quote Type
    Change Policy               Amendment
    Amendment Input
    Amendment Flow Complete
    Sleep                       55s
    ClickText                   Related                     anchor=Details
    VerifyText                  Renewal                     anchor=Quote Type
    VerifyText                  Amendment                   anchor=Quote Type


To verify Amendment transaction on renewed policy PCC Excess
    # Author = Pinki Lubana
    #TC=122529
    [Documentation]             Change endorsement on Renewed policy
    [Tags]                      Regression_Test_PCC         Regression_Test
    Creating a new Account
    Enter data on Insured info Page for PCC
    Select Broker
    Select Industry             Basic Materials
    Select Classification       Precious Metals
    # Select Product            EPL
    # Select Product            Fiduciary
    # Select Product            Crime
    ClickText                   NEXT:Underwriting Console >                             anchor=Save
    Enter Data In D&O
    # Enter Data In EPL
    # Enter EPL Underwritting Input Fields
    # Enter Data In Fiduciary
    # Enter Fiduciary Underwritting Input Fields
    # Enter Data In Crime
    ClickText                   New Excess Quote
    Sleep                       30s
    Click On Rate
    Sleep                       5s
    Click On Finalize
    Click On Generate Document
    Click On Bind Button
    Show More Actions
    Sleep                       10s
    ClickText                   Renewal                     anchor=Send Mail
    Sleep                       30s
    VerifyText                  Account Information
    ClickText                   NEXT:Underwriting Console
    VerifyText                  D&O
    ClickText                   Quote Console
    Click On Rate
    Click On Finalize
    Click On Bind Button
    Sleep                       5s
    ClickText                   Related                     anchor=Details
    VerifyText                  Renewal                     anchor=Quote Type
    Change Policy               Amendment
    Amendment Input
    Amendment Flow Complete
    Sleep                       55s
    ClickText                   Related                     anchor=Details
    VerifyText                  Renewal                     anchor=Quote Type
    VerifyText                  Amendment                   anchor=Quote Type



To verify Midterm cancel transaction on Renewed policy for PCC Primary
    # Author = Pinki Lubana
    #TC=122530
    [Documentation]             Change endorsement on Renewed policy
    [Tags]                      Regression_Test_PCC         Regression_Test
    Creating a new Account
    Enter data on Insured info Page for PCC
    Select Broker
    Select Industry             Basic Materials
    Select Classification       Precious Metals
    # Select Product            EPL
    # Select Product            Fiduciary
    # Select Product            Crime
    ClickText                   NEXT:Underwriting Console >                             anchor=Save
    Enter Data In D&O
    # Enter Data In EPL
    # Enter EPL Underwritting Input Fields
    # Enter Data In Fiduciary
    # Enter Fiduciary Underwritting Input Fields
    # Enter Data In Crime
    ClickText                   New Primary Quote
    Sleep                       30s
    Click On Rate
    Sleep                       5s
    Click On Finalize
    Click On Generate Document
    Click On Bind Button
    Show More Actions
    Sleep                       10s
    ClickText                   Renewal                     anchor=Send Mail
    Sleep                       30s
    VerifyText                  Account Information
    ClickText                   NEXT:Underwriting Console
    VerifyText                  D&O
    ClickText                   Quote Console
    Click On Rate
    Click On Finalize
    Click On Bind Button
    Sleep                       5s
    ClickText                   Related                     anchor=Details
    VerifyText                  Renewal                     anchor=Quote Type
    Midterm Cancellation Input and select
    Midterm Cancellation Input
    Sleep                       45s
    Midterm Cancellation Flow Complete
    Sleep                       10s
    ClickText                   Related                     anchor=Details
    VerifyText                  Renewal                     anchor=Quote Type
    VerifyText                  Midterm Cancellation        anchor=Quote Type
    

To verify Midterm cancel transaction on Renewed policy for PCC Excess
    # Author = Pinki Lubana
    #TC=122531
    [Documentation]             Change endorsement on Renewed policy
    [Tags]                      Regression_Test_PCC         Regression_Test
    Creating a new Account
    Enter data on Insured info Page for PCC
    Select Broker
    Select Industry             Basic Materials
    Select Classification       Precious Metals
    # Select Product            EPL
    # Select Product            Fiduciary
    # Select Product            Crime
    ClickText                   NEXT:Underwriting Console >                             anchor=Save
    Enter Data In D&O
    # Enter Data In EPL
    # Enter EPL Underwritting Input Fields
    # Enter Data In Fiduciary
    # Enter Fiduciary Underwritting Input Fields
    # Enter Data In Crime
    ClickText                   New Excess Quote
    Sleep                       30s
    Click On Rate
    Sleep                       5s
    Click On Finalize
    Click On Generate Document
    Click On Bind Button
    Show More Actions
    Sleep                       10s
    ClickText                   Renewal                     anchor=Send Mail
    Sleep                       30s
    VerifyText                  Account Information
    ClickText                   NEXT:Underwriting Console
    VerifyText                  D&O
    ClickText                   Quote Console
    Click On Rate
    Click On Finalize
    Click On Bind Button
    Sleep                       5s
    ClickText                   Related                     anchor=Details
    VerifyText                  Renewal                     anchor=Quote Type
    Midterm Cancellation Input and select
    Midterm Cancellation Input
    Sleep                       45s
    Midterm Cancellation Flow Complete
    Sleep                       10s
    ClickText                   Related                     anchor=Details
    VerifyText                  Renewal                     anchor=Quote Type
    VerifyText                  Midterm Cancellation        anchor=Quote Type