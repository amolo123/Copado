*** Settings ***
Resource                        ../../../../../resources/common.robot
Resource                        ../../../../../PageObjects/RiskX_PageObjects/PageObjects_Accounts.robot
Resource                        ../../../../../PageObjects/RiskX_PageObjects/PageObjects_HomePage.robot
Resource                        ../../../../../PageObjects/RiskX_PageObjects/PCC/PageObjects_PCC_InsuredInfo.robot
Resource                        ../../../../../PageObjects/RiskX_PageObjects/PCC/PageObjects_PCC_UnderwrittingConsole.robot
Resource                        ../../../../../PageObjects/RiskX_PageObjects/PCC/PageObjects_PCC_QuoteConsole.robot
Resource                        ../../../../../PageObjects/RiskX_PageObjects/PageObjects_PolicyPage.robot

Library                         RetryFailed                 global_retries=${retry_count}

Suite Setup                     Setup Browser
Suite Teardown                  CloseAllBrowsers


*** Test Cases ***

To verify Multiple Change endorsement on single PCC Primary policy 
    # Author = Pinki Lubana
    #TC=122380,
    [Documentation]             Multiple change endorsement
    [Tags]                      Regression_Test_PCC         Regression_Test
    Creating a new Account
    Enter data on Insured info Page for PCC
    Select Broker
    Select Industry             Basic Materials
    Select Classification       Precious Metals
    ClickText                   NEXT:Underwriting Console >                             anchor=Save
    Enter Data In D&O
    ClickText                   New Primary Quote
    Sleep                       30s
    Click On Rate
    Sleep                       5s
    Click On Finalize
    Click On Generate Document
    Click On Bind Button
    Sleep                       5s
    Change Policy               Amendment
    Amendment Input
    Amendment Flow Complete
    Sleep                       5s
    ClickText                   Related                     anchor=Details
    VerifyText                  New Business                anchor=Quote Type
    VerifyText                  Amendment                   anchor=Quote Type
    Midterm Cancellation Input and select
    Midterm Cancellation Input
    Sleep                       45s
    Midterm Cancellation Flow Complete
    Sleep                       10s
    VerifyText                  New Business                anchor=Quote Type
    VerifyText                  Amendment                   anchor=Quote Type
    VerifyText                  Midterm Cancellation        anchor=Quote Type
    Change Policy               Reinstatement
    Reinstatement Input
    Sleep                       20s
    ClickText                   Related                     anchor=Details
    VerifyText                  New Business                anchor=Quote Type
    VerifyText                  Amendment                   anchor=Quote Type
    VerifyText                  Midterm Cancellation        anchor=Quote Type
    VerifyText                  Reinstatement               anchor=Quote Type
    Policy Duration Change Input and select
    Policy Duration Change Flow Complete
    Sleep                       20s
    ClickText                   Related                     anchor=Details
    VerifyText                  New Business                anchor=Quote Type
    VerifyText                  Amendment                   anchor=Quote Type
    VerifyText                  Midterm Cancellation        anchor=Quote Type
    VerifyText                  Reinstatement               anchor=Quote Type
    VerifyText                  Policy Duration Change      anchor=Quote Type


To verify Multiple Change endorsement on single PCC Excess policy 
    # Author = Pinki Lubana
    #TC=122490
    [Documentation]             Multiple change endorsement
    [Tags]                      Regression_Test_PCC         Regression_Test
    Creating a new Account
    Enter data on Insured info Page for PCC
    Select Broker
    Select Industry             Basic Materials
    Select Classification       Precious Metals
    ClickText                   NEXT:Underwriting Console >                             anchor=Save
    Enter Data In D&O
    ClickText                   New Excess Quote
    Sleep                       30s
    Click On Rate
    Sleep                       5s
    Click On Finalize
    Click On Generate Document
    Click On Bind Button
    Sleep                       5s
    Change Policy               Amendment
    Amendment Input
    Amendment Flow Complete
    Sleep                       5s
    ClickText                   Related                     anchor=Details
    VerifyText                  New Business                anchor=Quote Type
    VerifyText                  Amendment                   anchor=Quote Type
    Midterm Cancellation Input and select
    Midterm Cancellation Input
    Sleep                       45s
    Midterm Cancellation Flow Complete
    Sleep                       10s
    ClickText                   Related                     anchor=Details
    VerifyText                  New Business                anchor=Quote Type
    VerifyText                  Amendment                   anchor=Quote Type
    VerifyText                  Midterm Cancellation        anchor=Quote Type
    Change Policy               Reinstatement
    Reinstatement Input
    Sleep                       20s
    ClickText                   Related                     anchor=Details
    VerifyText                  New Business                anchor=Quote Type
    VerifyText                  Amendment                   anchor=Quote Type
    VerifyText                  Midterm Cancellation        anchor=Quote Type
    VerifyText                  Reinstatement               anchor=Quote Type
    Policy Duration Change Input and select
    Policy Duration Change Flow Complete
    Sleep                       20s
    ClickText                   Related                     anchor=Details
    VerifyText                  New Business                anchor=Quote Type
    VerifyText                  Amendment                   anchor=Quote Type
    VerifyText                  Midterm Cancellation        anchor=Quote Type
    VerifyText                  Reinstatement               anchor=Quote Type
    VerifyText                  Policy Duration Change      anchor=Quote Type