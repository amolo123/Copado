*** Settings ***
Resource                        ../../../../../resources/common.robot
Resource                        ../../../../../PageObjects/RiskX_PageObjects/PageObjects_Accounts.robot
Resource                        ../../../../../PageObjects/RiskX_PageObjects/PageObjects_HomePage.robot
Resource                        ../../../../../PageObjects/RiskX_PageObjects/PCC/PageObjects_PCC_InsuredInfo.robot
Resource                        ../../../../../PageObjects/RiskX_PageObjects/PCC/PageObjects_PCC_UnderwrittingConsole.robot
Resource                        ../../../../../PageObjects/RiskX_PageObjects/PCC/PageObjects_PCC_QuoteConsole.robot
Resource                        ../../../../../resources/ReadPDF.robot
Resource                        ../../../../../PageObjects/RiskX_PageObjects/PCC/PageObjects_ReadPDF_PCC.robot
Resource                        ../../.././../../PageObjects/RiskX_PageObjects/PageObjects_PolicyPage.robot
Resource                        ../../../../../PageObjects/RiskX_PageObjects/PageObjects_MultipleIndustries.robot


Library                         RetryFailed                 global_retries=${retry_count}

Suite Setup                     Setup Browser
Suite Teardown                  CloseAllBrowsers

*** Test Cases ***
Verify Eligible Industry for PCC
    # Author = Mitesh Patil
    #TC=121985
    [Documentation]             field on Submission_Info for MPL
    [Tags]                      Smoke_Test_PCC             Smoke_Test
    Creating a new Account
    Enter data on Insured info Page for PCC
    Select Broker and Click On Next
    ClickText                   NEXT:Submission Info >
    
    Select Eligible industry on PCC                       Business Services    Auctioneer
 
    Select Eligible industry on PCC                       Real Estate    Commercial Appraisers
 
    Select Eligible industry on PCC                       Biotechnology    Pharmaceutical
 
    Select Eligible industry on PCC                       Construction    Building Construction