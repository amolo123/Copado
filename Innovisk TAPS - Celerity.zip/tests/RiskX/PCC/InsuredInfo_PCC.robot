*** Settings ***
Resource                        ../../../resources/common.robot
Resource                        ../../../PageObjects/RiskX_PageObjects/PageObjects_Accounts.robot
Resource                        ../../../PageObjects/RiskX_PageObjects/PageObjects_HomePage.robot
Resource                        ../../../PageObjects/RiskX_PageObjects/PCC/PageObjects_PCC_InsuredInfo.robot

Library                         RetryFailed                 global_retries=${retry_count}

Suite Setup                     Setup Browser
Suite Teardown                  CloseAllBrowsers


*** Test Cases ***

Verify Save Button and Next Submission Info Functionality on Insured Info Page - PCC
    # Author = Amol Gaymukhe
    #TC=111472,111471
    [Documentation]             Field on Insured Info for PCC
    [Tags]                      Smoke_Test_PCC              Smoke_Test

    Creating a new Account
    Validate field on Insured Info page for PCC
    Click On Account Link
