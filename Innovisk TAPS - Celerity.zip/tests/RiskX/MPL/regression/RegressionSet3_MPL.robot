*** Settings ***
Resource                        ../../../../resources/common.robot
Resource                        ../../../../PageObjects/RiskX_PageObjects/PageObjects_Accounts.robot
Resource                        ../../../../PageObjects/RiskX_PageObjects/MPL/PageObjects_MPL_InsuredInfo.robot
Resource                        ../../../../PageObjects/RiskX_PageObjects/MPL/PageObjects_MPL_SubmissionInfo.robot
Resource                        ../../../../PageObjects/RiskX_PageObjects/MPL/PageObjects_MPL_UnderwriterAnalysis.robot
Resource                        ../../../../PageObjects/RiskX_PageObjects/MPL/PageObjects_MPL_CompareAndRateQuote.robot
Resource                        ../../../../PageObjects/RiskX_PageObjects/PageObjects_PolicyPage.robot

Library                         RetryFailed                 global_retries=${retry_count}
Suite Setup                     Setup Browser
Suite Teardown                  CloseAllBrowsers

*** Test Cases ***
Verify Amendments on MPL Primary
    # Author = Amol Gaymukhe
    #TC=111281
    [Documentation]             field on Submission_Info for MPL
    [Tags]                      Regression_Test_MPL         Regression_Test
    Creating a new Account
    Enter data on Insured info Page for MPL
    ClickText                   NEXT:Submission Info >
    Select Broker and Click On Next
    Select Industry             Business Services
    Select Classification       Administrators
    ClickText                   Save                        anchor=NEXT:Underwriter Analysis >
    Sleep                       10s
    ClickText                   NEXT:Underwriter Analysis >
    Enter Data in Underwriter Analysis Page
    ClickText                   Save                        anchor=Check Risk Health
    VerifyText                  Success                     anchor=Update records successfully!
    ClickText                   Check Risk Health           anchor=Save
    ClickText                   New Primary Quote
    Sleep                       20s
    VerifyText                  Quote Console
    Click On Finalize
    Sleep                       30s
    Click On Generate Document
    Click On Bind Button
    Change Policy               Amendment
    Amendment Input
    Amendment Flow Complete
    Sleep                       55s
    ClickText                   Related                     anchor=Details
    VerifyText                  Amendment                   anchor=Quote Type


Verify Amendments on MPL Excess 
    # Author = Amol Gaymukhe
    #TC=111281
    [Documentation]             field on Submission_Info for MPL
    [Tags]                      Regression_Test_MPL         Regression_Test
    Creating a new Account
    Enter data on Insured info Page for MPL
    ClickText                   NEXT:Submission Info >
    Select Broker and Click On Next
    Select Industry             Business Services
    Select Classification       Administrators
    ClickText                   Save                        anchor=NEXT:Underwriter Analysis >
    Sleep                       10s
    ClickText                   NEXT:Underwriter Analysis >
    Enter Data in Underwriter Analysis Page
    ClickText                   Save                        anchor=Check Risk Health
    VerifyText                  Success                     anchor=Update records successfully!
    ClickText                   Check Risk Health           anchor=Save
    ClickText                   New Excess Quote
    Sleep                       20s
    VerifyText                  Quote Console
    Click On Finalize
    Sleep                       30s
    Click On Generate Document
    Click On Bind Button
    Change Policy               Amendment
    Amendment Input
    Amendment Flow Complete
    Sleep                       55s
    ClickText                   Related                     anchor=Details
    VerifyText                  Amendment                   anchor=Quote Type


Verify Name and Address change on MPL Primary
    # Author = Amol Gaymukhe
    #TC=111281
    [Documentation]             field on Submission_Info for MPL
    [Tags]                      Regression_Test_MPL         Regression_Test
    Creating a new Account
    Enter data on Insured info Page for MPL
    ClickText                   NEXT:Submission Info >
    Select Broker and Click On Next
    Select Industry             Business Services
    Select Classification       Administrators
    ClickText                   Save                        anchor=NEXT:Underwriter Analysis >
    Sleep                       10s
    ClickText                   NEXT:Underwriter Analysis >
    Enter Data in Underwriter Analysis Page
    ClickText                   Save                        anchor=Check Risk Health
    VerifyText                  Success                     anchor=Update records successfully!
    ClickText                   Check Risk Health           anchor=Save
    ClickText                   New Primary Quote
    Sleep                       20s
    VerifyText                  Quote Console
    Click On Finalize
    Click On Bind Button
    Change Policy               Update Insured Name or Address
    Update Name and Insured Input
    Sleep                       20s
    Update Name and Insured Address Change Complete
    Sleep                       35s
    ClickText                   Related                     anchor=Details
    VerifyText                  Update Insured Name or Address                          anchor=Quote Type


Verify Name and Address change on MPL Excess 
    # Author = Amol Gaymukhe
    #TC=111281
    [Documentation]             field on Submission_Info for MPL
    [Tags]                      Regression_Test_MPL         Regression_Test
    Creating a new Account
    Enter data on Insured info Page for MPL
    ClickText                   NEXT:Submission Info >
    Select Broker and Click On Next
    Select Industry             Business Services
    Select Classification       Administrators
    ClickText                   Save                        anchor=NEXT:Underwriter Analysis >
    Sleep                       10s
    ClickText                   NEXT:Underwriter Analysis >
    Enter Data in Underwriter Analysis Page
    ClickText                   Save                        anchor=Check Risk Health
    VerifyText                  Success                     anchor=Update records successfully!
    ClickText                   Check Risk Health           anchor=Save
    ClickText                   New Excess Quote
    Sleep                       20s
    VerifyText                  Quote Console
    Click On Finalize
    Sleep                       30s
    Click On Generate Document
    Click On Bind Button
    Change Policy               Update Insured Name or Address
    Update Name and Insured Input
    Sleep                       20s
    Update Name and Insured Address Change Complete
    Sleep                       35s
    ClickText                   Related                     anchor=Details
    VerifyText                  Update Insured Name or Address                          anchor=Quote Type
