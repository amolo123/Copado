*** Settings ***
Resource                        ../../../../../resources/common.robot
Resource                        ../../../../../PageObjects/RiskX_PageObjects/PageObjects_Accounts.robot
Resource                        ../../../../../PageObjects/RiskX_PageObjects/MPL/PageObjects_MPL_InsuredInfo.robot
Resource                        ../../../../../PageObjects/RiskX_PageObjects/MPL/PageObjects_MPL_SubmissionInfo.robot
Resource                        ../../../../../PageObjects/RiskX_PageObjects/MPL/PageObjects_MPL_UnderwriterAnalysis.robot
Resource                        ../../../../../PageObjects/RiskX_PageObjects/MPL/PageObjects_MPL_CompareAndRateQuote.robot
Resource                        ../../../../../PageObjects/RiskX_PageObjects/PageObjects_PolicyPage.robot

Library                         RetryFailed                 global_retries=${retry_count}
Suite Setup                     Setup Browser
Suite Teardown                  CloseAllBrowsers



*** Test Cases ***
To verify Amendment transaction on renewed policy MPL Primary  
    # Author = Saurabh Salgaonkar
    #TC=122516
    [Documentation]             field on Submission_Info for MPL
    [Tags]                      Regression_Test_MPL         Regression_Test
    Creating a new Account
    Enter data on Insured info Page for MPL
    ClickText                   NEXT:Submission Info >
    Select Broker and Click On Next
    Select Industry             Business Services
    Select Classification       Administrators
    ClickText                   Save                        anchor=NEXT:Underwriter Analysis >
    Sleep                       10s
    ClickText                   NEXT:Underwriter Analysis >
    Enter Data in Underwriter Analysis Page
    ClickText                   Save                        anchor=Check Risk Health
    VerifyText                  Success                     anchor=Update records successfully!
    ClickText                   Check Risk Health           anchor=Save
    ClickText                   New Primary Quote
    Sleep                       20s
    VerifyText                  Quote Console
    Click On Finalize
    Sleep                       10s
    Click On Bind Button
    Show More Actions
    Sleep                       10s
    ClickText                   Renewal                     anchor=Send Mail
    Sleep                       30s
    VerifyText                  Submission Info
    ClickText                   NEXT:Underwriter Analysis >
    VerifyText                  Industry Class
    ClickText                   Compare & Rate Quotes
    Sleep                       20s
    VerifyText                  Quote Console
    Click On Rate
    Click On Finalize
    Click On Bind Button
    ClickText                   Related                     anchor=Details
    VerifyText                  Renewal                     anchor=Quote Type
    Change Policy               Amendment
    Amendment Input
    Amendment Flow Complete
    Sleep                       55s
    ClickText                   Related                     anchor=Details
    VerifyText                  Renewal                     anchor=Quote Type
    VerifyText                  Amendment                   anchor=Quote Type

To verify Amendment transaction on renewed policy MPL Excess  
    # Author = Saurabh Salgaonkar
    #TC=122516
    [Documentation]             field on Submission_Info for MPL
    [Tags]                      Regression_Test_MPL         Regression_Test
    Creating a new Account
    Enter data on Insured info Page for MPL
    ClickText                   NEXT:Submission Info >
    Select Broker and Click On Next
    Select Industry             Business Services
    Select Classification       Administrators
    ClickText                   Save                        anchor=NEXT:Underwriter Analysis >
    Sleep                       10s
    ClickText                   NEXT:Underwriter Analysis >
    Enter Data in Underwriter Analysis Page
    ClickText                   Save                        anchor=Check Risk Health
    VerifyText                  Success                     anchor=Update records successfully!
    ClickText                   Check Risk Health           anchor=Save
    ClickText                   New Primary Quote
    Sleep                       20s
    VerifyText                  Quote Console
    Click On Finalize
    Sleep                       10s
    Click On Bind Button
    Show More Actions
    Sleep                       10s
    ClickText                   Renewal                     anchor=Send Mail
    Sleep                       30s
    VerifyText                  Submission Info
    ClickText                   NEXT:Underwriter Analysis >
    VerifyText                  Industry Class
    ClickText                   Compare & Rate Quotes
    Sleep                       20s
    VerifyText                  Quote Console
    Click On Rate
    Click On Finalize
    Click On Bind Button
    ClickText                   Related                     anchor=Details
    VerifyText                  Renewal                     anchor=Quote Type
    Change Policy               Amendment
    Amendment Input
    Amendment Flow Complete
    Sleep                       55s
    ClickText                   Related                     anchor=Details
    VerifyText                  Renewal                     anchor=Quote Type
    VerifyText                  Amendment                   anchor=Quote Type

To verify Midterm cancel transaction on Renewed policy for MPL Primary 
    # Author = Saurabh Salgaonkar
    #TC=122518
    [Documentation]             field on Submission_Info for MPL
    [Tags]                      Regression_Test_MPL         Regression_Test
    Creating a new Account
    Enter data on Insured info Page for MPL
    ClickText                   NEXT:Submission Info >
    Select Broker and Click On Next
    Select Industry             Business Services
    Select Classification       Administrators
    ClickText                   Save                        anchor=NEXT:Underwriter Analysis >
    Sleep                       10s
    ClickText                   NEXT:Underwriter Analysis >
    Enter Data in Underwriter Analysis Page
    ClickText                   Save                        anchor=Check Risk Health
    VerifyText                  Success                     anchor=Update records successfully!
    ClickText                   Check Risk Health           anchor=Save
    ClickText                   New Primary Quote
    Sleep                       20s
    VerifyText                  Quote Console
    Click On Finalize
    Sleep                       10s
    Click On Bind Button
    Show More Actions
    Sleep                       10s
    ClickText                   Renewal                     anchor=Send Mail
    Sleep                       30s
    VerifyText                  Submission Info
    ClickText                   NEXT:Underwriter Analysis >
    VerifyText                  Industry Class
    ClickText                   Compare & Rate Quotes
    Sleep                       20s
    VerifyText                  Quote Console
    Click On Rate
    Click On Finalize
    Click On Bind Button
    ClickText                   Related                     anchor=Details
    VerifyText                  Renewal                     anchor=Quote Type
    Midterm Cancellation Input and select
    Midterm Cancellation Input
    Midterm Cancellation Flow Complete
    Sleep                       25s
    ClickText                   Related                     anchor=Details
    VerifyText                  Renewal                     anchor=Quote Type
    VerifyText                  Midterm Cancellation        anchor=Quote Type

To verify Midterm cancel transaction on Renewed policy for MPL Excess
    # Author = Saurabh Salgaonkar
    #TC=122519
    [Documentation]             field on Submission_Info for MPL
    [Tags]                      Regression_Test_MPL         Regression_Test
    Creating a new Account
    Enter data on Insured info Page for MPL
    ClickText                   NEXT:Submission Info >
    Select Broker and Click On Next
    Select Industry             Business Services
    Select Classification       Administrators
    ClickText                   Save                        anchor=NEXT:Underwriter Analysis >
    Sleep                       10s
    ClickText                   NEXT:Underwriter Analysis >
    Enter Data in Underwriter Analysis Page
    ClickText                   Save                        anchor=Check Risk Health
    VerifyText                  Success                     anchor=Update records successfully!
    ClickText                   Check Risk Health           anchor=Save
    ClickText                   New Primary Quote
    Sleep                       20s
    VerifyText                  Quote Console
    Click On Finalize
    Sleep                       10s
    Click On Bind Button
    Show More Actions
    Sleep                       10s
    ClickText                   Renewal                     anchor=Send Mail
    Sleep                       30s
    VerifyText                  Submission Info
    ClickText                   NEXT:Underwriter Analysis >
    VerifyText                  Industry Class
    ClickText                   Compare & Rate Quotes
    Sleep                       20s
    VerifyText                  Quote Console
    Click On Rate
    Click On Finalize
    Click On Bind Button
    ClickText                   Related                     anchor=Details
    VerifyText                  Renewal                     anchor=Quote Type
    Midterm Cancellation Input and select
    Midterm Cancellation Input
    Midterm Cancellation Flow Complete
    Sleep                       45s
    ClickText                   Related                     anchor=Details
    VerifyText                  Renewal                     anchor=Quote Type
    VerifyText                  Midterm Cancellation        anchor=Quote Type