*** Settings ***
Resource                        ../../../../../resources/common.robot
Resource                        ../../../../../PageObjects/RiskX_PageObjects/PageObjects_Accounts.robot
Resource                        ../../../../../PageObjects/RiskX_PageObjects/MPL/PageObjects_MPL_InsuredInfo.robot
Resource                        ../../../../../PageObjects/RiskX_PageObjects/MPL/PageObjects_MPL_SubmissionInfo.robot
Resource                        ../../../../../PageObjects/RiskX_PageObjects/MPL/PageObjects_MPL_UnderwriterAnalysis.robot
Resource                        ../../../../../PageObjects/RiskX_PageObjects/MPL/PageObjects_MPL_CompareAndRateQuote.robot
Resource                        ../../../../../PageObjects/RiskX_PageObjects/PageObjects_PolicyPage.robot

Library                         RetryFailed                 global_retries=${retry_count}
Suite Setup                     Setup Browser
Suite Teardown                  CloseAllBrowsers



*** Test Cases ***
to verify Flat cancel on renewed policy for MPL Primary  
    # Author = Saurabh Salgaonkar
    #TC=122520
    [Documentation]             field on Submission_Info for MPL
    [Tags]                      Regression_Test_MPL         Regression_Test
    Creating a new Account
    Enter data on Insured info Page for MPL
    ClickText                   NEXT:Submission Info >
    Select Broker and Click On Next
    Select Industry             Business Services
    Select Classification       Administrators
    ClickText                   Save                        anchor=NEXT:Underwriter Analysis >
    Sleep                       10s
    ClickText                   NEXT:Underwriter Analysis >
    Enter Data in Underwriter Analysis Page
    ClickText                   Save                        anchor=Check Risk Health
    VerifyText                  Success                     anchor=Update records successfully!
    ClickText                   Check Risk Health           anchor=Save
    ClickText                   New Primary Quote
    Sleep                       20s
    VerifyText                  Quote Console
    Click On Finalize
    Sleep                       10s
    Click On Bind Button
    Show More Actions
    Sleep                       10s
    ClickText                   Renewal                     anchor=Send Mail
    Sleep                       30s
    VerifyText                  Submission Info
    ClickText                   NEXT:Underwriter Analysis >
    VerifyText                  Industry Class
    ClickText                   Compare & Rate Quotes
    Sleep                       20s
    VerifyText                  Quote Console
    Click On Rate
    Click On Finalize
    Click On Bind Button
    ClickText                   Related                     anchor=Details
    VerifyText                  Renewal                     anchor=Quote Type
    Change Policy               Flat Cancellation
    Flat Cancellation Input
    Sleep                       5s
    ClickText                   Related                     anchor=Details
    VerifyText                  Flat Cancellation           anchor=Quote Type

to verify Flat cancel on renewed policy for MPL Excess  
    # Author = Saurabh Salgaonkar
    #TC=122521
    [Documentation]             field on Submission_Info for MPL
    [Tags]                      Regression_Test_MPL         Regression_Test
    Creating a new Account
    Enter data on Insured info Page for MPL
    ClickText                   NEXT:Submission Info >
    Select Broker and Click On Next
    Select Industry             Business Services
    Select Classification       Administrators
    ClickText                   Save                        anchor=NEXT:Underwriter Analysis >
    Sleep                       10s
    ClickText                   NEXT:Underwriter Analysis >
    Enter Data in Underwriter Analysis Page
    ClickText                   Save                        anchor=Check Risk Health
    VerifyText                  Success                     anchor=Update records successfully!
    ClickText                   Check Risk Health           anchor=Save
    ClickText                   New Primary Quote
    Sleep                       20s
    VerifyText                  Quote Console
    Click On Finalize
    Sleep                       10s
    Click On Bind Button
    Show More Actions
    Sleep                       10s
    ClickText                   Renewal                     anchor=Send Mail
    Sleep                       30s
    VerifyText                  Submission Info
    ClickText                   NEXT:Underwriter Analysis >
    VerifyText                  Industry Class
    ClickText                   Compare & Rate Quotes
    Sleep                       20s
    VerifyText                  Quote Console
    Click On Rate
    Click On Finalize
    Click On Bind Button
    ClickText                   Related                     anchor=Details
    VerifyText                  Renewal                     anchor=Quote Type
    Change Policy               Flat Cancellation
    Flat Cancellation Input
    Sleep                       5s
    ClickText                   Related                     anchor=Details
    VerifyText                  Flat Cancellation           anchor=Quote Type

To verify Coverage cancel and replace on renewed policy for MPL Primary
    # Author = Saurabh Salgaonkar
    #TC=122522
    [Documentation]             field on Submission_Info for MPL
    [Tags]                      Regression_Test_MPL         Regression_Test
    Creating a new Account
    Enter data on Insured info Page for MPL
    ClickText                   NEXT:Submission Info >
    Select Broker and Click On Next
    Select Industry             Business Services
    Select Classification       Administrators
    ClickText                   Save                        anchor=NEXT:Underwriter Analysis >
    Sleep                       10s
    ClickText                   NEXT:Underwriter Analysis >
    Enter Data in Underwriter Analysis Page
    ClickText                   Save                        anchor=Check Risk Health
    VerifyText                  Success                     anchor=Update records successfully!
    ClickText                   Check Risk Health           anchor=Save
    ClickText                   New Primary Quote
    Sleep                       20s
    VerifyText                  Quote Console
    Click On Finalize
    Sleep                       10s
    Click On Bind Button
    Show More Actions
    Sleep                       10s
    ClickText                   Renewal                     anchor=Send Mail
    Sleep                       30s
    VerifyText                  Submission Info
    ClickText                   NEXT:Underwriter Analysis >
    VerifyText                  Industry Class
    ClickText                   Compare & Rate Quotes
    Sleep                       20s
    VerifyText                  Quote Console
    Click On Rate
    Click On Finalize
    Click On Bind Button
    ClickText                   Related                     anchor=Details
    VerifyText                  Renewal                     anchor=Quote Type
    Sleep                       10s
    ${currPolicyPage_url}=      Get URL
    Cancel Coverage Replace Input and select
    Sleep                       10s
    Go To                       ${currPolicyPage_url}
    ClickText                   Related                     anchor=Emails
    ClickElement                //th[@data-label\='Submission Name']/lightning-primitive-cell-factory
    Cancel Coverage Replace Complete flow
    ClickText                   Related                     anchor=Details
    VerifyText                  Cancelled                   anchor=Status
    VerifyText                  Correction                  anchor=Status
    VerifyText                  Bound                       anchor=Status

To verify Coverage cancel and replace on renewed policy for MPL Excess
    # Author = Saurabh Salgaonkar
    #TC=122523
    [Documentation]             field on Submission_Info for MPL
    [Tags]                      Regression_Test_MPL         Regression_Test
    Creating a new Account
    Enter data on Insured info Page for MPL
    ClickText                   NEXT:Submission Info >
    Select Broker and Click On Next
    Select Industry             Business Services
    Select Classification       Administrators
    ClickText                   Save                        anchor=NEXT:Underwriter Analysis >
    Sleep                       10s
    ClickText                   NEXT:Underwriter Analysis >
    Enter Data in Underwriter Analysis Page
    ClickText                   Save                        anchor=Check Risk Health
    VerifyText                  Success                     anchor=Update records successfully!
    ClickText                   Check Risk Health           anchor=Save
    ClickText                   New Primary Quote
    Sleep                       20s
    VerifyText                  Quote Console
    Click On Finalize
    Sleep                       10s
    Click On Bind Button
    Show More Actions
    Sleep                       10s
    ClickText                   Renewal                     anchor=Send Mail
    Sleep                       30s
    VerifyText                  Submission Info
    ClickText                   NEXT:Underwriter Analysis >
    VerifyText                  Industry Class
    ClickText                   Compare & Rate Quotes
    Sleep                       20s
    VerifyText                  Quote Console
    Click On Rate
    Click On Finalize
    Click On Bind Button
    ClickText                   Related                     anchor=Details
    VerifyText                  Renewal                     anchor=Quote Type
    Sleep                       10s
    ${currPolicyPage_url}=      Get URL
    Cancel Coverage Replace Input and select
    Sleep                       10s
    Go To                       ${currPolicyPage_url}
    ClickText                   Related                     anchor=Emails
    ClickElement                //th[@data-label\='Submission Name']/lightning-primitive-cell-factory
    Cancel Coverage Replace Complete flow
    ClickText                   Related                     anchor=Details
    VerifyText                  Cancelled                   anchor=Status
    VerifyText                  Correction                  anchor=Status
    VerifyText                  Bound                       anchor=Status