*** Settings ***
Resource                        ../../../../../resources/common.robot
Resource                        ../../../../../PageObjects/RiskX_PageObjects/PageObjects_Accounts.robot
Resource                        ../../../../../PageObjects/RiskX_PageObjects/MPL/PageObjects_MPL_InsuredInfo.robot
Resource                        ../../../../../PageObjects/RiskX_PageObjects/MPL/PageObjects_MPL_SubmissionInfo.robot
Resource                        ../../../../../PageObjects/RiskX_PageObjects/MPL/PageObjects_MPL_UnderwriterAnalysis.robot
Resource                        ../../../../../PageObjects/RiskX_PageObjects/MPL/PageObjects_MPL_CompareAndRateQuote.robot
Resource                        ../../../../../PageObjects/RiskX_PageObjects/MPL/PageObjects_MultipleIndustries_MPL.robot

Library                         RetryFailed                 global_retries=${retry_count}
Suite Setup                     Setup Browser
Suite Teardown                  CloseAllBrowsers

*** Test Cases ***
Verify Eligible Industry for MPL
    # Author = Mitesh Patil
    #TC=103976
    [Documentation]             field on Submission_Info for MPL
    [Tags]                      Smoke_Test_MPL              Smoke_Test
    Creating a new Account
    Enter data on Insured info Page for MPL
    Select Broker and Click On Next
    ClickText                   NEXT:Submission Info >
    
    Select Eligible industry on MPL                       Business Services    Auctioneer
 
    Select Eligible industry on MPL                       Real Estate    Commercial Appraisers
 
    Select Eligible industry on MPL                       Biotechnology    Pharmaceutical
 
    Select Eligible industry on MPL                       Construction    Building Construction