*** Settings ***
Resource                        ../../../resources/common.robot
Resource                        ../../../PageObjects/RiskX_PageObjects/PageObjects_Accounts.robot
Resource                        ../../../PageObjects/RiskX_PageObjects/MPL/PageObjects_MPL_InsuredInfo.robot
Resource                        ../../../PageObjects/RiskX_PageObjects/MPL/PageObjects_MPL_SubmissionInfo.robot
Resource                        ../../../PageObjects/RiskX_PageObjects/MPL/PageObjects_MPL_UnderwriterAnalysis.robot
Library                         RetryFailed                 global_retries=${retry_count}
Suite Setup                     Setup Browser
Suite Teardown                  CloseAllBrowsers



*** Test Cases ***

Verify elements on Underwriting Analysis page 
    # Author = Amol Gaymukhe
    #TC=111477, 111478
    [Documentation]             field on Submission_Info for MPL
    [Tags]                      Smoke_Test_MPL              Smoke_Test
    Creating a new Account
    Enter data on Insured info Page for MPL
    ClickText                   NEXT:Submission Info >
    Select Broker and Click On Next
    Select Industry             Business Services
    Select Classification       Administrators
    ClickText                   Save                        anchor=NEXT:Underwriter Analysis >
    Sleep                       10s
    ClickText                   NEXT:Underwriter Analysis >
    Verify Underwriter Analysis Page Elements
    Enter Data in Underwriter Analysis Page
    ClickText                   Save                        anchor=Check Risk Health
    VerifyText                  Success                     anchor=Update records successfully!
