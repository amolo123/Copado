*** Settings ***
Resource                        ../../../resources/common.robot
Resource                        ../../../PageObjects/RiskX_PageObjects/PageObjects_Accounts.robot
Resource                        ../../../PageObjects/RiskX_PageObjects/MPL/PageObjects_MPL_InsuredInfo.robot
Resource                        ../../../PageObjects/RiskX_PageObjects/MPL/PageObjects_MPL_SubmissionInfo.robot
Resource                        ../../../PageObjects/RiskX_PageObjects/MPL/PageObjects_MPL_UnderwriterAnalysis.robot
Resource                        ../../../PageObjects/RiskX_PageObjects/MPL/PageObjects_MPL_CompareAndRateQuote.robot

Resource                        ../../../resources/ReadPDF.robot
Resource                        ../../../PageObjects/RiskX_PageObjects/MPL/PageObjects_ReadPDF_MPL.robot
Resource                        ../../../PageObjects/RiskX_PageObjects/PageObjects_PolicyPage.robot

Library                         RetryFailed                 global_retries=${retry_count}
Suite Setup                     Setup Browser
Suite Teardown                  CloseAllBrowsers



*** Test Cases ***
Verify Policy document for MPL- Primary
    # Author = Amol Gaymukhe
    #TC=111679
    [Documentation]             Reading the Policy Document for MPL
    [Tags]                      Smoke_Test_MPL              Smoke_Test
    Creating a new Account
    Enter data on Insured info Page for MPL
    ClickText                   NEXT:Submission Info >
    Select Broker and Click On Next
    Select Industry             Business Services
    Select Classification       Administrators
    ClickText                   Save                        anchor=NEXT:Underwriter Analysis >
    Sleep                       10s
    ClickText                   NEXT:Underwriter Analysis >
    Enter Data in Underwriter Analysis Page
    ClickText                   Save                        anchor=Check Risk Health
    VerifyText                  Success                     anchor=Update records successfully!
    ClickText                   Check Risk Health           anchor=Save
    ClickText                   New Primary Quote
    Sleep                       30s
    Get Quote Letter Dynamic Document MPL
    Click On Finalize
    Click On Bind Button
    Generate Document on Policy                             PolicyForm
    Sleep                       15s
    ClickElement                //article[contains(@aria-label,'CelerityRiskPolicyForm')]//a
    ClickText                   View Document
    VerifyText                  Success                     anchor=Document has been downloaded sucessfully!                  timeout=45s    partial_match=false
    Sleep                       15s
    Move to outputdir
    Read Policy Letter Static Document MPL
    Read Policy Letter Dynamic Document MPL

Verify Policy document for MPL- Excess
    # Author = Amol Gaymukhe
    #TC=111680
    [Documentation]             Reading the Policy Document for MPL
    [Tags]                      Smoke_Test_MPL              Smoke_Test
    Creating a new Account
    Enter data on Insured info Page for MPL
    ClickText                   NEXT:Submission Info >
    Select Broker and Click On Next
    Select Industry             Business Services
    Select Classification       Administrators
    ClickText                   Save                        anchor=NEXT:Underwriter Analysis >
    Sleep                       10s
    ClickText                   NEXT:Underwriter Analysis >
    Enter Data in Underwriter Analysis Page
    ClickText                   Save                        anchor=Check Risk Health
    VerifyText                  Success                     anchor=Update records successfully!
    ClickText                   Check Risk Health           anchor=Save
    ClickText                   New Excess Quote
    Sleep                       30s
    Get Quote Letter Dynamic Document MPL
    Click On Finalize
    Click On Bind Button
    Generate Document on Policy                             PolicyForm
    Sleep                       15s
    ClickElement                //article[contains(@aria-label,'CelerityRiskExcessPolicy')]//a
    ClickText                   View Document
    VerifyText                  Success                     anchor=Document has been downloaded sucessfully!                  timeout=45s    partial_match=false
    Sleep                       45s
    Move to outputdir
    Read Policy Letter Static Document MPL Excess
    Read Policy Letter Dynamic Document MPL

