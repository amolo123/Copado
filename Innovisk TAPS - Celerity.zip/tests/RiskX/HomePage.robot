*** Settings ***
Resource                        ../../resources/common.robot
Resource                        ../../PageObjects/RiskX_PageObjects/PageObjects_Accounts.robot
Resource                        ../../PageObjects/RiskX_PageObjects/PageObjects_HomePage.robot
Library                         RetryFailed                 global_retries=2
Suite Setup                     Setup Browser
Suite Teardown                  CloseAllBrowsers


*** Test Cases ***


Validate Home Page 
    # Author = Amol
    #TC=110933,111652,111653,111654
    [Documentation]             Verify All HomePage Elemets
    [Tags]                      Smoke_Test
    Verify All HomePage Elemets