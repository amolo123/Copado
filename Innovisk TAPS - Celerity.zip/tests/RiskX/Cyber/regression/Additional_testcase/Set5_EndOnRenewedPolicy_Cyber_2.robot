*** Settings ***
Resource                        ../../../../../resources/common.robot
Resource                        ../../../../../PageObjects/RiskX_PageObjects/PageObjects_Accounts.robot
Resource                        ../../../../../PageObjects/RiskX_PageObjects/Cyber/PageObjects_Cyber_InsuredInfo.robot
Resource                        ../../../../../PageObjects/RiskX_PageObjects/Cyber/PageObjects_Cyber_SubmissionInfo.robot
Resource                        ../../../../../PageObjects/RiskX_PageObjects/Cyber/PageObjects_Cyber_UnderwriterAnalysis.robot
Resource                        ../../../../../PageObjects/RiskX_PageObjects/Cyber/PageObjects_Cyber_CompareAndRateQuote.robot
Resource                        ../../../../../PageObjects/RiskX_PageObjects/PageObjects_PolicyPage.robot

Library                         RetryFailed                 global_retries=${retry_count}
Suite Setup                     Setup Browser
Suite Teardown                  CloseAllBrowsers



*** Test Cases ***

To verify Flat Cancel transaction on renewed policy Cyber Primary  
    # Author = Saurabh Salgaonkar
    #TC=122509
    [Documentation]             Change endorsement on renewed Policy
    [Tags]                      Regression_Test_Cyber       Regression_Test
    Creating a new Account
    Enter data on Insured info Page for Cyber
    ClickText                   NEXT:Submission Info >
    Select Broker and Click On Next
    Select Industry             Business Services
    Select Classification       Administrators
    ClickText                   Save                        anchor=NEXT:Underwriter Analysis >
    Sleep                       10s
    ClickText                   NEXT:Underwriter Analysis >
    Enter Data in Underwriter Analysis Page
    ClickText                   Save                        anchor=Check Risk Health
    VerifyText                  Success                     anchor=Update records successfully!
    ClickText                   Check Risk Health           anchor=Save
    ClickText                   New Primary Quote
    Sleep                       20s
    VerifyText                  Quote Console
    Click On Finalize
    Sleep                       30s
    Click On Generate Document
    Click On Bind Button
    Show More Actions
    ClickText                   Renewal                     anchor=Send Mail
    Sleep                       30s
    VerifyText                  Submission Info
    ClickText                   NEXT:Underwriter Analysis >
    VerifyText                  Base Rate
    ClickText                   Compare & Rate Quotes
    Sleep                       20s
    VerifyText                  Quote Console
    Click On Rate
    Click On Finalize
    Click On Bind Button
    ClickText                   Related                     anchor=Details
    VerifyText                  Renewal                     anchor=Quote Type
    Change Policy               Flat Cancellation
    Flat Cancellation Input
    Sleep                       45s
    ClickText                   Related                     anchor=Details
    VerifyText                  Flat Cancellation           anchor=Quote Type

To verify Flat Cancel transaction on renewed policy Cyber Excess
    # Author = Saurabh Salgaonkar
    #TC=122510
    [Documentation]             Change endorsement on renewed Policy
    [Tags]                      Regression_Test_Cyber       Regression_Test
    Creating a new Account
    Enter data on Insured info Page for Cyber
    ClickText                   NEXT:Submission Info >
    Select Broker and Click On Next
    Select Industry             Business Services
    Select Classification       Administrators
    ClickText                   Save                        anchor=NEXT:Underwriter Analysis >
    Sleep                       10s
    ClickText                   NEXT:Underwriter Analysis >
    Enter Data in Underwriter Analysis Page
    ClickText                   Save                        anchor=Check Risk Health
    VerifyText                  Success                     anchor=Update records successfully!
    ClickText                   Check Risk Health           anchor=Save
    ClickText                   New Excess Quote
    Sleep                       20s
    VerifyText                  Quote Console
    Click On Finalize
    Sleep                       30s
    Click On Generate Document
    Click On Bind Button
    Show More Actions
    ClickText                   Renewal                     anchor=Send Mail
    Sleep                       30s
    VerifyText                  Submission Info
    ClickText                   NEXT:Underwriter Analysis >
    VerifyText                  Base Rate
    ClickText                   Compare & Rate Quotes
    Sleep                       20s
    VerifyText                  Quote Console
    Click On Rate
    Click On Finalize
    Click On Bind Button
    ClickText                   Related                     anchor=Details
    VerifyText                  Renewal                     anchor=Quote Type
    Change Policy               Flat Cancellation
    Flat Cancellation Input
    Sleep                       45s
    ClickText                   Related                     anchor=Details
    VerifyText                  Flat Cancellation           anchor=Quote Type


To verify Coverage cancel and replace transaction on renewed policy Cyber Primary  
    # Author = Saurabh Salgaonkar
    #TC=122511
    [Documentation]             Change endorsement on renewed Policy
    [Tags]                      Regression_Test_Cyber       Regression_Test
    Creating a new Account
    Enter data on Insured info Page for Cyber
    ClickText                   NEXT:Submission Info >
    Select Broker and Click On Next
    Select Industry             Business Services
    Select Classification       Administrators
    ClickText                   Save                        anchor=NEXT:Underwriter Analysis >
    Sleep                       10s
    ClickText                   NEXT:Underwriter Analysis >
    Enter Data in Underwriter Analysis Page
    ClickText                   Save                        anchor=Check Risk Health
    VerifyText                  Success                     anchor=Update records successfully!
    ClickText                   Check Risk Health           anchor=Save
    ClickText                   New Primary Quote
    Sleep                       20s
    VerifyText                  Quote Console
    Click On Finalize
    Sleep                       30s
    Click On Generate Document
    Click On Bind Button
    Show More Actions
    ClickText                   Renewal                     anchor=Send Mail
    Sleep                       30s
    VerifyText                  Submission Info
    ClickText                   NEXT:Underwriter Analysis >
    VerifyText                  Base Rate
    ClickText                   Compare & Rate Quotes
    Sleep                       20s
    VerifyText                  Quote Console
    Click On Rate
    Click On Finalize
    #Click On Bind Button
    Click On Bind Button more than once
    ClickText                   Related                     anchor=Details
    VerifyText                  Renewal                     anchor=Quote Type
    Sleep                       10s
    ${currPolicyPage_url}=      Get URL
    Cancel Coverage Replace Input and select
    Sleep                       10s
    Go To                       ${currPolicyPage_url}
    ClickText                   Related                     anchor=Emails
    ClickElement                //th[@data-label\='Submission Name']/lightning-primitive-cell-factory
    Cancel Coverage Replace Complete flow
    ClickText                   Related                     anchor=Details
    VerifyText                  Cancelled                   anchor=Status
    VerifyText                  Correction                  anchor=Status
    VerifyText                  Bound                       anchor=Status

To verify Coverage cancel and replace transaction on renewed policy Cyber Excess
    # Author = Saurabh Salgaonkar
    #TC=122512
    [Documentation]             Change endorsement on renewed Policy
    [Tags]                      Regression_Test_Cyber       Regression_Test
    Creating a new Account
    Enter data on Insured info Page for Cyber
    ClickText                   NEXT:Submission Info >
    Select Broker and Click On Next
    Select Industry             Business Services
    Select Classification       Administrators
    ClickText                   Save                        anchor=NEXT:Underwriter Analysis >
    Sleep                       10s
    ClickText                   NEXT:Underwriter Analysis >
    Enter Data in Underwriter Analysis Page
    ClickText                   Save                        anchor=Check Risk Health
    VerifyText                  Success                     anchor=Update records successfully!
    ClickText                   Check Risk Health           anchor=Save
    ClickText                   New Excess Quote
    Sleep                       20s
    VerifyText                  Quote Console
    Click On Finalize
    Sleep                       30s
    Click On Generate Document
    Click On Bind Button
    Show More Actions
    ClickText                   Renewal                     anchor=Send Mail
    Sleep                       30s
    VerifyText                  Submission Info
    ClickText                   NEXT:Underwriter Analysis >
    VerifyText                  Base Rate
    ClickText                   Compare & Rate Quotes
    Sleep                       20s
    VerifyText                  Quote Console
    Click On Rate
    Click On Finalize
    Click On Bind Button
    ClickText                   Related                     anchor=Details
    VerifyText                  Renewal                     anchor=Quote Type
    Sleep                       10s
    ${currPolicyPage_url}=      Get URL
    Cancel Coverage Replace Input and select
    Sleep                       10s
    Go To                       ${currPolicyPage_url}
    ClickText                   Related                     anchor=Emails
    ClickElement                //th[@data-label\='Submission Name']/lightning-primitive-cell-factory
    Cancel Coverage Replace Complete flow
    ClickText                   Related                     anchor=Details
    VerifyText                  Cancelled                   anchor=Status
    VerifyText                  Correction                  anchor=Status
    VerifyText                  Bound                       anchor=Status