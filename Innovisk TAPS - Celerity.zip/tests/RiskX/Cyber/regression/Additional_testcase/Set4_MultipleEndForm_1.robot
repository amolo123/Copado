*** Settings ***
Resource                        ../../../../../resources/common.robot
Resource                        ../../../../../PageObjects/RiskX_PageObjects/PageObjects_Accounts.robot
Resource                        ../../../../../PageObjects/RiskX_PageObjects/Cyber/PageObjects_Cyber_InsuredInfo.robot
Resource                        ../../../../../PageObjects/RiskX_PageObjects/Cyber/PageObjects_Cyber_SubmissionInfo.robot
Resource                        ../../../../../PageObjects/RiskX_PageObjects/Cyber/PageObjects_Cyber_UnderwriterAnalysis.robot
Resource                        ../../../../../PageObjects/RiskX_PageObjects/Cyber/PageObjects_Cyber_CompareAndRateQuote.robot
Resource                        ../../../../../PageObjects/RiskX_PageObjects/PageObjects_PolicyPage.robot

Library                         RetryFailed                 global_retries=${retry_count}
Suite Setup                     Setup Browser
Suite Teardown                  CloseAllBrowsers



*** Test Cases ***
To Verify Creating policy with multiple Endorsement forms added for Cyber Primary
    # Author = Saurabh Salgaonkar
    #TC=122384
    [Documentation]             To Verify Creating policy with multiple Endorsement forms added for Cyber Primary
    [Tags]                      Regression_Test_Cyber       Regression_Test
    Creating a new Account
    Enter data on Insured info Page for Cyber
    ClickText                   NEXT:Submission Info >
    Select Broker and Click On Next
    Select Industry             Business Services
    Select Classification       Administrators
    ClickText                   Save                        anchor=NEXT:Underwriter Analysis >
    Sleep                       10s
    ClickText                   NEXT:Underwriter Analysis >
    Enter Data in Underwriter Analysis Page
    ClickText                   Save                        anchor=Check Risk Health
    VerifyText                  Success                     anchor=Update records successfully!
    ClickText                   Check Risk Health           anchor=Save
    ClickText                   New Primary Quote
    Sleep                       20s
    VerifyText                  Quote Console

    Click On Endorsement and Subjectivity

    #Keyword

    TypeText                    Search for Endorsements     CYB 68 01 25\n
    Sleep                       2s
    ClickElement                //span[text()\='Select Item 1']
    ClickElement                //button[@title\='Add']
    VerifyText                  Success                     anchor=The data is saved successfully
    ClickText                   Save                        anchor=Return Quote Process
    ClickText                   Return Quote Process
    Log To Console              ----- Endorsements selected successful------

    Click On Endorsement and Subjectivity

    #Keyword

    ScrollText                  CYB 68 01 25
    use table                   Effective Date ?
    ClickElement                //*[@data-key\="edit"]       anchor=Bricking Endorsement

    Click On Finalize
    Sleep                       30s
    Click On Generate Document
    Click On Bind Button
    Generate Document on Policy                             PolicyForm

