*** Settings ***
Resource                        ../../../../../resources/common.robot
Resource                        ../../../../../PageObjects/RiskX_PageObjects/PageObjects_Accounts.robot
Resource                        ../../../../../PageObjects/RiskX_PageObjects/Cyber/PageObjects_Cyber_InsuredInfo.robot
Resource                        ../../../../../PageObjects/RiskX_PageObjects/Cyber/PageObjects_Cyber_SubmissionInfo.robot
Resource                        ../../../../../PageObjects/RiskX_PageObjects/Cyber/PageObjects_Cyber_UnderwriterAnalysis.robot
Resource                        ../../../../../PageObjects/RiskX_PageObjects/Cyber/PageObjects_Cyber_CompareAndRateQuote.robot


Library                         RetryFailed                 global_retries=${retry_count}
Suite Setup                     Setup Browser
Suite Teardown                  CloseAllBrowsers



*** Test Cases ***
Verify that user can enter max revenue as 5000000000 in Risk X for Cyber Primary
    # Author = Amol Gaymukhe
    #TC=121871
    [Documentation]             field on Submission_Info for Cyber
    [Tags]                      Smoke_Test_Cyber            Smoke_Test
    Creating a new Account
    Enter data on Insured info Page for Cyber
    ClickText                   NEXT:Submission Info >
    Select Broker and Click On Next
    Select Industry             Business Services
    Select Classification       Administrators
    ClickText                   Save                        anchor=NEXT:Underwriter Analysis >
    Sleep                       10s
    ClickText                   NEXT:Underwriter Analysis >
    Enter Data in Underwriter Analysis Page Max Revenue 5000000000
    ClickText                   Save                        anchor=Check Risk Health
    VerifyText                  Success                     anchor=Update records successfully!
    ClickText                   Check Risk Health           anchor=Save
    ClickText                   New Primary Quote
    Sleep                       30s
    Verify Elements on Compare and Rate Quote Primary
    VerifyText                  Rating: Ineligible
    # ClickElement                //span[text()\='Underwriting Analysis']


Verify that user can enter max revenue as 5000000000 in Risk X for Cyber Excess
    # Author = Mitesh Patil
    #TC=122357
    [Documentation]             field on Submission_Info for Cyber
    [Tags]                      Smoke_Test_Cyber            Smoke_Test
    Creating a new Account
    Enter data on Insured info Page for Cyber
    ClickText                   NEXT:Submission Info >
    Select Broker and Click On Next
    Select Industry             Business Services
    Select Classification       Administrators
    ClickText                   Save                        anchor=NEXT:Underwriter Analysis >
    Sleep                       10s
    ClickText                   NEXT:Underwriter Analysis >
    Enter Data in Underwriter Analysis Page Max Revenue 5000000000
    ClickText                   Save                        anchor=Check Risk Health
    VerifyText                  Success                     anchor=Update records successfully!
    ClickText                   Check Risk Health           anchor=Save
    ClickText                   New Excess Quote
    Sleep                       20s
    VerifyText                  Quote Console
    Verify Elements on Compare and Rate Quote Excess
    VerifyText                  Rating: Ineligible