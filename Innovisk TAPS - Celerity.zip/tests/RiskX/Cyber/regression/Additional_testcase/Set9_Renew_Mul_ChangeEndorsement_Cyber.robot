*** Settings ***
Resource                        ../../../../../resources/common.robot
Resource                        ../../../../../PageObjects/RiskX_PageObjects/PageObjects_Accounts.robot
Resource                        ../../../../../PageObjects/RiskX_PageObjects/Cyber/PageObjects_Cyber_InsuredInfo.robot
Resource                        ../../../../../PageObjects/RiskX_PageObjects/Cyber/PageObjects_Cyber_SubmissionInfo.robot
Resource                        ../../../../../PageObjects/RiskX_PageObjects/Cyber/PageObjects_Cyber_UnderwriterAnalysis.robot
Resource                        ../../../../../PageObjects/RiskX_PageObjects/Cyber/PageObjects_Cyber_CompareAndRateQuote.robot
Resource                        ../../../../../PageObjects/RiskX_PageObjects/PageObjects_PolicyPage.robot

Library                         RetryFailed                 global_retries=${retry_count}
Suite Setup                     Setup Browser
Suite Teardown                  CloseAllBrowsers



*** Test Cases ***
To Verify Renewal transaction on multiple endorsement performed on single Cyber Primary policy
    #Author = Pinki Lubana
    #TC=122548
    [Documentation]             Renewal on multiple change endorsement
    [Tags]                      Regression_Test_Cyber       Regression_Test
    Creating a new Account
    Enter data on Insured info Page for Cyber
    ClickText                   NEXT:Submission Info >
    Select Broker and Click On Next
    Select Industry             Business Services
    Select Classification       Administrators
    ClickText                   Save                        anchor=NEXT:Underwriter Analysis >
    Sleep                       10s
    ClickText                   NEXT:Underwriter Analysis >
    Enter Data in Underwriter Analysis Page
    ClickText                   Save                        anchor=Check Risk Health
    VerifyText                  Success                     anchor=Update records successfully!
    ClickText                   Check Risk Health           anchor=Save
    ClickText                   New Primary Quote
    Sleep                       20s
    VerifyText                  Quote Console
    Click On Finalize
    Sleep                       30s
    Click On Generate Document
    Click On Bind Button
    Change Policy               Amendment
    Amendment Input
    Amendment Flow Complete
    Sleep                       25s
    ClickText                   Related                     anchor=Details
    VerifyText                  New Business                anchor=Quote Type
    VerifyText                  Amendment                   anchor=Quote Type
    Midterm Cancellation Input and select
    Midterm Cancellation Input
    Sleep                       45s
    Midterm Cancellation Flow Complete
    ClickText                   Related                     anchor=Details
    VerifyText                  Midterm Cancellation        anchor=Quote Type
    Sleep                       10s
    VerifyText                  New Business                anchor=Quote Type
    VerifyText                  Amendment                   anchor=Quote Type
    VerifyText                  Midterm Cancellation        anchor=Quote Type
    Change Policy               Reinstatement
    Reinstatement Input
    Sleep                       20s
    ClickText                   Related                     anchor=Details
    VerifyText                  New Business                anchor=Quote Type
    VerifyText                  Amendment                   anchor=Quote Type
    VerifyText                  Midterm Cancellation        anchor=Quote Type
    VerifyText                  Reinstatement               anchor=Quote Type
    Policy Duration Change Input and select
    Policy Duration Change Flow Complete
    Sleep                       5s
    ClickText                   Related                     anchor=Details
    ClickText                   Related                     anchor=Details
    VerifyText                  New Business                anchor=Quote Type
    VerifyText                  Amendment                   anchor=Quote Type
    VerifyText                  Midterm Cancellation        anchor=Quote Type
    VerifyText                  Reinstatement               anchor=Quote Type
    VerifyText                  Policy Duration Change      anchor=Quote Type
    Show More Actions
    Sleep                       10s
    ClickText                   Renewal                     anchor=Send Mail
    Sleep                       30s
    VerifyText                  Submission Info
    ClickText                   NEXT:Underwriter Analysis >
    VerifyText                  Base Rate
    ClickText                   Compare & Rate Quotes
    Sleep                       20s
    VerifyText                  Quote Console
    Click On Rate
    Click On Finalize
    Click On Bind Button
    Sleep                       5s
    ClickText                   Related                     anchor=Details
    VerifyText                  Renewal                     anchor=Quote Type

To Verify Renewal transaction on multiple endorsement performed on single Cyber Excess policy
    #Author = Pinki Lubana
    #TC=122552
    [Documentation]             Renewal on multiple change endorsement
    [Tags]                      Regression_Test_Cyber       Regression_Test
    Creating a new Account
    Enter data on Insured info Page for Cyber
    ClickText                   NEXT:Submission Info >
    Select Broker and Click On Next
    Select Industry             Business Services
    Select Classification       Administrators
    ClickText                   Save                        anchor=NEXT:Underwriter Analysis >
    Sleep                       10s
    ClickText                   NEXT:Underwriter Analysis >
    Enter Data in Underwriter Analysis Page
    ClickText                   Save                        anchor=Check Risk Health
    VerifyText                  Success                     anchor=Update records successfully!
    ClickText                   Check Risk Health           anchor=Save
    ClickText                   New Excess Quote
    Sleep                       20s
    VerifyText                  Quote Console
    Click On Finalize
    Sleep                       30s
    Click On Generate Document
    Click On Bind Button
    Change Policy               Amendment
    Amendment Input
    Amendment Flow Complete
    Sleep                       25s
    ClickText                   Related                     anchor=Details
    VerifyText                  New Business                anchor=Quote Type
    VerifyText                  Amendment                   anchor=Quote Type
    Midterm Cancellation Input and select
    Midterm Cancellation Input
    Sleep                       45s
    Midterm Cancellation Flow Complete
    ClickText                   Related                     anchor=Details
    VerifyText                  Midterm Cancellation        anchor=Quote Type
    Sleep                       10s
    VerifyText                  New Business                anchor=Quote Type
    VerifyText                  Amendment                   anchor=Quote Type
    VerifyText                  Midterm Cancellation        anchor=Quote Type
    Change Policy               Reinstatement
    Reinstatement Input
    Sleep                       20s
    ClickText                   Related                     anchor=Details
    VerifyText                  New Business                anchor=Quote Type
    VerifyText                  Amendment                   anchor=Quote Type
    VerifyText                  Midterm Cancellation        anchor=Quote Type
    VerifyText                  Reinstatement               anchor=Quote Type
    Policy Duration Change Input and select
    Policy Duration Change Flow Complete
    Sleep                       5s
    ClickText                   Related                     anchor=Details
    ClickText                   Related                     anchor=Details
    VerifyText                  New Business                anchor=Quote Type
    VerifyText                  Amendment                   anchor=Quote Type
    VerifyText                  Midterm Cancellation        anchor=Quote Type
    VerifyText                  Reinstatement               anchor=Quote Type
    VerifyText                  Policy Duration Change      anchor=Quote Type
    Show More Actions
    Sleep                       10s
    ClickText                   Renewal                     anchor=Send Mail
    Sleep                       30s
    VerifyText                  Submission Info
    ClickText                   NEXT:Underwriter Analysis >
    VerifyText                  Base Rate
    ClickText                   Compare & Rate Quotes
    Sleep                       20s
    VerifyText                  Quote Console
    Click On Rate
    Click On Finalize
    Click On Bind Button
    Sleep                       5s
    ClickText                   Related                     anchor=Details
    VerifyText                  Renewal                     anchor=Quote Type
