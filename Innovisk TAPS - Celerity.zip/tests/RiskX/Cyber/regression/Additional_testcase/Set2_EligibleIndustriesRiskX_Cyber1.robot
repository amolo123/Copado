*** Settings ***
Resource                        ../../../../../resources/common.robot
Resource                        ../../../../../PageObjects/RiskX_PageObjects/PageObjects_Accounts.robot
Resource                        ../../../../../PageObjects/RiskX_PageObjects/Cyber/PageObjects_Cyber_InsuredInfo.robot
Resource                        ../../../../../PageObjects/RiskX_PageObjects/Cyber/PageObjects_Cyber_SubmissionInfo.robot
Resource                        ../../../../../PageObjects/RiskX_PageObjects/Cyber/PageObjects_Cyber_UnderwriterAnalysis.robot
Resource                        ../../../../../PageObjects/RiskX_PageObjects/Cyber/PageObjects_Cyber_CompareAndRateQuote.robot
Resource                        ../../../../../PageObjects/RiskX_PageObjects/Cyber/PageObjects_MultipleIndustries_Cyber.robot
Resource                        ../../../../../PageObjects/RiskX_PageObjects/PageObjects_PolicyPage.robot


Library                         RetryFailed                 global_retries=${retry_count}
Suite Setup                     Setup Browser
Suite Teardown                  CloseAllBrowsers


*** Test Cases ***
Verify Eligible Industry for Cyber
    # Author = Mitesh Patil
    #TC=121986
    [Documentation]             field on Submission_Info for Cyber
    [Tags]                      Regression_Test_Cyber       Regression_Test
    Creating a new Account
    Enter data on Insured info Page for Cyber
    ClickText                   NEXT:Submission Info >
    Select Broker and Click On Next
    Select Eligible industry on Cyber                       Business Services           Auctioneer

    Select Eligible industry on Cyber                       Real Estate                 Commercial Appraisers

    Select Eligible industry on Cyber                       Biotechnology               Pharmaceutical

    Select Eligible industry on Cyber                       Construction                Building Construction


