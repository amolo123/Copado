*** Settings ***
Resource                        ../../../../resources/common.robot
Resource                        ../../../../PageObjects/RiskX_PageObjects/PageObjects_Accounts.robot
Resource                        ../../../../PageObjects/RiskX_PageObjects/Cyber/PageObjects_Cyber_InsuredInfo.robot
Resource                        ../../../../PageObjects/RiskX_PageObjects/Cyber/PageObjects_Cyber_SubmissionInfo.robot
Resource                        ../../../../PageObjects/RiskX_PageObjects/Cyber/PageObjects_Cyber_UnderwriterAnalysis.robot
Resource                        ../../../../PageObjects/RiskX_PageObjects/Cyber/PageObjects_Cyber_CompareAndRateQuote.robot
Resource                        ../../../../PageObjects/RiskX_PageObjects/PageObjects_PolicyPage.robot

Library                         RetryFailed                 global_retries=${retry_count}
Suite Setup                     Setup Browser
Suite Teardown                  CloseAllBrowsers


*** Test Cases ***
Verify Broker on Record Change on Cyber Primary
    # Author = Amol Gaymukhe
    #TC=111281
    [Documentation]             field on Submission_Info for Cyber
    [Tags]                      Regression_Test_Cyber       Regression_Test
    Creating a new Account
    Enter data on Insured info Page for Cyber
    ClickText                   NEXT:Submission Info >
    Select Broker and Click On Next
    Select Industry             Business Services
    Select Classification       Administrators
    ClickText                   Save                        anchor=NEXT:Underwriter Analysis >
    Sleep                       10s
    ClickText                   NEXT:Underwriter Analysis >
    Enter Data in Underwriter Analysis Page
    ClickText                   Save                        anchor=Check Risk Health
    VerifyText                  Success                     anchor=Update records successfully!
    ClickText                   Check Risk Health           anchor=Save
    ClickText                   New Primary Quote
    Sleep                       20s
    VerifyText                  Quote Console
    Click On Finalize
    Sleep                       30s
    Click On Generate Document
    Click On Bind Button
    Broker on Record Change and select
    Broker on Record Change Input
    Update Insured Name and Address Change complete
    Sleep                       10s
    ClickText                   Related                     anchor=Details
    VerifyText                  Broker on Record Change     anchor=Quote Type



Verify Broker on Record Change on Cyber Excess
    # Author = Amol Gaymukhe
    #TC=111281
    [Documentation]             field on Submission_Info for Cyber
    [Tags]                      Regression_Test_Cyber       Regression_Test
    Creating a new Account
    Enter data on Insured info Page for Cyber
    ClickText                   NEXT:Submission Info >
    Select Broker and Click On Next
    Select Industry             Business Services
    Select Classification       Administrators
    ClickText                   Save                        anchor=NEXT:Underwriter Analysis >
    Sleep                       10s
    ClickText                   NEXT:Underwriter Analysis >
    Enter Data in Underwriter Analysis Page
    ClickText                   Save                        anchor=Check Risk Health
    VerifyText                  Success                     anchor=Update records successfully!
    ClickText                   Check Risk Health           anchor=Save
    ClickText                   New Excess Quote
    Sleep                       20s
    VerifyText                  Quote Console
    Click On Finalize
    Sleep                       30s
    Click On Generate Document
    Click On Bind Button
    Broker on Record Change and select
    Broker on Record Change Input
    Update Insured Name and Address Change complete
    Sleep                       20s
    ClickText                   Related                     anchor=Details
    VerifyText                  Broker on Record Change     anchor=Quote Type

Verify ERP on Cyber Primary
    # Author = Amol Gaymukhe
    #TC=111281
    [Documentation]             field on Submission_Info for Cyber
    [Tags]                      Regression_Test_Cyber       Regression_Test
    Creating a new Account
    Enter data on Insured info Page for Cyber
    ClickText                   NEXT:Submission Info >
    Select Broker and Click On Next
    Select Industry             Business Services
    Select Classification       Administrators
    ClickText                   Save                        anchor=NEXT:Underwriter Analysis >
    Sleep                       10s
    ClickText                   NEXT:Underwriter Analysis >
    Enter Data in Underwriter Analysis Page
    ClickText                   Save                        anchor=Check Risk Health
    VerifyText                  Success                     anchor=Update records successfully!
    ClickText                   Check Risk Health           anchor=Save
    ClickText                   New Primary Quote
    Sleep                       20s
    VerifyText                  Quote Console
    Click On Finalize
    Sleep                       30s
    Click On Generate Document
    Click On Bind Button
    Midterm Cancellation Input and select
    Midterm Cancellation Input
    Sleep                       45s
    Midterm Cancellation Flow Complete
    #Change Policy               Extended Reporting Period
    Change Policy ERP
    ClickText                   Confirm                     anchor=Back
    Sleep                       20s
    ERP flow Complete
    ClickText                   Related                     anchor=Details
    VerifyText                  Extended Reporting Period                               anchor=Quote Type


Verify ERP on Cyber Excess
    # Author = Amol Gaymukhe
    #TC=111281
    [Documentation]             field on Submission_Info for Cyber
    [Tags]                      Regression_Test_Cyber       Regression_Test
    Creating a new Account
    Enter data on Insured info Page for Cyber
    ClickText                   NEXT:Submission Info >
    Select Broker and Click On Next
    Select Industry             Business Services
    Select Classification       Administrators
    ClickText                   Save                        anchor=NEXT:Underwriter Analysis >
    Sleep                       10s
    ClickText                   NEXT:Underwriter Analysis >
    Enter Data in Underwriter Analysis Page
    ClickText                   Save                        anchor=Check Risk Health
    VerifyText                  Success                     anchor=Update records successfully!
    ClickText                   Check Risk Health           anchor=Save
    ClickText                   New Excess Quote
    Sleep                       20s
    VerifyText                  Quote Console
    Click On Finalize
    Sleep                       30s
    Click On Generate Document
    Click On Bind Button
    Midterm Cancellation Input and select
    Midterm Cancellation Input
    Sleep                       45s
    Midterm Cancellation Flow Complete
    #Change Policy               Extended Reporting Period (ERP)
    Change Policy ERP
    ClickText                   Confirm                     anchor=Back
    Sleep                       20s
    ERP flow Complete
    ClickText                   Related                     anchor=Details
    VerifyText                  Extended Reporting Period                               anchor=Quote Type

Verify Policy Duration Change on Cyber Primary
    # Author = Amol Gaymukhe
    #TC=111281
    [Documentation]             field on Submission_Info for Cyber
    [Tags]                      Regression_Test_Cyber       Regression_Test
    Creating a new Account
    Enter data on Insured info Page for Cyber
    ClickText                   NEXT:Submission Info >
    Select Broker and Click On Next
    Select Industry             Business Services
    Select Classification       Administrators
    ClickText                   Save                        anchor=NEXT:Underwriter Analysis >
    Sleep                       10s
    ClickText                   NEXT:Underwriter Analysis >
    Enter Data in Underwriter Analysis Page
    ClickText                   Save                        anchor=Check Risk Health
    VerifyText                  Success                     anchor=Update records successfully!
    ClickText                   Check Risk Health           anchor=Save
    ClickText                   New Primary Quote
    Sleep                       20s
    VerifyText                  Quote Console
    Click On Finalize
    Sleep                       30s
    Click On Generate Document
    Click On Bind Button
    Policy Duration Change Input and select
    Policy Duration Change Flow Complete
    Sleep                       5s
    ClickText                   Related                     anchor=Details
    VerifyText                  Policy Duration Change      anchor=Quote Type

Verify Policy Duration Change on Cyber Excess
    # Author = Amol Gaymukhe
    #TC=111281
    [Documentation]             field on Submission_Info for Cyber
    [Tags]                      Regression_Test_Cyber       Regression_Test
    Creating a new Account
    Enter data on Insured info Page for Cyber
    ClickText                   NEXT:Submission Info >
    Select Broker and Click On Next
    Select Industry             Business Services
    Select Classification       Administrators
    ClickText                   Save                        anchor=NEXT:Underwriter Analysis >
    Sleep                       10s
    ClickText                   NEXT:Underwriter Analysis >
    Enter Data in Underwriter Analysis Page
    ClickText                   Save                        anchor=Check Risk Health
    VerifyText                  Success                     anchor=Update records successfully!
    ClickText                   Check Risk Health           anchor=Save
    ClickText                   New Excess Quote
    Sleep                       20s
    VerifyText                  Quote Console
    Click On Finalize
    Sleep                       30s
    Click On Generate Document
    Click On Bind Button
    Policy Duration Change Input and select
    Policy Duration Change Flow Complete
    Sleep                       20s
    ClickText                   Related                     anchor=Details
    VerifyText                  Policy Duration Change      anchor=Quote Type