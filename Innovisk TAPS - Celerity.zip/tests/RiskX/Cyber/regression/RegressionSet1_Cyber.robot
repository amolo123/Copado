*** Settings ***
Resource                        ../../../../resources/common.robot
Resource                        ../../../../PageObjects/RiskX_PageObjects/PageObjects_Accounts.robot
Resource                        ../../../../PageObjects/RiskX_PageObjects/Cyber/PageObjects_Cyber_InsuredInfo.robot
Resource                        ../../../../PageObjects/RiskX_PageObjects/Cyber/PageObjects_Cyber_SubmissionInfo.robot
Resource                        ../../../../PageObjects/RiskX_PageObjects/Cyber/PageObjects_Cyber_UnderwriterAnalysis.robot
Resource                        ../../../../PageObjects/RiskX_PageObjects/Cyber/PageObjects_Cyber_CompareAndRateQuote.robot
Resource                        ../../../../PageObjects/RiskX_PageObjects/PageObjects_PolicyPage.robot

Library                         RetryFailed                 global_retries=${retry_count}
Suite Setup                     Setup Browser
Suite Teardown                  CloseAllBrowsers



*** Test Cases ***
Verify Cyber Primary E2E NB Flow - RiskX
    # Author = Amol Gaymukhe
    #TC=111281
    [Documentation]             field on Submission_Info for Cyber
    [Tags]                      Regression_Test_Cyber       Regression_Test
    Creating a new Account
    Enter data on Insured info Page for Cyber
    ClickText                   NEXT:Submission Info >
    Select Broker and Click On Next
    Select Industry             Business Services
    Select Classification       Administrators
    ClickText                   Save                        anchor=NEXT:Underwriter Analysis >
    Sleep                       10s
    ClickText                   NEXT:Underwriter Analysis >
    Enter Data in Underwriter Analysis Page
    ClickText                   Save                        anchor=Check Risk Health
    VerifyText                  Success                     anchor=Update records successfully!
    ClickText                   Check Risk Health           anchor=Save
    ClickText                   New Primary Quote
    Sleep                       20s
    VerifyText                  Quote Console
    Click On Finalize
    Sleep                       30s
    Click On Generate Document
    Click On Bind Button
    Generate Document on Policy                             PolicyForm


Verify Cyber Excess E2E NB Flow - RiskX 
    # Author = Amol Gaymukhe
    #TC=111281
    [Documentation]             field on Submission_Info for Cyber
    [Tags]                      Regression_Test_Cyber       Regression_Test
    Creating a new Account
    Enter data on Insured info Page for Cyber
    ClickText                   NEXT:Submission Info >
    Select Broker and Click On Next
    Select Industry             Business Services
    Select Classification       Administrators
    ClickText                   Save                        anchor=NEXT:Underwriter Analysis >
    Sleep                       10s
    ClickText                   NEXT:Underwriter Analysis >
    Enter Data in Underwriter Analysis Page
    ClickText                   Save                        anchor=Check Risk Health
    VerifyText                  Success                     anchor=Update records successfully!
    ClickText                   Check Risk Health           anchor=Save
    ClickText                   New Excess Quote
    Sleep                       20s
    VerifyText                  Quote Console
    Click On Finalize
    Sleep                       30s
    Click On Generate Document
    Click On Bind Button
    Generate Document on Policy                             PolicyForm


Verify Renewals RiskX Cyber Primary  
    # Author = Amol Gaymukhe
    #TC=111281
    [Documentation]             field on Submission_Info for Cyber
    [Tags]                      Regression_Test_Cyber       Regression_Test
    Creating a new Account
    Enter data on Insured info Page for Cyber
    ClickText                   NEXT:Submission Info >
    Select Broker and Click On Next
    Select Industry             Business Services
    Select Classification       Administrators
    ClickText                   Save                        anchor=NEXT:Underwriter Analysis >
    Sleep                       10s
    ClickText                   NEXT:Underwriter Analysis >
    Enter Data in Underwriter Analysis Page
    ClickText                   Save                        anchor=Check Risk Health
    VerifyText                  Success                     anchor=Update records successfully!
    ClickText                   Check Risk Health           anchor=Save
    ClickText                   New Primary Quote
    Sleep                       20s
    VerifyText                  Quote Console
    Click On Finalize
    Sleep                       30s
    Click On Generate Document
    Click On Bind Button
    Show More Actions
    ClickText                   Renewal                     anchor=Send Mail
    Sleep                       30s
    VerifyText                  Submission Info
    ClickText                   NEXT:Underwriter Analysis >
    VerifyText                  Base Rate
    ClickText                   Compare & Rate Quotes
    Sleep                       20s
    VerifyText                  Quote Console
    Click On Rate
    Click On Finalize
    Click On Bind Button
    ClickText                   Related                     anchor=Details
    VerifyText                  Renewal                     anchor=Quote Type

Verify Renewals RiskX Cyber Excess
    # Author = Amol Gaymukhe
    #TC=111281
    [Documentation]             field on Submission_Info for Cyber
    [Tags]                      Regression_Test_Cyber       Regression_Test
    Creating a new Account
    Enter data on Insured info Page for Cyber
    ClickText                   NEXT:Submission Info >
    Select Broker and Click On Next
    Select Industry             Business Services
    Select Classification       Administrators
    ClickText                   Save                        anchor=NEXT:Underwriter Analysis >
    Sleep                       10s
    ClickText                   NEXT:Underwriter Analysis >
    Enter Data in Underwriter Analysis Page
    ClickText                   Save                        anchor=Check Risk Health
    VerifyText                  Success                     anchor=Update records successfully!
    ClickText                   Check Risk Health           anchor=Save
    ClickText                   New Excess Quote
    Sleep                       20s
    VerifyText                  Quote Console
    Click On Finalize
    Sleep                       30s
    Click On Generate Document
    Click On Bind Button
    Show More Actions
    ClickText                   Renewal                     anchor=Send Mail
    Sleep                       30s
    VerifyText                  Submission Info
    ClickText                   NEXT:Underwriter Analysis >
    VerifyText                  Base Rate
    ClickText                   Compare & Rate Quotes
    Sleep                       20s
    VerifyText                  Quote Console
    Click On Rate
    Click On Finalize
    Click On Bind Button
    ClickText                   Related                     anchor=Details
    VerifyText                  Renewal                     anchor=Quote Type
