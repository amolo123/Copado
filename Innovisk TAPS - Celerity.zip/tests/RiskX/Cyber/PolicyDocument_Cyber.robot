* Settings ***
Resource                        ../../../resources/common.robot
Resource                        ../../../PageObjects/RiskX_PageObjects/PageObjects_Accounts.robot
Resource                        ../../../PageObjects/RiskX_PageObjects/Cyber/PageObjects_Cyber_InsuredInfo.robot
Resource                        ../../../PageObjects/RiskX_PageObjects/Cyber/PageObjects_Cyber_SubmissionInfo.robot
Resource                        ../../../PageObjects/RiskX_PageObjects/Cyber/PageObjects_Cyber_UnderwriterAnalysis.robot
Resource                        ../../../PageObjects/RiskX_PageObjects/Cyber/PageObjects_Cyber_CompareAndRateQuote.robot
Resource                        ../../../resources/ReadPDF.robot
Resource                        ../../../PageObjects/RiskX_PageObjects/Cyber/PageObjects_PDFRead_Cyber.robot
Resource                        ../../../PageObjects/RiskX_PageObjects/PageObjects_PolicyPage.robot

Library                         RetryFailed                 global_retries=${retry_count}
Suite Setup                     Setup Browser
Suite Teardown                  CloseAllBrowsers


*** Test Cases ***
Verify Policy document for Cyber - Primary 
    # Author = Amol Gaymukhe
    #TC=111677
    [Documentation]             field on Submission_Info for Cyber
    [Tags]                      Smoke_Test_Cyber            Smoke_Test
    Creating a new Account
    Enter data on Insured info Page for Cyber
    ClickText                   NEXT:Submission Info >
    Select Broker and Click On Next
    Select Industry             Business Services
    Select Classification       Administrators
    Add Details In SubmissionInfo Page
    ClickText                   Save                        anchor=NEXT:Underwriter Analysis >
    Sleep                       10s
    ClickText                   NEXT:Underwriter Analysis >
    Enter Data in Underwriter Analysis Page
    ClickText                   Save                        anchor=Check Risk Health
    VerifyText                  Success                     anchor=Update records successfully!
    ClickText                   Check Risk Health           anchor=Save
    ClickText                   New Primary Quote
    Sleep                       20s
    VerifyText                  Quote Console
    Click On Rate
    Click On Finalize
    Get Quote Letter Dynamic Document Cyber
    Click On Generate Document
    Click On Bind Button
    Generate Document on Policy                             PolicyForm
    Sleep                       15s
    ClickElement                //article[contains(@aria-label,'CelerityRiskPolicyForm')]//a
    ClickText                   View Document
    VerifyText                  Success                     anchor=Document has been downloaded sucessfully!    timeout=45s
    Sleep                       15s
    Move to outputdir
    Read Policy Letter Static Document Cyber
    Read Policy Letter Dynamic Document Cyber


Verify Policy document for Cyber - Excess 
    # Author = Amol Gaymukhe
    #TC=111677
    [Documentation]             field on Submission_Info for Cyber
    [Tags]                      Smoke_Test_Cyber            Smoke_Test
    Creating a new Account
    Enter data on Insured info Page for Cyber
    ClickText                   NEXT:Submission Info >
    Select Broker and Click On Next
    Select Industry             Business Services
    Select Classification       Administrators
    Add Details In SubmissionInfo Page
    ClickText                   Save                        anchor=NEXT:Underwriter Analysis >
    Sleep                       10s
    ClickText                   NEXT:Underwriter Analysis >
    Enter Data in Underwriter Analysis Page
    ClickText                   Save                        anchor=Check Risk Health
    VerifyText                  Success                     anchor=Update records successfully!
    ClickText                   Check Risk Health           anchor=Save
    ClickText                   New Excess Quote
    Sleep                       20s
    VerifyText                  Quote Console
    Sleep                       30s
    Click On Rate
    Click On Finalize
    Sleep                       30s
    Get Quote Letter Dynamic Document Cyber Excess
    Click On Generate Document
    Click On Bind Button
    Generate Document on Policy                             PolicyForm
    Sleep                       15s
    ClickElement                //article[contains(@aria-label,'CelerityRiskExcessPolicy')]//a
    ClickText                   View Document
    VerifyText                  Success                     anchor=Document has been downloaded sucessfully!    timeout=45s
    Sleep                       15s
    Move to outputdir
    Read Policy Letter Static Document Cyber Excess
    Read Policy Letter Dynamic Document Cyber