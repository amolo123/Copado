*** Settings ***
Resource                        ../../../resources/common.robot
Resource                        ../../../PageObjects/RiskX_PageObjects/PageObjects_Accounts.robot
Resource                        ../../../PageObjects/RiskX_PageObjects/Cyber/PageObjects_Cyber_InsuredInfo.robot
Resource                        ../../../PageObjects/RiskX_PageObjects/Cyber/PageObjects_Cyber_SubmissionInfo.robot

Library                         RetryFailed                 global_retries=${retry_count}
Suite Setup                     Setup Browser
Suite Teardown                  CloseAllBrowsers

*** Test Cases ***

Verify Elements on Submission Info Page 
    # Author = Amol Gaymukhe
    #TC=111280
    [Documentation]             field on Submission_Info for ECC
    [Tags]                      Smoke_Test_Cyber            Smoke_Test
    Creating a new Account
    Enter data on Insured info Page for Cyber
    ClickText                   NEXT:Submission Info >
    Select Broker and Click On Next
    Validate SubmissionInfo New submission Fields



Verify Elements with Action Submission Info Page 
    # Author = Amol Gaymukhe
    #TC=111281
    [Documentation]             field on Submission_Info for Cyber
    [Tags]                      Smoke_Test_Cyber            Smoke_Test
    Creating a new Account
    Enter data on Insured info Page for Cyber
    ClickText                   NEXT:Submission Info >
    Select Broker and Click On Next
    Select Industry             Business Services
    Select Classification       Administrators
    Verify Effective Date Received date and Close date
    ClickText                   Save                        anchor=NEXT:Underwriter Analysis >
    Click On Account
    Back
    Click On Submission Owner
    Back


Verify static information from Submission Info page
    # Author = Amol Gaymukhe
    #TC=111281
    [Documentation]             field on Submission_Info for Cyber
    [Tags]                      Smoke_Test_Cyber            Smoke_Test
    Creating a new Account
    Enter data on Insured info Page for Cyber
    ClickText                   NEXT:Submission Info >
    Select Broker and Click On Next
    Select Industry             Business Services
    Select Classification       Administrators
    Verify Effective Date Received date and Close date
    ClickText                   Save                        anchor=NEXT:Underwriter Analysis >
    Verify Submission Info Fields
