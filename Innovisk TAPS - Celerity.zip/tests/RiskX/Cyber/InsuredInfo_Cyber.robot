*** Settings ***
Resource                        ../../../resources/common.robot
Resource                        ../../../PageObjects/RiskX_PageObjects/PageObjects_Accounts.robot
Resource                        ../../../PageObjects/RiskX_PageObjects/PageObjects_HomePage.robot
Resource                        ../../../PageObjects/RiskX_PageObjects/Cyber/PageObjects_Cyber_InsuredInfo.robot

Library                         RetryFailed                 global_retries=${retry_count}

Suite Setup                     Setup Browser
Suite Teardown                  CloseAllBrowsers


*** Test Cases ***

Verify Save Button and Next Submission Info Functionality on Insured Info Page - Cyber
    # Author = Amol Gaymukhe
    #TC=111258,111255
    [Documentation]             Field on Insured Info for Cyber
    [Tags]                      Smoke_Test_Cyber            Smoke_Test

    Creating a new Account
    Validate field on Insured Info page for Cyber
    Click On Account Link
