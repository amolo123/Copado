*** Settings ***
Resource                        ../../../resources/common.robot
Resource                        ../../../PageObjects/RiskX_PageObjects/PageObjects_Accounts.robot
Resource                        ../../../PageObjects/RiskX_PageObjects/Cyber/PageObjects_Cyber_InsuredInfo.robot
Resource                        ../../../PageObjects/RiskX_PageObjects/Cyber/PageObjects_Cyber_SubmissionInfo.robot
Resource                        ../../../PageObjects/RiskX_PageObjects/Cyber/PageObjects_Cyber_UnderwriterAnalysis.robot
Resource                        ../../../PageObjects/RiskX_PageObjects/Cyber/PageObjects_Cyber_CompareAndRateQuote.robot

Library                         RetryFailed                 global_retries=${retry_count}
Suite Setup                     Setup Browser
Suite Teardown                  CloseAllBrowsers



*** Test Cases ***
Verify elements on Compare and Rate Quote page Primary Cyber 
    # Author = Amol Gaymukhe
    #TC=111281
    [Documentation]             field on Submission_Info for Cyber
    [Tags]                      Smoke_Test_Cyber            Smoke_Test
    Creating a new Account
    Enter data on Insured info Page for Cyber
    ClickText                   NEXT:Submission Info >
    Select Broker and Click On Next
    Select Industry             Business Services
    Select Classification       Administrators
    ClickText                   Save                        anchor=NEXT:Underwriter Analysis >
    Sleep                       10s
    ClickText                   NEXT:Underwriter Analysis >
    Enter Data in Underwriter Analysis Page Max Revenue 5000000000 
    ClickText                   Save                        anchor=Check Risk Health
    VerifyText                  Success                     anchor=Update records successfully!
    ClickText                   Check Risk Health           anchor=Save
    ClickText                   New Primary Quote
    Sleep                       30s
    Verify Elements on Compare and Rate Quote Primary


Verify elements on Compare and Rate Quote page Excess Cyber 
    # Author = Amol Gaymukhe
    #TC=111281
    [Documentation]             field on Submission_Info for Cyber
    [Tags]                      Smoke_Test_Cyber            Smoke_Test
    Creating a new Account
    Enter data on Insured info Page for Cyber
    ClickText                   NEXT:Submission Info >
    Select Broker and Click On Next
    Select Industry             Business Services
    Select Classification       Administrators
    ClickText                   Save                        anchor=NEXT:Underwriter Analysis >
    Sleep                       10s
    ClickText                   NEXT:Underwriter Analysis >
    Enter Data in Underwriter Analysis Page
    ClickText                   Save                        anchor=Check Risk Health
    VerifyText                  Success                     anchor=Update records successfully!
    ClickText                   Check Risk Health           anchor=Save
    ClickText                   New Excess Quote
    Sleep                       20s
    VerifyText                  Quote Console
    Verify Elements on Compare and Rate Quote Excess


Verify actions performed on Primary Quote console page Cyber
    # Author = Amol Gaymukhe
    #TC=111281
    [Documentation]             field on Submission_Info for Cyber
    [Tags]                      Smoke_Test_Cyber            Smoke_Test
    Creating a new Account
    Enter data on Insured info Page for Cyber
    ClickText                   NEXT:Submission Info >
    Select Broker and Click On Next
    Select Industry             Business Services
    Select Classification       Administrators
    ClickText                   Save                        anchor=NEXT:Underwriter Analysis >
    Sleep                       10s
    ClickText                   NEXT:Underwriter Analysis >
    Enter Data in Underwriter Analysis Page
    ClickText                   Save                        anchor=Check Risk Health
    Sleep                       5s
    ClickText                   Check Risk Health           anchor=Save
    ClickText                   New Primary Quote
    Sleep                       20s
    VerifyText                  Quote Console
    TypeText                    //input[contains(@name,'-Commission %')]                25             timeout=65s            partial_match=false
    Click On Save
    Click On Rate
    Click On Clone
    Close cloned Quote
    Click On Endorsement and Subjectivity
    VerifyText                  Endorsement and Subjectivity
    ClickText                   Return Quote Process
    Click On Finalize
    Sleep                       30s
    Click On Generate Document
    Click On Bind Button



Verify actions performed on Excess Quote console page
    # Author = Amol Gaymukhe
    #TC=111281
    [Documentation]             field on Submission_Info for Cyber
    [Tags]                      Smoke_Test_Cyber            Smoke_Test
    Creating a new Account
    Enter data on Insured info Page for Cyber
    ClickText                   NEXT:Submission Info >
    Select Broker and Click On Next
    Select Industry             Business Services
    Select Classification       Administrators
    ClickText                   Save                        anchor=NEXT:Underwriter Analysis >
    Sleep                       10s
    ClickText                   NEXT:Underwriter Analysis >
    Enter Data in Underwriter Analysis Page
    ClickText                   Save                        anchor=Check Risk Health
    Sleep                       5s
    ClickText                   Check Risk Health           anchor=Save
    ClickText                   New Excess Quote
    Sleep                       20s
    VerifyText                  Quote Console
    TypeText                    //input[contains(@name,'-Commission %')]                25             timeout=65s            partial_match=false
    Click On Save
    Click On Rate
    Click On Clone
    Close cloned Quote
    Click On Endorsement and Subjectivity
    VerifyText                  Endorsement and Subjectivity
    ClickText                   Return Quote Process
    Click On Finalize
    Sleep                       30s
    Click On Generate Document
    Click On Bind Button
