*** Settings ***
Resource                        ../../../resources/common.robot
Resource                        ../../../PageObjects/RiskX_PageObjects/PageObjects_Accounts.robot
Resource                        ../../../PageObjects/RiskX_PageObjects/PageObjects_HomePage.robot
Resource                        ../../../PageObjects/RiskX_PageObjects/PDO/PageObjects_PDO_SubmissionInfo.robot
Resource                        ../../../PageObjects/RiskX_PageObjects/PDO/PageObjects_PDO_UnderwrittingConsole.robot
Resource                        ../../../PageObjects/RiskX_PageObjects/PDO/PageObjects_PDO_QuoteConsole.robot

Library                         RetryFailed                 global_retries=${retry_count}

Suite Setup                     Setup Browser
Suite Teardown                  CloseAllBrowsers


*** Test Cases ***
Verify the details displayed on Quote console page for Primary Quote
    # Author = Amol Gaymukhe
    #TC=117128,117129,117144,117143
    [Documentation]             field on Quote Console for PDO
    [Tags]                      Smoke_Test_PDO              Smoke_Test
    Creating a new Account
    Enter data on Submission info Page for PDO
    Add Data In submission console
    #Add the details displayed on Additional Insured Details
    ClickText                   NEXT:Underwriting Console >                             anchor=Save
    VerifyText                  Industry & Sector
    Verify that the Underwriting analysis details are saved successfully
    ClickText                   New Primary Quote
    Sleep                       30s
    Verify the details displayed on Quote console page for Primary and Excess Quote



Verify Quote Operations on Quote console page
    # Author = Amol Gaymukhe
    #TC=117128,117129,117144,117143
    [Documentation]             field on Quote Console for PDO
    [Tags]                      Smoke_Test_PDO              Smoke_Test
    Creating a new Account
    Enter data on Submission info Page for PDO
    Add Data In submission console
    #Add the details displayed on Additional Insured Details
    ClickText                   NEXT:Underwriting Console >                             anchor=Save
    VerifyText                  Industry & Sector
    Verify that the Underwriting analysis details are saved successfully
    ClickText                   New Primary Quote
    Sleep                       30s
    Rate Quote Click
    Click On Clone
    Close Clone Quote
    Click On Endorsement and Subjectivity
    Select Endorsements
    Click On Endorsement and Subjectivity
    Select Subjectivities
    Get Premium Value before Override
    Enter Data In Override Premium
    Click On Save
    Rate Quote Click
    Sleep                       25s
    Get Premium Value after Override and check change
    Click On Finalize
    Verify Bind Page Elements
    Click On Bind Button


