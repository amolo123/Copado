*** Settings ***
Resource                        ../../../resources/common.robot
Resource                        ../../../PageObjects/RiskX_PageObjects/PageObjects_Accounts.robot
Resource                        ../../../PageObjects/RiskX_PageObjects/PageObjects_HomePage.robot
Resource                        ../../../PageObjects/RiskX_PageObjects/PDO/PageObjects_PDO_SubmissionInfo.robot
Resource                        ../../../PageObjects/RiskX_PageObjects/PDO/PageObjects_PDO_UnderwrittingConsole.robot
Resource                        ../../../PageObjects/RiskX_PageObjects/PDO/PageObjects_PDO_QuoteConsole.robot
Resource                        ../../../PageObjects/RiskX_PageObjects/PageObjects_PolicyPage.robot
Library                         ../../../libraries/MailLib.py                           ${tenant_id}         ${client_id_mail}        ${client_secret_mail}

Library                         ../../../libraries/graph.py
Resource                        ../../../resources/graph.resource


Library                         RetryFailed                 global_retries=${retry_count}

Suite Setup                     Setup Browser
Suite Teardown                  CloseAllBrowsers


*** Test Cases ***
Verify Bind email template
    # Author = Amol Gaymukhe
    #TC=117128,117129,117144,117143
    [Documentation]             Bind email template
    [Tags]                      Smoke_Test_PDO              Smoke_Test
    Creating a new Account
    Enter data on Submission info Page for PDO
    Add Data In submission console
    #Add the details displayed on Additional Insured Details
    ClickText                   NEXT:Underwriting Console >                             anchor=Save
    VerifyText                  Industry & Sector
    Verify that the Underwriting analysis details are saved successfully
    ClickText                   New Primary Quote
    Sleep                       30s
    VerifyText                  Quote Console               timeout=30s
    Click On Finalize
    Click On Bind Button
    Send Mail On Submission Page                            Bind email
    Send Mail On Submission Page                            Decline email
    Send Mail On Submission Page                            Quote email
    Send Mail On Submission Page                            Submission email