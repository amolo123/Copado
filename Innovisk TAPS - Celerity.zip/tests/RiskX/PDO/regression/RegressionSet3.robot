*** Settings ***
Resource                        ../../../../resources/common.robot
Resource                        ../../../../PageObjects/RiskX_PageObjects/PageObjects_Accounts.robot
Resource                        ../../../../PageObjects/RiskX_PageObjects/PageObjects_HomePage.robot
Resource                        ../../../../PageObjects/RiskX_PageObjects/PDO/PageObjects_PDO_SubmissionInfo.robot
Resource                        ../../../../PageObjects/RiskX_PageObjects/PDO/PageObjects_PDO_UnderwrittingConsole.robot
Resource                        ../../../../PageObjects/RiskX_PageObjects/PDO/PageObjects_PDO_QuoteConsole.robot
Resource                        ../../../../PageObjects/RiskX_PageObjects/PageObjects_PolicyPage.robot

Library                         RetryFailed                 global_retries=${retry_count}

Suite Setup                     Setup Browser
Suite Teardown                  CloseAllBrowsers


*** Test Cases ***

Verify the details displayed on Policy details page
    # Author = Amol Gaymukhe
    #TC=117167,
    [Documentation]             Regression For PDO
    [Tags]                      Regression_Test_PDO         Regression_Test
    Creating a new Account
    Enter data on Submission info Page for PDO
    Add Data In submission console
    #Add the details displayed on Additional Insured Details
    ClickText                   NEXT:Underwriting Console >                             anchor=Save
    VerifyText                  Industry & Sector
    Verify that the Underwriting analysis details are saved successfully
    ClickText                   New Primary Quote
    Sleep                       30s
    VerifyText                  Quote Console
    Click On Finalize
    Click On Bind Button
    Verify Elements On Policy Page
    Show More Actions
    ClickText                   Renewal                     anchor=Send Mail
    VerifyText                  Account Information         timeout=45s
    ClickText                   Quote Console
    VerifyText                  Quote Console               anchor=Primary Quotes       timeout=45s
    Rate Quote Click
    Click On Finalize
    Click On Bind Button
    ClickText                   Related                     anchor=Details
    VerifyText                  Renewal                     anchor=Status