*** Settings ***
Resource                        ../../../../resources/common.robot
Resource                        ../../../../PageObjects/RiskX_PageObjects/PageObjects_Accounts.robot
Resource                        ../../../../PageObjects/RiskX_PageObjects/PageObjects_HomePage.robot
Resource                        ../../../../PageObjects/RiskX_PageObjects/PDO/PageObjects_PDO_SubmissionInfo.robot
Resource                        ../../../../PageObjects/RiskX_PageObjects/PDO/PageObjects_PDO_UnderwrittingConsole.robot
Resource                        ../../../../PageObjects/RiskX_PageObjects/PDO/PageObjects_PDO_QuoteConsole.robot
Resource                        ../../../../PageObjects/RiskX_PageObjects/PageObjects_PolicyPage.robot

Library                         RetryFailed                 global_retries=${retry_count}

Suite Setup                     Setup Browser
Suite Teardown                  CloseAllBrowsers


*** Test Cases ***
Verify the Flat Cancellation functionality
    # Author = Amol Gaymukhe
    #TC=117261
    [Documentation]             Regression For PDO
    [Tags]                      Regression_Test_PDO         Regression_Test
    Creating a new Account
    Enter data on Submission info Page for PDO
    Add Data In submission console
    #Add the details displayed on Additional Insured Details
    ClickText                   NEXT:Underwriting Console >                             anchor=Save
    VerifyText                  Industry & Sector
    Verify that the Underwriting analysis details are saved successfully
    ClickText                   New Primary Quote
    Sleep                       30s
    VerifyText                  Quote Console               timeout=30s
    Click On Finalize
    Click On Bind Button
    Change Policy               Flat Cancellation
    Flat Cancellation Input
    Sleep                       45s
    ClickText                   Related                     anchor=Details
    VerifyText                  Flat Cancellation           anchor=Quote Type

Verify the MidTerm Cancellation functionality
    # Author = Amol Gaymukhe
    #TC=117262
    [Documentation]             Regression For PDO
    [Tags]                      Regression_Test_PDO         Regression_Test
    Creating a new Account
    Enter data on Submission info Page for PDO
    Add Data In submission console
    #Add the details displayed on Additional Insured Details
    ClickText                   NEXT:Underwriting Console >                             anchor=Save
    VerifyText                  Industry & Sector
    Verify that the Underwriting analysis details are saved successfully
    ClickText                   New Primary Quote
    Sleep                       30s
    VerifyText                  Quote Console               timeout=30s
    Click On Finalize
    Click On Bind Button
    Sleep                       10s
    Change Policy               Midterm Cancellation
    Midterm Cancellation Input PDO
    Midterm Cancellation Input Complete PDO
    Sleep                       10s
    ClickText                   Related                     anchor=Details
    VerifyText                  Midterm Cancellation        anchor=Quote Type

Verify the Amendment functionality
    # Author = Amol Gaymukhe
    #TC=117258
    [Documentation]             Regression For PDO
    [Tags]                      Regression_Test_PDO         Regression_Test
    Creating a new Account
    Enter data on Submission info Page for PDO
    Add Data In submission console
    #Add the details displayed on Additional Insured Details
    ClickText                   NEXT:Underwriting Console >                             anchor=Save
    VerifyText                  Industry & Sector
    Verify that the Underwriting analysis details are saved successfully
    ClickText                   New Primary Quote
    Sleep                       30s
    VerifyText                  Quote Console               timeout=30s
    Click On Finalize
    Click On Bind Button
    Change Policy               Amendment
    Amendment Input
    Amendment Input Complete PDO
    Sleep                       10s
    ClickText                   Related                     anchor=Details
    VerifyText                  Amendment                   anchor=Quote Type
