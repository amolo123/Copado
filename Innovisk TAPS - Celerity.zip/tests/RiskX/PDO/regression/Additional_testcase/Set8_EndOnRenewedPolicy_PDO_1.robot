*** Settings ***
Resource                        ../../../../../resources/common.robot
Resource                        ../../../../../PageObjects/RiskX_PageObjects/PageObjects_Accounts.robot
Resource                        ../../../../../PageObjects/RiskX_PageObjects/PageObjects_HomePage.robot
Resource                        ../../../../../PageObjects/RiskX_PageObjects/PDO/PageObjects_PDO_SubmissionInfo.robot
Resource                        ../../../../../PageObjects/RiskX_PageObjects/PDO/PageObjects_PDO_UnderwrittingConsole.robot
Resource                        ../../../../../PageObjects/RiskX_PageObjects/PDO/PageObjects_PDO_QuoteConsole.robot
Resource                        ../../../../../PageObjects/RiskX_PageObjects/PageObjects_PolicyPage.robot

Library                         RetryFailed                 global_retries=${retry_count}

Suite Setup                     Setup Browser
Suite Teardown                  CloseAllBrowsers


*** Test Cases ***

To verify Amendment transaction on renewed policy PDO Primary
    # Author = Saurabh Salgaonkar
    #TC=122538,
    [Documentation]             Regression For PDO
    [Tags]                      Regression_Test_PDO         Regression_Test
    Creating a new Account
    Enter data on Submission info Page for PDO
    Add Data In submission console
    #Add the details displayed on Additional Insured Details
    ClickText                   NEXT:Underwriting Console >                             anchor=Save
    VerifyText                  Industry & Sector
    Verify that the Underwriting analysis details are saved successfully
    ClickText                   New Primary Quote
    Sleep                       30s
    VerifyText                  Quote Console
    Click On Finalize
    Click On Bind Button
    Verify Elements On Policy Page
    Show More Actions
    ClickText                   Renewal                     anchor=Send Mail
    VerifyText                  Account Information         timeout=45s
    ClickText                   Quote Console
    VerifyText                  Quote Console               anchor=Primary Quotes       timeout=45s
    Rate Quote Click
    Click On Finalize
    Click On Bind Button
    ClickText                   Related                     anchor=Details
    VerifyText                  Renewal                     anchor=Status
    Change Policy               Amendment
    Amendment Input
    Amendment Input Complete PDO
    Sleep                       10s
    ClickText                   Related                     anchor=Details
    VerifyText                  Amendment                   anchor=Quote Type

    
To verify Amendment transaction on renewed policy PDO Excess
    # Author = Saurabh Salgaonkar
    #TC=122539,
    [Documentation]             Regression For PDO
    [Tags]                      Regression_Test_PDO         Regression_Test
    Creating a new Account
    Enter data on Submission info Page for PDO
    Add Data In submission console
    #Add the details displayed on Additional Insured Details
    ClickText                   NEXT:Underwriting Console >                             anchor=Save
    VerifyText                  Industry & Sector
    Verify that the Underwriting analysis details are saved successfully
    ClickText                   New Excess Quote
    Sleep                       30s
    VerifyText                  Quote Console
    Click On Finalize
    Click On Bind Button
    Verify Elements On Policy Page
    Show More Actions
    ClickText                   Renewal                     anchor=Send Mail
    VerifyText                  Account Information         timeout=45s
    ClickText                   Quote Console
    VerifyText                  Quote Console               anchor=Excess Quotes       timeout=45s
    Rate Quote Click
    Click On Finalize
    Click On Bind Button
    ClickText                   Related                     anchor=Details
    VerifyText                  Renewal                     anchor=Status
    Change Policy               Amendment
    Amendment Input
    Amendment Input Complete PDO
    Sleep                       10s
    ClickText                   Related                     anchor=Details
    VerifyText                  Amendment                   anchor=Quote Type

To verify Mid Term cancellation transaction on renewed policy PDO Primary 
    # Author = Saurabh Salgaonkar
    #TC=122540,
    [Documentation]             Regression For PDO
    [Tags]                      Regression_Test_PDO         Regression_Test
    Creating a new Account
    Enter data on Submission info Page for PDO
    Add Data In submission console
    #Add the details displayed on Additional Insured Details
    ClickText                   NEXT:Underwriting Console >                             anchor=Save
    VerifyText                  Industry & Sector
    Verify that the Underwriting analysis details are saved successfully
    ClickText                   New Primary Quote
    Sleep                       30s
    VerifyText                  Quote Console
    Click On Finalize
    Click On Bind Button
    Verify Elements On Policy Page
    Show More Actions
    ClickText                   Renewal                     anchor=Send Mail
    VerifyText                  Account Information         timeout=45s
    ClickText                   Quote Console
    VerifyText                  Quote Console               anchor=Primary Quotes       timeout=45s
    Rate Quote Click
    Click On Finalize
    Click On Bind Button
    ClickText                   Related                     anchor=Details
    VerifyText                  Renewal                     anchor=Status
    Sleep                       10s
    Change Policy               Midterm Cancellation
    Midterm Cancellation Input PDO
    Midterm Cancellation Input Complete PDO
    Sleep                       10s
    ClickText                   Related                     anchor=Details
    VerifyText                  Midterm Cancellation        anchor=Quote Type


To verify Mid Term cancellation transaction on renewed policy PDO Excess 
    # Author = Saurabh Salgaonkar
    #TC=122541,
    [Documentation]             Regression For PDO
    [Tags]                      Regression_Test_PDO         Regression_Test
    Creating a new Account
    Enter data on Submission info Page for PDO
    Add Data In submission console
    #Add the details displayed on Additional Insured Details
    ClickText                   NEXT:Underwriting Console >                             anchor=Save
    VerifyText                  Industry & Sector
    Verify that the Underwriting analysis details are saved successfully
    ClickText                   New Primary Quote
    Sleep                       30s
    VerifyText                  Quote Console
    Click On Finalize
    Click On Bind Button
    Verify Elements On Policy Page
    Show More Actions
    ClickText                   Renewal                     anchor=Send Mail
    VerifyText                  Account Information         timeout=45s
    ClickText                   Quote Console
    VerifyText                  Quote Console               anchor=Primary Quotes       timeout=45s
    Rate Quote Click
    Click On Finalize
    Click On Bind Button
    ClickText                   Related                     anchor=Details
    VerifyText                  Renewal                     anchor=Status
    Sleep                       10s
    Change Policy               Midterm Cancellation
    Midterm Cancellation Input PDO
    Midterm Cancellation Input Complete PDO
    Sleep                       10s
    ClickText                   Related                     anchor=Details
    VerifyText                  Midterm Cancellation        anchor=Quote Type


