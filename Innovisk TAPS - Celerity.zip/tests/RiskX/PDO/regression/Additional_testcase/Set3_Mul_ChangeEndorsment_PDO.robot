*** Settings ***
Resource                        ../../../../../resources/common.robot
Resource                        ../../../../../PageObjects/RiskX_PageObjects/PageObjects_Accounts.robot
Resource                        ../../../../../PageObjects/RiskX_PageObjects/PageObjects_HomePage.robot
Resource                        ../../../../../PageObjects/RiskX_PageObjects/PDO/PageObjects_PDO_SubmissionInfo.robot
Resource                        ../../../../../PageObjects/RiskX_PageObjects/PDO/PageObjects_PDO_UnderwrittingConsole.robot
Resource                        ../../../../../PageObjects/RiskX_PageObjects/PDO/PageObjects_PDO_QuoteConsole.robot
Resource                        ../../../../../PageObjects/RiskX_PageObjects/PageObjects_PolicyPage.robot

Library                         RetryFailed                 global_retries=${retry_count}

Suite Setup                     Setup Browser
Suite Teardown                  CloseAllBrowsers


*** Test Cases ***

To verify Multiple Change endorsement on single PDO Primary policy
    # Author = Pinki Lubana
    #TC=122381,
    [Documentation]             Multiple change endorsement
    [Tags]                      Regression_Test_PDO         Regression_Test
    Creating a new Account
    Enter data on Submission info Page for PDO
    Add Data In submission console
    #Add the details displayed on Additional Insured Details
    ClickText                   NEXT:Underwriting Console >                             anchor=Save
    VerifyText                  Industry & Sector
    Verify that the Underwriting analysis details are saved successfully
    ClickText                   New Primary Quote
    Sleep                       30s
    VerifyText                  Quote Console
    Click On Finalize
    Click On Bind Button
    Change Policy               Amendment
    Amendment Input
    Amendment Input Complete PDO
    Sleep                       10s
    ClickText                   Related                     anchor=Details
    VerifyText                  New Business                anchor=Quote Type
    VerifyText                  Amendment                   anchor=Quote Type
    Change Policy               Midterm Cancellation
    Sleep                       10s
    Midterm Cancellation Input PDO
    Sleep                       10s
    Midterm Cancellation Input Complete PDO
    Sleep                       10s
    ClickText                   Related                     anchor=Details
    VerifyText                  New Business                anchor=Quote Type
    VerifyText                  Amendment                   anchor=Quote Type
    
    VerifyText                  Midterm Cancellation        anchor=Quote Type
    Change Policy               Reinstatement
    Reinstatement Input
    Sleep                       20s
    ClickText                   Related                     anchor=Details
    VerifyText                  New Business                anchor=Quote Type
    VerifyText                  Amendment                   anchor=Quote Type
    VerifyText                  Midterm Cancellation        anchor=Quote Type
    VerifyText                  Reinstatement               anchor=Quote Type
    ClickText                   Change Policy
    Sleep                       20s
    DropDown                    //select                    Policy Duration Change
    ClickText                   Confirm                     anchor=Cancel
    Policy Duration Chage Input Complete PDO
    ClickText                   Related                     anchor=Details
    VerifyText                  New Business                anchor=Quote Type
    VerifyText                  Amendment                   anchor=Quote Type
    VerifyText                  Midterm Cancellation        anchor=Quote Type
    VerifyText                  Policy Duration Change      anchor=Status


To verify Multiple Change endorsement on single PDO Excess policy
    # Author = Pinki Lubana
    #TC=122491,
    [Documentation]             Multiple change endorsement
    [Tags]                      Regression_Test_PDO         Regression_Test
    Creating a new Account
    Enter data on Submission info Page for PDO
    Add Data In submission console
    #Add the details displayed on Additional Insured Details
    ClickText                   NEXT:Underwriting Console >                             anchor=Save
    VerifyText                  Industry & Sector
    Verify that the Underwriting analysis details are saved successfully
    ClickText                   New Excess Quote
    Sleep                       30s
    VerifyText                  Quote Console
    Click On Finalize
    Click On Bind Button
    Change Policy               Amendment
    Amendment Input
    Amendment Input Complete PDO
    Sleep                       10s
    ClickText                   Related                     anchor=Details
    VerifyText                  New Business                anchor=Quote Type
    VerifyText                  Amendment                   anchor=Quote Type
    Change Policy               Midterm Cancellation
    Sleep                       10s
    Midterm Cancellation Input PDO
    Sleep                       10s
    Midterm Cancellation Input Complete PDO
    Sleep                       10s
    ClickText                   Related                     anchor=Details
    VerifyText                  New Business                anchor=Quote Type
    VerifyText                  Amendment                   anchor=Quote Type
    
    VerifyText                  Midterm Cancellation        anchor=Quote Type
    Change Policy               Reinstatement
    Reinstatement Input
    Sleep                       20s
    ClickText                   Related                     anchor=Details
    VerifyText                  New Business                anchor=Quote Type
    VerifyText                  Amendment                   anchor=Quote Type
    VerifyText                  Midterm Cancellation        anchor=Quote Type
    VerifyText                  Reinstatement               anchor=Quote Type
    ClickText                   Change Policy
    Sleep                       20s
    DropDown                    //select                    Policy Duration Change
    ClickText                   Confirm                     anchor=Cancel
    Policy Duration Chage Input Complete PDO
    ClickText                   Related                     anchor=Details
    VerifyText                  New Business                anchor=Quote Type
    VerifyText                  Amendment                   anchor=Quote Type
    VerifyText                  Midterm Cancellation        anchor=Quote Type
    VerifyText                  Policy Duration Change      anchor=Status