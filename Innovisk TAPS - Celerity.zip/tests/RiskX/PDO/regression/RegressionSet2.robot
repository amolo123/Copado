*** Settings ***
Resource                        ../../../../resources/common.robot
Resource                        ../../../../PageObjects/RiskX_PageObjects/PageObjects_Accounts.robot
Resource                        ../../../../PageObjects/RiskX_PageObjects/PageObjects_HomePage.robot
Resource                        ../../../../PageObjects/RiskX_PageObjects/PDO/PageObjects_PDO_SubmissionInfo.robot
Resource                        ../../../../PageObjects/RiskX_PageObjects/PDO/PageObjects_PDO_UnderwrittingConsole.robot
Resource                        ../../../../PageObjects/RiskX_PageObjects/PDO/PageObjects_PDO_QuoteConsole.robot
Resource                        ../../../../PageObjects/RiskX_PageObjects/PageObjects_PolicyPage.robot

Library                         RetryFailed                 global_retries=${retry_count}

Suite Setup                     Setup Browser
Suite Teardown                  CloseAllBrowsers


*** Test Cases ***

Verify the Broker Record Change functionality
    # Author = Amol Gaymukhe
    #TC=117258
    [Documentation]             Regression For PDO
    [Tags]                      Regression_Test_PDO         Regression_Test
    Creating a new Account
    Enter data on Submission info Page for PDO
    Add Data In submission console
    #Add the details displayed on Additional Insured Details
    ClickText                   NEXT:Underwriting Console >                             anchor=Save
    VerifyText                  Industry & Sector
    Verify that the Underwriting analysis details are saved successfully
    ClickText                   New Primary Quote
    Sleep                       30s
    VerifyText                  Quote Console               timeout=30s
    Click On Finalize
    Click On Bind Button
    ClickText                   Change Policy
    DropDown                    //select                    Broker on Record Change
    Broker on Record Change Input Complete PDO
    Sleep                       25s
    ClickText                   Related                     anchor=Details
    VerifyText                  Broker on Record Change     anchor=Quote Type

Verify the Coverage Cancel & Replace functionality
    # Author = Amol Gaymukhe
    #TC=117263
    [Documentation]             Regression For PDO
    [Tags]                      Regression_Test_PDO         Regression_Test
    Creating a new Account
    Enter data on Submission info Page for PDO
    Add Data In submission console
    #Add the details displayed on Additional Insured Details
    ClickText                   NEXT:Underwriting Console >                             anchor=Save
    VerifyText                  Industry & Sector
    Verify that the Underwriting analysis details are saved successfully
    ClickText                   New Primary Quote
    Sleep                       30s
    VerifyText                  Quote Console               timeout=30s
    Click On Finalize
    Click On Bind Button
    ClickText                   Change Policy
    DropDown                    //select                    Coverage Cancel & Replace
    ClickText                   Confirm                     anchor=Cancel
    VerifyText                  Confirmation
    ClickText                   Confirm                     anchor=Cancel
    Cancel Coverage Replace Input Complete PDO
    Sleep                       20s
    ClickText                   Related                     anchor=Details
    VerifyText                  Cancelled                   anchor=Status
    VerifyText                  Correction                  anchor=Status
    VerifyText                  Bound                       anchor=Status





Verify the Policy Duration change functionality
    # Author = Amol Gaymukhe
    #TC=117260
    [Documentation]             Regression For PDO
    [Tags]                      Regression_Test_PDO         Regression_Test
    Creating a new Account
    Enter data on Submission info Page for PDO
    Add Data In submission console
    #Add the details displayed on Additional Insured Details
    ClickText                   NEXT:Underwriting Console >                             anchor=Save
    VerifyText                  Industry & Sector
    Verify that the Underwriting analysis details are saved successfully
    ClickText                   New Primary Quote
    Sleep                       30s
    VerifyText                  Quote Console               timeout=30s
    Click On Finalize
    Click On Bind Button
    ClickText                   Change Policy
    DropDown                    //select                    Policy Duration Change
    ClickText                   Confirm                     anchor=Cancel
    Policy Duration Chage Input Complete PDO
    ClickText                   Related                     anchor=Details
    VerifyText                  Policy Duration Change      anchor=Status

Verify the Update Insured Name or Address functionality
    # Author = Amol Gaymukhe
    #TC=117259
    [Documentation]             Regression For PDO
    [Tags]                      Regression_Test_PDO         Regression_Test
    Creating a new Account
    Enter data on Submission info Page for PDO
    Add Data In submission console
    #Add the details displayed on Additional Insured Details
    ClickText                   NEXT:Underwriting Console >                             anchor=Save
    VerifyText                  Industry & Sector
    Verify that the Underwriting analysis details are saved successfully
    ClickText                   New Primary Quote
    Sleep                       30s
    VerifyText                  Quote Console               timeout=30s
    Click On Finalize
    Click On Bind Button
    ClickText                   Change Policy
    DropDown                    //select                    Update Insured Name or Address
    ClickText                   Confirm                     anchor=Cancel
    ClickElement                (//input[@placeholder\="Search..."])[1]
    TypeText                    (//input[@placeholder\="Search..."])[1]                 901 Alabama Drive
    ClickElement                (//li[@role\='presentation']/span)[2]
    ClickText                   Save                        anchor=NEXT:Underwriting Console >
    VerifyText                  Success!                    anchor=Record is saved !    timeout=35s
    ClickText                   Quote Console
    Update Insured Name or Address Input Complete PDO
    ClickText                   Related                     anchor=Details
    VerifyText                  Update Insured Name or Address                          anchor=Status
