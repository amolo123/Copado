*** Settings ***
Resource                        ../../../resources/common.robot
Resource                        ../../../PageObjects/RiskX_PageObjects/PageObjects_Accounts.robot
Resource                        ../../../PageObjects/RiskX_PageObjects/PageObjects_HomePage.robot
Resource                        ../../../PageObjects/RiskX_PageObjects/PDO/PageObjects_PDO_SubmissionInfo.robot
Resource                        ../../../PageObjects/RiskX_PageObjects/PDO/PageObjects_PDO_UnderwrittingConsole.robot

Library                         RetryFailed                 global_retries=${retry_count}

Suite Setup                     Setup Browser
Suite Teardown                  CloseAllBrowsers


*** Test Cases ***
Validate the picklist and button displayed on Underwriting Console
    # Author = Amol Gaymukhe
    #TC=117121,117123
    [Documentation]             Field on Submission Console for PDO
    [Tags]                      Smoke_Test_PDO              Smoke_Test
    Creating a new Account
    Enter data on Submission info Page for PDO
    Add Data In submission console
    ClickText                   NEXT:Underwriting Console >                             anchor=Save
    VerifyText                  Industry & Sector
    Validate the picklist and button displayed on Underwriting Console
    Verify that the Submission gets decline when u/w select the answer of the question whose status is Stop!Decline!



Verify that the Underwriting analysis details are saved successfully  
    # Author = Amol Gaymukhe
    #TC=117121,117123
    [Documentation]             Field on Submission Console for PDO
    [Tags]                      Smoke_Test_PDO              Smoke_Test
    Creating a new Account
    Enter data on Submission info Page for PDO
    Add Data In submission console
    ClickText                   NEXT:Underwriting Console >                             anchor=Save
    VerifyText                  Industry & Sector
    Verify that the Underwriting analysis details are saved successfully
    ClickText                   New Primary Quote
    Sleep                       30s

