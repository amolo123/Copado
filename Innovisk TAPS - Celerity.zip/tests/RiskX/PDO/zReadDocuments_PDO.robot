*** Settings ***
Resource                        ../../../resources/common.robot
Resource                        ../../../PageObjects/RiskX_PageObjects/PageObjects_Accounts.robot
Resource                        ../../../PageObjects/RiskX_PageObjects/PDO/PageObjects_PDO_SubmissionInfo.robot
Resource                        ../../../PageObjects/RiskX_PageObjects/PDO/PageObjects_PDO_UnderwrittingConsole.robot
Resource                        ../../../PageObjects/RiskX_PageObjects/PDO/PageObjects_PDO_QuoteConsole.robot
Resource                        ../../../PageObjects/RiskX_PageObjects/PageObjects_PolicyPage.robot
Resource                        ../../../resources/ReadPDF.robot

Resource                        ../../../PageObjects/RiskX_PageObjects/PDO/PageObjects_PDFRead_PDO.robot

Library                         RetryFailed                 global_retries=${retry_count}

Suite Setup                     Setup Browser
Suite Teardown                  CloseAllBrowsers


*** Test Cases ***
Verify that the Multiple Quote letter is generated and Quote letter is generated
    # Author = Amol Gaymukhe
    #TC=117169,117168
    [Documentation]             Smoke_Test
    [Tags]                      Smoke_Test_PDO              Smoke_Test
    Creating a new Account
    Enter data on Submission info Page for PDO
    Add Data In submission console
    #Add the details displayed on Additional Insured Details
    ClickText                   NEXT:Underwriting Console >                             anchor=Save
    VerifyText                  Industry & Sector
    Verify that the Underwriting analysis details are saved successfully
    ClickText                   New Primary Quote
    Sleep                       30s
    VerifyText                  Quote Console               timeout=30s
    Click On Finalize
    Get Quote Letter Dynamic Document PDO
    Click On Generate Document
    #Sleep                       20s
    Move to outputdir
    Read Doc Quote Letter Static Document PDO
    Read Doc Quote Letter Dynamic Document PDO
    ClickText                   New Primary Quote
    VerifyText                  Success                     anchor=Rating successful!                          partial_match=false    timeout=65s
    ClickElement                (//lightning-icon[@title\='Finalize Quote'])[2]
    VerifyText                  Success                     anchor=Finalize quote and Document Generation Successful!         partial_match=false    timeout=65s



Verify that the Binder Letter for PDO
    # Author = Amol Gaymukhe
    #TC=117169,117168
    [Documentation]             Smoke_Test
    [Tags]                      Smoke_Test_PDO              Smoke_Test
    Creating a new Account
    Enter data on Submission info Page for PDO
    Add Data In submission console
    #Add the details displayed on Additional Insured Details
    ClickText                   NEXT:Underwriting Console >                             anchor=Save
    VerifyText                  Industry & Sector
    Verify that the Underwriting analysis details are saved successfully
    ClickText                   New Primary Quote
    Sleep                       30s
    VerifyText                  Quote Console               timeout=30s
    Click On Finalize
    Get Quote Letter Dynamic Document PDO
    Click On Bind Button
    Generate Document on Policy                             Binder
    ClickElement                //a//span[contains(text(),'CelerityRiskBinder_')]
    ClickText                   View Document               anchor=NewQuoteProcess
    VerifyText                  Success                     anchor=Document has been generated successfully!                  timeout=45s
    #Sleep                       20s
    Move to outputdir
    Read Binder Letter Static Document PDO
    Read Binder Letter Dynamic Document PDO



Verify that the Policy Letter is generated for PDO 
    # Author = Amol Gaymukhe
    #TC=117169,117168
    [Documentation]             Smoke_Test
    [Tags]                      Smoke_Test_PDO              Smoke_Test
    Creating a new Account
    Enter data on Submission info Page for PDO
    Add Data In submission console
    #Add the details displayed on Additional Insured Details
    ClickText                   NEXT:Underwriting Console >                             anchor=Save
    VerifyText                  Industry & Sector
    Verify that the Underwriting analysis details are saved successfully
    ClickText                   New Primary Quote
    Sleep                       30s
    VerifyText                  Quote Console               timeout=30s
    Click On Finalize
    Get Quote Letter Dynamic Document PDO
    Click On Bind Button
    Generate Document on Policy                             PolicyForm
    ClickElement                //a//span[contains(text(),'CelerityRiskPolicyForm')]
    ClickText                   View Document               anchor=NewQuoteProcess
    VerifyText                  Success                     anchor=Document has been generated successfully!                  timeout=45s
    Sleep                       20s
    Move to outputdir
    Read Policy Letter Dynamic Document PDO
    Read Policy Letter Static Document PDO


Verify that the Change Endorsement is generated for PDO 
    # Author = Amol Gaymukhe
    #TC=117169,117168
    [Documentation]             Smoke_Test
    [Tags]                      Smoke_Test_PDO              Smoke_Test
    Creating a new Account
    Enter data on Submission info Page for PDO
    Add Data In submission console
    #Add the details displayed on Additional Insured Details
    ClickText                   NEXT:Underwriting Console >                             anchor=Save
    VerifyText                  Industry & Sector
    Verify that the Underwriting analysis details are saved successfully
    ClickText                   New Primary Quote
    Sleep                       30s
    VerifyText                  Quote Console               timeout=30s
    Click On Finalize
    Get Quote Letter Dynamic Document PDO
    Click On Bind Button
    Change Policy               Amendment
    Amendment Input
    Amendment Input Complete PDO
    Generate Document on Policy ChangeEndorsement           ChangeEndorsement
    ClickElement                //a//span[contains(text(),'CelerityRiskChangeEndorsementPolicy')]
    ClickText                   View Document               anchor=NewQuoteProcess
    VerifyText                  Success                     anchor=Document has been generated successfully!                  timeout=45s
    #Sleep                       20s
    Move to outputdir
    Read Change Endorsement Letter Static Document PDO