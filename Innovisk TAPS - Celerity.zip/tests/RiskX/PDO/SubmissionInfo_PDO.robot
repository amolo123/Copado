*** Settings ***
Resource                        ../../../resources/common.robot
Resource                        ../../../PageObjects/RiskX_PageObjects/PageObjects_Accounts.robot
Resource                        ../../../PageObjects/RiskX_PageObjects/PageObjects_HomePage.robot
Resource                        ../../../PageObjects/RiskX_PageObjects/PDO/PageObjects_PDO_SubmissionInfo.robot

Library                         RetryFailed                 global_retries=${retry_count}

Suite Setup                     Setup Browser
Suite Teardown                  CloseAllBrowsers


*** Test Cases ***

Verify the details listed on Submission Console page
    # Author = Amol Gaymukhe
    #TC=111258,111255
    [Documentation]             Field on Submission Console for PDO
    [Tags]                      Smoke_Test_PDO              Smoke_Test
    Creating a new Account
    Validate field on Insured Info page for PDO
    Validate the Industry drop picklist value and Service Classification picklist values


Validate the creation new submission
    # Author = Amol Gaymukhe
    #TC=111258,111255
    [Documentation]             Field on Submission Console for PDO
    [Tags]                      Smoke_Test_PDO              Smoke_Test
    Creating a new Account
    Enter data on Submission info Page for PDO
    Add Data In submission console
    #Add the details displayed on Additional Insured Details
    ClickText                   NEXT:Underwriting Console >                             anchor=Save
    VerifyText                  Industry & Sector