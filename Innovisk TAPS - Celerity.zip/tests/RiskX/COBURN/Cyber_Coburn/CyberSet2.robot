* Settings ***
Resource                        ../../../../resources/common.robot
Resource                        ../../../../PageObjects/RiskX_PageObjects/PageObjects_Accounts.robot
Resource                        ../../../../PageObjects/RiskX_PageObjects/Cyber/PageObjects_Cyber_InsuredInfo.robot
Resource                        ../../../../PageObjects/RiskX_PageObjects/Cyber/PageObjects_Cyber_SubmissionInfo.robot
Resource                        ../../../../PageObjects/RiskX_PageObjects/Cyber/PageObjects_Cyber_UnderwriterAnalysis.robot
Resource                        ../../../../PageObjects/RiskX_PageObjects/Cyber/PageObjects_Cyber_CompareAndRateQuote.robot
Resource                        ../../../../resources/ReadPDF.robot
Resource                        ../../../../PageObjects/RiskX_PageObjects/Cyber/PageObjects_PDFRead_Cyber.robot
Resource                        ../../../../PageObjects/RiskX_PageObjects/PageObjects_PolicyPage.robot
Resource                        ../../../../PageObjects/RiskX_PageObjects/PageObjects_Coburn.robot

Library                         RetryFailed                 global_retries=${retry_count}
Suite Setup                     Setup Browser
Suite Teardown                  CloseAllBrowsers

*** Test Cases ***
Verify Billing record for Mid term cancellation Cyber Primary
    # Author = Saurabh Salgaonkar
    #TC=117177
    [Documentation]             Verify Billing record for Mid term cancellation Cyber Primary
    [Tags]                      Celerity_Coburn

    Creating a new Account
    Enter data on Insured info Page for Cyber
    ClickText                   NEXT:Submission Info >
    Select Broker and Click On Next
    Select Industry             Business Services
    Select Classification       Administrators
    ClickText                   Save                        anchor=NEXT:Underwriter Analysis >
    Sleep                       10s
    ClickText                   NEXT:Underwriter Analysis >
    Enter Data in Underwriter Analysis Page
    ClickText                   Save                        anchor=Check Risk Health
    VerifyText                  Success                     anchor=Update records successfully!
    ClickText                   Check Risk Health           anchor=Save
    ClickText                   New Primary Quote
    Sleep                       20s
    VerifyText                  Quote Console
    Click On Finalize
    Sleep                       30s
    Click On Generate Document
    Click On Bind Button
    Midterm Cancellation Input and select
    Midterm Cancellation Input
    Sleep                       45s
    Midterm Cancellation Flow Complete
    ClickText                   Related                     anchor=Details
    VerifyText                  Midterm Cancellation        anchor=Quote Type
    Verify Billing Record details                           Midterm Cancellation



Verify Billing record for Mid term cancellation Cyber Excess
    # Author = Saurabh Salgaonkar
    #TC=117178
    [Documentation]             Verify Billing record for Mid term cancellation Cyber Excess
    [Tags]                      Celerity_Coburn

    Creating a new Account
    Enter data on Insured info Page for Cyber
    ClickText                   NEXT:Submission Info >
    Select Broker and Click On Next
    Select Industry             Business Services
    Select Classification       Administrators
    ClickText                   Save                        anchor=NEXT:Underwriter Analysis >
    Sleep                       10s
    ClickText                   NEXT:Underwriter Analysis >
    Enter Data in Underwriter Analysis Page
    ClickText                   Save                        anchor=Check Risk Health
    VerifyText                  Success                     anchor=Update records successfully!
    ClickText                   Check Risk Health           anchor=Save
    ClickText                   New Excess Quote
    Sleep                       20s
    VerifyText                  Quote Console
    Click On Finalize
    Sleep                       30s
    Click On Generate Document
    Click On Bind Button
    Midterm Cancellation Input and select
    Midterm Cancellation Input
    Sleep                       45s
    Midterm Cancellation Flow Complete
    ClickText                   Related                     anchor=Details
    VerifyText                  Midterm Cancellation        anchor=Quote Type
    Verify Billing Record details                           Midterm Cancellation



Verify Billing record for Flat Cancellation Cyber Primary
    # Author = Saurabh Salgaonkar
    #TC=117179
    [Documentation]             Verify Billing record for Flat Cancellation Cyber Primary
    [Tags]                      Celerity_Coburn 

    Creating a new Account
    Enter data on Insured info Page for Cyber
    ClickText                   NEXT:Submission Info >
    Select Broker and Click On Next
    Select Industry             Business Services
    Select Classification       Administrators
    ClickText                   Save                        anchor=NEXT:Underwriter Analysis >
    Sleep                       10s
    ClickText                   NEXT:Underwriter Analysis >
    Enter Data in Underwriter Analysis Page
    ClickText                   Save                        anchor=Check Risk Health
    VerifyText                  Success                     anchor=Update records successfully!
    ClickText                   Check Risk Health           anchor=Save
    ClickText                   New Primary Quote
    Sleep                       20s
    VerifyText                  Quote Console
    Click On Finalize
    Sleep                       30s
    Click On Generate Document
    Click On Bind Button
    Change Policy               Flat Cancellation
    Flat Cancellation Input
    Sleep                       45s
    ClickText                   Related                     anchor=Details
    VerifyText                  Flat Cancellation           anchor=Quote Type
    Verify Billing Record details                           Flat Cancellation


Verify billing record for Flat Cancellation Cyber Excess
    # Author = Saurabh Salgaonkar
    #TC=117180
    [Documentation]             Verify billing record for Flat Cancellation Cyber Excess
    [Tags]                      Celerity_Coburn

    Creating a new Account
    Enter data on Insured info Page for Cyber
    ClickText                   NEXT:Submission Info >
    Select Broker and Click On Next
    Select Industry             Business Services
    Select Classification       Administrators
    ClickText                   Save                        anchor=NEXT:Underwriter Analysis >
    Sleep                       10s
    ClickText                   NEXT:Underwriter Analysis >
    Enter Data in Underwriter Analysis Page
    ClickText                   Save                        anchor=Check Risk Health
    VerifyText                  Success                     anchor=Update records successfully!
    ClickText                   Check Risk Health           anchor=Save
    ClickText                   New Excess Quote
    Sleep                       20s
    VerifyText                  Quote Console
    Click On Finalize
    Sleep                       30s
    Click On Generate Document
    Click On Bind Button
    Sleep                       25s
    Change Policy               Flat Cancellation
    Flat Cancellation Input
    Sleep                       55s
    ClickText                   Related                     anchor=Details
    VerifyText                  Flat Cancellation           anchor=Quote Type
    Verify Billing Record details                           Flat Cancellation
