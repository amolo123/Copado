*** Settings ***
Resource                        ../../../../resources/common.robot
Resource                        ../../../../PageObjects/RiskX_PageObjects/PageObjects_Accounts.robot
Resource                        ../../../../PageObjects/RiskX_PageObjects/MPL/PageObjects_MPL_InsuredInfo.robot
Resource                        ../../../../PageObjects/RiskX_PageObjects/MPL/PageObjects_MPL_SubmissionInfo.robot
Resource                        ../../../../PageObjects/RiskX_PageObjects/MPL/PageObjects_MPL_UnderwriterAnalysis.robot
Resource                        ../../../../PageObjects/RiskX_PageObjects/MPL/PageObjects_MPL_CompareAndRateQuote.robot

Resource                        ../../../../resources/ReadPDF.robot
Resource                        ../../../../PageObjects/RiskX_PageObjects/MPL/PageObjects_ReadPDF_MPL.robot
Resource                        ../../../../PageObjects/RiskX_PageObjects/PageObjects_PolicyPage.robot
Resource                        ../../../../PageObjects/RiskX_PageObjects/PageObjects_Coburn.robot

Library                         RetryFailed                 global_retries=${retry_count}
Suite Setup                     Setup Browser
Suite Teardown                  CloseAllBrowsers



*** Test Cases ***
Verify Billing record for Mid term cancellation MPL Primary
    # Author = Saurabh Salgaonkar
    #TC=117287
    [Documentation]             Verify Billing record for Mid term cancellation MPL Primary
    [Tags]                      Celerity_Coburn

    Creating a new Account
    Enter data on Insured info Page for MPL
    ClickText                   NEXT:Submission Info >
    Select Broker and Click On Next
    Select Industry             Business Services
    Select Classification       Administrators
    ClickText                   Save                        anchor=NEXT:Underwriter Analysis >
    Sleep                       10s
    ClickText                   NEXT:Underwriter Analysis >
    Enter Data in Underwriter Analysis Page
    ClickText                   Save                        anchor=Check Risk Health
    VerifyText                  Success                     anchor=Update records successfully!
    ClickText                   Check Risk Health           anchor=Save
    ClickText                   New Primary Quote
    Sleep                       20s
    VerifyText                  Quote Console
    Click On Finalize
    Sleep                       10s
    Click On Bind Button
    Midterm Cancellation Input and select
    Midterm Cancellation Input
    Midterm Cancellation Flow Complete
    Sleep                       5s
    ClickText                   Related                     anchor=Details
    VerifyText                  Midterm Cancellation        anchor=Quote Type
    Verify Billing Record details                           Midterm Cancellation


Verify Billing record for Mid term cancellation Cyber Excess
    # Author = Saurabh Salgaonkar
    #TC=117288
    [Documentation]             Verify Billing record for Mid term cancellation Cyber Excess
    [Tags]                      Celerity_Coburn

    Creating a new Account
    Enter data on Insured info Page for MPL
    ClickText                   NEXT:Submission Info >
    Select Broker and Click On Next
    Select Industry             Business Services
    Select Classification       Administrators
    ClickText                   Save                        anchor=NEXT:Underwriter Analysis >
    Sleep                       10s
    ClickText                   NEXT:Underwriter Analysis >
    Enter Data in Underwriter Analysis Page
    ClickText                   Save                        anchor=Check Risk Health
    VerifyText                  Success                     anchor=Update records successfully!
    ClickText                   Check Risk Health           anchor=Save
    ClickText                   New Excess Quote
    Sleep                       20s
    VerifyText                  Quote Console
    Click On Finalize
    Sleep                       10s
    Click On Bind Button
    Midterm Cancellation Input and select
    Midterm Cancellation Input
    Midterm Cancellation Flow Complete
    Sleep                       5s
    ClickText                   Related                     anchor=Details
    VerifyText                  Midterm Cancellation        anchor=Quote Type
    Verify Billing Record details                           Midterm Cancellation



Verify Billing record for Flat Cancellation MPL Primary
    # Author = Saurabh Salgaonkar
    #TC=117289
    [Documentation]             Verify Billing record for Flat Cancellation MPL Primary
    [Tags]                      Celerity_Coburn

    Creating a new Account
    Enter data on Insured info Page for MPL
    ClickText                   NEXT:Submission Info >
    Select Broker and Click On Next
    Select Industry             Business Services
    Select Classification       Administrators
    ClickText                   Save                        anchor=NEXT:Underwriter Analysis >
    Sleep                       10s
    ClickText                   NEXT:Underwriter Analysis >
    Enter Data in Underwriter Analysis Page
    ClickText                   Save                        anchor=Check Risk Health
    VerifyText                  Success                     anchor=Update records successfully!
    ClickText                   Check Risk Health           anchor=Save
    ClickText                   New Primary Quote
    Sleep                       20s
    VerifyText                  Quote Console
    Click On Finalize
    Sleep                       10s
    Click On Bind Button
    Change Policy               Flat Cancellation
    Flat Cancellation Input
    Sleep                       5s
    ClickText                   Related                     anchor=Details
    VerifyText                  Flat Cancellation           anchor=Quote Type
    Verify Billing Record details                           Flat Cancellation


Verify billing record for Flat Cancellation MPL Excess
    # Author = Saurabh Salgaonkar
    #TC=117290
    [Documentation]             Verify billing record for Flat Cancellation MPL Excess
    [Tags]                      Celerity_Coburn

    Creating a new Account
    Enter data on Insured info Page for MPL
    ClickText                   NEXT:Submission Info >
    Select Broker and Click On Next
    Select Industry             Business Services
    Select Classification       Administrators
    ClickText                   Save                        anchor=NEXT:Underwriter Analysis >
    Sleep                       10s
    ClickText                   NEXT:Underwriter Analysis >
    Enter Data in Underwriter Analysis Page
    ClickText                   Save                        anchor=Check Risk Health
    VerifyText                  Success                     anchor=Update records successfully!
    ClickText                   Check Risk Health           anchor=Save
    ClickText                   New Excess Quote
    Sleep                       20s
    VerifyText                  Quote Console
    Click On Finalize
    Sleep                       10s
    Click On Bind Button
    Sleep                       25s
    Change Policy               Flat Cancellation
    Flat Cancellation Input
    Sleep                       55s
    ClickText                   Related                     anchor=Details
    VerifyText                  Flat Cancellation           anchor=Quote Type
    Verify Billing Record details                           Flat Cancellation