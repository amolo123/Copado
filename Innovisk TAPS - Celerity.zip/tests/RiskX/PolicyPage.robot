*** Settings ***
Resource                        ../../resources/common.robot
Resource                        ../../PageObjects/RiskX_PageObjects/PageObjects_Accounts.robot
Resource                        ../../PageObjects/RiskX_PageObjects/Cyber/PageObjects_Cyber_InsuredInfo.robot
Resource                        ../../PageObjects/RiskX_PageObjects/Cyber/PageObjects_Cyber_SubmissionInfo.robot
Resource                        ../../PageObjects/RiskX_PageObjects/Cyber/PageObjects_Cyber_UnderwriterAnalysis.robot
Resource                        ../../PageObjects/RiskX_PageObjects/Cyber/PageObjects_Cyber_CompareAndRateQuote.robot
Resource                        ../../PageObjects/RiskX_PageObjects/PageObjects_PolicyPage.robot

Library                         RetryFailed                 global_retries=${retry_count}
Suite Setup                     Setup Browser
Suite Teardown                  CloseAllBrowsers



*** Test Cases ***
Verify Elements on Policy Details Page 
    # Author = Amol Gaymukhe
    #TC=111469,111468
    [Documentation]             field on Submission_Info for Cyber
    [Tags]                      Smoke_Test
    Creating a new Account
    Enter data on Insured info Page for Cyber
    ClickText                   NEXT:Submission Info >
    Select Broker and Click On Next
    Select Industry             Business Services
    Select Classification       Administrators
    ClickText                   Save                        anchor=NEXT:Underwriter Analysis >
    Sleep                       10s
    ClickText                   NEXT:Underwriter Analysis >
    Enter Data in Underwriter Analysis Page
    ClickText                   Save                        anchor=Check Risk Health
    VerifyText                  Success                     anchor=Update records successfully!
    ClickText                   Check Risk Health           anchor=Save
    ClickText                   New Primary Quote
    Sleep                       20s
    VerifyText                  Quote Console
    Click On Finalize
    Sleep                       30s
    Click On Bind Button
    Verify Elements On Policy Page
    Verify Endorsement Type Field On Change Endorsement
    ClickText                   Back                        anchor=Cancel
    Show More Actions
    Verify Show More Actions List