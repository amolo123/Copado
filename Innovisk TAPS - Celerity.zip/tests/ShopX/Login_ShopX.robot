*** Settings ***

Resource               ../../resources/common.robot

Library                RetryFailed                 global_retries=${retry_count}

Library                DateTime
Library                OperatingSystem

Test Setup             Setup Browser
Suite Teardown         CloseAllBrowsers

*** Test Cases ***

Login to ShopX
    [Documentation]    Login to ShopX
    [Tags]             LOGIN_TO_ShopX                 ShopX
    Log To Console              ShopX testing on hold
    # Login to ShopX
