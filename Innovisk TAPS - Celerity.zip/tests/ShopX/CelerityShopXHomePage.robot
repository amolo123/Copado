*** Settings ***

Resource               ../../resources/common.robot

Library                RetryFailed                 global_retries=${retry_count}

Library                DateTime
Library                OperatingSystem

Test Setup             Setup Browser
Suite Teardown         CloseAllBrowsers
Resource               ../../PageObjects/ShopX_PageObjects/PageObjects_Home_ShopX.robot

*** Test Cases ***

Verify all the data available on ShopX Home page

    [Documentation]    Verify all the data available on ShopX Home page
    [Tags]             Smoke_Test                  ShopX                       ShopX_Smoke_Test

    
    Log To Console              ShopX testing on hold
    # Login to ShopX
    # Validate Celerity ShopX Home page

Verify All the actions performed on Home Page
    [Documentation]    Verify All the actions performed on Home Page
    [Tags]             Smoke_Test                  ShopX                       ShopX_Smoke_Test
    
    Log To Console              ShopX testing on hold
    # Login to ShopX
    # Validate Celerity ShopX Home page
    # Validate Start Quote button
    # Validate clicking on Go to My Saved Quotes
    # Validate clicking on Products
    # Validate Download Page
    # Validate about Celerity Pro
    # Validate Our Team
    # Validate Logout

