*** Settings ***
Resource                        ../../../resources/common.robot
Resource                        ../../../PageObjects/ShopX_PageObjects/ShopX_Celerity_Common.robot
Resource                        ../../../PageObjects/ShopX_PageObjects/MPL/PageObjects_MPL_InsuredDetailsPage.robot
Resource                        ../../../PageObjects/ShopX_PageObjects/MPL/PageObjects_MPL_EligibilityGuidelinesPage.robot
Resource                        ../../../PageObjects/ShopX_PageObjects/MPL/PageObjects_MPL_CoverageQuestionPage.robot
Resource                        ../../../PageObjects/ShopX_PageObjects/MPL/PageObjects_MPL_ReviewQuotePage.robot

Library                         RetryFailed                 global_retries=${retry_count}
Library                         DateTime
Library                         OperatingSystem

Test Setup                      Setup Browser
Suite Teardown                  CloseAllBrowsers

*** Test Cases ***

Verify static and dynamic text on Review Quote page for MPL

    [Documentation]             Verify static and dynamic text on Review Quote page for MPL
    [Tags]                      MPL                         ShopX_MPL                   Smoke-Test    Smoke-Test-MPL    113283    Review_Quote_Page_for_MPL
    
    Log To Console              ShopX testing on hold
    # Login to ShopX
    # Select ShopX Product on homepage                        MPL
    # Verify Actions performed on Insured details Page for MPL                            Business Services - Billing Services      Address1                    Address2    Washington    DC    20037    2000000
    # #Hazzard group "HG2" Industry
    # Click on Next Button - Eligibility Guidelines Page
    # Click on No and Next Button - Coverage question page
    # Validate elements on Review quote Page for MPL
    # Click on Back Button - Review my quote Page
    # Click on Back Button - Coverage question Page
    # Click on Back Button - Eligibility Guidelines Page


    # #Hazzard group "HG1" Industry
    # Enter MPL Industry for validating eligibility           Business Services - Audio/Video
    # Click on Next Button - Eligibility Guidelines Page
    # Click on No and Next Button - Coverage question page
    # Validate elements on Review quote Page for MPL
    # Click on Back Button - Review my quote Page
    # Click on Back Button - Coverage question Page
    # Click on Back Button - Eligibility Guidelines Page




Verify save to my quote button on Review Quote page for MPL
    [Documentation]             Verify save to my quote button on Review Quote page for MPL
    [Tags]                      MPL                         ShopX_MPL                   Smoke-Test    Smoke-Test-MPL    110851    113285

    Log To Console              ShopX testing on hold
    # Login to ShopX
    # Select ShopX Product on homepage                        MPL
    # Verify Actions performed on Insured details Page for MPL                            Business Services - Accreditation & Certification Services            Address1    Address2    Washington    DC    20037    2000000
    # Click on Next Button - Eligibility Guidelines Page
    # Verify actions performed on Coverage question page select - Yes                     Business Services - Accreditation & Certification Services
    # Click on Next Button - Coverage question Page
    # Validate Clicking on Save to My quote button
    # Convert Name to Upper Case                              ${uniqueName}
    # VerifyText                  ${str1}

Verify clicking on back button on Review Quote page for MPL
    [Documentation]             Verify clicking on back button on Review Quote page for MPL
    [Tags]                      MPL                         ShopX_MPL                   Smoke-Test    Smoke-Test-MPL    110850
    Log To Console              ShopX testing on hold
    # Login to ShopX
    # Select ShopX Product on homepage                        MPL
    # Verify Actions performed on Insured details Page for MPL                            Business Services - Accreditation & Certification Services            Address1    Address2    Washington    DC    20037    2000000
    # #Hazzard group "HG3" Industry
    # Click on Next Button - Eligibility Guidelines Page
    # Click on No and Next Button - Coverage question page
    # Validate elements on Review quote Page for MPL
    # Click on Back Button - Review my quote Page


Verify action performed when quote is checked for Refferal MPL
    [Documentation]             Verify action performed when quote is checked for Refferal MPL
    [Tags]                      MPL                         ShopX_MPL                   Smoke-Test    Smoke-Test-MPL    110664
    
    Log To Console              ShopX testing on hold
    # Login to ShopX
    # Select ShopX Product on homepage                        MPL

    # Verify Actions performed on Insured details Page for MPL                            Business Services - Accreditation & Certification Services            Address1    Address2    Washington    DC    20037    2000000
    # Click on Next Button - Eligibility Guidelines Page
    # Verify actions performed on Coverage question page select - Yes                     Business Services - Auctioneer
    # Click on Next Button - Coverage question Page
    # Validate clicking on referral button
    # Validate actions performed on review quote page with referral
    # Click on back button on Review quote page
    # ClickText                   Next
    # sleep                       40
    # Validate clicking on referral button
    # sleep                       5s
    # Validate Clicking on Save to My quote button
    # Convert Name to Upper Case                              ${uniqueName}
    # VerifyText                  ${str1}

