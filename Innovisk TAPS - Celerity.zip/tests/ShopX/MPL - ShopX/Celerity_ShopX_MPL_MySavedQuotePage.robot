*** Settings ***

Resource                        ../../../resources/common.robot
Resource                        ../../../PageObjects/ShopX_PageObjects/PageObjects_MySavedQuotes_ShopX.robot
Resource                        ../../../PageObjects/ShopX_PageObjects/ShopX_Celerity_Common.robot
Resource                        ../../../PageObjects/ShopX_PageObjects/MPL/PageObjects_MPL_InsuredDetailsPage.robot
Resource                        ../../../PageObjects/ShopX_PageObjects/MPL/PageObjects_MPL_EligibilityGuidelinesPage.robot
Resource                        ../../../PageObjects/ShopX_PageObjects/MPL/PageObjects_MPL_CoverageQuestionPage.robot
Resource                        ../../../PageObjects/ShopX_PageObjects/MPL/PageObjects_MPL_ReviewQuotePage.robot
Resource                        ../../../resources/ReadPDF.robot

Library                         RetryFailed                 global_retries=${retry_count}
Library                         DateTime
Library                         OperatingSystem

Test Setup                      Setup Browser
Suite Teardown                  CloseAllBrowsers


*** Test Cases ***
Verify Elements with its action on My Quote Screen - Celerity Portal - MPL
    [Documentation]             Verify Elements with its action on My Quote Screen - Celerity Portal - MPL
    [Tags]                      Smoke_Test                  ShopX                       ShopX_Smoke_Test    111657
    
    Log To Console              ShopX testing on hold
    # Login to ShopX
    # Select ShopX Product on homepage                        MPL
    # Verify Actions performed on Insured details Page for MPL                            Business Services - Billing Services    Address1            Address2    Washington    DC    20037    2000000
    # #-----------------------Hazzard group "HG2" Industry---------------------------
    # Click on Next Button - Eligibility Guidelines Page
    # Click on No and Next Button - Coverage question page
    # Validate Clicking on Save to My quote button
    # Convert Name to Upper Case                              ${uniqueName}
    # VerifyText                  ${str1}
    # TypeText                    ENTER ACCOUNT NAME          ${str1}
    # Validate Clicking on Search button
    # VerifyText                  ${str1}                     timeout=30s
    # Validate clicking on Reset button
    # Validate searching with Product name MPL
    # Validate Clicking on Search button
    # Validate Download quote letter button
    # Move to outputdir
    # Test PDF File               QUOTE LETTER
    # Test PDF File               ${uniqueName}

    # Validate Download signature pack button
    # Move to outputdir
    # Test PDF File               SIGNATURE PACK
    # Test PDF File               ${uniqueName}
    # Validate Bind Quote button




Verify Elements on My Quote Screen - Celerity Portal - MPL
    [Documentation]             Verify Elements on My Quote Screen - Celerity Portal
    [Tags]                      Smoke_Test                  ShopX                       ShopX_Smoke_Test    111658
    
    Log To Console              ShopX testing on hold
    # Login to ShopX
    # Select ShopX Product on homepage                        MPL
    # Verify Actions performed on Insured details Page for MPL                            Business Services - Billing Services    Address1            Address2    Washington    DC    20037    2000000
    # #-----------------------Hazzard group "HG2" Industry---------------------------
    # Click on Next Button - Eligibility Guidelines Page
    # Click on No and Next Button - Coverage question page
    # Validate Clicking on Save to My quote button
    # Convert Name to Upper Case                              ${uniqueName}
    # VerifyText                  ${str1}
    # Validate all the elements on My saved quotes page
