*** Settings ***
Resource                        ../../../resources/common.robot
Resource                        ../../../PageObjects/ShopX_PageObjects/ShopX_Celerity_Common.robot
Resource                        ../../../PageObjects/ShopX_PageObjects/MPL/PageObjects_MPL_InsuredDetailsPage.robot
Resource                        ../../../PageObjects/ShopX_PageObjects/MPL/PageObjects_MPL_EligibilityGuidelinesPage.robot

Library                         RetryFailed                 global_retries=${retry_count}
Library                         DateTime
Library                         OperatingSystem

Test Setup                      Setup Browser
Suite Teardown                  CloseAllBrowsers

*** Test Cases ***

Verify static text on eligibility page for MPL
    [Documentation]             Verify static text on eligibility page for MPL
    [Tags]                      MPL                         ShopX_MPL                   Smoke-Test    Smoke-Test-MPL    110654    Eligibility_Page_for_MPL

    Log To Console              ShopX testing on hold
    # Login to ShopX
    # Select ShopX Product on homepage                        MPL
    # Verify Actions performed on Insured details Page for MPL                            Business Services - Billing Services      Address1                    Address2    Washington    DC    20037    2000000
    # Validate elements on Eligibility Guidelines Page for MPL                            Business Services - Billing Services
    # Click on Back Button - Eligibility Guidelines Page

    # Enter MPL Industry for validating eligibility           Business Services - Accreditation & Certification Services
    # Validate elements on Eligibility Guidelines Page for MPL                            Business Services - Accreditation & Certification Services
    # Click on Back Button - Eligibility Guidelines Page

    # Enter MPL Industry for validating eligibility           Business Services - Alarm Monitors
    # Validate elements on Eligibility Guidelines Page for MPL                            Business Services - Alarm Monitors
    # Click on Back Button - Eligibility Guidelines Page

    # Enter MPL Industry for validating eligibility           Business Services - Auctioneer
    # Validate elements on Eligibility Guidelines Page for MPL                            Business Services - Auctioneer
    # Click on Back Button - Eligibility Guidelines Page

    # Enter MPL Industry for validating eligibility           Business Services - Audio/Video
    # Validate elements on Eligibility Guidelines Page for MPL                            Business Services - Audio/Video
    # Click on Back Button - Eligibility Guidelines Page

    # Enter MPL Industry for validating eligibility           Business Services - Bookkeeper & Record Keeper
    # Validate elements on Eligibility Guidelines Page for MPL                            Business Services - Bookkeeper & Record Keeper
    # Click on Back Button - Eligibility Guidelines Page

    # Enter MPL Industry for validating eligibility           Business Services - Business Training & Seminars
    # Validate elements on Eligibility Guidelines Page for MPL                            Business Services - Business Training & Seminars
    # Click on Back Button - Eligibility Guidelines Page

    # Enter MPL Industry for validating eligibility           Business Services - Court Reporting
    # Validate elements on Eligibility Guidelines Page for MPL                            Business Services - Court Reporting
    # Click on Back Button - Eligibility Guidelines Page

    # Enter MPL Industry for validating eligibility           Business Services - Dispute Resolution
    # Validate elements on Eligibility Guidelines Page for MPL                            Business Services - Dispute Resolution
    # Click on Back Button - Eligibility Guidelines Page

    # Enter MPL Industry for validating eligibility           Business Services - Employment Agencies
    # Validate elements on Eligibility Guidelines Page for MPL                            Business Services - Employment Agencies
    # Click on Back Button - Eligibility Guidelines Page

    # Enter MPL Industry for validating eligibility           Business Services - Event Planner
    # Validate elements on Eligibility Guidelines Page for MPL                            Business Services - Event Planner
    # Click on Back Button - Eligibility Guidelines Page

    # Enter MPL Industry for validating eligibility           Business Services - Executive Placement
    # Validate elements on Eligibility Guidelines Page for MPL                            Business Services - Executive Placement
    # Click on Back Button - Eligibility Guidelines Page

    # Enter MPL Industry for validating eligibility           Business Services - Funeral & Crematories
    # Validate elements on Eligibility Guidelines Page for MPL                            Business Services - Funeral & Crematories
    # Click on Back Button - Eligibility Guidelines Page

    # Enter MPL Industry for validating eligibility           Business Services - Interior & Graphic Design
    # Validate elements on Eligibility Guidelines Page for MPL                            Business Services - Interior & Graphic Design
    # Click on Back Button - Eligibility Guidelines Page

    # Enter MPL Industry for validating eligibility           Business Services - Literary Agents
    # Validate elements on Eligibility Guidelines Page for MPL                            Business Services - Literary Agents
    # Click on Back Button - Eligibility Guidelines Page

    # Enter MPL Industry for validating eligibility           Business Services - Management & Business Consulting
    # Validate elements on Eligibility Guidelines Page for MPL                            Business Services - Management & Business Consulting
    # Click on Back Button - Eligibility Guidelines Page

    # Enter MPL Industry for validating eligibility           Business Services - Membership Organizations
    # Validate elements on Eligibility Guidelines Page for MPL                            Business Services - Membership Organizations
    # Click on Back Button - Eligibility Guidelines Page

    # Enter MPL Industry for validating eligibility           Business Services - Modeling/Talent Agency
    # Validate elements on Eligibility Guidelines Page for MPL                            Business Services - Modeling/Talent Agency
    # Click on Back Button - Eligibility Guidelines Page

    # Enter MPL Industry for validating eligibility           Business Services - Notary Public
    # Validate elements on Eligibility Guidelines Page for MPL                            Business Services - Notary Public
    # Click on Back Button - Eligibility Guidelines Page

    # Enter MPL Industry for validating eligibility           Business Services - Office Management
    # Validate elements on Eligibility Guidelines Page for MPL                            Business Services - Office Management
    # Click on Back Button - Eligibility Guidelines Page

    # Enter MPL Industry for validating eligibility           Business Services - Pet Related Services
    # Validate elements on Eligibility Guidelines Page for MPL                            Business Services - Pet Related Services
    # Click on Back Button - Eligibility Guidelines Page

    # Enter MPL Industry for validating eligibility           Business Services - Photographic Studios
    # Validate elements on Eligibility Guidelines Page for MPL                            Business Services - Photographic Studios
    # Click on Back Button - Eligibility Guidelines Page

    # Enter MPL Industry for validating eligibility           Business Services - Printers
    # Validate elements on Eligibility Guidelines Page for MPL                            Business Services - Printers
    # Click on Back Button - Eligibility Guidelines Page

    # Enter MPL Industry for validating eligibility           Business Services - Process Server
    # Validate elements on Eligibility Guidelines Page for MPL                            Business Services - Process Server
    # Click on Back Button - Eligibility Guidelines Page

    # Enter MPL Industry for validating eligibility           Business Services - Tax Preparation (NON-CPA SERVICES)
    # Validate elements on Eligibility Guidelines Page for MPL                            Business Services - Tax Preparation (NON-CPA SERVICES)
    # Click on Back Button - Eligibility Guidelines Page

    # Enter MPL Industry for validating eligibility           Business Services - Translation & Interpretation Services
    # Validate elements on Eligibility Guidelines Page for MPL                            Business Services - Translation & Interpretation Services
    # Click on Back Button - Eligibility Guidelines Page

    # Enter MPL Industry for validating eligibility           Education - Exam Preparation and Tutoring
    # Validate elements on Eligibility Guidelines Page for MPL                            Education - Exam Preparation and Tutoring
    # Click on Back Button - Eligibility Guidelines Page

    # Enter MPL Industry for validating eligibility           Media - Public Relations
    # Validate elements on Eligibility Guidelines Page for MPL                            Media - Public Relations
    # Click on Back Button - Eligibility Guidelines Page

    # Enter MPL Industry for validating eligibility           Real Estate - Residential Appraisers
    # Validate elements on Eligibility Guidelines Page for MPL                            Real Estate - Residential Appraisers
    # Click on Back Button - Eligibility Guidelines Page

    # Enter MPL Industry for validating eligibility           Real Estate - Relocation Agent
    # Validate elements on Eligibility Guidelines Page for MPL                            Real Estate - Relocation Agent
    # Click on Back Button - Eligibility Guidelines Page

    # Enter MPL Industry for validating eligibility           Transportation - Travel Agencies/Tour Operators
    # Validate elements on Eligibility Guidelines Page for MPL                            Transportation - Travel Agencies/Tour Operators
    # Click on Back Button - Eligibility Guidelines Page


Verify Next button on Elegibility page for MPL

    [Documentation]             Verify Next button on Elegibility page for MPL
    [Tags]                      MPL                         ShopX_MPL                   Smoke-Test    Smoke-Test-MPL    110796    Eligibility_Page_for_MPL

    Log To Console              ShopX testing on hold
    # Login to ShopX
    # Select ShopX Product on homepage                        MPL
    # Verify Actions performed on Insured details Page for MPL                            Business Services - Billing Services      Address1                    Address2    Washington    DC    20037    2000000
    # Click on Next Button - Eligibility Guidelines Page
    # Click on Back Button - Coverage question Page
    # Click on Back Button - Eligibility Guidelines Page

    # Enter MPL Industry for validating eligibility           Business Services - Accreditation & Certification Services
    # Click on Next Button - Eligibility Guidelines Page
    # Click on Back Button - Coverage question Page
    # Click on Back Button - Eligibility Guidelines Page

    # Enter MPL Industry for validating eligibility           Business Services - Alarm Monitors
    # Click on Next Button - Eligibility Guidelines Page
    # Click on Back Button - Coverage question Page
    # Click on Back Button - Eligibility Guidelines Page

    # Enter MPL Industry for validating eligibility           Business Services - Auctioneer
    # Click on Next Button - Eligibility Guidelines Page
    # Click on Back Button - Coverage question Page
    # Click on Back Button - Eligibility Guidelines Page

    # Enter MPL Industry for validating eligibility           Business Services - Audio/Video
    # Click on Next Button - Eligibility Guidelines Page
    # Click on Back Button - Coverage question Page
    # Click on Back Button - Eligibility Guidelines Page

    # Enter MPL Industry for validating eligibility           Business Services - Bookkeeper & Record Keeper
    # Click on Next Button - Eligibility Guidelines Page
    # Click on Back Button - Coverage question Page
    # Click on Back Button - Eligibility Guidelines Page

    # Enter MPL Industry for validating eligibility           Business Services - Business Training & Seminars
    # Click on Next Button - Eligibility Guidelines Page
    # Click on Back Button - Coverage question Page
    # Click on Back Button - Eligibility Guidelines Page

    # Enter MPL Industry for validating eligibility           Business Services - Court Reporting
    # Click on Next Button - Eligibility Guidelines Page
    # Click on Back Button - Coverage question Page
    # Click on Back Button - Eligibility Guidelines Page

    # Enter MPL Industry for validating eligibility           Business Services - Dispute Resolution
    # Click on Next Button - Eligibility Guidelines Page
    # Click on Back Button - Coverage question Page
    # Click on Back Button - Eligibility Guidelines Page

    # Enter MPL Industry for validating eligibility           Business Services - Employment Agencies
    # Click on Next Button - Eligibility Guidelines Page
    # Click on Back Button - Coverage question Page
    # Click on Back Button - Eligibility Guidelines Page

    # Enter MPL Industry for validating eligibility           Business Services - Event Planner
    # Click on Next Button - Eligibility Guidelines Page
    # Click on Back Button - Coverage question Page
    # Click on Back Button - Eligibility Guidelines Page

    # Enter MPL Industry for validating eligibility           Business Services - Executive Placement
    # Click on Next Button - Eligibility Guidelines Page
    # Click on Back Button - Coverage question Page
    # Click on Back Button - Eligibility Guidelines Page

    # Enter MPL Industry for validating eligibility           Business Services - Funeral & Crematories
    # Click on Next Button - Eligibility Guidelines Page
    # Click on Back Button - Coverage question Page
    # Click on Back Button - Eligibility Guidelines Page

    # Enter MPL Industry for validating eligibility           Business Services - Interior & Graphic Design
    # Click on Next Button - Eligibility Guidelines Page
    # Click on Back Button - Coverage question Page
    # Click on Back Button - Eligibility Guidelines Page

    # Enter MPL Industry for validating eligibility           Business Services - Literary Agents
    # Click on Next Button - Eligibility Guidelines Page
    # Click on Back Button - Coverage question Page
    # Click on Back Button - Eligibility Guidelines Page

    # Enter MPL Industry for validating eligibility           Business Services - Management & Business Consulting
    # Click on Next Button - Eligibility Guidelines Page
    # Click on Back Button - Coverage question Page
    # Click on Back Button - Eligibility Guidelines Page

    # Enter MPL Industry for validating eligibility           Business Services - Membership Organizations
    # Click on Next Button - Eligibility Guidelines Page
    # Click on Back Button - Coverage question Page
    # Click on Back Button - Eligibility Guidelines Page

    # Enter MPL Industry for validating eligibility           Business Services - Modeling/Talent Agency
    # Click on Next Button - Eligibility Guidelines Page
    # Click on Back Button - Coverage question Page
    # Click on Back Button - Eligibility Guidelines Page

    # Enter MPL Industry for validating eligibility           Business Services - Notary Public
    # Click on Next Button - Eligibility Guidelines Page
    # Click on Back Button - Coverage question Page
    # Click on Back Button - Eligibility Guidelines Page

    # Enter MPL Industry for validating eligibility           Business Services - Office Management
    # Click on Next Button - Eligibility Guidelines Page
    # Click on Back Button - Coverage question Page
    # Click on Back Button - Eligibility Guidelines Page

    # Enter MPL Industry for validating eligibility           Business Services - Pet Related Services
    # Click on Next Button - Eligibility Guidelines Page
    # Click on Back Button - Coverage question Page
    # Click on Back Button - Eligibility Guidelines Page

    # Enter MPL Industry for validating eligibility           Business Services - Photographic Studios
    # Click on Next Button - Eligibility Guidelines Page
    # Click on Back Button - Coverage question Page
    # Click on Back Button - Eligibility Guidelines Page

    # Enter MPL Industry for validating eligibility           Business Services - Printers
    # Click on Next Button - Eligibility Guidelines Page
    # Click on Back Button - Coverage question Page
    # Click on Back Button - Eligibility Guidelines Page

    # Enter MPL Industry for validating eligibility           Business Services - Process Server
    # Click on Next Button - Eligibility Guidelines Page
    # Click on Back Button - Coverage question Page
    # Click on Back Button - Eligibility Guidelines Page

    # Enter MPL Industry for validating eligibility           Business Services - Tax Preparation (NON-CPA SERVICES)
    # Click on Next Button - Eligibility Guidelines Page
    # Click on Back Button - Coverage question Page
    # Click on Back Button - Eligibility Guidelines Page

    # Enter MPL Industry for validating eligibility           Business Services - Translation & Interpretation Services
    # Click on Next Button - Eligibility Guidelines Page
    # Click on Back Button - Coverage question Page
    # Click on Back Button - Eligibility Guidelines Page

    # Enter MPL Industry for validating eligibility           Education - Exam Preparation and Tutoring
    # Click on Next Button - Eligibility Guidelines Page
    # Click on Back Button - Coverage question Page
    # Click on Back Button - Eligibility Guidelines Page

    # Enter MPL Industry for validating eligibility           Media - Public Relations
    # Click on Next Button - Eligibility Guidelines Page
    # Click on Back Button - Coverage question Page
    # Click on Back Button - Eligibility Guidelines Page

    # Enter MPL Industry for validating eligibility           Real Estate - Residential Appraisers
    # Click on Next Button - Eligibility Guidelines Page
    # Click on Back Button - Coverage question Page
    # Click on Back Button - Eligibility Guidelines Page

    # Enter MPL Industry for validating eligibility           Real Estate - Relocation Agent
    # Click on Next Button - Eligibility Guidelines Page
    # Click on Back Button - Coverage question Page
    # Click on Back Button - Eligibility Guidelines Page

    # Enter MPL Industry for validating eligibility           Transportation - Travel Agencies/Tour Operators
    # Click on Next Button - Eligibility Guidelines Page
    # Click on Back Button - Coverage question Page
    # Click on Back Button - Eligibility Guidelines Page

Verify back button on Elegibility page for MPL

    [Documentation]             Verify Next button on Elegibility page for MPL
    [Tags]                      MPL                         ShopX_MPL                   Smoke-Test    Smoke-Test-MPL    110789    Eligibility_Page_for_MPL
    
    Log To Console              ShopX testing on hold
    # Login to ShopX
    # Select ShopX Product on homepage                        MPL
    # Verify Actions performed on Insured details Page for MPL                            Business Services - Billing Services      Address1                    Address2    Washington    DC    20037    2000000
    # Click on Back Button - Eligibility Guidelines Page

    # Enter MPL Industry for validating eligibility           Business Services - Accreditation & Certification Services
    # Click on Back Button - Eligibility Guidelines Page

    # Enter MPL Industry for validating eligibility           Business Services - Alarm Monitors
    # Click on Back Button - Eligibility Guidelines Page

    # Enter MPL Industry for validating eligibility           Business Services - Auctioneer
    # Click on Back Button - Eligibility Guidelines Page

    # Enter MPL Industry for validating eligibility           Business Services - Audio/Video
    # Click on Back Button - Eligibility Guidelines Page

    # Enter MPL Industry for validating eligibility           Business Services - Bookkeeper & Record Keeper
    # Click on Back Button - Eligibility Guidelines Page

    # Enter MPL Industry for validating eligibility           Business Services - Business Training & Seminars
    # Click on Back Button - Eligibility Guidelines Page

    # Enter MPL Industry for validating eligibility           Business Services - Court Reporting
    # Click on Back Button - Eligibility Guidelines Page

    # Enter MPL Industry for validating eligibility           Business Services - Dispute Resolution
    # Click on Back Button - Eligibility Guidelines Page

    # Enter MPL Industry for validating eligibility           Business Services - Employment Agencies
    # Click on Back Button - Eligibility Guidelines Page

    # Enter MPL Industry for validating eligibility           Business Services - Event Planner
    # Click on Back Button - Eligibility Guidelines Page

    # Enter MPL Industry for validating eligibility           Business Services - Executive Placement
    # Click on Back Button - Eligibility Guidelines Page

    # Enter MPL Industry for validating eligibility           Business Services - Funeral & Crematories
    # Click on Back Button - Eligibility Guidelines Page

    # Enter MPL Industry for validating eligibility           Business Services - Interior & Graphic Design
    # Click on Back Button - Eligibility Guidelines Page

    # Enter MPL Industry for validating eligibility           Business Services - Literary Agents
    # Click on Back Button - Eligibility Guidelines Page

    # Enter MPL Industry for validating eligibility           Business Services - Management & Business Consulting
    # Click on Back Button - Eligibility Guidelines Page

    # Enter MPL Industry for validating eligibility           Business Services - Membership Organizations
    # Click on Back Button - Eligibility Guidelines Page

    # Enter MPL Industry for validating eligibility           Business Services - Modeling/Talent Agency
    # Click on Back Button - Eligibility Guidelines Page

    # Enter MPL Industry for validating eligibility           Business Services - Notary Public
    # Click on Back Button - Eligibility Guidelines Page

    # Enter MPL Industry for validating eligibility           Business Services - Office Management
    # Click on Back Button - Eligibility Guidelines Page

    # Enter MPL Industry for validating eligibility           Business Services - Pet Related Services
    # Click on Back Button - Eligibility Guidelines Page

    # Enter MPL Industry for validating eligibility           Business Services - Photographic Studios
    # Click on Back Button - Eligibility Guidelines Page

    # Enter MPL Industry for validating eligibility           Business Services - Printers
    # Click on Back Button - Eligibility Guidelines Page

    # Enter MPL Industry for validating eligibility           Business Services - Process Server
    # Click on Back Button - Eligibility Guidelines Page

    # Enter MPL Industry for validating eligibility           Business Services - Tax Preparation (NON-CPA SERVICES)
    # Click on Back Button - Eligibility Guidelines Page

    # Enter MPL Industry for validating eligibility           Business Services - Translation & Interpretation Services
    # Click on Back Button - Eligibility Guidelines Page

    # Enter MPL Industry for validating eligibility           Education - Exam Preparation and Tutoring
    # Click on Back Button - Eligibility Guidelines Page

    # Enter MPL Industry for validating eligibility           Media - Public Relations
    # Click on Back Button - Eligibility Guidelines Page

    # Enter MPL Industry for validating eligibility           Real Estate - Residential Appraisers
    # Click on Back Button - Eligibility Guidelines Page

    # Enter MPL Industry for validating eligibility           Real Estate - Relocation Agent
    # Click on Back Button - Eligibility Guidelines Page

    # Enter MPL Industry for validating eligibility           Transportation - Travel Agencies/Tour Operators
    # Click on Back Button - Eligibility Guidelines Page

    