*** Settings ***
Resource                        ../../../resources/common.robot
Resource                        ../../../PageObjects/ShopX_PageObjects/ShopX_Celerity_Common.robot
Resource                        ../../../PageObjects/ShopX_PageObjects/MPL/PageObjects_MPL_InsuredDetailsPage.robot
Resource                        ../../../PageObjects/ShopX_PageObjects/MPL/PageObjects_MPL_EligibilityGuidelinesPage.robot

Library                         RetryFailed                 global_retries=${retry_count}
Library                         DateTime
Library                         OperatingSystem

Test Setup                      Setup Browser
Suite Teardown                  CloseAllBrowsers

*** Test Cases ***

Verify static text on Insured details Page for MPL
    [Documentation]             Verify static text on Insured details Page for MPL
    [Tags]                      MPL                         ShopX_MPL                   Smoke-Test    Smoke-Test-MPL    110655    110726

    Log To Console              ShopX testing on hold
    # Login to ShopX
    # Select ShopX Product on homepage                        MPL
    # Verify Actions performed on Insured details Page for MPL                            Business Services - Billing Services      Address1            Address2    Washington    DC    20037    2000000

