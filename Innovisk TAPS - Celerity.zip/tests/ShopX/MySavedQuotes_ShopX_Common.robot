*** Settings ***
Resource                        ../../../resources/common.robot
Resource                        ../../../PageObjects/ShopX_PageObjects/ShopX_Celerity_Common.robot
Resource                        ../../../PageObjects/ShopX_PageObjects/MPL/PageObjects_MPL_InsuredDetailsPage.robot
Resource                        ../../../PageObjects/ShopX_PageObjects/MPL/PageObjects_MPL_EligibilityGuidelinesPage.robot
Resource                        ../../../PageObjects/ShopX_PageObjects/MPL/PageObjects_MPL_CoverageQuestionPage.robot
Resource                        ../../../PageObjects/ShopX_PageObjects/MPL/PageObjects_MPL_ReviewQuotePage.robot

Library                         RetryFailed                 global_retries=${retry_count}
Library                         DateTime
Library                         OperatingSystem

Test Setup                      Setup Browser
Suite Teardown                  CloseAllBrowsers

*** Test Cases ***


Verify Elements with its action on My Quote Screen - Celerity Portal - MPL
    [Documentation]             Verify Elements with its action on My Quote Screen - Celerity Portal - MPL
    [Tags]                      Smoke_Test                  ShopX                       ShopX_Smoke_Test    111657

    
    Log To Console              ShopX testing on hold
    # Login to ShopX
    # Select ShopX Product on homepage                        MPL
    # Verify Actions performed on Insured details Page for MPL                            Business Services - Accreditation & Certification Services            Address1    Address2    Washington    DC    20037    2000000
    # #Hazzard group "HG3" Industry
    # Click on Next Button - Eligibility Guidelines Page
    # Click on No and Next Button - Coverage question page
    # Validate elements on Review quote Page for MPL
    # Click on Back Button - Review my quote Page
