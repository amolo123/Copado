*** Settings ***
Resource                        ../../../resources/common.robot
Resource                        ../../../PageObjects/ShopX_PageObjects/ShopX_Celerity_Common.robot
Resource                        ../../../PageObjects/ShopX_PageObjects/Cyber/PageObjects_Cyber_InsuredDetailPage.robot
Resource                        ../../../PageObjects/ShopX_PageObjects/Cyber/PageObject_Cyber_EligibilityGuidelinesPage.robot
Resource                        ../../../PageObjects/ShopX_PageObjects/Cyber/PageObjects_Cyber_ReviewQuotePage.robot


Library                         RetryFailed                 global_retries=${retry_count}
Library                         DateTime
Library                         OperatingSystem

Test Setup                      Setup Browser
Suite Teardown                  CloseAllBrowsers

*** Test Cases ***

Verify static text on Insured details Page for Cyber
    [Documentation]             Verify static text on Insured details Page for Cyber
    [Tags]                      Cyber                       ShopX_Cyber                 Smoke-Test    Smoke-Test-Cyber    110728

    Log To Console              ShopX testing on hold
    # Login to ShopX
    # Select ShopX Product on homepage                        Cyber
    # Click on Next Button - Eligibility Guidelines Page
    # Validate Static Elements on Insured Details

Verify Actions performed on Insured details Page for Cyber
    [Documentation]             Verify Actions performed on Insured details Page for Cyber
    [Tags]                      Cyber                       ShopX_Cyber                 Smoke-Test    Smoke-Test-Cyber    110727
    Log To Console              ShopX testing on hold
    # Login to ShopX
    # Select ShopX Product on homepage                        Cyber
    # Click on Next Button - Eligibility Guidelines Page
    # Click on Next Button - Insured Details Page             Business Services - Billing Services      Address1            Address2           Washington    DC    20037    2000000
    # Click on back button on Review quote page
    # Click on Back Button - Insured Details Page
    # Click on Back Button - Lets get started page