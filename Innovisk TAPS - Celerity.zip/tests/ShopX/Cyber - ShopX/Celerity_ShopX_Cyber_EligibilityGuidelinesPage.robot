*** Settings ***
Resource                        ../../../resources/common.robot
Resource                        ../../../PageObjects/ShopX_PageObjects/ShopX_Celerity_Common.robot
Resource                        ../../../PageObjects/ShopX_PageObjects/Cyber/PageObjects_Cyber_InsuredDetailPage.robot
Resource                        ../../../PageObjects/ShopX_PageObjects/Cyber/PageObject_Cyber_EligibilityGuidelinesPage.robot

Library                         RetryFailed                 global_retries=${retry_count}
Library                         DateTime
Library                         OperatingSystem

Test Setup                      Setup Browser
Suite Teardown                  CloseAllBrowsers

*** Test Cases ***

Verify static text on eligibility page for Cyber
    [Documentation]             Verify static text on eligibility page for Cyber
    [Tags]                      Cyber                       ShopX_Cyber                 Smoke-Test    Smoke-Test-Cyber    110793    Eligibility_Page_for_Cyber

    Log To Console              ShopX testing on hold
    #Login to ShopX
    # Select ShopX Product on homepage                        Cyber
    # Validate elements on Eligibility Guidelines Page for Cyber


Verify Next button on Elegibility page for Cyber

    [Documentation]             Verify Next button on Elegibility page for Cyber
    [Tags]                      Cyber                       ShopX_Cyber                 Smoke-Test    Smoke-Test-Cyber    110797    Eligibility_Page_for_Cyber
    
    Log To Console              ShopX testing on hold
    # Login to ShopX
    # Select ShopX Product on homepage                        Cyber
    # Click on Next Button - Eligibility Guidelines Page


Verify back button on Elegibility page for Cyber

    [Documentation]             Verify Next button on Elegibility page for Cyber
    [Tags]                      Cyber                       ShopX_Cyber                 Smoke-Test    Smoke-Test-Cyber    110794    Eligibility_Page_for_Cyber
    
    Log To Console              ShopX testing on hold
    # Login to ShopX
    # Select ShopX Product on homepage                        Cyber
    # Click on Back Button - Eligibility Guidelines Page
