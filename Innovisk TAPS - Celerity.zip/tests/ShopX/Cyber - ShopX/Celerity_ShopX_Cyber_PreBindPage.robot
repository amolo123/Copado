*** Settings ***

Resource                        ../../../resources/common.robot
Resource                        ../../../PageObjects/ShopX_PageObjects/PageObjects_MySavedQuotes_ShopX.robot
Resource                        ../../../PageObjects/ShopX_PageObjects/ShopX_Celerity_Common.robot
Resource                        ../../../PageObjects/ShopX_PageObjects/Cyber/PageObjects_Cyber_InsuredDetailPage.robot
Resource                        ../../../PageObjects/ShopX_PageObjects/Cyber/PageObject_Cyber_EligibilityGuidelinesPage.robot
Resource                        ../../../PageObjects/ShopX_PageObjects/Cyber/PageObjects_Cyber_ReviewQuotePage.robot
Resource                        ../../../PageObjects/ShopX_PageObjects/PageObjects_PreBind_ShopX.robot

Library                         RetryFailed                 global_retries=${retry_count}
Library                         DateTime
Library                         OperatingSystem

Test Setup                      Setup Browser
Suite Teardown                  CloseAllBrowsers


*** Test Cases ***
Verify Elements with its action on Pre-bind Screen - Celerity Portal - Cyber
    [Documentation]             Verify Elements with its action on Pre-Bind Screen - Celerity Portal - Cyber
    [Tags]                      Smoke_Test                  ShopX                       ShopX_Smoke_Test    114432
    Log To Console              ShopX testing on hold
    # Login to ShopX
    # Select ShopX Product on homepage                        Cyber
    # Click on Next Button - Eligibility Guidelines Page
    # Click on Next Button - Insured Details Page             Business Services - Administrators              Address1      Address2    Washington    DC         20037    2000000
    # Validate Clicking on Save to My quote button
    # Convert Name to Upper Case                              ${uniqueName}
    # VerifyText                  ${str1}
    # TypeText                    ENTER ACCOUNT NAME          ${str1}
    # Validate Clicking on Search button
    # VerifyText                  ${str1}                     timeout=30s
    # Validate Bind Quote button
    # Validate entering all the details on Pre bind page      Cyber                       23341               testMPL       Address1    Address2      Washington          DC           20037       Firstname    LastName      Mpl@c.com    1234567890
    # Validate clicking on bind quote button on Pre-bind Page


Verify Elements on Pre bind page - Celerity Portal - Cyber
    [Documentation]             Verify Elements on Pre bind page - Celerity Portal
    [Tags]                      Smoke_Test                  ShopX                       ShopX_Smoke_Test    114431
    
    Log To Console              ShopX testing on hold
    # Login to ShopX
    # Select ShopX Product on homepage                        Cyber
    # Click on Next Button - Eligibility Guidelines Page
    # Click on Next Button - Insured Details Page             Business Services - Administrators              Address1      Address2    Washington    DC         20037    2000000
    # Validate Clicking on Save to My quote button
    # Convert Name to Upper Case                              ${uniqueName}
    # VerifyText                  ${str1}
    # TypeText                    ENTER ACCOUNT NAME          ${str1}
    # Validate Clicking on Search button
    # VerifyText                  ${str1}                     timeout=30s
    # Validate Bind Quote button
    # Validate all the elements on Pre bind page              Cyber
