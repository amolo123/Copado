*** Settings ***
Resource                        ../../../resources/common.robot
Resource                        ../../../PageObjects/ShopX_PageObjects/ShopX_Celerity_Common.robot
Resource                        ../../../PageObjects/ShopX_PageObjects/Cyber/PageObjects_Cyber_InsuredDetailPage.robot
Resource                        ../../../PageObjects/ShopX_PageObjects/Cyber/PageObject_Cyber_EligibilityGuidelinesPage.robot
Resource                        ../../../PageObjects/ShopX_PageObjects/Cyber/PageObjects_Cyber_ReviewQuotePage.robot


Library                         RetryFailed                 global_retries=${retry_count}
Library                         DateTime
Library                         OperatingSystem

Test Setup                      Setup Browser
Suite Teardown                  CloseAllBrowsers

*** Test Cases ***

Verify static text on Review Quote page for Cyber
    [Documentation]             Verify static text on Review Quote page for Cyber
    [Tags]                      Cyber                       ShopX_Cyber                 Smoke-Test    Smoke-Test-Cyber    110790
    Log To Console              ShopX testing on hold
    # Login to ShopX
    # Select ShopX Product on homepage                        Cyber
    # Click on Next Button - Eligibility Guidelines Page
    # #Hazard group 'G2' Industry
    # Click on Next Button - Insured Details Page             Business Services - Administrators        Address1            Address2           Washington    DC    20037    2000000
    # Validate Static Elements on Review Quote page for Cyber                          Business Services - Administrators                      
    # Click on back button on Review quote page
    # Click on Back Button - Insured Details Page
    # #Hazard group 'G3' Industry
    # Click on Next Button - Insured Details Page 1           Business Services - Membership Organizations
    # Click on Next Button - Insured Details Page 2
    # Validate Static Elements on Review Quote page for Cyber                        Business Services - Membership Organizations
    # Click on back button on Review quote page
    # Click on Back Button - Insured Details Page
    
    # #Hazard group 'G1' Industry

    # Click on Next Button - Insured Details Page 1           Business Services - Yacht/Boat Broker
    # Click on Next Button - Insured Details Page 2
    # Validate Static Elements on Review Quote page for Cyber                        Business Services - Yacht/Boat Broker

Verify static text on Review Quote page for Cyber - Insurance - Insurance Company (Life)
    [Documentation]    Verify static text on Review Quote page for Cyber - Insurance - Insurance Company (Life) HG4

    #Hazard group 'HG1' Industry
    Log To Console              ShopX testing on hold
    # Login to ShopX
    # Select ShopX Product on homepage                        Cyber
    # Click on Next Button - Eligibility Guidelines Page
    # Click on Next Button - Insured Details Page             Insurance - Insurance Company (Life)      Address1            Address2           Washington    DC    20037    2000000
    # Validate Static Elements on Review Quote page for Cyber                         Insurance - Insurance Company (Life)


Verify Actions performed on Review Quote page for Cyber
    [Documentation]             Verify Actions performed on Review Quote page for Cyber
    [Tags]                      Cyber                       ShopX_Cyber                 Smoke-Test    Smoke-Test-Cyber    110792
    Log To Console              ShopX testing on hold
    # Login to ShopX
    # Select ShopX Product on homepage                        Cyber
    # Click on Next Button - Eligibility Guidelines Page
    # Click on Next Button - Insured Details Page             Business Services - Administrators        Address1            Address2           Washington    DC    20037    2000000
    # Validate Clicking on Save to My quote button


Verify action performed when quote is checked for Refferal cyber
    [Documentation]             Verify action performed when quote is checked for Refferal cyber
    [Tags]                      Cyber                       ShopX_Cyber                 Smoke-Test    Smoke-Test-Cyber    113271
    
    Log To Console              ShopX testing on hold
    # Login to ShopX
    # Select ShopX Product on homepage                        Cyber
    # Click on Next Button - Eligibility Guidelines Page
    # Click on Next Button - Insured Details Page             Business Services - Administrators        Address1            Address2           Washington    DC    20037    2000000
    # Validate clicking on referral button
    # Validate actions performed on review quote page with referral
    # Click on back button on Review quote page
    # ClickText                   Next
    # sleep                       40
    # Validate clicking on referral button
    # sleep                       5s
    # Validate Clicking on Save to My quote button
    # Convert Name to Upper Case                              ${uniqueName}
    # VerifyText                  ${str1}
