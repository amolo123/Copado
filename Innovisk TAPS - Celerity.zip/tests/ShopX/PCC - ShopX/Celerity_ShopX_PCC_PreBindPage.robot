*** Settings ***

Resource                        ../../../resources/common.robot
Resource                        ../../../PageObjects/ShopX_PageObjects/PageObjects_MySavedQuotes_ShopX.robot
Resource                        ../../../PageObjects/ShopX_PageObjects/ShopX_Celerity_Common.robot
Resource                        ../../../PageObjects/ShopX_PageObjects/PCC/PageObjects_PCC_InsuredDetailPage.robot
Resource                        ../../../PageObjects/ShopX_PageObjects/PCC/PageObject_PCC_EligibilityGuidelinesPage.robot
Resource                        ../../../PageObjects/ShopX_PageObjects/PCC/PageObjects_Choose_Your_Coverage.robot
Resource                        ../../../PageObjects/ShopX_PageObjects/PCC/PageObjects_PCC_D&OPage.robot
Resource                        ../../../PageObjects/ShopX_PageObjects/PCC/PageObjects_PCC_EPLPage.robot
Resource                        ../../../PageObjects/ShopX_PageObjects/PCC/PageObjects_PCC_FiduciaryPage.robot
Resource                        ../../../PageObjects/ShopX_PageObjects/PCC/PageObjects_PCC_CrimePage.robot
Resource                        ../../../PageObjects/ShopX_PageObjects/PCC/PageObjects_PCC_ReviewMyQuote.robot
Resource                        ../../../PageObjects/ShopX_PageObjects/Cyber/PageObjects_Cyber_ReviewQuotePage.robot
Resource                        ../../../PageObjects/ShopX_PageObjects/PageObjects_PreBind_ShopX.robot

Library                         RetryFailed                 global_retries=${retry_count}
Library                         DateTime
Library                         OperatingSystem

Test Setup                      Setup Browser
Suite Teardown                  CloseAllBrowsers




*** Test Cases ***
Verify Elements with its action on Pre-bind Screen - Celerity Portal - PCC
    [Documentation]             Verify Elements with its action on Pre-Bind Screen - Celerity Portal - PCC
    [Tags]                      Smoke_Test                  ShopX                       ShopX_Smoke_Test    114434
    
    Log To Console              ShopX testing on hold
    # Login to ShopX
    # Select ShopX Product on homepage                        PCC
    # Click on Next Button - Eligibility Guidelines Page
    # Verify Actions performed on Insured details Page for PCC                            Business Services - Billing Services           Address1              Address2    Washington    DC    20037    2000000    2000000
    # Select all PCC Coverage

    # #------------------ D&O------------------------------
    
    # Select Next on D&O page
    # Verify elements on Tell us more about your D&O Exposure click YES

    # #------------------ EPL ------------------------------
    
    # Select Next on EPL page
    # Verify elements on Tell us more about your EPL Exposure click YES

    # #------------------ Fiduciary ------------------------------
    # Verify Element on PCC Fiduciary page
    # Verify clicking Yes and continue on Fiduciary Elegibility page
    # Verify Elements on Tell us more about your Fiduciary Exposure page click yes and next

    # #------------------ Crime ------------------------------
    
    # Verify clicking Yes and continue on Crime Elegibility page
    # Verify actions performed on Tell us more about your Crime Exposure page             Unknown
    # Validate Clicking on Save to My quote button
    # Convert Name to Upper Case                              ${uniqueName}
    # VerifyText                  ${str1}
    # TypeText           ENTER ACCOUNT NAME    ${str1}
    # Validate Clicking on Search button
    # VerifyText                  ${str1}      timeout=30s
    # Validate Bind Quote button
    # Validate entering all the details on Pre bind page      PCC                       23341               testMPL       Address1    Address2      Washington          DC           20037       Firstname    LastName      Mpl@c.com    1234567890
    # Validate clicking on bind quote button on Pre-bind Page

Verify Elements on Pre bind page - Celerity Portal - PCC
    [Documentation]             Verify Elements on Pre bind page - Celerity Portal - PCC
    [Tags]                      Smoke_Test                  ShopX                       ShopX_Smoke_Test    114433
    
    Log To Console              ShopX testing on hold
    # Login to ShopX
    # Select ShopX Product on homepage                        PCC
    # Click on Next Button - Eligibility Guidelines Page
    # Verify Actions performed on Insured details Page for PCC                            Business Services - Billing Services           Address1              Address2    Washington    DC    20037    2000000    2000000
    # Select all PCC Coverage

    # #------------------ D&O------------------------------
    
    # Select Next on D&O page
    # Verify elements on Tell us more about your D&O Exposure click YES

    # #------------------ EPL ------------------------------
    
    # Select Next on EPL page
    # Verify elements on Tell us more about your EPL Exposure click YES

    # #------------------ Fiduciary ------------------------------
    # Verify Element on PCC Fiduciary page
    # Verify clicking Yes and continue on Fiduciary Elegibility page
    # Verify Elements on Tell us more about your Fiduciary Exposure page click yes and next

    # #------------------ Crime ------------------------------
    
    # Verify clicking Yes and continue on Crime Elegibility page
    # Verify actions performed on Tell us more about your Crime Exposure page             Unknown
    # Validate Clicking on Save to My quote button
    # Convert Name to Upper Case                              ${uniqueName}
    # VerifyText                  ${str1}
    # TypeText           ENTER ACCOUNT NAME    ${str1}
    # Validate Clicking on Search button
    # VerifyText                  ${str1}      timeout=30s
    # Validate Bind Quote button
    # Validate all the elements on Pre bind page              PCC
    