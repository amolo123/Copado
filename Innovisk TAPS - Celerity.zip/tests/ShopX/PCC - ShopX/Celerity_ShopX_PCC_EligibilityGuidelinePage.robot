*** Settings ***
Resource                        ../../../resources/common.robot
Resource                        ../../../PageObjects/ShopX_PageObjects/ShopX_Celerity_Common.robot
#Resource                        ../../../PageObjects/ShopX_PageObjects/PCC/PageObjects_PCC_InsuredDetailPage.robot
Resource                        ../../../PageObjects/ShopX_PageObjects/PCC/PageObject_PCC_EligibilityGuidelinesPage.robot

Library                         RetryFailed                 global_retries=${retry_count}
Library                         DateTime
Library                         OperatingSystem

Test Setup                      Setup Browser
Suite Teardown                  CloseAllBrowsers

*** Test Cases ***

Verify static text on eligibility page for PCC

    [Documentation]             Verify static text on eligibility page for PCC
    [Tags]                      PCC                       ShopX_PCC                 Smoke-Test    Smoke-Test-PCC    110449
    
    Log To Console              ShopX testing on hold
    # Login to ShopX
    # Select ShopX Product on homepage                        PCC
    # Validate elements on Eligibility Guidelines Page for PCC


Verify Next button on Elegibility page for PCC

    [Documentation]             Verify Next button on Elegibility page for PCC
    [Tags]                      PCC                       ShopX_PCC                Smoke-Test    Smoke-Test-PCC    110795    Eligibility_Page_for_PCC
    
    Log To Console              ShopX testing on hold
    # Login to ShopX
    # Select ShopX Product on homepage                        PCC
    # Click on Next Button - Eligibility Guidelines Page


Verify back button on Elegibility page for PCC

    [Documentation]             Verify Next button on Elegibility page for PCC
    [Tags]                      PCC                       ShopX_PCC                Smoke-Test    Smoke-Test-PCC    110751    Eligibility_Page_for_PCC
    Log To Console              ShopX testing on hold
    # Login to ShopX
    # Select ShopX Product on homepage                        PCC
    # Click on Back Button - Eligibility Guidelines Page
