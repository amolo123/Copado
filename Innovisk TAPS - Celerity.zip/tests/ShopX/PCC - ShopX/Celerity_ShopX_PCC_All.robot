*** Settings ***
Resource                        ../../../resources/common.robot
Resource                        ../../../PageObjects/ShopX_PageObjects/ShopX_Celerity_Common.robot
Resource                        ../../../PageObjects/ShopX_PageObjects/PCC/PageObjects_PCC_InsuredDetailPage.robot
Resource                        ../../../PageObjects/ShopX_PageObjects/PCC/PageObject_PCC_EligibilityGuidelinesPage.robot
Resource                        ../../../PageObjects/ShopX_PageObjects/PCC/PageObjects_Choose_Your_Coverage.robot
Resource                        ../../../PageObjects/ShopX_PageObjects/PCC/PageObjects_PCC_D&OPage.robot
Resource                        ../../../PageObjects/ShopX_PageObjects/PCC/PageObjects_PCC_EPLPage.robot
Resource                        ../../../PageObjects/ShopX_PageObjects/PCC/PageObjects_PCC_FiduciaryPage.robot
Resource                        ../../../PageObjects/ShopX_PageObjects/PCC/PageObjects_PCC_CrimePage.robot


Library                         RetryFailed                 global_retries=${retry_count}
Library                         DateTime
Library                         OperatingSystem

Test Setup                      Setup Browser
Suite Teardown                  CloseAllBrowsers

*** Test Cases ***

Verify PCC coverage selection and Ststic elements
    [Documentation]             Verify PCC coverage selection and Ststic elements
    [Tags]                      PCC                         ShopX_PCC                   Smoke-Test    Smoke-Test-PCC    110783    110631    110629    110782    110649    110648    110781    110635    110634    110780    110644    110645
    Log To Console              ShopX testing on hold
#     Login to ShopX
#     Select ShopX Product on homepage                        PCC
#     Click on Next Button - Eligibility Guidelines Page
#     Verify Actions performed on Insured details Page for PCC                            Business Services - Billing Services      Address1             Address2    Washington    DC    20037    2000000    2000000
#     Select all PCC Coverage

#     #------------------ D&O------------------------------
#     Verify Element on PCC D&O page
#     Select Next on D&O page
#     Verify elements on Tell us more about your D&O Exposure click NO
#     Select Back on D&O page
#     Select Next on D&O page
#     Verify elements on Tell us more about your D&O Exposure click YES

#     #------------------ EPL ------------------------------
#     Verify Element on PCC EPL page
#     Select Next on EPL page
#     Verify elements on Tell us more about your EPL Exposure click NO
#     Select Back on EPL page
#     Select Next on EPL page
#     Verify elements on Tell us more about your EPL Exposure click YES

#     #------------------ Fiduciary ------------------------------
#     Verify Element on PCC Fiduciary page
#     Select Next on Fiduciary page
#     Verify Elements on Tell us more about your Fiduciary Exposure page click yes and next

#     #------------------ Crime ------------------------------
#    Verify Element on PCC Crime page
#    Verify clicking Yes and continue on Crime Elegibility page
#    Verify element on Tell us more about your Crime Exposure page
#    Verify actions performed on Tell us more about your Crime Exposure page              Unknown         




