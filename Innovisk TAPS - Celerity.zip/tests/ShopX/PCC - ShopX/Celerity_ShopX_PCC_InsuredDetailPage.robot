*** Settings ***
Resource                        ../../../resources/common.robot
Resource                        ../../../PageObjects/ShopX_PageObjects/ShopX_Celerity_Common.robot
Resource                        ../../../PageObjects/ShopX_PageObjects/PCC/PageObjects_PCC_InsuredDetailPage.robot
Resource                        ../../../PageObjects/ShopX_PageObjects/PCC/PageObject_PCC_EligibilityGuidelinesPage.robot


Library                         RetryFailed                 global_retries=${retry_count}
Library                         DateTime
Library                         OperatingSystem

Test Setup                      Setup Browser
Suite Teardown                  CloseAllBrowsers

*** Test Cases ***

Verify static text on Insured details Page for PCC
    [Documentation]             Verify static text on Insured details Page for PCC
    [Tags]                      PCC                       ShopX_PCC                 Smoke-Test    Smoke-Test-PCC    110570

    Log To Console              ShopX testing on hold
    # Login to ShopX
    # Select ShopX Product on homepage                        PCC
    # Click on Next Button - Eligibility Guidelines Page
    # Verify Actions performed on Insured details Page for PCC                            Business Services - Billing Services      Address1            Address2    Washington    DC    20037    2000000    2000000


Verify Actions performed on Insured details Page for PCC
    [Documentation]             Verify Actions performed on Insured details Page for PCC
    [Tags]                      PCC                       ShopX_PCC                 Smoke-Test    Smoke-Test-PCC    110725
    Log To Console              ShopX testing on hold
    # Login to ShopX
    # Select ShopX Product on homepage                        PCC
    # Click on Next Button - Eligibility Guidelines Page
    # Click on Back Button - Insured Details Page             