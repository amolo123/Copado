*** Settings ***
Library                         QWeb
Library                         QForce
#Library                        QVision
Library                         FakerLibrary
Library                         String
Library                         BuiltIn
Library                         DateTime
Resource                        ../resources/common.robot
Resource                        ../PageObjects/PageObjects_Account.robot
#Resource                       ../PageObjects/PageObjects_HomePage.robot
Resource                        ../PageObjects/PageObjects_Submission.robot
Resource                        ../PageObjects/PageObjects_InsuredInfo.robot
Resource                        ../PageObjects/PageObjects_SubmissionInit.robot
Library                         RetryFailed                 global_retries=${retry_count}
Suite Setup                     Setup Browser
Suite Teardown                  CloseAllBrowsers
Resource                        ../resources/common.robot
Resource                        ../PageObjects/PageObjects_SubmissionInfo.robot
Resource                        ../PageObjects/PageObjects_UnderwriterAnalysis.robot
Resource                        ../PageObjects/PageObjects_QuoteConsole.robot


*** Test Cases ***
Validate all the dropdown values and Dates in the field
    [Tags]                      Smoke_Test
    [Documentation]             Insured Info page
    # Author = Amol
    #TC=108771,102784,108766,108772
    Creating a new Account
    Validate Aqueous New submission Fields
    VerifyText                  Underwriter Workbench
    #Validate field on Insured info
    Add Account name on Insured info page                   ${uniqueName}
    Click on save button
    ClickText                   NEXT:Submission Info >
    #Validate NewSubmission Init on Submission info page
    Select and add broker
    Select and add Profession                               Accountants
    Select and add Largest work type                        Directorships
    ClickText                   Next                        anchor=Cancel
    VerifyText                  Submission Info             anchor=*Submission Name
    ClickText                   NEXT:Underwriter Analysis >
    VerifyText                  Proposal Form Info
    #Validate Underwriter Analysis Fields
    Add Details In Underwriter Analysis Page
    ClickText                   Check Risk Health
    ClickText                   New Primary Quote
    Sleep                       30s
    VerifyText                  Quote Details
    Validate all the quote console elements
    Validate Dates on Quote Console
    Validate dropdown Values



Verify all Buttons Functionality On Quote Console Page
    [Tags]                      Smoke_Test
    [Documentation]             Insured Info page
    # Author = Amol
    #TC=109392,
    Creating a new Account
    Validate Aqueous New submission Fields
    VerifyText                  Underwriter Workbench
    #Validate field on Insured info
    Add Account name on Insured info page                   ${uniqueName}
    Click on save button
    ClickText                   NEXT:Submission Info >
    #Validate NewSubmission Init on Submission info page
    Select and add broker
    Select and add Profession                               Accountants
    Select and add Largest work type                        Directorships
    ClickText                   Next                        anchor=Cancel
    VerifyText                  Submission Info             anchor=*Submission Name
    ClickText                   NEXT:Underwriter Analysis >
    VerifyText                  Proposal Form Info
    #Validate Underwriter Analysis Fields
    Add Details In Underwriter Analysis Page
    ClickText                   Check Risk Health
    ClickText                   New Primary Quote
    Sleep                       30s
    VerifyText                  Quote Details
    Enter Broker Commission
    Click On Rate
    Sleep                       15s
    Create New Primary Quote
    Verify After Creating Primary
    Create New Excess Quote     Binder
    Verify After Creating Excess
    Verify Referral Reasons
    Click On Endorsements and Subjectivities
    Click On Return To Quote Process
    Click On Close Quote
    Click On First Quote
    Click On Finalize
    Sleep                       20s
    Generate Document
    Click On First Excess Quote
    ClickText                   Re-Open
    VerifyText                  Re-Open Quote
    ClickText                   Yes                         anchor=Cancel
    Enter Details in Layer
    Enter Broker Commission
    Click Rate After Amendment
    Click On Finalize
    Sleep                       20s
    Generate Document



    
   