*** Settings ***
Resource                        ../resources/common.robot
Resource                        ../PageObjects/PageObjects_Account.robot
#Resource                       ../PageObjects/PageObjects_HomePage.robot
#Resource                       ../PageObjects/PageObjects_Submission.robot
Library                         RetryFailed                 global_retries=${retry_count}
Suite Setup                     Setup Browser
Suite Teardown                  CloseAllBrowsers



*** Test Cases ***
Validate Creation of Business Account : Save Button
    # Author = Pinki
    #TC=100558
    [Tags]                      Smoke_Test
    [Documentation]             Creation of Business Account : Save Button
    Creating a new Account
    Validate Account Elements
    Validate account form fields
    Creating a new Account

Validate Creation of Business Account : Cancel Button 
    # Author = Pinki
    [Documentation]             Creation of Business Account : Cancel Button
    #TC=100560
    [Tags]                      Smoke_Test
    Creation of Account Cancel

Validate Creation of Business Account : Save and New Button
    # Author = Pinki
    [Documentation]             Creation of Business Account : Save and New Button
    #TC=100559
    [Tags]                      Smoke_Test
    Creating a new Account with Save and new

Validate Editing the Details Tab after the Account Creation
    # Author = Pinki
    #TC=100561
    [Tags]                      Smoke_Test
    [Documentation]             Editing the Details Tab after the Account Creation
    Creating a new Account
    Editing the Account

    # Validate the Buttons acc - Follow, Edit, Delete
    #                           # Author = Pinki
    #                           [Documentation]             Follow, Edit, Delete
    #                           #TC=100564
    #                           [Tags]                      Account                     Business_Account    Create_Business_Account    Smoke-Test    100564
    #                           Creating a new Account
    #                           Follow Edit and Delete Account Click

