*** Settings ***
Library                         QWeb
Library                         QForce
#Library                        QVision
Library                         FakerLibrary
Library                         String
Library                         BuiltIn
Library                         DateTime
Resource                        ../resources/common.robot
Resource                        ../PageObjects/PageObjects_Account.robot
#Resource                       ../PageObjects/PageObjects_HomePage.robot
Resource                        ../PageObjects/PageObjects_Submission.robot
Resource                        ../PageObjects/PageObjects_InsuredInfo.robot
Resource                        ../PageObjects/PageObjects_SubmissionInit.robot
Library                         RetryFailed                 global_retries=${retry_count}
Suite Setup                     Setup Browser
Suite Teardown                  CloseAllBrowsers
Resource                        ../resources/common.robot
Resource                        ../PageObjects/PageObjects_SubmissionInfo.robot
Resource                        ../PageObjects/PageObjects_UnderwriterAnalysis.robot
Resource                        ../PageObjects/PageObjects_EndToEnd.robot

*** Test Cases ***
Validate Underwriter Analysis Page Elements
    [Tags]                      Smoke_Test
    [Documentation]             Insured Info page
    # Author = Amol
    #TC=109251,109259,109257,102489
    Creating a new Account
    Validate Aqueous New submission Fields
    VerifyText                  Underwriter Workbench
    #Validate field on Insured info
    Add Account name on Insured info page                   ${uniqueName}
    Click on save button
    ClickText                   NEXT:Submission Info >
    #Validate NewSubmission Init on Submission info page
    Select and add broker
    Select and add Profession                               Accountants
    Select and add Largest work type                        Computer consultancy
    ClickText                   Next                        anchor=Cancel
    VerifyText                  Submission Info             anchor=*Submission Name
    ClickText                   NEXT:Underwriter Analysis >
    VerifyText                  Proposal Form Info
    Validate Underwriter Analysis Fields
    Add Details In Underwriter Analysis Page


Validate Underwriter Analysis Page Elements According to Profession
    [Tags]                      Smoke_Test
    [Documentation]             Insured Info page
    # Author = Amol
    #TC=109251,109259,109257,102489
    Creating a new Account
    Validate Aqueous New submission Fields
    VerifyText                  Underwriter Workbench
    #Validate field on Insured info
    Add Account name on Insured info page                   ${uniqueName}
    Click on save button
    ClickText                   NEXT:Submission Info >
    #Validate NewSubmission Init on Submission info page
    Select and add broker
    Select and add Profession                               Accountants
    Select and add Largest work type                        Computer consultancy
    ClickText                   Next                        anchor=Cancel
    VerifyText                  Submission Info             anchor=*Submission Name
    ClickText                   NEXT:Underwriter Analysis >
    VerifyText                  Proposal Form Info
    Check Endorsements According to Profession              Accountants

    Add Details In Underwriter Analysis Page
    ClickText                   Submission Info
    VerifyText                  Submission Info             anchor=*Submission Name
    Select and add Profession                               Architects
    Select and add Largest work type                        Arbitrator
    ClickText                   Save
    ClickText                   NEXT:Underwriter Analysis >
    ClickText                   Yes                         anchor=No
    ClickElement                //a[@data-value\='Underwritting Analysis']
    VerifyText                  Proposal Form Info
    Check Endorsements According to Profession              Architects

    Add Details on underwriter For Dynamic Element Change
    ClickText                   Submission Info
    VerifyText                  Submission Info             anchor=*Submission Name
    Select and add Profession                               Design & Construct
    Select and add Largest work type                        Biomass
    ClickText                   Save
    ClickText                   NEXT:Underwriter Analysis >
    ClickText                   Yes                         anchor=No
    ClickElement                //a[@data-value\='Underwritting Analysis']
    VerifyText                  Proposal Form Info
    Check Endorsements According to Profession              DesignandConstruct

    Add Details on underwriter For Dynamic Element Change for Design and construct
    ClickText                   Submission Info
    VerifyText                  Submission Info             anchor=*Submission Name
    Select and add Profession                               Engineers
    Select and add Largest work type                        Biomass
    ClickText                   Save
    ClickText                   NEXT:Underwriter Analysis >
    ClickText                   Yes                         anchor=No
    ClickElement                //a[@data-value\='Underwritting Analysis']
    VerifyText                  Proposal Form Info
    Check Endorsements According to Profession              Engineers

    Add Details on underwriter For Dynamic Element Change
    ClickText                   Submission Info
    VerifyText                  Submission Info             anchor=*Submission Name
    Select and add Profession                               Insurance Brokers
    Select and add Largest work type                        Bloodstock
    ClickText                   Save
    ClickText                   NEXT:Underwriter Analysis >
    ClickText                   Yes                         anchor=No
    ClickElement                //a[@data-value\='Underwritting Analysis']
    VerifyText                  Proposal Form Info
    Check Endorsements According to Profession              InsuranceBrokers

    Add Details on underwriter For Dynamic Element Change
    ClickText                   Submission Info
    VerifyText                  Submission Info             anchor=*Submission Name
    Select and add Profession                               IT Consultants
    Select and add Largest work type                        Data Processing
    ClickText                   Save
    ClickText                   NEXT:Underwriter Analysis >
    ClickText                   Yes                         anchor=No
    ClickElement                //a[@data-value\='Underwritting Analysis']
    VerifyText                  Proposal Form Info
    Check Endorsements According to Profession              ITConsultants

    Add Details on underwriter For Dynamic Element Change
    ClickText                   Submission Info
    VerifyText                  Submission Info             anchor=*Submission Name
    Select and add Profession                               Media Professionals
    Select and add Largest work type                        Marketing
    ClickText                   Save
    ClickText                   NEXT:Underwriter Analysis >
    ClickText                   Yes                         anchor=No
    ClickElement                //a[@data-value\='Underwritting Analysis']
    VerifyText                  Proposal Form Info
    Check Endorsements According to Profession              MediaProfessionals

    Add Details on underwriter For Dynamic Element Change
    ClickText                   Submission Info
    VerifyText                  Submission Info             anchor=*Submission Name
    Select and add Profession                               Miscellaneous
    Select and add Largest work type                        Adjudicator
    ClickText                   Save
    ClickText                   NEXT:Underwriter Analysis >
    ClickText                   Yes                         anchor=No
    ClickElement                //a[@data-value\='Underwritting Analysis']
    VerifyText                  Proposal Form Info
    Check Endorsements According to Profession              Miscellaneous

    Add Details on underwriter For Dynamic Element Change
    ClickText                   Submission Info
    VerifyText                  Submission Info             anchor=*Submission Name
    Select and add Profession                               Property Professionals
    Select and add Largest work type                        Arbitrator
    ClickText                   Save
    ClickText                   NEXT:Underwriter Analysis >
    ClickText                   Yes                         anchor=No
    ClickElement                //a[@data-value\='Underwritting Analysis']
    VerifyText                  Proposal Form Info
    Check Endorsements According to Profession              PropertyProfessionals

    Add Details on underwriter For Dynamic Element Change for Property Professionals
    ClickText                   Submission Info
    VerifyText                  Submission Info             anchor=*Submission Name
    Select and add Profession                               Solicitors
    Select and add Largest work type                        Arbitration
    ClickText                   Save
    ClickText                   NEXT:Underwriter Analysis >
    ClickText                   Yes                         anchor=No
    ClickElement                //a[@data-value\='Underwritting Analysis']
    VerifyText                  Proposal Form Info
    Check Endorsements According to Profession              Solicitors


Verify that Number of partner field is available on underwriting analysis page
    [Tags]                      Smoke_Test
    [Documentation]             Underwriting Analysis page
    # Author = Pinki
    #TC=113708,
    Creating a new Account
    Validate Aqueous New submission Fields
    VerifyText                  Underwriter Workbench
    Add Account name on Insured info page                   ${uniqueName}
    Click on save button
    ClickText                   NEXT:Submission Info >
    Select and add broker
    Select and add Profession                               Solicitors
    Select and add Largest work type                        Arbitration
    ClickText                   Next                        anchor=Cancel
    VerifyText                  Submission Info             anchor=*Submission Name
    ClickText                   NEXT:Underwriter Analysis >
    Add Proposal date
    VerifyText                  *Number of Partners
    Log To Console              ---Partner Field is available ---


Verify that Number of partner field is not accepting '0' value in it
    [Tags]                      Smoke_Test
    [Documentation]             Underwriting Analysis page
    # Author = Pinki
    #TC=113709,
    Creating a new Account
    Validate Aqueous New submission Fields
    VerifyText                  Underwriter Workbench
    Add Account name on Insured info page                   ${uniqueName}
    Click on save button
    ClickText                   NEXT:Submission Info >
    Select and add broker
    Select and add Profession                               Solicitors
    Select and add Largest work type                        Arbitration
    ClickText                   Next                        anchor=Cancel
    VerifyText                  Submission Info             anchor=*Submission Name
    ClickText                   NEXT:Underwriter Analysis >
    Add Proposal date
    Check Solicitor Partner field                           0

Verify that Number of partner field is accepting value greater than '0' in it
    [Tags]                      Smoke_Test
    [Documentation]             Underwriting Analysis page
    # Author = Pinki
    #TC=113710,
    Creating a new Account
    Validate Aqueous New submission Fields
    VerifyText                  Underwriter Workbench
    Add Account name on Insured info page                   ${uniqueName}
    Click on save button
    ClickText                   NEXT:Submission Info >
    Select and add broker
    Select and add Profession                               Solicitors
    Select and add Largest work type                        Arbitration
    ClickText                   Next                        anchor=Cancel
    VerifyText                  Submission Info             anchor=*Submission Name
    ClickText                   NEXT:Underwriter Analysis >
    Add Proposal date
    Check Solicitor Partner field                           3

