*** Settings ***
Library                         QWeb
Library                         QForce
#Library                        QVision
Library                         FakerLibrary
Library                         String
Library                         BuiltIn
Library                         DateTime
Resource                        ../resources/common.robot
Resource                        ../PageObjects/PageObjects_Account.robot
#Resource                       ../PageObjects/PageObjects_HomePage.robot
Resource                        ../PageObjects/PageObjects_Submission.robot
Resource                        ../PageObjects/PageObjects_InsuredInfo.robot
Resource                        ../PageObjects/PageObjects_SubmissionInit.robot
Library                         RetryFailed                 global_retries=${retry_count}
Suite Setup                     Setup Browser
Suite Teardown                  CloseAllBrowsers
Resource                        ../resources/common.robot
Resource                        ../PageObjects/PageObjects_SubmissionInit.robot
*** Test Cases ***
Check the functionality of Next Button on New Submission Pop-Up
    [Tags]                      Smoke_Test
    # Author = Pinki
    [Documentation]             Functionality of Next Button on New Submission Pop-Up
    #TC=102481

    Creating a new Account
    Validate Aqueous New submission Fields
    VerifyText                  Underwriter Workbench
    #Validate field on Insured info
    Add Account name on Insured info page                   ${uniqueName}
    Click on save button
    ClickText                   NEXT:Submission Info >
    Select and add broker
    Select and add Profession                               Accountants
    Select and add Largest work type                        Directorships
    ClickText                   Next
    VerifyText                  Submission Info

Check the functionality of Cancel button on New Submission Pop Up.
    [Tags]                      Smoke_Test
    [Documentation]             Functionality of Cancel button on New Submission Pop Up
    # Author = Pinki
    #TC=102482

    Creating a new Account
    Validate Aqueous New submission Fields
    VerifyText                  Underwriter Workbench
    Add Account name on Insured info page                   ${uniqueName}
    Click on save button
    ClickText                   NEXT:Submission Info >
    Select and add broker
    Select and add Profession                               Accountants
    Select and add Largest work type                        Directorships
    ClickText                   Cancel


Validate Broker with Main profession selected as Accountant and Largest work type selected
    [Tags]                      Smoke_Test
    [Documentation]             Main profession selected as Accountant and Largest work type selected
    # Author = Pinki
    #TC=102475
    Creating a new Account
    Validate Aqueous New submission Fields
    VerifyText                  Underwriter Workbench
    Add Account name on Insured info page                   ${uniqueName}
    Click on save button
    ClickText                   NEXT:Submission Info >
    Select and add broker
    Select and add Profession                               Accountants
    Select and add Largest work type                        Directorships
    ClickText                   Next
    VerifyText                  Submission Info

Validate Broker with Main profession selected as Architects and Largest work type selected from drop down
    [Tags]                      Smoke_Test
    [Documentation]             Main profession selected as Architects and Largest work type selected
    # Author = Pinki
    #TC=102476

    Creating a new Account
    Validate Aqueous New submission Fields
    VerifyText                  Underwriter Workbench
    Add Account name on Insured info page                   ${uniqueName}
    Click on save button
    ClickText                   NEXT:Submission Info >
    Select and add broker
    Select and add Profession                               Architects
    Select and add Largest work type                        Electrical Engineering
    ClickText                   Next
    VerifyText                  Submission Info

Validate Broker with Main profession selected as Design and construct and Largest work type selected from drop down
    [Tags]                      Smoke_Test
    [Documentation]             Main profession selected as Design and construct and Largest work type
    # Author = Pinki
    #TC=102477

    Creating a new Account
    Validate Aqueous New submission Fields
    VerifyText                  Underwriter Workbench
    Add Account name on Insured info page                   ${uniqueName}
    Click on save button
    ClickText                   NEXT:Submission Info >
    Select and add broker
    Select and add Profession                               Design & Construct
    Select and add Largest work type                        Glazing
    ClickText                   Next
    VerifyText                  Submission Info

Validate Broker with Main profession selected as Engineers and Largest work type selected from drop down
    [Tags]                      Smoke_Test
    [Documentation]             Main profession selected as Engineers and Largest work type
    # Author = Pinki
    #TC=102478

    Creating a new Account
    Validate Aqueous New submission Fields
    VerifyText                  Underwriter Workbench
    Add Account name on Insured info page                   ${uniqueName}
    Click on save button
    ClickText                   NEXT:Submission Info >
    Select and add broker
    Select and add Profession                               Engineers
    Select and add Largest work type                        Electronic Engineers
    ClickText                   Next
    VerifyText                  Submission Info


Validate Broker with Main profession selected as Insurance broker and Largest work type selected from drop down
    [Tags]                      Smoke_Test
    [Documentation]             Main profession selected as Insurance broker and Largest work type
    # Author = Pinki
    #TC=102479

    Creating a new Account
    Validate Aqueous New submission Fields
    VerifyText                  Underwriter Workbench
    Add Account name on Insured info page                   ${uniqueName}
    Click on save button
    ClickText                   NEXT:Submission Info >
    Select and add broker
    Select and add Profession                               Insurance Brokers
    Select and add Largest work type                        Warranty
    ClickText                   Next
    VerifyText                  Submission Info

Validate Broker with Main profession selected as IT Consultants and Largest work type selected from drop down    
    [Tags]                      Smoke_Test
    [Documentation]             Main profession selected as IT Consultants and Largest work type
    # Author = Pinki
    #TC=102480

    Creating a new Account
    Validate Aqueous New submission Fields
    VerifyText                  Underwriter Workbench
    Add Account name on Insured info page                   ${uniqueName}
    Click on save button
    ClickText                   NEXT:Submission Info >
    Select and add broker
    Select and add Profession                               IT Consultants
    Select and add Largest work type                        Training
    ClickText                   Next
    VerifyText                  Submission Info

Validate Broker with Main profession selected as Media Professionals and Largest work type selected from drop down    
    [Tags]                      Smoke_Test
    [Documentation]             Main profession selected as Media Professionals and Largest work type
    # Author = Pinki
    #TC=102483

    Creating a new Account
    Validate Aqueous New submission Fields
    VerifyText                  Underwriter Workbench
    Add Account name on Insured info page                   ${uniqueName}
    Click on save button
    ClickText                   NEXT:Submission Info >
    Select and add broker
    Select and add Profession                               Media Professionals
    Select and add Largest work type                        Copywriter
    ClickText                   Next
    VerifyText                  Submission Info

Validate Broker with Main profession selected as Miscellaneous and Largest work type selected from drop down   
    [Tags]                      Smoke_Test
    [Documentation]             Main profession selected as Miscellaneous and Largest work type
    # Author = Pinki
    #TC=102484

    Creating a new Account
    Validate Aqueous New submission Fields
    VerifyText                  Underwriter Workbench
    Add Account name on Insured info page                   ${uniqueName}
    Click on save button
    ClickText                   NEXT:Submission Info >
    Select and add broker
    Select and add Profession                               Miscellaneous
    Select and add Largest work type                        Adjudicator
    ClickText                   Next
    VerifyText                  Submission Info

Validate Broker with Main profession selected as Property Professionals and Largest work type selected from drop down   
    [Tags]                      Smoke_Test
    [Documentation]             Main profession selected as Property Professionals and Largest work type
    # Author = Pinki
    #TC=102485

    Creating a new Account
    Validate Aqueous New submission Fields
    VerifyText                  Underwriter Workbench
    Add Account name on Insured info page                   ${uniqueName}
    Click on save button
    ClickText                   NEXT:Submission Info >
    Select and add broker
    Select and add Profession                               Property Professionals
    Select and add Largest work type                        Arbitrator
    ClickText                   Next
    VerifyText                  Submission Info

Validate Broker with Main profession selected as Solicitors and Largest work type selected from drop down
    [Tags]                      Smoke_Test
    [Documentation]             Main profession selected as Solicitors and Largest work type
    # Author = Pinki
    #TC=102486

    Creating a new Account
    Validate Aqueous New submission Fields
    VerifyText                  Underwriter Workbench
    Add Account name on Insured info page                   ${uniqueName}
    Click on save button
    ClickText                   NEXT:Submission Info >
    Select and add broker
    Select and add Profession                               Solicitors
    Select and add Largest work type                        Criminal Law
    ClickText                   Next
    VerifyText                  Submission Info

Verify Worktypes based on Profession
    [Tags]                      Smoke_Test
    [Documentation]             Worktypes based on Profession
    # Author = Pinki
    #TC=109137

    Creating a new Account
    Validate Aqueous New submission Fields
    VerifyText                  Underwriter Workbench
    Validate field on Insured info
    Add Account name on Insured info page                   ${uniqueName}
    Click on save button
    ClickText                   NEXT:Submission Info >
    Validate NewSubmission Init on Submission info page
    Select and add broker
    Validate largest worktype according to profession       Accountants
    Validate largest worktype according to profession       Architects
    Validate largest worktype according to profession       Design & Construct
    Validate largest worktype according to profession       Engineers
    Validate largest worktype according to profession       Insurance Brokers
    Validate largest worktype according to profession       IT Consultants
    Validate largest worktype according to profession       Media Professionals
    Validate largest worktype according to profession       Miscellaneous
    Validate largest worktype according to profession       Property Professionals
    Validate largest worktype according to profession       Solicitors
    Validate largest worktype according to profession       XYZ
