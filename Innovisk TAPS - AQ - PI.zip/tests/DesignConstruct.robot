*** Settings ***
Library                         QWeb
Library                         QForce
#Library                        QVision
Library                         FakerLibrary
Library                         String
Library                         BuiltIn
Library                         DateTime
Resource                        ../resources/common.robot
Resource                        ../PageObjects/PageObjects_Account.robot
#Resource                       ../PageObjects/PageObjects_HomePage.robot
Resource                        ../PageObjects/PageObjects_Submission.robot
Resource                        ../PageObjects/PageObjects_InsuredInfo.robot
Resource                        ../PageObjects/PageObjects_SubmissionInit.robot
Library                         RetryFailed                 global_retries=${retry_count}
Suite Setup                     Setup Browser
Suite Teardown                  CloseAllBrowsers
Resource                        ../resources/common.robot
Resource                        ../PageObjects/PageObjects_SubmissionInfo.robot
Resource                        ../PageObjects/PageObjects_UnderwriterAnalysis.robot
Resource                        ../PageObjects/PageObjects_QuoteConsole.robot
Resource                        ../PageObjects/PageObjects_PreBindPage.robot
Resource                        ../PageObjects/PageObjects_PolicyPage.robot
Resource                        ../PageObjects/PageObjects_EndToEnd.robot


*** Test Cases ***
Verify that the primary quote is bind and policy is generated- Design and Construct
    [Tags]                      Smoke_Test_DesignConstruct                              Smoke_Test
    [Documentation]             Insured Info page
    # Author = Pinki
    #TC=103583,
    Creating a new Account
    Validate Aqueous New submission Fields
    VerifyText                  Underwriter Workbench
    Add Account name on Insured info page                   ${uniqueName}
    Click on save button
    ClickText                   NEXT:Submission Info >
    Select and add broker
    Select and add Profession                               Design & Construct
    Select and add Largest work type                        Electrical Engineering
    ClickText                   Next                        anchor=Cancel
    VerifyText                  Submission Info             anchor=*Submission Name
    ClickText                   NEXT:Underwriter Analysis >
    Add Proposal date
    TypeText                    Annual gross fees / turnover - change                   40000
    Add Split Percentage
    TypeText                    All other turnover          100
    Save Details and check risk health
    ClickText                   New Primary Quote
    Sleep                       30s
    VerifyText                  Quote Details
    Click On Finalize
    Sleep                       20s
    Generate Document
    Click Proceed To Bind
    Sleep                       15s
    Select first Quote
    Sleep                       10s
    Click On Bind
    ClickText                   Related                     anchor=Details
    Select Policy from PolicyPage

Verify that the excess XOL binder quote gets bind and policy is generated- Design and Construct
    [Tags]                      Smoke_Test_DesignConstruct                              Smoke_Test
    [Documentation]             Insured Info page
    # Author = Pinki
    #TC=103586,
    Creating a new Account
    Validate Aqueous New submission Fields
    VerifyText                  Underwriter Workbench
    Add Account name on Insured info page                   ${uniqueName}
    Click on save button
    ClickText                   NEXT:Submission Info >
    Select and add broker
    Select and add Profession                               Design & Construct
    Select and add Largest work type                        Electrical Engineering
    ClickText                   Next                        anchor=Cancel
    VerifyText                  Submission Info             anchor=*Submission Name
    ClickText                   NEXT:Underwriter Analysis >
    Add Proposal date
    TypeText                    Annual gross fees / turnover - change                   40000
    Add Split Percentage
    TypeText                    All other turnover          100
    Save Details and check risk health
    ClickText                   New Excess Quote
    Select Binder Name          XOL
    Sleep                       30s
    VerifyText                  Quote Details
    Enter Details in Layer
    Click On Finalize
    Sleep                       20s
    Generate Document
    Click Proceed To Bind
    Sleep                       15s
    Select first Quote
    Sleep                       20s
    Click On Bind
    ClickText                   Related                     anchor=Details
    Select Policy from PolicyPage

Verify that the excess Main binder quote gets bind and policy is generated- Design and Construct
    [Tags]                      Smoke_Test_DesignConstruct                              Smoke_Test
    [Documentation]             Insured Info page
    # Author = Pinki
    #TC=103584,
    Creating a new Account
    Validate Aqueous New submission Fields
    VerifyText                  Underwriter Workbench
    Add Account name on Insured info page                   ${uniqueName}
    Click on save button
    ClickText                   NEXT:Submission Info >
    Select and add broker
    Select and add Profession                               Design & Construct
    Select and add Largest work type                        Electrical Engineering
    ClickText                   Next                        anchor=Cancel
    VerifyText                  Submission Info             anchor=*Submission Name
    ClickText                   NEXT:Underwriter Analysis >
    Add Proposal date
    TypeText                    Annual gross fees / turnover - change                   40000
    Add Split Percentage
    TypeText                    All other turnover          100
    Save Details and check risk health
    ClickText                   New Excess Quote
    Select Binder Name          Binder
    Sleep                       30s
    VerifyText                  Quote Details
    Enter Details in Layer
    Click On Finalize
    Sleep                       20s
    Generate Document
    Click Proceed To Bind
    Sleep                       15s
    Select first Quote
    Sleep                       20s
    Click On Bind
    ClickText                   Related                     anchor=Details
    Select Policy from PolicyPage

Verify that the excess GAIC binder quote gets bind and policy is generated- Design and Construct
    [Tags]                      Smoke_Test_DesignConstruct                              Smoke_Test
    [Documentation]             Insured Info page
    # Author = Pinki
    #TC=103585,
    Creating a new Account
    Validate Aqueous New submission Fields
    VerifyText                  Underwriter Workbench
    Add Account name on Insured info page                   ${uniqueName}
    Click on save button
    ClickText                   NEXT:Submission Info >
    Select and add broker
    Select and add Profession                               Design & Construct
    Select and add Largest work type                        Electrical Engineering
    ClickText                   Next                        anchor=Cancel
    VerifyText                  Submission Info             anchor=*Submission Name
    ClickText                   NEXT:Underwriter Analysis >
    Add Proposal date
    TypeText                    Annual gross fees / turnover - change                   40000
    Add Split Percentage
    TypeText                    All other turnover          100
    Save Details and check risk health
    ClickText                   New Excess Quote
    Select Binder Name          GAIC
    Sleep                       30s
    VerifyText                  Quote Details
    Enter Details in Layer
    Click On Finalize
    Sleep                       20s
    Generate Document
    Click Proceed To Bind
    Sleep                       15s
    Select first Quote
    Sleep                       20s
    Click On Bind
    ClickText                   Related                     anchor=Details
    Select Policy from PolicyPage