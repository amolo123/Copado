*** Settings ***
Resource                        ../resources/common.robot
Resource                        ../PageObjects/PageObjects_Account.robot
#Resource                       ../PageObjects/PageObjects_HomePage.robot
Resource                        ../PageObjects/PageObjects_Submission.robot
#Resource                       ../PageObjects/PageObjects_InusredInfo.robot
Library                         RetryFailed                 global_retries=${retry_count}
Suite Setup                     Setup Browser
Suite Teardown                  CloseAllBrowsers


*** Test Cases ***
Validate Record Type AQPI and Product Professional Indemnity on the New Submission Pop Up.
    [Tags]                      Smoke_Test
    [Documentation]             Record Type AQPI and Product Professional Indemnity on the New Submission Pop Up
    # Author = Pinki
    #TC=102466

    Creating a new Account
    Validate Aqueous New submission Fields
    VerifyText                  Underwriter Workbench

Check the functionality of Cancel button on New Submission Pop Up.   
    [Tags]                      Smoke_Test
    [Documentation]             Functionality of Cancel button on New Submission Pop Up
    # Author = Pinki
    # TC= 102472
    Checking Cancel Button On New Submission


Check the functionality of Next Button on New Submission Pop-Up
    [Tags]                      Smoke_Test
    [Documentation]             Functionality of Next Button on New Submission Pop-Up
    # Author = Pinki
    # TC= 102473

    Validate Aqueous New submission Fields
    VerifyText                  Underwriter Workbench