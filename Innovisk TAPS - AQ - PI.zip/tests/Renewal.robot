*** Settings ***
Library                         QWeb
Library                         QForce
#Library                        QVision
Library                         FakerLibrary
Library                         String
Library                         BuiltIn
Library                         DateTime
Resource                        ../resources/common.robot
Resource                        ../resources/ReadPDF.robot
Resource                        ../PageObjects/PageObjects_Account.robot
#Resource                       ../PageObjects/PageObjects_HomePage.robot
Resource                        ../PageObjects/PageObjects_Submission.robot
Resource                        ../PageObjects/PageObjects_InsuredInfo.robot
Resource                        ../PageObjects/PageObjects_SubmissionInit.robot
Library                         RetryFailed                 global_retries=${retry_count}
Suite Setup                     Setup Browser
Suite Teardown                  CloseAllBrowsers
Resource                        ../resources/common.robot
Resource                        ../PageObjects/PageObjects_SubmissionInfo.robot
Resource                        ../PageObjects/PageObjects_UnderwriterAnalysis.robot
Resource                        ../PageObjects/PageObjects_QuoteConsole.robot
Resource                        ../PageObjects/PageObjects_PreBindPage.robot
Resource                        ../PageObjects/PageObjects_PolicyPage.robot
Resource                        ../PageObjects/PageObjects_SendEmail.robot
Resource                        ../PageObjects/PageObjects_EndToEnd.robot

*** Test Cases ***
Verify that the renewal is successfully created for Accountant profession - Main Binder
    [Documentation]             Quote Console page
    [Tags]                      Regression_Test_Accountants                             Regression_Test
    # Author = Pinki Lubana
    #TC=120481

    Creating a new Account
    Validate Aqueous New submission Fields
    VerifyText                  Underwriter Workbench
    Add Account name on Insured info page                   ${uniqueName}
    Click on save button
    ClickText                   NEXT:Submission Info >
    Select and add broker
    Select and add Profession                               Design & Construct
    Select and add Largest work type                        Electrical Engineering
    ClickText                   Next                        anchor=Cancel
    VerifyText                  Submission Info             anchor=*Submission Name
    ClickText                   NEXT:Underwriter Analysis >
    Add Proposal date
    TypeText                    Annual gross fees / turnover - change                   40000
    Add Split Percentage
    TypeText                    All other turnover          100
    Save Details and check risk health
    ClickText                   New Primary Quote
    Sleep                       30s
    VerifyText                  Quote Details
    Enter Expiration Date
    ClickText                   Save
    ClickElement                //button[text()\='Confirm']
    Click Rate After Amendment
    Click On Finalize
    Sleep                       20s
    Generate Document
    Click Proceed To Bind
    Sleep                       15s
    Select first Quote
    Sleep                       20s
    Click On Bind
    VerifyText                  Policy Details
    ClickText                   //button[text()\='Renew']
    Sleep                       20s
    ClickElement                //span[text()\='Underwriting Analysis']
    Add Proposal date
    ClickText                   Save
    ClickElement                //span[text()\='Quote Console']
    Check Quote Type as Renewal on Quote 
    ClickText                   Rate
    ClickText                   Finalize
    Sleep                       20s
    Click Proceed To Bind
    Sleep                       15s
    Select first Quote
    Sleep                       20s
    Click On Bind
    VerifyText                  Policy Details
    Check Quote Type as Renewal on Policy

Verify that the renewal is successfully created for Design and Construct- XOL Binder
    [Tags]                      Smoke_Test_DesignConstruct                              Smoke_Test
    [Documentation]             Insured Info page
    # Author = Pinki
    #TC=103586,
    Creating a new Account
    Validate Aqueous New submission Fields
    VerifyText                  Underwriter Workbench
    Add Account name on Insured info page                   ${uniqueName}
    Click on save button
    ClickText                   NEXT:Submission Info >
    Select and add broker
    Select and add Profession                               Design & Construct
    Select and add Largest work type                        Electrical Engineering
    ClickText                   Next                        anchor=Cancel
    VerifyText                  Submission Info             anchor=*Submission Name
    ClickText                   NEXT:Underwriter Analysis >
    Add Proposal date
    TypeText                    Annual gross fees / turnover - change                   40000
    Add Split Percentage
    TypeText                    All other turnover          100
    Save Details and check risk health
    ClickText                   New Excess Quote
    Select Binder Name          XOL
    Sleep                       30s
    VerifyText                  Quote Details
    Enter Details in Layer
    Enter Expiration Date
    ClickText                   Save
    ClickElement                //button[text()\='Confirm']
    Click Rate After Amendment
    Click On Finalize
    Sleep                       20s
    Generate Document
    Click Proceed To Bind
    Sleep                       15s
    Select first Quote
    Sleep                       20s
    Click On Bind
    VerifyText                  Policy Details
    ClickText                   //button[text()\='Renew']
    Sleep                       30s
    ClickElement                //span[text()\='Underwriting Analysis']
    Add Proposal date
    ClickText                   Save
    ClickElement                //span[text()\='Quote Console']
    Check Quote Type as Renewal on Quote  
    ClickText                   Rate
    ClickText                   Finalize
    Sleep                       20s
    Click Proceed To Bind
    Sleep                       15s
    Select first Quote
    Sleep                       20s
    Click On Bind
    VerifyText                  Policy Details
    Check Quote Type as Renewal on Policy

Verify that the renewal is successfully created for Property Professional- GAIC
    [Tags]                      Smoke_Test_PropertyProfessional                         Smoke_Test
    [Documentation]             Insured Info page
    # Author = Pinki
    #TC=103510,
    Creating a new Account
    Validate Aqueous New submission Fields
    VerifyText                  Underwriter Workbench
    Add Account name on Insured info page                   ${uniqueName}
    Click on save button
    ClickText                   NEXT:Submission Info >
    Select and add broker
    Select and add Profession                               Property Professionals
    Select and add Largest work type                        Arbitrator
    ClickText                   Next                        anchor=Cancel
    VerifyText                  Submission Info             anchor=*Submission Name
    ClickText                   NEXT:Underwriter Analysis >
    Add Proposal date
    TypeText                    Annual gross fees / turnover - change                   40000
    ClickElement                (//span[text()\='Yes'])[2]
    Add Split Percentage
    Save Details and check risk health
    ClickText                   New Excess Quote
    Select Binder Name          GAIC
    Sleep                       30s
    VerifyText                  Quote Details
    Enter Details in Layer
    Enter Expiration Date
    ClickText                   Save
    ClickElement                //button[text()\='Confirm']
    Click Rate After Amendment
    Click On Finalize
    Sleep                       20s
    Generate Document
    Click Proceed To Bind
    Sleep                       15s
    Select first Quote
    Sleep                       20s
    Click On Bind
    VerifyText                  Policy Details
    ClickText                   //button[text()\='Renew']
    Sleep                       30s
    ClickElement                //span[text()\='Underwriting Analysis']
    Add Proposal date
    ClickText                   Save
    ClickElement                //span[text()\='Quote Console']
    Check Quote Type as Renewal on Quote  
    ClickText                   Rate
    ClickText                   Finalize
    Sleep                       20s
    Click Proceed To Bind
    Sleep                       15s
    Select first Quote
    Sleep                       20s
    Click On Bind
    VerifyText                  Policy Details
    Check Quote Type as Renewal on Policy

Verify that the renewal is successfully created for Architects - Excess Main Binder
    [Tags]                      Smoke_Test_Architects       Smoke_Test
    [Documentation]             Insured Info page
    # Author = Amol
    #TC=103572,
    Creating a new Account
    Validate Aqueous New submission Fields
    VerifyText                  Underwriter Workbench
    #Validate field on Insured info
    Add Account name on Insured info page                   ${uniqueName}
    Click on save button
    ClickText                   NEXT:Submission Info >
    #Validate NewSubmission Init on Submission info page
    Select and add broker
    Select and add Profession                               Architects
    Select and add Largest work type                        Electrical Engineering
    ClickText                   Next                        anchor=Cancel
    VerifyText                  Submission Info             anchor=*Submission Name
    ClickText                   NEXT:Underwriter Analysis >
    Add Proposal date
    TypeText                    Annual gross fees / turnover - change                   40000
    Add Split Percentage
    Save Details and check risk health
    ClickText                   New Excess Quote
    Select Binder Name          Binder
    Sleep                       30s
    VerifyText                  Quote Details
    Enter Details in Layer
    Enter Expiration Date
    ClickText                   Save
    ClickElement                //button[text()\='Confirm']
    Click Rate After Amendment
    Click On Finalize
    Sleep                       20s
    Generate Document
    Click Proceed To Bind
    Sleep                       15s
    Select first Quote
    Sleep                       20s
    Click On Bind
    VerifyText                  Policy Details
    ClickText                   //button[text()\='Renew']
    Sleep                       30s
    ClickElement                //span[text()\='Underwriting Analysis']
    Add Proposal date
    ClickText                   Save
    ClickElement                //span[text()\='Quote Console']
    Check Quote Type as Renewal on Quote  
    ClickText                   Rate
    ClickText                   Finalize
    Sleep                       20s
    Click Proceed To Bind
    Sleep                       15s
    Select first Quote
    Sleep                       20s
    Click On Bind
    VerifyText                  Policy Details
    Check Quote Type as Renewal on Policy

Verify that the renewal is successfully created for Solicitors Binder
    [Tags]                      Smoke_Test_Solicitors       Smoke_Test
    [Documentation]             Insured Info page
    # Author = Pinki
    #TC=103474,
    Creating a new Account
    Validate Aqueous New submission Fields
    VerifyText                  Underwriter Workbench
    Add Account name on Insured info page                   ${uniqueName}
    Click on save button
    ClickText                   NEXT:Submission Info >
    Select and add broker
    Select and add Profession                               Solicitors
    Select and add Largest work type                        Arbitration
    ClickText                   Next                        anchor=Cancel
    VerifyText                  Submission Info             anchor=*Submission Name
    ClickText                   NEXT:Underwriter Analysis >
    Add Proposal date
    Dynamic element of Solicitors
    Add Split Percentage
    Save Details and check risk health
    ClickText                   New Excess Quote
    ClickElement                (//span[text()\='Select Item 1']/parent::*)[last()]
    ClickText                   Proceed to Quote
    Sleep                       30s
    VerifyText                  Quote Details
    Enter Details in Layer
    Enter Expiration Date
    ClickText                   Save
    ClickElement                //button[text()\='Confirm']
    Click Rate After Amendment
    Click On Finalize
    Sleep                       20s
    Generate Document
    Click Proceed To Bind
    Sleep                       15s
    Select first Quote
    Sleep                       20s
    Click On Bind
    VerifyText                  Policy Details
    ClickText                   //button[text()\='Renew']
    Sleep                       30s
    ClickElement                //span[text()\='Underwriting Analysis']
    Add Proposal date
    ClickText                   Save
    ClickElement                //span[text()\='Quote Console']
    Check Quote Type as Renewal on Quote  
    ClickText                   Rate
    ClickText                   Finalize
    Sleep                       20s
    Click Proceed To Bind
    Sleep                       15s
    Select first Quote
    Sleep                       20s
    Click On Bind
    VerifyText                  Policy Details
    ScrollTo                    Quotes                      anchor= Quote Type
    Check Quote Type as Renewal on Policy  