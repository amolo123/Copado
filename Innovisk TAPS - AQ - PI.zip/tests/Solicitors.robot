*** Settings ***
Library                         QWeb
Library                         QForce
#Library                        QVision
Library                         FakerLibrary
Library                         String
Library                         BuiltIn
Library                         DateTime
Resource                        ../resources/common.robot
Resource                        ../PageObjects/PageObjects_Account.robot
#Resource                       ../PageObjects/PageObjects_HomePage.robot
Resource                        ../PageObjects/PageObjects_Submission.robot
Resource                        ../PageObjects/PageObjects_InsuredInfo.robot
Resource                        ../PageObjects/PageObjects_SubmissionInit.robot
Library                         RetryFailed                 global_retries=${retry_count}
Suite Setup                     Setup Browser
Suite Teardown                  CloseAllBrowsers
Resource                        ../resources/common.robot
Resource                        ../PageObjects/PageObjects_SubmissionInfo.robot
Resource                        ../PageObjects/PageObjects_UnderwriterAnalysis.robot
Resource                        ../PageObjects/PageObjects_QuoteConsole.robot
Resource                        ../PageObjects/PageObjects_PreBindPage.robot
Resource                        ../PageObjects/PageObjects_PolicyPage.robot
Resource                        ../PageObjects/PageObjects_EndToEnd.robot

*** Test Cases ***
Verify that the primary quote is bind and policy is generated- Solicitors Binder
    [Tags]                      Smoke_Test_Solicitors       Smoke_Test
    [Documentation]             Insured Info page
    # Author = Pinki
    #TC=103474,
    Creating a new Account
    Validate Aqueous New submission Fields
    VerifyText                  Underwriter Workbench
    Add Account name on Insured info page                   ${uniqueName}
    Click on save button
    ClickText                   NEXT:Submission Info >
    Select and add broker
    Select and add Profession                               Solicitors
    Select and add Largest work type                        Arbitration
    ClickText                   Next                        anchor=Cancel
    VerifyText                  Submission Info             anchor=*Submission Name
    ClickText                   NEXT:Underwriter Analysis >
    Add Proposal date
    Dynamic element of Solicitors
    Add Split Percentage
    Save Details and check risk health
    ClickText                   New Excess Quote
    ClickElement                (//span[text()\='Select Item 1']/parent::*)[last()]
    ClickText                   Proceed to Quote
    Sleep                       30s
    VerifyText                  Quote Details
    Enter Details in Layer
    Click On Finalize
    Sleep                       20s
    Click Proceed To Bind
    Sleep                       15s
    Select first Quote
    Sleep                       20s
    Click On Bind
    ClickText                   Related                     anchor=Details
    Select Policy from PolicyPage


Verify that the primary quote is bind and policy is generated- GA AmTrust Solicitors Binder
    [Tags]                      Smoke_Test_Solicitors       Smoke_Test
    [Documentation]             Insured Info page
    # Author = Pinki
    #TC=111063,
    Creating a new Account
    Validate Aqueous New submission Fields
    VerifyText                  Underwriter Workbench
    Add Account name on Insured info page                   ${uniqueName}
    Click on save button
    ClickText                   NEXT:Submission Info >
    Select and add broker
    Select and add Profession                               Solicitors
    Select and add Largest work type                        Arbitration
    ClickText                   Next                        anchor=Cancel
    VerifyText                  Submission Info             anchor=*Submission Name
    ClickText                   NEXT:Underwriter Analysis >
    Add Proposal date
    Dynamic element of Solicitors
    Add Split Percentage
    Save Details and check risk health
    ClickText                   New Excess Quote
    ClickElement                (//span[text()\='Select Item 2']/parent::*)[last()]
    ClickText                   Proceed to Quote
    Sleep                       30s
    VerifyText                  Quote Details
    Enter Details in Layer
    Click On Finalize
    Sleep                       20s
    Click Proceed To Bind
    Sleep                       15s
    Select first Quote
    Sleep                       20s
    Click On Bind
    ClickText                   Related                     anchor=Details
    Select Policy from PolicyPage


