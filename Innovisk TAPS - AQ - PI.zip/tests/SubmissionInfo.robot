*** Settings ***
Library                         QWeb
Library                         QForce
#Library                        QVision
Library                         FakerLibrary
Library                         String
Library                         BuiltIn
Library                         DateTime
Resource                        ../resources/common.robot
Resource                        ../PageObjects/PageObjects_Account.robot
#Resource                       ../PageObjects/PageObjects_HomePage.robot
Resource                        ../PageObjects/PageObjects_Submission.robot
Resource                        ../PageObjects/PageObjects_InsuredInfo.robot
Resource                        ../PageObjects/PageObjects_SubmissionInit.robot
Library                         RetryFailed                 global_retries=${retry_count}
Suite Setup                     Setup Browser
Suite Teardown                  CloseAllBrowsers
Resource                        ../resources/common.robot
Resource                        ../PageObjects/PageObjects_SubmissionInfo.robot


*** Test Cases ***
Validate submission info page, Decline, Undecline, Copy
    [Tags]                      Smoke_Test
    [Documentation]             Insured Info page
    # Author = Amol
    #TC=109251,109259,109257,102489
    Creating a new Account
    Validate Aqueous New submission Fields
    VerifyText                  Underwriter Workbench
    #Validate field on Insured info
    Add Account name on Insured info page                   ${uniqueName}
    Click on save button
    ClickText                   NEXT:Submission Info >
    #Validate NewSubmission Init on Submission info page
    Select and add broker
    Select and add Profession                               Accountants
    Select and add Largest work type                        Computer consultancy
    ClickText                   Next                        anchor=Cancel
    Validate SubmissionInfo New submission Fields
    Verify SubmissionInfo Page Input Details
    Verify Decline
    Verify Un Decline
    Verify Copy

Validate submission info page Open Additional Insured Page
    [Tags]                      Smoke_Test
    [Documentation]             Insured Info page
    # Author = Amol
    #TC=109262
    Creating a new Account
    Validate Aqueous New submission Fields
    VerifyText                  Underwriter Workbench
    #Validate field on Insured info
    Add Account name on Insured info page                   ${uniqueName}
    Click on save button
    ClickText                   NEXT:Submission Info >
    #Validate NewSubmission Init on Submission info page
    Select and add broker
    Select and add Profession                               Accountants
    Select and add Largest work type                        Computer consultancy
    ClickText                   Next                        anchor=Cancel
    Additional Insured Details Validation
