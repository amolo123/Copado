*** Settings ***
Library                         QWeb
Library                         QForce
#Library                        QVision
Library                         FakerLibrary
Library                         String
Library                         BuiltIn
Library                         DateTime
Resource                        ../../resources/common.robot
Resource                        ../../resources/ReadPDF.robot
Resource                        ../../PageObjects/PageObjects_Account.robot
#Resource                       ../PageObjects/PageObjects_HomePage.robot
Resource                        ../../PageObjects/PageObjects_Submission.robot
Resource                        ../../PageObjects/PageObjects_InsuredInfo.robot
Resource                        ../../PageObjects/PageObjects_SubmissionInit.robot
Library                         RetryFailed                 global_retries=${retry_count}
Suite Setup                     Setup Browser
Suite Teardown                  CloseAllBrowsers
Resource                        ../../resources/common.robot
Resource                        ../../PageObjects/PageObjects_SubmissionInfo.robot
Resource                        ../../PageObjects/PageObjects_UnderwriterAnalysis.robot
Resource                        ../../PageObjects/PageObjects_QuoteConsole.robot
Resource                        ../../PageObjects/PageObjects_PreBindPage.robot
Resource                        ../../PageObjects/PageObjects_PolicyPage.robot
Resource                        ../../PageObjects/PageObjects_SendEmail.robot

*** Test Cases ***
Verify that the Referral is triggered when rateable exposure is greater than £10m where the total underlying limit is £5m or higher for 2022- GAIC Binder with User Level 1
    [Tags]                      Regression_Test_Accountants                             Regression_Test
    [Documentation]             Insured Info page
    # Author = Amol Gaymukhe
    #TC=79018
    Creating a new Account
    Validate Aqueous New submission Fields
    VerifyText                  Underwriter Workbench
    #Validate field on Insured info
    Add Account name on Insured info page                   ${uniqueName}
    Click on save button
    ClickText                   NEXT:Submission Info >
    #Validate NewSubmission Init on Submission info page
    Select and add broker
    Select and add Profession                               Accountants
    Select and add Largest work type                        Mergers, Acquisitions, Disposals, Take-overs or Corporate Finance
    ClickText                   Next                        anchor=Cancel
    VerifyText                  Submission Info             anchor=*Submission Name
    ClickText                   NEXT:Underwriter Analysis >
    VerifyText                  Proposal Form Info
    #Validate Underwriter Analysis Fields
    Add Details In Underwriter Analysis Page
    TypeText                    Annual gross fees / turnover - change                   20000000
    ClickText                   Check Risk Health
    ClickText                   New Excess Quote
    Select Binder Name          GAIC
    Sleep                       20s
    Enter Details in Layer
    ClickText                   Finalize
    VerifyElement               (//span[text()\='Referred'])[1]
    ClickElement                //lightning-icon[@title\='View Referral Reasons']
    VerifyText                  Excess quote on GAIC binder where the rateable exposure is over 10,000,000


Verify that the Referral is triggering for the property professionals if Largest Valuation Size is 0 with Level 1
    [Tags]                      Regression_Test_PropertyProfessional                    Regression_Test
    [Documentation]             Insured Info page
    # Author = Amol Gaymukhe
    #TC=79019
    Creating a new Account
    Validate Aqueous New submission Fields
    VerifyText                  Underwriter Workbench
    #Validate field on Insured info
    Add Account name on Insured info page                   ${uniqueName}
    Click on save button
    ClickText                   NEXT:Submission Info >
    #Validate NewSubmission Init on Submission info page
    Select and add broker
    Select and add Profession                               Property Professionals
    Select and add Largest work type                        Arbitrator
    ClickText                   Next                        anchor=Cancel
    VerifyText                  Submission Info             anchor=*Submission Name
    ClickText                   NEXT:Underwriter Analysis >
    VerifyText                  Proposal Form Info
    Add Details On Underwriter
    TypeText                    (//span[text()\='Largest Valuation Size']/parent::*/following-sibling::td//input)[last()]    0
    ClickElement                (//button[@class\='slds-button slds-button_icon slds-button_icon-container'])[2]
    ClickElement                //div[text()\='Adjudicator']/parent::*/preceding-sibling::td
    ClickElement                //div[text()\='Commercial Lending Valuations']/parent::*/preceding-sibling::td
    ClickElement                //div[text()\='Residential Lending Valuations']/parent::*/preceding-sibling::td
    ClickElement                //button[@title\='Add']
    TypeText                    (//input[contains(@name,'_split')])[1]                  30
    TypeText                    (//input[contains(@name,'_split')])[2]                  20
    TypeText                    (//input[contains(@name,'_split')])[3]                  50
    ClickText                   Check Risk Health
    ClickText                   New Primary Quote
    Sleep                       15s
    ClickText                   Finalize
    VerifyElement               (//span[text()\='Referred'])[1]
    ClickElement                //lightning-icon[@title\='View Referral Reasons']
    VerifyText                  Property Professionals, Commercial Lending Valuations selected

Verify that the Referral is triggered when Insured Country is Jersey, Guernsey or Isle of Man for Solicitor profession
    [Tags]                      Regression_Test_Solicitors                              Regression_Test
    [Documentation]             Insured Info page
    # Author = Amol Gaymukhe
    #TC=79019
    Creating a new Account
    ClickText                   Accounts
    VerifyText                  Recently Viewed             anchor=span                 timeout=40s
    ClickText                   ${uniquename}
    ClickElement                //button[text()\='Edit']                        
    PickList                    Billing Country             Jersey
    ClickText                   Save                        anchor=Save & New           partial_match=false
    Validate Aqueous New submission Fields
    VerifyText                  Underwriter Workbench
    #Validate field on Insured info
    Add Account name on Insured info page                   ${uniqueName}
    Click on save button
    ClickText                   NEXT:Submission Info >
    #Validate NewSubmission Init on Submission info page
    Select and add broker
    Select and add Profession                               Solicitors
    Select and add Largest work type                        Adjudication
    ClickText                   Next                        anchor=Cancel
    VerifyText                  Submission Info             anchor=*Submission Name
    ClickText                   NEXT:Underwriter Analysis >
    VerifyText                  Proposal Form Info
    TypeText                    Number of Partners          1
    ClickElement                //span[text()\='Is the Firm a Partnership or LLP/Ltd']/parent::*/following::td
    ClickText                   //span[text()\='Partnership']
    TypeText                    //div[@class\='slds-form-element__control slds-grow']//input[@class\='slds-input']    5
    # TypeText                  (//input)[11]               5
    TypeText                    Claims Experience – Incurred in last 5 years            10
    TypeText                    Professional Business Description                       10
    Select split independantly                              2
    TypeText                    (//input[contains(@name,'_split')])[1]                  100
    ClickText                   Check Risk Health
    ClickText                   New Excess Quote
    ClickElement                //span[text()\='Select Item 1']
    ClickText                   Proceed to Quote
    Sleep                       15 sec
    VerifyText                  Quote Details
    Enter Details in Layer
    ClickText                   Finalize
    VerifyElement               (//span[text()\='Referred'])[1]
    ClickElement                //lightning-icon[@title\='View Referral Reasons']
    VerifyText                  Excess quote on GAIC binder where the insured country is Jersey
