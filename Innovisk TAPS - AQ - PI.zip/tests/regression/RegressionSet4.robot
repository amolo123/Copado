*** Settings ***
Library                         QWeb
Library                         QForce
#Library                        QVision
Library                         FakerLibrary
Library                         String
Library                         BuiltIn
Library                         DateTime
Resource                        ../../resources/common.robot
Resource                        ../../resources/ReadPDF.robot
Resource                        ../../PageObjects/PageObjects_Account.robot
#Resource                       ../PageObjects/PageObjects_HomePage.robot
Resource                        ../../PageObjects/PageObjects_Submission.robot
Resource                        ../../PageObjects/PageObjects_InsuredInfo.robot
Resource                        ../../PageObjects/PageObjects_SubmissionInit.robot
Library                         RetryFailed                 global_retries=${retry_count}
Suite Setup                     Setup Browser
Suite Teardown                  CloseAllBrowsers
Resource                        ../../resources/common.robot
Resource                        ../../PageObjects/PageObjects_SubmissionInfo.robot
Resource                        ../../PageObjects/PageObjects_UnderwriterAnalysis.robot
Resource                        ../../PageObjects/PageObjects_QuoteConsole.robot
Resource                        ../../PageObjects/PageObjects_PreBindPage.robot
Resource                        ../../PageObjects/PageObjects_PolicyPage.robot
Resource                        ../../PageObjects/PageObjects_SendEmail.robot

*** Test Cases ***

Verify the pattern for AQUW203 form in the documents
    [Tags]                      Regression_Test_Accountants                             Regression_Test
    [Documentation]             Insured Info page
    # Author = Amol
    #TC=78987
    Creating a new Account
    Validate Aqueous New submission Fields
    VerifyText                  Underwriter Workbench
    #Validate field on Insured info
    Add Account name on Insured info page                   ${uniqueName}
    Click on save button
    ClickText                   NEXT:Submission Info >
    #Validate NewSubmission Init on Submission info page
    Select and add broker
    Select and add Profession                               Accountants
    Select and add Largest work type                        Directorships
    ClickText                   Next                        anchor=Cancel
    VerifyText                  Submission Info             anchor=*Submission Name
    ClickText                   NEXT:Underwriter Analysis >
    VerifyText                  Proposal Form Info
    #Validate Underwriter Analysis Fields
    Add Details In Underwriter Analysis Page
    ClickText                   Check Risk Health
    ClickText                   New Primary Quote
    Sleep                       30s
    VerifyText                  Quote Details
    Enter Broker Commission
    Click On Rate
    Click on Endorsement
    Select Endorsement          AQUW144
    Click Rate After Amendment
    Click On Finalize
    Sleep                       20s
    Generate Document
    Click On First Quote Letter
    Sleep                       30s
    Move to outputdir
    Test PDF File               AQUW144


Verify that the Endorsement AQUW153B is displayed in Quote Letter
    [Tags]                      Regression_Test_Accountants                             Regression_Test
    [Documentation]             Insured Info page
    # Author = Amol
    #TC=78990
    Creating a new Account
    Validate Aqueous New submission Fields
    VerifyText                  Underwriter Workbench
    #Validate field on Insured info
    Add Account name on Insured info page                   ${uniqueName}
    Click on save button
    ClickText                   NEXT:Submission Info >
    #Validate NewSubmission Init on Submission info page
    Select and add broker
    Select and add Profession                               Accountants
    Select and add Largest work type                        Directorships
    ClickText                   Next                        anchor=Cancel
    VerifyText                  Submission Info             anchor=*Submission Name
    ClickText                   NEXT:Underwriter Analysis >
    VerifyText                  Proposal Form Info
    #Validate Underwriter Analysis Fields
    Add Details In Underwriter Analysis Page
    ClickText                   Check Risk Health
    ClickText                   New Primary Quote
    Sleep                       30s
    VerifyText                  Quote Details
    Enter Broker Commission
    Click On Rate
    Click on Endorsement
    Select Endorsement          AQUW153B
    Click on Endorsement
    Enter Data in the Endorsement
    Click Rate After Amendment
    Click On Finalize
    Sleep                       20s
    Generate Document
    Click On First Quote Letter
    Sleep                       30s
    Move to outputdir
    Test PDF File               AQUW153B


Verify that the Claims' and 'Renewals' menu tabs are visible for u/w user 
    [Tags]                      Regression_Test
    [Documentation]             Insured Info page
    # Author = Amol
    #TC=78991
    Home
    ClickText                   Renewals                    anchor=Claims Data
    VerifyText                  Upcoming Renewal List
    Home
    ClickText                   Claims Data                 anchor=Renewals
    VerifyText                  Recently Viewed


Verify that the Excess Wording is attached to the email on excess quote with XOL binders
    [Tags]                      Regression_Test_Accountants                             Regression_Test
    [Documentation]             Insured Info page
    # Author = Amol
    #TC=78992
    Creating a new Account
    Validate Aqueous New submission Fields
    VerifyText                  Underwriter Workbench
    #Validate field on Insured info
    Add Account name on Insured info page                   ${uniqueName}
    Click on save button
    ClickText                   NEXT:Submission Info >
    #Validate NewSubmission Init on Submission info page
    Select and add broker
    Select and add Profession                               Accountants
    Select and add Largest work type                        Directorships
    ClickText                   Next                        anchor=Cancel
    VerifyText                  Submission Info             anchor=*Submission Name
    ClickText                   NEXT:Underwriter Analysis >
    VerifyText                  Proposal Form Info
    #Validate Underwriter Analysis Fields
    Add Details In Underwriter Analysis Page
    ClickText                   Check Risk Health
    ClickText                   New Excess Quote
    Select Binder Name          XOL
    Sleep                       30s
    Enter Details in Layer
    Click On Finalize
    Sleep                       30sec
    Send Mail On Submission Page                            Quote Email Excess


Verify that the Foreign Exposures is calculated in V3
    [Tags]                      Regression_Test_Accountants                             Regression_Test
    [Documentation]             Foreign Exposures
    # Author = Amol
    #TC=79021
    Creating a new Account
    Validate Aqueous New submission Fields
    VerifyText                  Underwriter Workbench
    #Validate field on Insured info
    Add Account name on Insured info page                   ${uniqueName}
    Click on save button
    ClickText                   NEXT:Submission Info >
    #Validate NewSubmission Init on Submission info page
    Select and add broker
    Select and add Profession                               Accountants
    Select and add Largest work type                        Directorships
    ClickText                   Next                        anchor=Cancel
    VerifyText                  Submission Info             anchor=*Submission Name
    ClickText                   NEXT:Underwriter Analysis >
    VerifyText                  Proposal Form Info
    #Validate Underwriter Analysis Fields
    Add Details In Underwriter Analysis Page
    TypeText                    United Kingdom              60
    TypeText                    USA / Canada, and their territories and possessions     40
    ClickText                   Check Risk Health
    ClickText                   New Primary Quote
    Sleep                       30s
    ClickText                   Underwriting Analysis
    Check Foreign Exposure Value
