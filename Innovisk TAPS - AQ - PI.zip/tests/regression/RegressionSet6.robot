*** Settings ***
Library                         QWeb
Library                         QForce
#Library                        QVision
Library                         FakerLibrary
Library                         String
Library                         BuiltIn
Library                         DateTime
Resource                        ../../resources/common.robot
Resource                        ../../resources/ReadPDF.robot
Resource                        ../../PageObjects/PageObjects_Account.robot
#Resource                       ../PageObjects/PageObjects_HomePage.robot
Resource                        ../../PageObjects/PageObjects_Submission.robot
Resource                        ../../PageObjects/PageObjects_InsuredInfo.robot
Resource                        ../../PageObjects/PageObjects_SubmissionInit.robot
Library                         RetryFailed                 global_retries=${retry_count}
Suite Setup                     Setup Browser
Suite Teardown                  CloseAllBrowsers
Resource                        ../../resources/common.robot
Resource                        ../../PageObjects/PageObjects_SubmissionInfo.robot
Resource                        ../../PageObjects/PageObjects_UnderwriterAnalysis.robot
Resource                        ../../PageObjects/PageObjects_QuoteConsole.robot
Resource                        ../../PageObjects/PageObjects_PreBindPage.robot
Resource                        ../../PageObjects/PageObjects_PolicyPage.robot
Resource                        ../../PageObjects/PageObjects_SendEmail.robot

*** Test Cases ***
Verify that the Referral should not trigger if we set Largest total contract value size as less than 10M
    [Tags]                      Regression_Test_PropertyProfessional                    Regression_Test
    [Documentation]             Insured Info page
    # Author = Amol
    #TC=78999
    Home2
    Creating a new Account
    Validate Aqueous New submission Fields
    VerifyText                  Underwriter Workbench
    #Validate field on Insured info
    Add Account name on Insured info page                   ${uniqueName}
    Click on save button
    ClickText                   NEXT:Submission Info >
    #Validate NewSubmission Init on Submission info page
    Select and add broker
    Select and add Profession                               Property Professionals
    Select and add Largest work type                        Arbitrator
    ClickText                   Next                        anchor=Cancel
    VerifyText                  Submission Info             anchor=*Submission Name
    ClickText                   NEXT:Underwriter Analysis >
    Add Details On Underwriter
    TypeText                    Largest total contract value size                       500000
    Select split independantly                              2
    Select split independantly                              6
    TypeText                    (//input[contains(@name,'_split')])[1]                  50
    TypeText                    (//input[contains(@name,'_split')])[2]                  50
    ClickText                   Check Risk Health
    ClickText                   New Primary Quote
    Sleep                       20s
    VerifyText                  Quote Details
    VerifyElement               (//span[text()\='Rated'])[1]


Verify that the referral is triggered for Number of Partners for Solicitors profession
    [Tags]                      Regression_Test_Solicitors                              Regression_Test
    [Documentation]             Insured Info page
    # Author = Amol
    #TC=79005
    Home2
    Creating a new Account
    Validate Aqueous New submission Fields
    VerifyText                  Underwriter Workbench
    #Validate field on Insured info
    Add Account name on Insured info page                   ${uniqueName}
    Click on save button
    ClickText                   NEXT:Submission Info >
    #Validate NewSubmission Init on Submission info page
    Select and add broker
    Select and add Profession                               Solicitors
    Select and add Largest work type                        Adjudication
    ClickText                   Next                        anchor=Cancel
    VerifyText                  Submission Info             anchor=*Submission Name
    ClickText                   NEXT:Underwriter Analysis >
    TypeText                    Number of Partners          1
    ClickElement                //span[text()\='Is the Firm a Partnership or LLP/Ltd']/parent::*/following::td
    ClickText                   //span[text()\='Partnership']
    TypeText                    (//input)[11]               5
    TypeText                    Claims Experience – Incurred in last 5 years            10
    TypeText                    Professional Business Description                       10
    Select split independantly                              2
    TypeText                    (//input[contains(@name,'_split')])[1]                  100
    ClickText                   Check Risk Health
    ClickText                   New Excess Quote
    ClickElement                //span[text()\='Select Item 1']
    ClickText                   Proceed to Quote
    Enter Details in Layer
    ClickText                   Finalize
    VerifyElement               (//span[text()\='Referred'])[1]

Verify that the Referral Trigger for Level 2 when Fire Protection Consultant is 15.5 % for 2023-GAIC Binder In Excess Layer
    [Tags]                      Regression_Test_Miscellaneous                           Regression_Test
    [Documentation]             Insured Info page
    # Author = Amol
    #TC=79006
    Home2
    Creating a new Account
    Validate Aqueous New submission Fields
    VerifyText                  Underwriter Workbench
    #Validate field on Insured info
    Add Account name on Insured info page                   ${uniqueName}
    Click on save button
    ClickText                   NEXT:Submission Info >
    #Validate NewSubmission Init on Submission info page
    Select and add broker
    Select and add Profession                               Miscellaneous
    Select and add Largest work type                        Adjudicator
    ClickText                   Next                        anchor=Cancel
    VerifyText                  Submission Info             anchor=*Submission Name
    ClickText                   NEXT:Underwriter Analysis >
    VerifyText                  Proposal Form Info
    TypeText                    Annual gross fees / turnover - change                   50000
    TypeText                    Professional Business Description                       Test Description
    ClickElement                (//button[@class\='slds-button slds-button_icon slds-button_icon-container'])[2]
    ClickElement                //div[text()\='Fire protection consultant']/parent::*/preceding-sibling::td
    ClickElement                //div[text()\='Adjudicator']/parent::*/preceding-sibling::td
    ClickElement                //button[@title\='Add']
    TypeText                    (//input[contains(@name,'_split')])[1]                  15.5
    TypeText                    (//input[contains(@name,'_split')])[2]                  84.5
    ClickText                   Check Risk Health
    ClickText                   New Excess Quote
    Select Binder Name          GAIC
    Enter Details in Layer
    ClickText                   Finalize
    VerifyElement               (//span[text()\='Referred'])[1]
    ClickElement                //lightning-icon[@title\='View Referral Reasons']
    VerifyText                  Fire Protection Consultant, if over 15%


Verify that the Referral is triggered for Insurance broker profession with user level 1  
    [Tags]                      Regression_Test_InsuranceBrokers                        Regression_Test
    [Documentation]             Insured Info page
    # Author = Amol
    #TC=79010
    Home2
    Creating a new Account
    Validate Aqueous New submission Fields
    VerifyText                  Underwriter Workbench
    #Validate field on Insured info
    Add Account name on Insured info page                   ${uniqueName}
    Click on save button
    ClickText                   NEXT:Submission Info >
    #Validate NewSubmission Init on Submission info page
    Select and add broker
    Select and add Profession                               Insurance Brokers
    Select and add Largest work type                        Construction
    ClickText                   Next                        anchor=Cancel
    VerifyText                  Submission Info             anchor=*Submission Name
    ClickText                   NEXT:Underwriter Analysis >
    VerifyText                  Proposal Form Info
    TypeText                    Annual gross fees / turnover - change                   50000
    TypeText                    Professional Business Description                       Test Description
    ClickElement                (//button[@class\='slds-button slds-button_icon slds-button_icon-container'])[2]
    ClickElement                //div[text()\='Guaranteed Asset Protection Insurance (GAP)']/parent::*/preceding-sibling::td
    ClickElement                //div[text()\='Loss Assessing / Claims Adjusting']/parent::*/preceding-sibling::td
    ClickElement                //div[text()\='Motor (personal or commercial)']/parent::*/preceding-sibling::td
    ClickElement                //div[text()\='Personal lines (non motor)']/parent::*/preceding-sibling::td
    ClickElement                //div[text()\='Private Medical Insurance']/parent::*/preceding-sibling::td
    ClickElement                //button[@title\='Add']
    TypeText                    (//input[contains(@name,'_split')])[1]                  20
    TypeText                    (//input[contains(@name,'_split')])[2]                  20
    TypeText                    (//input[contains(@name,'_split')])[3]                  20
    TypeText                    (//input[contains(@name,'_split')])[4]                  20
    TypeText                    (//input[contains(@name,'_split')])[5]                  20
    ClickText                   Check Risk Health
    ClickText                   New Primary Quote
    ClickText                   Finalize
    VerifyElement               (//span[text()\='Referred'])[1]


Verify that the Referral is triggered for the Miscellaneous profession while selecting the work types with user level 3 
    [Tags]                      Regression_Test_Miscellaneous                           Regression_Test
    [Documentation]             Insured Info page
    # Author = Amol
    #TC=79012
    Home2
    Creating a new Account
    Validate Aqueous New submission Fields
    VerifyText                  Underwriter Workbench
    #Validate field on Insured info
    Add Account name on Insured info page                   ${uniqueName}
    Click on save button
    ClickText                   NEXT:Submission Info >
    #Validate NewSubmission Init on Submission info page
    Select and add broker
    Select and add Profession                               Miscellaneous
    Select and add Largest work type                        Adjudicator
    ClickText                   Next                        anchor=Cancel
    VerifyText                  Submission Info             anchor=*Submission Name
    ClickText                   NEXT:Underwriter Analysis >
    VerifyText                  Proposal Form Info
    TypeText                    Annual gross fees / turnover - change                   50000
    TypeText                    Professional Business Description                       Test Description
    ClickElement                (//button[@class\='slds-button slds-button_icon slds-button_icon-container'])[2]
    ClickElement                //div[text()\='Head Hunting']/parent::*/preceding-sibling::td
    ClickElement                //div[text()\='Recruitment Consultancy']/parent::*/preceding-sibling::td
    ClickElement                //button[@title\='Add']
    TypeText                    (//input[contains(@name,'_split')])[1]                  50
    TypeText                    (//input[contains(@name,'_split')])[2]                  50
    ClickText                   Check Risk Health
    ClickText                   New Primary Quote
    Delete Default added Endorsement
    Sleep                       30s
    ClickText                   Finalize
    Sleep                       10s
    VerifyElement               (//span[text()\='Referred'])[1]
    Logout


