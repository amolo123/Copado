*** Settings ***
Library                         QWeb
Library                         QForce
#Library                        QVision
Library                         FakerLibrary
Library                         String
Library                         BuiltIn
Library                         DateTime
Resource                        ../../resources/common.robot
Resource                        ../../resources/ReadPDF.robot
Resource                        ../../PageObjects/PageObjects_Account.robot
#Resource                       ../PageObjects/PageObjects_HomePage.robot
Resource                        ../../PageObjects/PageObjects_Submission.robot
Resource                        ../../PageObjects/PageObjects_InsuredInfo.robot
Resource                        ../../PageObjects/PageObjects_SubmissionInit.robot
Library                         RetryFailed                 global_retries=${retry_count}
Suite Setup                     Setup Browser
Suite Teardown                  CloseAllBrowsers
Resource                        ../../resources/common.robot
Resource                        ../../PageObjects/PageObjects_SubmissionInfo.robot
Resource                        ../../PageObjects/PageObjects_UnderwriterAnalysis.robot
Resource                        ../../PageObjects/PageObjects_QuoteConsole.robot
Resource                        ../../PageObjects/PageObjects_PreBindPage.robot
Resource                        ../../PageObjects/PageObjects_PolicyPage.robot
Resource                        ../../PageObjects/PageObjects_SendEmail.robot

*** Test Cases ***

Verify that the referral is triggered, when Endorsement AQUW125 is added
    [Documentation]             Insured Info page
    [Tags]                      Regression_Test_Accountants                             Regression_Test
    # Author = Amol Gaymukhe
    #TC=120009
    Home2
    Creating a new Account
    Validate Aqueous New submission Fields
    VerifyText                  Underwriter Workbench
    #Validate field on Insured info
    Add Account name on Insured info page                   ${uniqueName}
    Click on save button
    ClickText                   NEXT:Submission Info >
    #Validate NewSubmission Init on Submission info page
    Select and add broker
    Select and add Profession                               Engineers
    Select and add Largest work type                        Arbitrator
    ClickText                   Next                        anchor=Cancel
    VerifyText                  Submission Info             anchor=*Submission Name
    ClickText                   NEXT:Underwriter Analysis >
    VerifyText                  Proposal Form Info
    #Validate Underwriter Analysis Fields
    ${cur_date}=                Get Current Date            result_format=%-m/%d/%Y
    ${cur_date2}=               Get Current Date            result_format=%-m/%d/%Y
    Log To Console              ${cur_date}
    TypeText                    Proposal Form Date          ${cur_date2}
    ClickText                   Date of Last Full Proposal Form on file                 #${cur_date2}
    TypeText                    //span[text()\='Annual gross fees / turnover']/ancestor::tbody//input          5000005
    TypeText                    Professional Business Description                       Text
    ClickElement                (//button[@class\='slds-button slds-button_icon slds-button_icon-container'])[2]
    ClickElement                (//c-work-type-analysis-section//lightning-primitive-input-checkbox)[2]
    ClickElement                //button[@title\='Add']
    Sleep                       10s
    TypeText                    //input[contains(@name,'_split')]                       100
    ClickText                   Save                        anchor=Check Risk Health
    VerifyText                  Success                     anchor=Update records successfully!                partial_match=false
    ClickText                   Check Risk Health
    ClickText                   New Primary Quote
    Click On Endorsements and Subjectivities
    Select Endorsement          AQUW125
    ClickElement                (//div[@class\='slds-page-header__controls']//lightning-icon[@title\='Endorsements & Subjectivities'])[1]
    UseModal                    On
    VerifyText                  Endorsement and Subjectivity
    Add Endorsement Detail Amount                           AQUW125
    ScrollText                  Rate
    ClickText                   Rate                        anchor=Finalize
    Sleep                       20s
    ClickText                   Finalize
    VerifyElement               (//span[text()\='Referred'])[1]
    ${referred_submission_link}=                            GetUrl
    Log To Console              ${referred_submission_link}
    Set Global Variable         ${referred_submission_link}
    OpenBrowser                 ${login_url}                chrome
    Login
    Go To                       ${referred_submission_link}
    ClickElement                //lightning-icon[@title\='View Referral Reasons']
    VerifyText                  Referral Reasons
    ClickText                   Go to Approval
    SwitchWindow                2
    VerifyText                  Approval Details
    ClickText                   Approve
    TypeText                    Comments                    Please Approve
    ClickText                   Approve                     anchor=Cancel
    SwitchBrowser               1
    RefreshPage
    VerifyElement               (//span[text()\='In Progress'])[1]
    Logout
    Home2
    Go To                       ${referred_submission_link}
    VerifyText                  Quote Details
    Enter Broker Commission
    Enter Expiration Date
    ScrollText                  Finalize
    ClickText                   Rate                        anchor=Finalize
    Sleep                       20s
    Click On Finalize
    Sleep                       20s
    Click Proceed To Bind
    Select first Quote
    Sleep                       30s
    ClickElement                //button[text()\='Bind']
    VerifyText                  Warning!
    ClickText                   Bind                        anchor=Cancel
    VerifyText                  Success                     anchor=Bind quote successfully!                    timeout=45s             partial_match= false
    #Click On Bind
    Change Policy               Full Amendment
    Full Amendment Input
    RefreshPage
    Click Rate After Amendment
    Sleep                       10s
    ClickText                   Finalize
    ClickElement                //button[text()\='Bind']
    VerifyText                  Warning!
    ClickText                   Bind                        anchor=Cancel
    VerifyText                  Success                     anchor=Bind quote successfully!                    timeout=45s             partial_match= false



Verify that the referral is triggered, when Endorsement AQUW139 is added
    [Documentation]             Insured Info page
    [Tags]                      Regression_Test_Accountants                             Regression_Test
    # Author = Amol Gaymukhe
    #TC=120010
    Home2
    Creating a new Account
    Validate Aqueous New submission Fields
    VerifyText                  Underwriter Workbench
    #Validate field on Insured info
    Add Account name on Insured info page                   ${uniqueName}
    Click on save button
    ClickText                   NEXT:Submission Info >
    #Validate NewSubmission Init on Submission info page
    Select and add broker
    Select and add Profession                               Insurance Brokers
    Select and add Largest work type                        Bloodstock
    ClickText                   Next                        anchor=Cancel
    VerifyText                  Submission Info             anchor=*Submission Name
    ClickText                   NEXT:Underwriter Analysis >
    VerifyText                  Proposal Form Info
    #Validate Underwriter Analysis Fields
    ${cur_date}=                Get Current Date            result_format=%-m/%d/%Y
    ${cur_date2}=               Get Current Date            result_format=%-m/%d/%Y
    Log To Console              ${cur_date}
    TypeText                    Proposal Form Date          ${cur_date2}
    ClickText                   Date of Last Full Proposal Form on file                 #${cur_date2}
    TypeText                    //span[text()\='Annual gross fees / turnover']/ancestor::tbody//input          5000005
    TypeText                    Professional Business Description                       Text
    ClickElement                (//button[@class\='slds-button slds-button_icon slds-button_icon-container'])[2]
    ClickElement                (//c-work-type-analysis-section//lightning-primitive-input-checkbox)[2]
    ClickElement                //button[@title\='Add']
    Sleep                       10s
    TypeText                    //input[contains(@name,'_split')]                       100
    ClickText                   Save                        anchor=Check Risk Health
    VerifyText                  Success                     anchor=Update records successfully!                partial_match=false
    ClickText                   Check Risk Health
    ClickText                   New Primary Quote
    Click On Endorsements and Subjectivities
    Select Endorsement          AQUW139
    ScrollText                  Rated
    Scroll                      //html                      page_up
    ClickText                   Rate                        anchor=Finalize
    ClickText                   Confirm                     anchor=Cancel
    Sleep                       20s
    ClickText                   Finalize
    VerifyElement               (//span[text()\='Referred'])[1]
    ${referred_submission_link}=                            GetUrl
    Log To Console              ${referred_submission_link}
    Set Global Variable         ${referred_submission_link}
    OpenBrowser                 ${login_url}                chrome
    Login
    Go To                       ${referred_submission_link}
    ClickElement                //lightning-icon[@title\='View Referral Reasons']
    VerifyText                  Referral Reasons
    ClickText                   Go to Approval
    SwitchWindow                2
    VerifyText                  Approval Details
    ClickText                   Approve
    TypeText                    Comments                    Please Approve
    ClickText                   Approve                     anchor=Cancel
    SwitchBrowser               1
    RefreshPage
    VerifyElement               (//span[text()\='In Progress'])[1]
    Logout
    Home2
    Go To                       ${referred_submission_link}
    VerifyText                  Quote Details
    Enter Broker Commission
    Enter Expiration Date
    ScrollText                  Finalize
    ClickText                   Rate                        anchor=Finalize
    Sleep                       20s
    Click On Finalize
    Sleep                       20s
    Click Proceed To Bind
    Select first Quote
    Sleep                       30s
    ClickElement                //button[text()\='Bind']
    VerifyText                  Warning!
    ClickText                   Bind                        anchor=Cancel
    VerifyText                  Success                     anchor=Bind quote successfully!                    timeout=45s             partial_match= false
    #Click On Bind
    Change Policy               Full Amendment
    Full Amendment Input
    RefreshPage
    Click Rate After Amendment
    Sleep                       20s
    ClickText                   Finalize
    ClickElement                //button[text()\='Bind']
    VerifyText                  Warning!
    ClickText                   Bind                        anchor=Cancel
    VerifyText                  Success                     anchor=Bind quote successfully!                    timeout=45s             partial_match= false



Verify that the referral is triggered, when Endorsement AQUW140 is added
    [Documentation]             Insured Info page
    [Tags]                      Regression_Test_Accountants                             Regression_Test
    # Author = Amol Gaymukhe
    #TC=120011
    Home2
    Creating a new Account
    Validate Aqueous New submission Fields
    VerifyText                  Underwriter Workbench
    #Validate field on Insured info
    Add Account name on Insured info page                   ${uniqueName}
    Click on save button
    ClickText                   NEXT:Submission Info >
    #Validate NewSubmission Init on Submission info page
    Select and add broker
    Select and add Profession                               Accountants
    Select and add Largest work type                        Directorships
    ClickText                   Next                        anchor=Cancel
    VerifyText                  Submission Info             anchor=*Submission Name
    ClickText                   NEXT:Underwriter Analysis >
    VerifyText                  Proposal Form Info
    #Validate Underwriter Analysis Fields
    Add Details In Underwriter Analysis Page
    ClickText                   Check Risk Health
    ClickText                   New Primary Quote
    Sleep                       30s
    Click On Endorsements and Subjectivities
    Select Endorsement          AQUW140

    Scroll                      //html                      page_up
    ClickText                   Rate                        anchor=Finalize
    ClickText                   Confirm                     anchor=Cancel
    Sleep                       20s
    ClickText                   Finalize
    VerifyElement               (//span[text()\='Referred'])[1]
    ${referred_submission_link}=                            GetUrl
    Log To Console              ${referred_submission_link}
    Set Global Variable         ${referred_submission_link}
    OpenBrowser                 ${login_url}                chrome
    Login
    Go To                       ${referred_submission_link}
    ClickElement                //lightning-icon[@title\='View Referral Reasons']
    VerifyText                  Referral Reasons
    ClickText                   Go to Approval
    SwitchWindow                2
    VerifyText                  Approval Details
    ClickText                   Approve
    TypeText                    Comments                    Please Approve
    ClickText                   Approve                     anchor=Cancel
    SwitchBrowser               1
    RefreshPage
    VerifyElement               (//span[text()\='In Progress'])[1]
    Logout
    Home2
    Go To                       ${referred_submission_link}
    VerifyText                  Quote Details
    Enter Broker Commission
    Enter Expiration Date
    ScrollText                  Finalize
    ClickText                   Rate                        anchor=Finalize
    Sleep                       20s
    Click On Finalize
    Sleep                       20s
    Click Proceed To Bind
    Select first Quote
    Sleep                       30s
    ClickElement                //button[text()\='Bind']
    VerifyText                  Success                     anchor=Bind quote successfully!                    timeout=45s             partial_match= false
    #Click On Bind
    Change Policy               Full Amendment
    Full Amendment Input
    RefreshPage
    Click Rate After Amendment
    ClickText                   Finalize
    ClickElement                //button[text()\='Bind']
    VerifyText                  Success                     anchor=Bind quote successfully!                    timeout=75s             partial_match= false


Verify that the referral is triggered, when Jurisdiction selected as "Worldwide"
    [Documentation]             Insured Info page
    [Tags]                      Regression_Test_Accountants                             Regression_Test
    # Author = Amol Gaymukhe
    #TC=120001
    Home2
    Creating a new Account
    Validate Aqueous New submission Fields
    VerifyText                  Underwriter Workbench
    #Validate field on Insured info
    Add Account name on Insured info page                   ${uniqueName}
    Click on save button
    ClickText                   NEXT:Submission Info >
    #Validate NewSubmission Init on Submission info page
    Select and add broker
    Select and add Profession                               Accountants
    Select and add Largest work type                        Directorships
    ClickText                   Next                        anchor=Cancel
    VerifyText                  Submission Info             anchor=*Submission Name
    ClickText                   NEXT:Underwriter Analysis >
    VerifyText                  Proposal Form Info
    Add Details In Underwriter Analysis Page
    ClickText                   Check Risk Health
    ClickText                   New Excess Quote
    ClickText                   Select Item 3
    ClickText                   Proceed to Quote
    Sleep                       30s
    ClickElement                //button[@aria-label\='Jurisdiction Limits']
    ClickText                   //lightning-base-combobox-item[@data-value\='Worldwide']
    ClickText                   Rate                        anchor=Finalize
    ClickText                   Confirm                     anchor=Cancel
    Sleep                       20s
    ClickText                   Finalize
    Enter Details in Layer
    ClickText                   Rate                        anchor=Finalize
    ClickText                   Confirm                     anchor=Cancel
    Sleep                       20s
    ClickText                   Finalize
    VerifyElement               (//span[text()\='Referred'])[1]
    ${referred_submission_link}=                            GetUrl
    Log To Console              ${referred_submission_link}
    Set Global Variable         ${referred_submission_link}
    OpenBrowser                 ${login_url}                chrome
    Login
    Go To                       ${referred_submission_link}
    ClickElement                //lightning-icon[@title\='View Referral Reasons']
    VerifyText                  Referral Reasons
    ClickText                   Go to Approval
    SwitchWindow                2
    VerifyText                  Approval Details
    ClickText                   Approve
    TypeText                    Comments                    Please Approve
    ClickText                   Approve                     anchor=Cancel
    SwitchBrowser               1
    RefreshPage
    VerifyElement               (//span[text()\='In Progress'])[1]
    Logout
    Home2
    Go To                       ${referred_submission_link}
    VerifyText                  Quote Details
    Enter Broker Commission
    Enter Expiration Date
    ScrollText                  Finalize
    ClickText                   Rate                        anchor=Finalize
    Sleep                       20s
    Click On Finalize
    Sleep                       20s
    Click Proceed To Bind
    Select first Quote
    ClickElement                //button[text()\='Bind']
    VerifyText                  Success                     anchor=Bind quote successfully!                    timeout=45s             partial_match= false
    #Click On Bind
    Change Policy               Full Amendment
    Full Amendment Input
    RefreshPage
    Click Rate After Amendment
    ClickText                   Finalize
    ClickElement                //button[text()\='Bind']
    VerifyText                  Success                     anchor=Bind quote successfully!                    timeout=45s             partial_match= false



Verify that the referral is triggered for Solicitor profession, when AnnualGrossFeesTurnover is greater than 5M and TUL is equal and more than 5M
    [Documentation]             Insured Info page
    [Tags]                      Regression_Test_Accountants                             Regression_Test
    # Author = Amol Gaymukhe
    #TC=120001
    Home2
    Creating a new Account
    Validate Aqueous New submission Fields
    VerifyText                  Underwriter Workbench
    #Validate field on Insured info
    Add Account name on Insured info page                   ${uniqueName}
    Click on save button
    ClickText                   NEXT:Submission Info >
    #Validate NewSubmission Init on Submission info page
    Select and add broker
    Select and add Profession                               Solicitors
    Select and add Largest work type                        Adjudication
    ClickText                   Next                        anchor=Cancel
    VerifyText                  Submission Info             anchor=*Submission Name
    ClickText                   NEXT:Underwriter Analysis >
    VerifyText                  Proposal Form Info
    ${cur_date}=                Get Current Date            result_format=%-m/%d/%Y
    ${cur_date2}=               Get Current Date            result_format=%-m/%d/%Y
    Log To Console              ${cur_date}
    TypeText                    Proposal Form Date          ${cur_date2}
    ClickText                   Date of Last Full Proposal Form on file                 #${cur_date2}
    TypeText                    //span[text()\='Annual gross fees / turnover']/ancestor::tbody//input          5000005
    ClickElement                //span[text()\='Is the Firm a Partnership or LLP/Ltd']/ancestor::tbody//button
    ClickText                   Partnership                 partial_match=false
    TypeText                    //span[text()\='Number of Partners']/ancestor::tbody//input                    10
    TypeText                    //span[text()\='Claims Experience – Incurred in last 5 years']/ancestor::tbody//input                  100
    TypeText                    Professional Business Description                       Text
    ClickElement                (//button[@class\='slds-button slds-button_icon slds-button_icon-container'])[2]
    ClickElement                (//c-work-type-analysis-section//lightning-primitive-input-checkbox)[2]
    ClickElement                //button[@title\='Add']
    Sleep                       10s
    TypeText                    //input[contains(@name,'_split')]                       100
    ClickText                   Save                        anchor=Check Risk Health
    VerifyText                  Success                     anchor=Update records successfully!                partial_match=false
    ClickText                   Check Risk Health
    ClickText                   New Excess Quote
    ClickText                   Select Item 2
    ClickText                   Proceed to Quote
    Sleep                       30s
    Click On Endorsements and Subjectivities
    UseModal                    On
    VerifyText                  Endorsement and Subjectivity                            timeout=45s
    ClickText                   Insurer Layer               partial_match=False
    ClickElement                //td[@data-label\='Insurer']
    TypeText                    //td[@data-label\='Insurer']//input                     Test 1
    TypeText                    //td[@data-label\='Insurer Policy Number']//input       234223
    TypeText                    //td[@data-label\='Insurer Layer Limit']//input         5000005
    ClickText                   Save                        anchor=Add a Layer
    VerifyText                  Success                     anchor=Data Saved Successfully!                    timeout=20s
    ClickText                   Return Quote Process
    Log To Console              ------Layer Entered Correctly---------
    Click Rate After Amendment
    Sleep                       20s
    ClickText                   Finalize
    VerifyElement               (//span[text()\='Referred'])[1]
    ${referred_submission_link}=                            GetUrl
    Log To Console              ${referred_submission_link}
    Set Global Variable         ${referred_submission_link}
    OpenBrowser                 ${login_url}                chrome
    Login
    Go To                       ${referred_submission_link}
    ClickElement                //lightning-icon[@title\='View Referral Reasons']
    VerifyText                  Referral Reasons
    ClickText                   Go to Approval
    SwitchWindow                2
    VerifyText                  Approval Details
    ClickText                   Approve
    TypeText                    Comments                    Please Approve
    ClickText                   Approve                     anchor=Cancel
    SwitchBrowser               1
    RefreshPage
    VerifyElement               (//span[text()\='In Progress'])[1]
    Logout
    Home2
    Go To                       ${referred_submission_link}
    VerifyText                  Quote Details
    Enter Broker Commission
    Enter Expiration Date
    ScrollText                  Finalize
    ClickText                   Rate                        anchor=Finalize
    Sleep                       20s
    Click On Finalize
    Sleep                       20s
    Click Proceed To Bind
    Select first Quote
    Sleep                       20s
    ClickElement                //button[text()\='Bind']
    VerifyText                  Warning!
    ClickText                   Bind                        anchor=Cancel
    VerifyText                  Success                     anchor=Bind quote successfully!                    timeout=45s             partial_match= false
    #Click On Bind
    Change Policy               Full Amendment
    Full Amendment Input
    RefreshPage
    Click Rate After Amendment
    ClickText                   Finalize
    ClickElement                //button[text()\='Bind']
    VerifyText                  Warning!
    ClickText                   Bind                        anchor=Cancel
    VerifyText                  Success                     anchor=Bind quote successfully!                    timeout=45s             partial_match= false
