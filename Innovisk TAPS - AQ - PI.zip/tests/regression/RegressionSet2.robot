*** Settings ***
Library                         QWeb
Library                         QForce
#Library                        QVision
Library                         FakerLibrary
Library                         String
Library                         BuiltIn
Library                         DateTime
Resource                        ../../resources/common.robot
Resource                        ../../resources/ReadPDF.robot
Resource                        ../../PageObjects/PageObjects_Account.robot
#Resource                       ../PageObjects/PageObjects_HomePage.robot
Resource                        ../../PageObjects/PageObjects_Submission.robot
Resource                        ../../PageObjects/PageObjects_InsuredInfo.robot
Resource                        ../../PageObjects/PageObjects_SubmissionInit.robot
Library                         RetryFailed                 global_retries=${retry_count}
Suite Setup                     Setup Browser
Suite Teardown                  CloseAllBrowsers
Resource                        ../../resources/common.robot
Resource                        ../../PageObjects/PageObjects_SubmissionInfo.robot
Resource                        ../../PageObjects/PageObjects_UnderwriterAnalysis.robot
Resource                        ../../PageObjects/PageObjects_QuoteConsole.robot
Resource                        ../../PageObjects/PageObjects_PreBindPage.robot
Resource                        ../../PageObjects/PageObjects_PolicyPage.robot
Resource                        ../../PageObjects/PageObjects_SendEmail.robot

*** Test Cases ***
Verify that the Non Prorated Premium is displayed on Reinstatment transactions
    #Author= Amol Gaymukhe
    #TC=78974
    [Documentation]             On Amenedments submission , policy is created and proper values and details are displaye
    [Tags]                      Regression_Test_Accountants                             Regression_Test
    Creating a new Account
    Validate Aqueous New submission Fields
    VerifyText                  Underwriter Workbench
    #Validate field on Insured info
    Add Account name on Insured info page                   ${uniqueName}
    Click on save button
    ClickText                   NEXT:Submission Info >
    #Validate NewSubmission Init on Submission info page
    Select and add broker
    Select and add Profession                               Accountants
    Select and add Largest work type                        Directorships
    ClickText                   Next                        anchor=Cancel
    VerifyText                  Submission Info             anchor=*Submission Name
    ClickText                   NEXT:Underwriter Analysis >
    VerifyText                  Proposal Form Info
    #Validate Underwriter Analysis Fields
    Add Details In Underwriter Analysis Page
    ClickText                   Check Risk Health
    ClickText                   New Primary Quote
    Sleep                       30s
    VerifyText                  Quote Details
    Enter Broker Commission
    Enter Expiration Date
    Click On Rate
    Click On Finalize
    Sleep                       20s
    Generate Document
    Click Proceed To Bind
    Select first Quote
    Sleep                       15s
    Click On Bind
    Change Policy               Midterm Cancellation
    Midterm Cancellation Input
    Click on First Quote with xpath
    Click Rate After Amendment
    Click On Finalize
    Sleep                       10s
    Click On Bind On Quote console
    Change Policy               Reinstatement
    Sleep                       10s
    Reinstatement Input
    Sleep                       15s
    ClickText                   Policies
    Click On First Policy
    Change Policy               Full Amendment
    Sleep                       20sec
    Full Amendment Input
    Sleep                       15s
    RefreshPage
    Click Rate After Amendment
    Edit Limit and Enter Value                              2000000
    Sleep                       2s
    ClickText                   Quote Options
    ClickText                   Save                        anchor=Cancel
    Click On Rate
    Edit BNDP Actual and Fee APRP                           900                         900            200
    Sleep                       2s
    ClickText                   Quote Options
    ClickText                   Save                        anchor=Cancel
    Click On Finalize

Verify that the Change Policy actions is not allowed on open Amendment Transactions
    #Author= Amol Gaymukhe
    #TC=78981
    [Documentation]             On Amenedments submission , policy is created and proper values and details are displaye
    [Tags]                      Regression_Test_Accountants                             Regression_Test
    Creating a new Account
    Validate Aqueous New submission Fields
    VerifyText                  Underwriter Workbench
    #Validate field on Insured info
    Add Account name on Insured info page                   ${uniqueName}
    Click on save button
    ClickText                   NEXT:Submission Info >
    #Validate NewSubmission Init on Submission info page
    Select and add broker
    Select and add Profession                               Accountants
    Select and add Largest work type                        Directorships
    ClickText                   Next                        anchor=Cancel
    VerifyText                  Submission Info             anchor=*Submission Name
    ClickText                   NEXT:Underwriter Analysis >
    VerifyText                  Proposal Form Info
    #Validate Underwriter Analysis Fields
    Add Details In Underwriter Analysis Page
    ClickText                   Check Risk Health
    ClickText                   New Primary Quote
    Sleep                       30s
    VerifyText                  Quote Details
    Enter Broker Commission
    Enter Expiration Date
    Click On Rate
    Click On Finalize
    Sleep                       20s
    Generate Document
    Click Proceed To Bind
    Select first Quote
    Sleep                       15s
    Click On Bind
    Change Policy               Full Amendment
    Full Amendment Input
    ClickText                   Policies
    Click On First Policy
    ClickText                   Change Policy
    #VerifyElement              //span[text()\='All open Quotes on related Submission must be bind or closed before initiating another policy Change']    timeout=25s
    VerifyText                  Error                       anchor=All open Quotes on related Submission must be bind or closed before initiating another policy Change    timeout=25s
