*** Settings ***
Library                         QWeb
Library                         QForce
#Library                        QVision
Library                         FakerLibrary
Library                         String
Library                         BuiltIn
Library                         DateTime
Resource                        ../../resources/common.robot
Resource                        ../../resources/ReadPDF.robot
Resource                        ../../PageObjects/PageObjects_Account.robot
#Resource                       ../PageObjects/PageObjects_HomePage.robot
Resource                        ../../PageObjects/PageObjects_Submission.robot
Resource                        ../../PageObjects/PageObjects_InsuredInfo.robot
Resource                        ../../PageObjects/PageObjects_SubmissionInit.robot
Library                         RetryFailed                 global_retries=${retry_count}
Suite Setup                     Setup Browser
Suite Teardown                  CloseAllBrowsers
Resource                        ../../resources/common.robot
Resource                        ../../PageObjects/PageObjects_SubmissionInfo.robot
Resource                        ../../PageObjects/PageObjects_UnderwriterAnalysis.robot
Resource                        ../../PageObjects/PageObjects_QuoteConsole.robot
Resource                        ../../PageObjects/PageObjects_PreBindPage.robot
Resource                        ../../PageObjects/PageObjects_PolicyPage.robot
Resource                        ../../PageObjects/PageObjects_SendEmail.robot

*** Test Cases ***

Verify that the Referral is triggered for the property professionals while selecting the work types with user level 1
    [Tags]                      Regression_Test_Property Professionals                  Regression_Test
    [Documentation]             Insured Info page
    # Author = Amol
    #TC=78999
    Creating a new Account
    Validate Aqueous New submission Fields
    VerifyText                  Underwriter Workbench
    #Validate field on Insured info
    Add Account name on Insured info page                   ${uniqueName}
    Click on save button
    ClickText                   NEXT:Submission Info >
    #Validate NewSubmission Init on Submission info page
    Select and add broker
    Select and add Profession                               Property Professionals
    Select and add Largest work type                        Arbitrator
    ClickText                   Next                        anchor=Cancel
    VerifyText                  Submission Info             anchor=*Submission Name
    ClickText                   NEXT:Underwriter Analysis >
    VerifyText                  Proposal Form Info
    Add Details On Underwriter
    ClickElement                (//button[@class\='slds-button slds-button_icon slds-button_icon-container'])[2]
    ClickElement                //div[text()\='Commercial Lending Valuations']/parent::*/preceding-sibling::td
    ClickElement                //div[text()\='Residential Lending Valuations']/parent::*/preceding-sibling::td
    ClickElement                //button[@title\='Add']
    TypeText                    (//input[contains(@name,'_split')])[1]                  50
    TypeText                    (//input[contains(@name,'_split')])[2]                  50
    ClickText                   Check Risk Health
    ClickText                   New Primary Quote
    Sleep                       15s
    ClickText                   Finalize
    VerifyElement               (//span[text()\='Referred'])[1]
    Logout


Verify that the Referral is triggered for the Account profession with User level 3
    [Tags]                      Regression_Test_Accountants                             Regression_Test
    [Documentation]             Insured Info page
    # Author = Amol
    #TC=79014
    Home2
    Creating a new Account
    Validate Aqueous New submission Fields
    VerifyText                  Underwriter Workbench
    #Validate field on Insured info
    Add Account name on Insured info page                   ${uniqueName}
    Click on save button
    ClickText                   NEXT:Submission Info >
    #Validate NewSubmission Init on Submission info page
    Select and add broker
    Select and add Profession                               Accountants
    Select and add Largest work type                        Directorships
    ClickText                   Next                        anchor=Cancel
    VerifyText                  Submission Info             anchor=*Submission Name
    ClickText                   NEXT:Underwriter Analysis >
    VerifyText                  Proposal Form Info
    Add Details On Underwriter
    ClickElement                (//button[@class\='slds-button slds-button_icon slds-button_icon-container'])[2]
    ClickElement                //div[text()\='Investment income']/parent::*/preceding-sibling::td
    ClickElement                //button[@title\='Add']
    TypeText                    (//input[contains(@name,'_split')])[1]                  100
    ClickText                   Check Risk Health
    ClickText                   New Primary Quote
    ClickText                   Finalize
    VerifyElement               (//span[text()\='Referred'])[1]
    ClickElement                //lightning-icon[@title\='View Referral Reasons']
    VerifyText                  Accountant, Investment income, where this exceeds 5% of rateable exposure


Verify that the Refferal is triggered to primary layer for the Media professions with User level 2  
    [Tags]                      Regression_Test_Media Professionals                     Regression_Test
    [Documentation]             Insured Info page
    # Author = Amol
    #TC=79014
    Home2
    Creating a new Account
    Validate Aqueous New submission Fields
    VerifyText                  Underwriter Workbench
    #Validate field on Insured info
    Add Account name on Insured info page                   ${uniqueName}
    Click on save button
    ClickText                   NEXT:Submission Info >
    #Validate NewSubmission Init on Submission info page
    Select and add broker
    Select and add Profession                               Media Professionals
    Select and add Largest work type                        Marketing
    ClickText                   Next                        anchor=Cancel
    VerifyText                  Submission Info             anchor=*Submission Name
    ClickText                   NEXT:Underwriter Analysis >
    VerifyText                  Proposal Form Info
    ${cur_date}=                Get Current Date            result_format=%-m/%d/%Y
    ${cur_date2}=               Get Current Date            result_format=%-m/%d/%Y
    Log To Console              ${cur_date}
    TypeText                    Proposal Form Date          ${cur_date2}
    ClickText                   Date of Last Full Proposal Form on file                 #${cur_date2}
    TypeText                    Annual gross fees / turnover - change                   5000000
    ClickElement                (//span[text()\='Yes'])[2]
    TypeText                    Professional Business Description                       Text
    ClickElement                (//button[@class\='slds-button slds-button_icon slds-button_icon-container'])[2]
    ClickElement                //div[text()\='Direct marketing - database management and list broking']/parent::*/preceding-sibling::td
    ClickElement                //div[text()\='Direct Marketing mailshots and postage costs']/parent::*/preceding-sibling::td
    ClickElement                //button[@title\='Add']
    TypeText                    (//input[contains(@name,'_split')])[1]                  50
    TypeText                    (//input[contains(@name,'_split')])[2]                  50
    ClickText                   Check Risk Health
    ClickText                   New Primary Quote
    ClickText                   Finalize
    VerifyElement               (//span[text()\='Referred'])[1]
    ClickElement                //lightning-icon[@title\='View Referral Reasons']
    VerifyText                  Media - Direct marketing - database management and list broking , rateable exposure over 150,000
    VerifyText                  Media - Direct Marketing mailshots and postage costs , rateable exposure over 150,000
    Logout


Verify that the Referral is triggered for the Miscellaneous profession with level 1 User  
    [Tags]                      Regression_Test_Miscellaneous                           Regression_Test
    [Documentation]             Insured Info page
    # Author = Amol
    #TC=79014
    Creating a new Account
    Validate Aqueous New submission Fields
    VerifyText                  Underwriter Workbench
    #Validate field on Insured info
    Add Account name on Insured info page                   ${uniqueName}
    Click on save button
    ClickText                   NEXT:Submission Info >
    #Validate NewSubmission Init on Submission info page
    Select and add broker
    Select and add Profession                               Miscellaneous
    Select and add Largest work type                        Adjudicator
    ClickText                   Next                        anchor=Cancel
    VerifyText                  Submission Info             anchor=*Submission Name
    ClickText                   NEXT:Underwriter Analysis >
    VerifyText                  Proposal Form Info
    TypeText                    Annual gross fees / turnover - change                   50000
    TypeText                    Professional Business Description                       Test Description
    ClickElement                (//button[@class\='slds-button slds-button_icon slds-button_icon-container'])[2]
    ClickElement                //div[text()\='Travel Agent: Tailor made package design']/parent::*/preceding-sibling::td
    ClickElement                //button[@title\='Add']
    TypeText                    (//input[contains(@name,'_split')])[1]                  100
    ClickText                   Check Risk Health
    ClickText                   New Primary Quote
    VerifyText                  Quote Details
    ClickElement                (//button[text()\='Finalize'])[1]
    VerifyElement               (//span[text()\='Referred'])[1]
    ClickElement                //lightning-icon[@title\='View Referral Reasons']
    VerifyText                  Miscellaneous, Travel Agent: Tailor made package design more than 10% of rateable exposure

Verify that the Referral is triggered for Excess quote on GAIC binder where actual premium is less than 50% of minimum premium
    #Author= Amol Gaymukhe
    #TC=78975
    [Documentation]             On Amenedments submission , policy is created and proper values and details are displayed
    [Tags]                      Regression_Test_Accountants                             Regression_Test
    Creating a new Account
    Validate Aqueous New submission Fields
    VerifyText                  Underwriter Workbench
    Add Account name on Insured info page                   ${uniqueName}
    Click on save button
    ClickText                   NEXT:Submission Info >
    #Validate NewSubmission Init on Submission info page
    Select and add broker
    Select and add Profession                               Accountants
    Select and add Largest work type                        Directorships
    ClickText                   Next                        anchor=Cancel
    VerifyText                  Submission Info             anchor=*Submission Name
    ClickText                   NEXT:Underwriter Analysis >
    VerifyText                  Proposal Form Info
    #Validate Underwriter Analysis Fields
    Add Details In Underwriter Analysis Page
    ClickText                   Check Risk Health
    ClickText                   New Excess Quote
    Select Binder Name          GAIC
    Sleep                       15s
    VerifyText                  Quote Details
    Enter Details in Layer
    Enter Final AP to reduce PA
    # ClickText                 Save                        anchor=Cancel
    Click Rate After Amendment
    ClickElement                (//button[text()\='Finalize'])[1]
    VerifyElement               (//span[text()\='Referred'])[1]
    ClickElement                //lightning-icon[@title\='View Referral Reasons']
    VerifyText                  Actual Premium goes below 50% of Min Premium
    VerifyText                  Excess quote on GAIC binder where actual premium is less than 50% of technical premium
    Logout
