*** Settings ***
Library                         QWeb
Library                         QForce
#Library                        QVision
Library                         FakerLibrary
Library                         String
Library                         BuiltIn
Library                         DateTime
Resource                        ../../resources/common.robot
Resource                        ../../resources/ReadPDF.robot
Resource                        ../../PageObjects/PageObjects_Account.robot
#Resource                       ../PageObjects/PageObjects_HomePage.robot
Resource                        ../../PageObjects/PageObjects_Submission.robot
Resource                        ../../PageObjects/PageObjects_InsuredInfo.robot
Resource                        ../../PageObjects/PageObjects_SubmissionInit.robot
Library                         RetryFailed                 global_retries=${retry_count}
Suite Setup                     Setup Browser
Suite Teardown                  CloseAllBrowsers
Resource                        ../../resources/common.robot
Resource                        ../../PageObjects/PageObjects_SubmissionInfo.robot
Resource                        ../../PageObjects/PageObjects_UnderwriterAnalysis.robot
Resource                        ../../PageObjects/PageObjects_QuoteConsole.robot
Resource                        ../../PageObjects/PageObjects_PreBindPage.robot
Resource                        ../../PageObjects/PageObjects_PolicyPage.robot
Resource                        ../../PageObjects/PageObjects_SendEmail.robot

*** Test Cases ***

Verify that the referral value over 15000000 is triggered for All profession, when LargestQuantitySurveyingContractValueSize is over 1.5M
    [Documentation]             Insured Info page
    [Tags]                      Regression_Test_Accountants                             Regression_Test
    # Author = Amol Gaymukhe
    #TC=120007
    Home2
    Creating a new Account
    Validate Aqueous New submission Fields
    VerifyText                  Underwriter Workbench
    #Validate field on Insured info
    Add Account name on Insured info page                   ${uniqueName}
    Click on save button
    ClickText                   NEXT:Submission Info >
    #Validate NewSubmission Init on Submission info page
    Select and add broker
    Select and add Profession                               Property Professionals
    Select and add Largest work type                        Adjudicator
    ClickText                   Next                        anchor=Cancel
    VerifyText                  Submission Info             anchor=*Submission Name
    ClickText                   NEXT:Underwriter Analysis >
    VerifyText                  Proposal Form Info
    #Validate Underwriter Analysis Fields
    Add Details In Underwriter Analysis Page
    TypeText                    Largest Quantity Surveying contract value size          15000005
    TypeText                    Annual gross fees / turnover - change                   20000000
    ClickText                   Check Risk Health
    ClickText                   New Primary Quote
    ClickText                   Rate                        anchor=Finalize             delay=25s
    ClickText                   Confirm                     anchor=Cancel
    Sleep                       30s
    ClickText                   Finalize
    VerifyElement               (//span[text()\='Referred'])[1]
    ${referred_submission_link}=                            GetUrl
    Log To Console              ${referred_submission_link}
    Set Global Variable         ${referred_submission_link}
    OpenBrowser                 ${login_url}                chrome
    Login
    Go To                       ${referred_submission_link}
    ClickElement                //lightning-icon[@title\='View Referral Reasons']
    VerifyText                  Referral Reasons
    ClickText                   Go to Approval
    SwitchWindow                2
    VerifyText                  Approval Details
    ClickText                   Approve
    TypeText                    Comments                    Please Approve
    ClickText                   Approve                     anchor=Cancel
    SwitchBrowser               1
    RefreshPage
    VerifyElement               (//span[text()\='In Progress'])[1]
    Logout
    Home2
    Go To                       ${referred_submission_link}
    VerifyText                  Quote Details
    RefreshPage
    Enter Broker Commission
    Enter Expiration Date
    Scroll                      //html                      page_up
    ClickText                   Rate                        anchor=Finalize
    Sleep                       25s
    Click On Finalize
    Sleep                       20s
    Click Proceed To Bind
    Select first Quote
    Sleep                       30s
    ClickElement                //button[text()\='Bind']
    VerifyText                  Warning!
    ClickText                   Bind                        anchor=Cancel
    VerifyText                  Success                     anchor=Bind quote successfully!                    timeout=45s             partial_match= false
    #Click On Bind
    Change Policy               Full Amendment
    Full Amendment Input
    RefreshPage
    Click Rate After Amendment
    ClickText                   Finalize
    ClickElement                //button[text()\='Bind']
    VerifyText                  Warning!
    ClickText                   Bind                        anchor=Cancel
    VerifyText                  Success                     anchor=Bind quote successfully!                    timeout=45s             partial_match= false




Verify that the referral value over 20000000 is triggered for Engineer profession, when LargestOwnContractValueSize is over 20000000
    [Documentation]             Insured Info page
    [Tags]                      Regression_Test_Accountants                             Regression_Test
    # Author = Amol Gaymukhe
    #TC=120005
    Home2
    Creating a new Account
    Validate Aqueous New submission Fields
    VerifyText                  Underwriter Workbench
    #Validate field on Insured info
    Add Account name on Insured info page                   ${uniqueName}
    Click on save button
    ClickText                   NEXT:Submission Info >
    #Validate NewSubmission Init on Submission info page
    Select and add broker
    Select and add Profession                               Engineers
    Select and add Largest work type                        Arbitrator
    ClickText                   Next                        anchor=Cancel
    VerifyText                  Submission Info             anchor=*Submission Name
    ClickText                   NEXT:Underwriter Analysis >
    VerifyText                  Proposal Form Info
    #Validate Underwriter Analysis Fields
    #Add Details In Underwriter Analysis Page
    TypeText                    //span[text()\='Annual gross fees / turnover']/ancestor::tbody//input          100000
    TypeText                    //span[text()\='Largest own contract value size']/ancestor::table//input       20000005
    TypeText                    Professional Business Description                       20000000
    ClickElement                (//button[@class\='slds-button slds-button_icon slds-button_icon-container'])[2]
    ClickElement                (//c-work-type-analysis-section//lightning-primitive-input-checkbox)[6]
    ClickElement                //button[@title\='Add']
    Sleep                       10s
    TypeText                    //input[contains(@name,'_split')]                       100
    ClickText                   Save                        anchor=Check Risk Health
    VerifyText                  Success                     anchor=Update records successfully!                partial_match=false
    ClickText                   Check Risk Health
    ClickText                   New Primary Quote
    ClickText                   Rate                        anchor=Finalize             timeout=35
    ClickText                   Confirm                     anchor=Cancel
    Sleep                       45s
    ClickText                   Finalize
    VerifyElement               (//span[text()\='Referred'])[1]
    ${referred_submission_link}=                            GetUrl
    Log To Console              ${referred_submission_link}
    Set Global Variable         ${referred_submission_link}
    OpenBrowser                 ${login_url}                chrome
    Login
    Go To                       ${referred_submission_link}
    ClickElement                //lightning-icon[@title\='View Referral Reasons']
    VerifyText                  Referral Reasons
    ClickText                   Go to Approval
    SwitchWindow                2
    VerifyText                  Approval Details
    ClickText                   Approve
    TypeText                    Comments                    Please Approve
    ClickText                   Approve                     anchor=Cancel
    SwitchBrowser               1
    RefreshPage
    VerifyElement               (//span[text()\='In Progress'])[1]
    Logout
    Home2
    Go To                       ${referred_submission_link}
    RefreshPage
    VerifyText                  Quote Details
    ClickElement                //a[@data-value\='Underwritting Analysis']
    ${cur_date}=                Get Current Date            result_format=%-m/%d/%Y
    ${cur_date2}=               Get Current Date            result_format=%-m/%d/%Y
    Log To Console              ${cur_date}
    TypeText                    Proposal Form Date          ${cur_date2}
    ClickText                   Date of Last Full Proposal Form on file
    ClickText                   Save                        anchor=Check Risk Health

    ClickText                   //span[text()\='Quote Console']                         delay=5s
    Click On Endorsements and Subjectivities
    ClickText                   Subjectivities
    ClickElement                (//span[text()\='Show actions'])[last()]
    ClickText                   Delete                      anchor=Edit
    ClickText                   Yes                         anchor=No
    ClickText                   Return Quote Process
    Enter Broker Commission
    Enter Expiration Date
    Scroll                      //html                      page_up
    Sleep                       2s
    ClickText                   Rate                        anchor=Finalize
    Sleep                       20s
    ClickText                   Finalize                    anchor=Rate
    Click Proceed To Bind
    Select first Quote
    Sleep                       30s
    ClickElement                //button[text()\='Bind']
    VerifyText                  Success                     anchor=Bind quote successfully!                    timeout=45s             partial_match= false
    #Click On Bind
    Change Policy               Full Amendment
    Full Amendment Input
    RefreshPage
    Click Rate After Amendment
    ClickText                   Finalize
    ClickElement                //button[text()\='Bind']
    VerifyText                  Success                     anchor=Bind quote successfully!                    timeout=45s             partial_match= false


Verify that the referral value over 30000000 is triggered for All profession, when LargestOwnContractValueSize is over 3M for level 1 user
    [Documentation]             Insured Info page
    [Tags]                      Regression_Test_Accountants                             Regression_Test
    # Author = Amol Gaymukhe
    #TC=120006
    Home2
    Creating a new Account
    Validate Aqueous New submission Fields
    VerifyText                  Underwriter Workbench
    #Validate field on Insured info
    Add Account name on Insured info page                   ${uniqueName}
    Click on save button
    ClickText                   NEXT:Submission Info >
    #Validate NewSubmission Init on Submission info page
    Select and add broker
    Select and add Profession                               Engineers
    Select and add Largest work type                        Arbitrator
    ClickText                   Next                        anchor=Cancel
    VerifyText                  Submission Info             anchor=*Submission Name
    ClickText                   NEXT:Underwriter Analysis >
    VerifyText                  Proposal Form Info
    #Validate Underwriter Analysis Fields
    #Add Details In Underwriter Analysis Page
    ${cur_date}=                Get Current Date            result_format=%-m/%d/%Y
    ${cur_date2}=               Get Current Date            result_format=%-m/%d/%Y
    Log To Console              ${cur_date}
    TypeText                    Proposal Form Date          ${cur_date2}
    ClickText                   Date of Last Full Proposal Form on file
    TypeText                    //span[text()\='Annual gross fees / turnover']/ancestor::tbody//input          100000
    TypeText                    //span[text()\='Largest own contract value size']/ancestor::table//input       30000005
    TypeText                    Professional Business Description                       20000000
    ClickElement                (//button[@class\='slds-button slds-button_icon slds-button_icon-container'])[2]
    ClickElement                (//c-work-type-analysis-section//lightning-primitive-input-checkbox)[6]
    ClickElement                //button[@title\='Add']
    Sleep                       10s
    TypeText                    //input[contains(@name,'_split')]                       100
    ClickText                   Save                        anchor=Check Risk Health
    VerifyText                  Success                     anchor=Update records successfully!                partial_match=false
    ClickText                   Check Risk Health
    ClickText                   New Primary Quote
    VerifyText                  Policy Wording Document     timeout=45s
    ClickText                   Finalize
    VerifyElement               (//span[text()\='Referred'])[1]
    ${referred_submission_link}=                            GetUrl
    Log To Console              ${referred_submission_link}
    Set Global Variable         ${referred_submission_link}
    OpenBrowser                 ${login_url}                chrome
    Login
    Go To                       ${referred_submission_link}
    ClickElement                //lightning-icon[@title\='View Referral Reasons']
    VerifyText                  Referral Reasons
    ClickText                   Go to Approval
    SwitchWindow                2
    VerifyText                  Approval Details
    ClickText                   Approve
    TypeText                    Comments                    Please Approve
    ClickText                   Approve                     anchor=Cancel
    SwitchBrowser               1
    RefreshPage
    VerifyElement               (//span[text()\='In Progress'])[1]
    Logout
    Home2
    Go To                       ${referred_submission_link}
    VerifyText                  Quote Details
    RefreshPage
    Enter Broker Commission
    Enter Expiration Date
    Scroll                      //html                      page_up
    Sleep                       2s
    ClickText                   Rate                        anchor=Finalize
    Sleep                       20s
    Click On Finalize
    Click Proceed To Bind
    Select first Quote
    Sleep                       30s
    ClickElement                //button[text()\='Bind']
    VerifyText                  Warning!
    ClickText                   Bind                        anchor=Cancel
    VerifyText                  Success                     anchor=Bind quote successfully!                    timeout=45s             partial_match= false
    #Click On Bind
    Change Policy               Full Amendment
    Full Amendment Input
    RefreshPage
    Click Rate After Amendment
    ClickText                   Finalize
    ClickElement                //button[text()\='Bind']
    VerifyText                  Warning!
    ClickText                   Bind                        anchor=Cancel
    VerifyText                  Success                     anchor=Bind quote successfully!                    timeout=45s             partial_match= false

Verify that the referral value over 30000000 is triggered for Property professionals Architectural - refurbishment / non structural, when LargestTotalContractValueSize is over 30000000
    [Documentation]             Insured Info page
    [Tags]                      Regression_Test_Accountants                             Regression_Test
    # Author = Amol Gaymukhe
    #TC=120003
    Home2
    Creating a new Account
    Validate Aqueous New submission Fields
    VerifyText                  Underwriter Workbench
    #Validate field on Insured info
    Add Account name on Insured info page                   ${uniqueName}
    Click on save button
    ClickText                   NEXT:Submission Info >
    #Validate NewSubmission Init on Submission info page
    Select and add broker
    Select and add Profession                               Property Professionals
    Select and add Largest work type                        Adjudicator
    ClickText                   Next                        anchor=Cancel
    VerifyText                  Submission Info             anchor=*Submission Name
    ClickText                   NEXT:Underwriter Analysis >
    VerifyText                  Proposal Form Info
    #Validate Underwriter Analysis Fields
    Add Details In Underwriter Analysis Page
    TypeText                    //span[text()\='Largest own contract value size']/ancestor::table//input       30000005
    TypeText                    Professional Business Description                       20000000
    Sleep                       10s
    ClickText                   Save                        anchor=Check Risk Health
    VerifyText                  Success                     anchor=Update records successfully!                partial_match=false
    ClickText                   Check Risk Health
    ClickText                   New Primary Quote
    VerifyText                  Policy Wording Document     timeout=45s
    ClickText                   Finalize
    VerifyElement               (//span[text()\='Referred'])[1]
    ${referred_submission_link}=                            GetUrl
    Log To Console              ${referred_submission_link}
    Set Global Variable         ${referred_submission_link}
    OpenBrowser                 ${login_url}                chrome
    Login
    Go To                       ${referred_submission_link}
    ClickElement                //lightning-icon[@title\='View Referral Reasons']
    VerifyText                  Referral Reasons
    ClickText                   Go to Approval
    SwitchWindow                2
    VerifyText                  Approval Details
    ClickText                   Approve
    TypeText                    Comments                    Please Approve
    ClickText                   Approve                     anchor=Cancel
    SwitchBrowser               1
    RefreshPage
    VerifyElement               (//span[text()\='In Progress'])[1]
    Logout
    Home2
    Go To                       ${referred_submission_link}
    VerifyText                  Quote Details
    RefreshPage
    Enter Broker Commission
    Enter Expiration Date
    Scroll                      //html                      page_up
    Sleep                       2s
    ClickText                   Rate                        anchor=Finalize
    Sleep                       20s
    Click On Finalize
    Sleep                       20s
    Click Proceed To Bind
    Select first Quote
    Sleep                       30s
    ClickElement                //button[text()\='Bind']
    VerifyText                  Warning!
    ClickText                   Bind                        anchor=Cancel
    VerifyText                  Success                     anchor=Bind quote successfully!                    timeout=45s             partial_match= false
    #Click On Bind
    Change Policy               Full Amendment
    Full Amendment Input
    RefreshPage
    Click Rate After Amendment
    ClickText                   Finalize
    ClickElement                //button[text()\='Bind']    timeout=45s
    VerifyText                  Warning!
    ClickText                   Bind                        anchor=Cancel
    VerifyText                  Success                     anchor=Bind quote successfully!                    timeout=45s             partial_match= false
