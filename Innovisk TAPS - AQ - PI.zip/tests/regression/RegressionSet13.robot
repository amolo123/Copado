*** Settings ***
Library                         QWeb
Library                         QForce
#Library                        QVision
Library                         FakerLibrary
Library                         String
Library                         BuiltIn
Library                         DateTime
Resource                        ../../resources/common.robot
Resource                        ../../resources/ReadPDF.robot
Resource                        ../../PageObjects/PageObjects_Account.robot
#Resource                       ../PageObjects/PageObjects_HomePage.robot
Resource                        ../../PageObjects/PageObjects_Submission.robot
Resource                        ../../PageObjects/PageObjects_InsuredInfo.robot
Resource                        ../../PageObjects/PageObjects_SubmissionInit.robot
Library                         RetryFailed                 global_retries=${retry_count}
Suite Setup                     Setup Browser
Suite Teardown                  CloseAllBrowsers
Resource                        ../../resources/common.robot
Resource                        ../../PageObjects/PageObjects_SubmissionInfo.robot
Resource                        ../../PageObjects/PageObjects_UnderwriterAnalysis.robot
Resource                        ../../PageObjects/PageObjects_QuoteConsole.robot
Resource                        ../../PageObjects/PageObjects_PreBindPage.robot
Resource                        ../../PageObjects/PageObjects_PolicyPage.robot
Resource                        ../../PageObjects/PageObjects_SendEmail.robot
Resource                        ../../PageObjects/PageObjects_EndToEnd.robot

*** Test Cases ***
Verify that new endorsement AQUW229 is available under the list of endorsement for Primary quote(Accountant profession)
    [Tags]                      Regression_Test_Accountants                             Regression_Test
    [Documentation]             Endorsement Qoute console
    # Author = Amol
    #TC=122471,
    Creating a new Account
    Validate Aqueous New submission Fields
    VerifyText                  Underwriter Workbench
    #Validate field on Insured info
    Add Account name on Insured info page                   ${uniqueName}
    Click on save button
    ClickText                   NEXT:Submission Info >
    #Validate NewSubmission Init on Submission info page
    Select and add broker
    Select and add Profession                               Accountants
    Select and add Largest work type                        General Accounting
    ClickText                   Next                        anchor=Cancel
    VerifyText                  Submission Info             anchor=*Submission Name
    ClickText                   NEXT:Underwriter Analysis >
    VerifyText                  Proposal Form Info
    #Validate Underwriter Analysis Fields
    Add Details In Underwriter Analysis Page
    ClickText                   Check Risk Health
    ClickText                   New Primary Quote
    Click On Endorsements and Subjectivities
    Select Endorsement AQUW229                              AQUW229
    ClickElement                //a[text()\='Total Bodily Injury Exclusion']
    SwitchWindow                2
    SwitchWindow                1
    ClickText                   Return Quote Process
    Click Rate After Amendment
    Sleep                       20s
    ClickText                   Finalize
    Sleep                       25s
    ClickText                   Proceed to Bind
    Select first Quote
    Sleep                       20s
    Click On Bind
    ClickText                   Related
    ClickText                   PolicySchedulePrimary
    Sleep                       15s
    ClickText                   View Document
    Move to outputdir
    Test PDF File               AQUW229
    Test PDF File               Total Bodily Injury Exclusion



Verify that new endorsement AQUW229 is available under the list of endorsement for Primary quote(Design and Construct)
    [Tags]                      Regression_Test_Accountants                             Regression_Test
    [Documentation]             Endorsement Qoute console
    # Author = Amol
    #TC=122472,
    Creating a new Account
    Validate Aqueous New submission Fields
    VerifyText                  Underwriter Workbench
    Add Account name on Insured info page                   ${uniqueName}
    Click on save button
    ClickText                   NEXT:Submission Info >
    Select and add broker
    Select and add Profession                               Design & Construct
    Select and add Largest work type                        Electrical Engineering
    ClickText                   Next                        anchor=Cancel
    VerifyText                  Submission Info             anchor=*Submission Name
    ClickText                   NEXT:Underwriter Analysis >
    Add Proposal date
    TypeText                    Annual gross fees / turnover - change                   40000
    Add Split Percentage
    TypeText                    All other turnover          100
    Save Details and check risk health
    ClickText                   New Primary Quote
    Sleep                       30s
    Click On Endorsements and Subjectivities
    Select Endorsement AQUW229                              AQUW229
    ClickElement                //a[text()\='Total Bodily Injury Exclusion']
    SwitchWindow                2
    SwitchWindow                1
    ClickText                   Return Quote Process
    Click Rate After Amendment
    Sleep                       20s
    ClickText                   Finalize
    Sleep                       25s
    ClickText                   Proceed to Bind
    Select first Quote
    Sleep                       20s
    Click On Bind
    ClickText                   Related
    ClickText                   PolicySchedulePrimary
    Sleep                       15s
    ClickText                   View Document
    Move to outputdir
    Test PDF File               AQUW229
    Test PDF File               Total Bodily Injury Exclusion

Verify that new endorsement AQUW229 is available under the list of endorsement for Primary quote(Property Professional)
    [Tags]                      Regression_Test_Accountants                             Regression_Test
    [Documentation]             Endorsement Qoute console
    # Author = Amol
    #TC=122473,
    Creating a new Account
    Validate Aqueous New submission Fields
    VerifyText                  Underwriter Workbench
    Add Account name on Insured info page                   ${uniqueName}
    Click on save button
    ClickText                   NEXT:Submission Info >
    Select and add broker
    Select and add Profession                               Design & Construct
    Select and add Largest work type                        Electrical Engineering
    ClickText                   Next                        anchor=Cancel
    VerifyText                  Submission Info             anchor=*Submission Name
    ClickText                   NEXT:Underwriter Analysis >
    Add Proposal date
    TypeText                    Annual gross fees / turnover - change                   40000
    Add Split Percentage
    TypeText                    All other turnover          100
    Save Details and check risk health
    ClickText                   New Primary Quote
    Sleep                       30s
    Click On Endorsements and Subjectivities
    Select Endorsement AQUW229                              AQUW229
    ClickElement                //a[text()\='Total Bodily Injury Exclusion']
    SwitchWindow                2
    SwitchWindow                1
    ClickText                   Return Quote Process
    Click Rate After Amendment
    Sleep                       20s
    ClickText                   Finalize
    Sleep                       25s
    ClickText                   Proceed to Bind
    Select first Quote
    Sleep                       20s
    Click On Bind
    ClickText                   Related
    ClickText                   PolicySchedulePrimary
    Sleep                       15s
    ClickText                   View Document
    Move to outputdir
    Test PDF File               AQUW229
    Test PDF File               Total Bodily Injury Exclusion

Verify that new endorsement AQUW229 is available under the list of endorsement for Primary quote(Architects )
    [Tags]                      Regression_Test_Accountants                             Regression_Test
    [Documentation]             Endorsement Qoute console
    # Author = Pinki Lubana
    #TC=122475,
    Creating a new Account
    Validate Aqueous New submission Fields
    VerifyText                  Underwriter Workbench
    #Validate field on Insured info
    Add Account name on Insured info page                   ${uniqueName}
    Click on save button
    ClickText                   NEXT:Submission Info >
    #Validate NewSubmission Init on Submission info page
    Select and add broker
    Select and add Profession                               Architects
    Select and add Largest work type                        Electrical Engineering
    ClickText                   Next                        anchor=Cancel
    VerifyText                  Submission Info             anchor=*Submission Name
    ClickText                   NEXT:Underwriter Analysis >
    Add Proposal date
    TypeText                    Annual gross fees / turnover - change                   40000
    Add Split Percentage
    Save Details and check risk health
    ClickText                   New Primary Quote
    Sleep                       30s
    Click On Endorsements and Subjectivities
    Select Endorsement AQUW229                              AQUW229
    ClickElement                //a[text()\='Total Bodily Injury Exclusion']
    SwitchWindow                2
    SwitchWindow                1
    ClickText                   Return Quote Process
    Click Rate After Amendment
    Sleep                       20s
    ClickText                   Finalize
    Sleep                       25s
    ClickText                   Proceed to Bind
    Select first Quote
    Sleep                       20s
    Click On Bind
    ClickText                   Related
    ClickText                   PolicySchedulePrimary
    Sleep                       15s
    ClickText                   View Document
    Move to outputdir
    Test PDF File               AQUW229
    Test PDF File               Total Bodily Injury Exclusion
