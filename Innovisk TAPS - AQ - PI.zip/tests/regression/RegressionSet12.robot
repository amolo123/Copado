*** Settings ***
Library                         QWeb
Library                         QForce
#Library                        QVision
Library                         FakerLibrary
Library                         String
Library                         BuiltIn
Library                         DateTime
Resource                        ../../resources/common.robot
Resource                        ../../resources/ReadPDF.robot
Resource                        ../../PageObjects/PageObjects_Account.robot
#Resource                       ../PageObjects/PageObjects_HomePage.robot
Resource                        ../../PageObjects/PageObjects_Submission.robot
Resource                        ../../PageObjects/PageObjects_InsuredInfo.robot
Resource                        ../../PageObjects/PageObjects_SubmissionInit.robot
Library                         RetryFailed                 global_retries=${retry_count}
Suite Setup                     Setup Browser
Suite Teardown                  CloseAllBrowsers
Resource                        ../../resources/common.robot
Resource                        ../../PageObjects/PageObjects_SubmissionInfo.robot
Resource                        ../../PageObjects/PageObjects_UnderwriterAnalysis.robot
Resource                        ../../PageObjects/PageObjects_QuoteConsole.robot
Resource                        ../../PageObjects/PageObjects_PreBindPage.robot
Resource                        ../../PageObjects/PageObjects_PolicyPage.robot
Resource                        ../../PageObjects/PageObjects_SendEmail.robot
Resource                        ../../PageObjects/PageObjects_EndToEnd.robot

*** Test Cases ***
Verify that Excess main binder is showing as "2025 Binder: Jun - May" for all Professions with inception date 1st june 2025
    [Documentation]             Quote Console page
    [Tags]                      Regression_Test_Accountants                             Regression_Test
    # Author = Pinki Lubana
    #TC=120481
    Creating a new Account
    Validate Aqueous New submission Fields
    VerifyText                  Underwriter Workbench
    #Validate field on Insured info
    Add Account name on Insured info page                   ${uniqueName}
    Click on save button
    ClickText                   NEXT:Submission Info >
    #Validate NewSubmission Init on Submission info page
    Select and add broker
    Select and add Profession                               Accountants
    Select and add Largest work type                        Directorships
    ClickText                   Next                        anchor=Cancel
    VerifyText                  Submission Info             anchor=*Submission Name
    ClickText                   NEXT:Underwriter Analysis >
    VerifyText                  Proposal Form Info
    Add Details In Underwriter Analysis Page
    ClickText                   Check Risk Health
    ClickText                   New Excess Quote
    Select Binder Name          Binder
    Sleep                       30s
    VerifyText                  Quote Details
    Binder Name Inception Date
    Enter Details in Layer
    Click On Rate
    Click On Finalize
    Sleep                       20s
    Generate Document
    Click Proceed To Bind
    Sleep                       15s
    Select first Quote
    Sleep                       20s
    Click On Bind
    ClickText                   Related                     anchor=Details
    Select Policy from PolicyPage

Verify that GAIC binder is showing as "2025 GAIC Excess Binder: Jun - May" for all Professions with inception date 1st june 2025
    [Documentation]             Quote Console page
    [Tags]                      Regression_Test_Accountants                             Regression_Test
    # Author = Pinki Lubana
    #TC=120477
    Creating a new Account
    Validate Aqueous New submission Fields
    VerifyText                  Underwriter Workbench
    #Validate field on Insured info
    Add Account name on Insured info page                   ${uniqueName}
    Click on save button
    ClickText                   NEXT:Submission Info >
    #Validate NewSubmission Init on Submission info page
    Select and add broker
    Select and add Profession                               Architects
    Select and add Largest work type                        Electrical Engineering
    ClickText                   Next                        anchor=Cancel
    VerifyText                  Submission Info             anchor=*Submission Name
    ClickText                   NEXT:Underwriter Analysis >
    Add Proposal date
    TypeText                    Annual gross fees / turnover - change                   40000
    Add Split Percentage
    Save Details and check risk health
    ClickText                   New Excess Quote
    Select Binder Name          GAIC
    Sleep                       30s
    VerifyText                  Quote Details
    Binder Name Inception Date
    Enter Details in Layer
    Click On Rate
    Click On Finalize
    Sleep                       20s
    Generate Document
    Click Proceed To Bind
    Sleep                       15s
    Select first Quote
    Sleep                       20s
    Click On Bind
    ClickText                   Related                     anchor=Details
    Select Policy from PolicyPage

Verify that XOL binder is showing as "2025 XOL Excess Binder: Jun - May" for all Professions with inception date 1st june 2025
    [Documentation]             Quote Console page
    [Tags]                      Regression_Test_Accountants                             Regression_Test
    # Author = Pinki Lubana
    #TC=120478
   Creating a new Account
    Validate Aqueous New submission Fields
    VerifyText                  Underwriter Workbench
    Add Account name on Insured info page                   ${uniqueName}
    Click on save button
    ClickText                   NEXT:Submission Info >
    Select and add broker
    Select and add Profession                               Engineers
    Select and add Largest work type                        Electrical Engineering
    ClickText                   Next                        anchor=Cancel
    VerifyText                  Submission Info             anchor=*Submission Name
    ClickText                   NEXT:Underwriter Analysis >
    Add Proposal date
    TypeText                    Annual gross fees / turnover - change                   40000
    Add Split Percentage
    Save Details and check risk health
     ClickText                   New Excess Quote
    Select Binder Name          XOL
    Sleep                       30s
    VerifyText                  Quote Details
    Binder Name Inception Date
    Enter Details in Layer
    Click On Rate
    Click On Finalize
    Sleep                       20s
    Generate Document
    Click Proceed To Bind
    Sleep                       15s
    Select first Quote
    Sleep                       20s
    Click On Bind
    ClickText                   Related                     anchor=Details
    Select Policy from PolicyPage


Verify that Primary main binder is showing as "2025 Binder: Jun - May" for all Professions with inception date 1st june 2025
    [Documentation]             Quote Console page
    [Tags]                      Regression_Test_Accountants                             Regression_Test
    # Author = Pinki Lubana
    #TC=120476
    Creating a new Account
    Validate Aqueous New submission Fields
    VerifyText                  Underwriter Workbench
    Add Account name on Insured info page                   ${uniqueName}
    Click on save button
    ClickText                   NEXT:Submission Info >
    Select and add broker
    Select and add Profession                               Design & Construct
    Select and add Largest work type                        Electrical Engineering
    ClickText                   Next                        anchor=Cancel
    VerifyText                  Submission Info             anchor=*Submission Name
    ClickText                   NEXT:Underwriter Analysis >
    Add Proposal date
    TypeText                    Annual gross fees / turnover - change                   40000
    Add Split Percentage
    TypeText                    All other turnover          100
    Save Details and check risk health
    ClickText                   New Primary Quote
    Sleep                       30s
    VerifyText                  Quote Details
    Binder Name Inception Date
    Click On Rate
    Click On Finalize
    Sleep                       20s
    Generate Document
    Click Proceed To Bind
    Sleep                       15s
    Select first Quote
    Sleep                       20s
    Click On Bind
    ClickText                   Related                     anchor=Details
    Select Policy from PolicyPage

Verify that Solicitors binder is showing as "2025 Solicitors Binder: Jun - May" for Solicitors Professions with inception date 1st june 2025
    [Documentation]             Quote Console page
    [Tags]                      Regression_Test_Accountants                             Regression_Test
    # Author = Pinki Lubana
    #TC=120479
    Creating a new Account
    Validate Aqueous New submission Fields
    VerifyText                  Underwriter Workbench
    Add Account name on Insured info page                   ${uniqueName}
    Click on save button
    ClickText                   NEXT:Submission Info >
    Select and add broker
    Select and add Profession                               Solicitors
    Select and add Largest work type                        Arbitration
    ClickText                   Next                        anchor=Cancel
    VerifyText                  Submission Info             anchor=*Submission Name
    ClickText                   NEXT:Underwriter Analysis >
    Add Proposal date
    Dynamic element of Solicitors
    Add Split Percentage
    Save Details and check risk health
    ClickText                   New Excess Quote
    Select Binder Name          Solicitors
    Sleep                       30s
    VerifyText                  Quote Details
    Binder Name Inception Date
    Enter Details in Layer
    Click On Finalize
    Sleep                       20s
    Click Proceed To Bind
    Sleep                       15s
    Select first Quote
    Sleep                       20s
    Click On Bind
    ClickText                   Related                     anchor=Details
    Select Policy from PolicyPage


Verify that GA AmTrust Solicitor Binde is showing as "2025 GA AmTrust Solicitors Binder June - May" for Solicitors Professions with inception date 1st june 2025
    [Documentation]             Quote Console page
    [Tags]                      Regression_Test_Accountants                             Regression_Test
    # Author = Pinki Lubana
    #TC=120480
    Creating a new Account
    Validate Aqueous New submission Fields
    VerifyText                  Underwriter Workbench
    Add Account name on Insured info page                   ${uniqueName}
    Click on save button
    ClickText                   NEXT:Submission Info >
    Select and add broker
    Select and add Profession                               Solicitors
    Select and add Largest work type                        Arbitration
    ClickText                   Next                        anchor=Cancel
    VerifyText                  Submission Info             anchor=*Submission Name
    ClickText                   NEXT:Underwriter Analysis >
    Add Proposal date
    Dynamic element of Solicitors
    Add Split Percentage
    Save Details and check risk health
    ClickText                   New Excess Quote
    Select Binder Name          Solicitors GA AmTrust
    Sleep                       30s
    VerifyText                  Quote Details
    Binder Name Inception Date
    Enter Details in Layer
    Click On Finalize
    Sleep                       20s
    Click Proceed To Bind
    Sleep                       15s
    Select first Quote
    Sleep                       20s
    Click On Bind
    ClickText                   Related                     anchor=Details
    Select Policy from PolicyPage