*** Settings ***
Library                         QWeb
Library                         QForce
#Library                        QVision
Library                         FakerLibrary
Library                         String
Library                         BuiltIn
Library                         DateTime
Resource                        ../../resources/common.robot
Resource                        ../../resources/ReadPDF.robot
Resource                        ../../PageObjects/PageObjects_Account.robot
#Resource                       ../PageObjects/PageObjects_HomePage.robot
Resource                        ../../PageObjects/PageObjects_Submission.robot
Resource                        ../../PageObjects/PageObjects_InsuredInfo.robot
Resource                        ../../PageObjects/PageObjects_SubmissionInit.robot
Library                         RetryFailed                 global_retries=${retry_count}
Suite Setup                     Setup Browser
Suite Teardown                  CloseAllBrowsers
Resource                        ../../resources/common.robot
Resource                        ../../PageObjects/PageObjects_SubmissionInfo.robot
Resource                        ../../PageObjects/PageObjects_UnderwriterAnalysis.robot
Resource                        ../../PageObjects/PageObjects_QuoteConsole.robot
Resource                        ../../PageObjects/PageObjects_PreBindPage.robot
Resource                        ../../PageObjects/PageObjects_PolicyPage.robot
Resource                        ../../PageObjects/PageObjects_SendEmail.robot

*** Test Cases ***
Verify that the on Amenedments submission , policy is created and proper values and details are displayed in Policy details page and policy documents
    #Author= Amol Gaymukhe
    #TC=78968
    [Documentation]             On Amenedments submission , policy is created and proper values and details are displaye
    [Tags]                      Regression_Test_Accountants                             Regression_Test
    Creating a new Account
    Validate Aqueous New submission Fields
    VerifyText                  Underwriter Workbench
    #Validate field on Insured info
    Add Account name on Insured info page                   ${uniqueName}
    Click on save button
    ClickText                   NEXT:Submission Info >
    #Validate NewSubmission Init on Submission info page
    Select and add broker
    Select and add Profession                               Accountants
    Select and add Largest work type                        Directorships
    ClickText                   Next                        anchor=Cancel
    VerifyText                  Submission Info             anchor=*Submission Name
    ClickText                   NEXT:Underwriter Analysis >
    VerifyText                  Proposal Form Info
    #Validate Underwriter Analysis Fields
    Add Details In Underwriter Analysis Page
    ClickText                   Check Risk Health
    ClickText                   New Primary Quote
    Sleep                       30s
    VerifyText                  Quote Details
    Enter Broker Commission
    Click On Rate
    Create New Excess Quote     Binder
    Verify After Creating Excess
    Enter Broker Commission
    Enter Expiration Date
    Click On Rate
    Click on First Quote with xpath
    Sleep                       20s
    Click On Finalize
    Sleep                       20s
    #Generate Document
    Click Proceed To Bind
    Select first Quote
    Sleep                       25s
    Click On Bind
    VerifyText                  Policy Details
    ClickText                   Related                     anchor=Details
    Click On Submission
    Click On First Excess Quote with xpath
    Enter Details in Layer
    Enter Expiration Date
    Click On Rate
    Click On Finalize
    Click Proceed To Bind
    Select first Quote
    Sleep                       20s
    Click On Bind
    Change Policy               Full Amendment
    Full Amendment Input
    VerifyText                  Quote Details
    RefreshPage
    Click Rate After Amendment
    Click On Finalize
    Sleep                       25s
    Click On Bind
    ClickText                   Related                     anchor=Details
    Select Amendment Policy from PolicyPage
    Sleep                       15s
    Move to outputdir
    ${curr_date}=               Get Current Date            result_format=%-d %B %Y
    Log To Console              ${curr_date}
    Test PDF File               ${curr_date}
    Test PDF File               Acquisition
    Test PDF File               £0.00
    GetUrl

Verify that the documents are attached, when an email is sent on Mid Term/Flat Cancellation policies
    #Author= Amol Gaymukhe
    #TC=78970
    [Documentation]             documents are attached, when an email is sent on Mid Term/Flat Cancellation policies
    [Tags]                      Regression_Test_Accountants                             Regression_Test
    Creating a new Account
    Validate Aqueous New submission Fields
    VerifyText                  Underwriter Workbench
    #Validate field on Insured info
    Add Account name on Insured info page                   ${uniqueName}
    Click on save button
    ClickText                   NEXT:Submission Info >
    #Validate NewSubmission Init on Submission info page
    Select and add broker
    Select and add Profession                               Accountants
    Select and add Largest work type                        Directorships
    ClickText                   Next                        anchor=Cancel
    VerifyText                  Submission Info             anchor=*Submission Name
    ClickText                   NEXT:Underwriter Analysis >
    VerifyText                  Proposal Form Info
    #Validate Underwriter Analysis Fields
    Add Details In Underwriter Analysis Page
    ClickText                   Check Risk Health
    ClickText                   New Primary Quote
    Sleep                       30s
    VerifyText                  Quote Details
    Enter Broker Commission
    Click On Rate
    Click On Finalize
    Sleep                       20s
    #Generate Document
    Click Proceed To Bind
    Select first Quote
    Sleep                       25s
    Click On Bind
    Change Policy               Flat Cancellation
    Flat Cancellation Input
    Click on First Quote with xpath
    Click On Bind
    Sleep                       30 sec
    Send Mail On Submission Page                            Bind Cancellation Email-Primary

Verify that the Quote status is changed to In-progress from Rated/Quoted when a broker is changed on a Submission
    [Tags]                      Regression_Test_Accountants                             Regression_Test
    [Documentation]             Insured Info page
    # Author = Amol Gaymukhe
    #TC=78971
    Creating a new Account
    Validate Aqueous New submission Fields
    VerifyText                  Underwriter Workbench
    #Validate field on Insured info
    Add Account name on Insured info page                   ${uniqueName}
    Click on save button
    ClickText                   NEXT:Submission Info >
    #Validate NewSubmission Init on Submission info page
    Select and add broker
    Select and add Profession                               Accountants
    Select and add Largest work type                        Directorships
    ClickText                   Next                        anchor=Cancel
    VerifyText                  Submission Info             anchor=*Submission Name
    ClickText                   NEXT:Underwriter Analysis >
    VerifyText                  Proposal Form Info
    #Validate Underwriter Analysis Fields
    Add Details In Underwriter Analysis Page
    ClickText                   Check Risk Health
    ClickText                   New Primary Quote
    Sleep                       30s
    VerifyText                  Quote Details
    Create New Excess Quote     Binder
    Verify After Creating Excess
    Enter Details in Layer
    Click On Finalize
    ClickText                   Submission Info
    Sleep                       20s
    Change Broker               Pinki Broker
    ClickText                   Quote Console
    RefreshPage
    VerifyElement               //lightning-badge/span[text()\='In Progress']
    Click On First Excess Quote with xpath
    Sleep                       5s
    VerifyElement               //lightning-badge/span[text()\='In Progress']


