*** Settings ***
Library                         QWeb
Library                         QForce
#Library                        QVision
Library                         FakerLibrary
Library                         String
Library                         BuiltIn
Library                         DateTime
Resource                        ../../resources/common.robot
Resource                        ../../resources/ReadPDF.robot
Resource                        ../../PageObjects/PageObjects_Account.robot
#Resource                       ../PageObjects/PageObjects_HomePage.robot
Resource                        ../../PageObjects/PageObjects_Submission.robot
Resource                        ../../PageObjects/PageObjects_InsuredInfo.robot
Resource                        ../../PageObjects/PageObjects_SubmissionInit.robot
Library                         RetryFailed                 global_retries=${retry_count}
Suite Setup                     Setup Browser
Suite Teardown                  CloseAllBrowsers
Resource                        ../../resources/common.robot
Resource                        ../../PageObjects/PageObjects_SubmissionInfo.robot
Resource                        ../../PageObjects/PageObjects_UnderwriterAnalysis.robot
Resource                        ../../PageObjects/PageObjects_QuoteConsole.robot
Resource                        ../../PageObjects/PageObjects_PreBindPage.robot
Resource                        ../../PageObjects/PageObjects_PolicyPage.robot
Resource                        ../../PageObjects/PageObjects_SendEmail.robot

*** Test Cases ***
Verify that the validation message is displayed when the quote is binded without Primary Broker
    [Tags]                      Regression_Test_Accountants                             Regression_Test
    [Documentation]             Insured Info page
    # Author = Amol
    #TC=78972
    Creating a new Account
    Validate Aqueous New submission Fields
    VerifyText                  Underwriter Workbench
    #Validate field on Insured info
    Add Account name on Insured info page                   ${uniqueName}
    Click on save button
    ClickText                   NEXT:Submission Info >
    #Validate NewSubmission Init on Submission info page
    Select and add broker
    Select and add Profession                               Accountants
    Select and add Largest work type                        Directorships
    ClickText                   Next                        anchor=Cancel
    VerifyText                  Submission Info             anchor=*Submission Name
    ClickText                   NEXT:Underwriter Analysis >
    VerifyText                  Proposal Form Info
    #Validate Underwriter Analysis Fields
    Add Details In Underwriter Analysis Page
    ClickText                   Check Risk Health
    ClickText                   New Primary Quote
    Sleep                       30s
    VerifyText                  Quote Details
    Create New Excess Quote     Binder
    Verify After Creating Excess
    ClickText                   Submission Info
    Delete Broker
    ClickText                   Quote Console
    ClickElement                (//button[text()\='Rate'])[1]
    Verifytext                  Warning                     anchor=Primary Broker is Required          timeout=45s

Verify that the Quote status changes to Rated on overidding fees for the 1st time on Amendments
    #Author= Amol Gaymukhe
    #TC=78973
    [Documentation]             On Amenedments submission , policy is created and proper values and details are displaye
    [Tags]                      Regression_Test_Accountants                             Regression_Test
    Creating a new Account
    Validate Aqueous New submission Fields
    VerifyText                  Underwriter Workbench
    #Validate field on Insured info
    Add Account name on Insured info page                   ${uniqueName}
    Click on save button
    ClickText                   NEXT:Submission Info >
    #Validate NewSubmission Init on Submission info page
    Select and add broker
    Select and add Profession                               Accountants
    Select and add Largest work type                        Directorships
    ClickText                   Next                        anchor=Cancel
    VerifyText                  Submission Info             anchor=*Submission Name
    ClickText                   NEXT:Underwriter Analysis >
    VerifyText                  Proposal Form Info
    #Validate Underwriter Analysis Fields
    Add Details In Underwriter Analysis Page
    ClickText                   Check Risk Health
    ClickText                   New Primary Quote
    Sleep                       30s
    VerifyText                  Quote Details
    Enter Broker Commission
    Enter Expiration Date
    Click On Rate
    Click On Finalize
    Sleep                       20s
    Generate Document
    Click Proceed To Bind
    Select first Quote
    Sleep                       30s
    Click On Bind
    Change Policy               Full Amendment
    Full Amendment Input
    RefreshPage
    Click Rate After Amendment
    Select Fee and check Rated state


Verify that the Broker Commission% is properly calculated when the BNDP is reduced to exclude the broker commission
    #Author= Amol Gaymukhe
    #TC=78975
    [Documentation]             On Amenedments submission , policy is created and proper values and details are displaye
    [Tags]                      Regression_Test_Accountants                             Regression_Test
    Creating a new Account
    Validate Aqueous New submission Fields
    VerifyText                  Underwriter Workbench
    #Validate field on Insured info
    Add Account name on Insured info page                   ${uniqueName}
    Click on save button
    ClickText                   NEXT:Submission Info >
    #Validate NewSubmission Init on Submission info page
    Select and add broker
    Select and add Profession                               Accountants
    Select and add Largest work type                        Directorships
    ClickText                   Next                        anchor=Cancel
    VerifyText                  Submission Info             anchor=*Submission Name
    ClickText                   NEXT:Underwriter Analysis >
    VerifyText                  Proposal Form Info
    #Validate Underwriter Analysis Fields
    Add Details In Underwriter Analysis Page
    ClickText                   Check Risk Health
    ClickText                   New Excess Quote
    Select Binder Name          Binder
    Sleep                       30s
    VerifyText                  Quote Details
    #Enter Broker Commission
    Enter Expiration Date
    Enter Details in Layer
    Click On Rate
    Sleep                       20s
    Click On Finalize
    Generate Document
    ClickElement                //a[contains(text(),'QuoteSchedule')]
    Sleep                       15s
    Move to outputdir
    Test PDF File               Commission
    Test PDF File               0.00%


Verify that the MGA commission % is reset to correct value for GAIC/XOL binders
    #Author= Amol Gaymukhe
    #TC=78983
    [Documentation]             On Amenedments submission , policy is created and proper values and details are displaye
    [Tags]                      Regression_Test_Accountants                             Regression_Test
    Creating a new Account
    Validate Aqueous New submission Fields
    VerifyText                  Underwriter Workbench
    #Validate field on Insured info
    Add Account name on Insured info page                   ${uniqueName}
    Click on save button
    ClickText                   NEXT:Submission Info >
    #Validate NewSubmission Init on Submission info page
    Select and add broker
    Select and add Profession                               Accountants
    Select and add Largest work type                        Directorships
    ClickText                   Next                        anchor=Cancel
    VerifyText                  Submission Info             anchor=*Submission Name
    ClickText                   NEXT:Underwriter Analysis >
    VerifyText                  Proposal Form Info
    #Validate Underwriter Analysis Fields
    Add Details In Underwriter Analysis Page
    ClickText                   Check Risk Health
    ClickText                   New Excess Quote
    Select Binder Name          Binder
    Sleep                       30s
    VerifyText                  Quote Details
    #Enter Broker Commission
    Enter Details in Layer
    #Enter Expiration Date
    Select Date From Calendar
    TypeText                    MGA Commission %            44
    Click On Rate
    Click On Finalize
    Click Proceed To Bind
    Select first Quote
    Sleep                       15s
    Click On Bind
    ClickElement                //button[text()\='Renew']
    Sleep                       30sec
    # Select Excess Binder On Policy                        XOL
    ClickElement                //button[text()\='New Excess Quote']
    ClickElement                (//span[text()\='Select Item 3']/parent::*)
    ClickElement                //button[text()\='Proceed to Quote']
    Sleep                       15s
    Verify MGA change
