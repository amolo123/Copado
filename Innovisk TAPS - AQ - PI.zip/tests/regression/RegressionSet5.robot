*** Settings ***
Library                         QWeb
Library                         QForce
#Library                        QVision
Library                         FakerLibrary
Library                         String
Library                         BuiltIn
Library                         DateTime
Resource                        ../../resources/common.robot
Resource                        ../../resources/ReadPDF.robot
Resource                        ../../PageObjects/PageObjects_Account.robot
#Resource                       ../PageObjects/PageObjects_HomePage.robot
Resource                        ../../PageObjects/PageObjects_Submission.robot
Resource                        ../../PageObjects/PageObjects_InsuredInfo.robot
Resource                        ../../PageObjects/PageObjects_SubmissionInit.robot
Library                         RetryFailed                 global_retries=${retry_count}
Suite Setup                     Setup Browser
Suite Teardown                  CloseAllBrowsers
Resource                        ../../resources/common.robot
Resource                        ../../PageObjects/PageObjects_SubmissionInfo.robot
Resource                        ../../PageObjects/PageObjects_UnderwriterAnalysis.robot
Resource                        ../../PageObjects/PageObjects_QuoteConsole.robot
Resource                        ../../PageObjects/PageObjects_PreBindPage.robot
Resource                        ../../PageObjects/PageObjects_PolicyPage.robot
Resource                        ../../PageObjects/PageObjects_SendEmail.robot

*** Test Cases ***
Verify that the status of an referral is changed to in progress when, changes are made in Splits table values
    [Tags]                      Regression_Test_Accountants                             Regression_Test
    [Documentation]             Insured Info page
    # Author = Amol
    #TC=78990
    Home2
    Creating a new Account
    Validate Aqueous New submission Fields
    VerifyText                  Underwriter Workbench
    #Validate field on Insured info
    Add Account name on Insured info page                   ${uniqueName}
    Click on save button
    ClickText                   NEXT:Submission Info >
    #Validate NewSubmission Init on Submission info page
    Select and add broker
    Select and add Profession                               Accountants
    Select and add Largest work type                        Mergers, Acquisitions, Disposals, Take-overs or Corporate Finance
    ClickText                   Next                        anchor=Cancel
    VerifyText                  Submission Info             anchor=*Submission Name
    ClickText                   NEXT:Underwriter Analysis >
    VerifyText                  Proposal Form Info
    #Validate Underwriter Analysis Fields
    Add Details On Underwriter
    Select Split                15
    ClickText                   Check Risk Health
    ClickText                   New Primary Quote
    Sleep                       25s
    VerifyText                  Quote Details
    ClickElement                (//button[text()\='Finalize'])[1]
    VerifyElement               (//span[text()\='Referred'])[1]
    ${referred_submission_link}=                            GetUrl
    Log To Console              ${referred_submission_link}
    Set Global Variable         ${referred_submission_link}
    OpenBrowser                 ${login_url}                chrome
    Login
    Go To                       ${referred_submission_link}
    ClickElement                //lightning-icon[@title\='View Referral Reasons']
    VerifyText                  Referral Reasons
    ClickText                   Go to Approval
    SwitchWindow                2
    VerifyText                  Approval Details
    ClickText                   Approve
    TypeText                    Comments                    Please Approve
    ClickText                   Approve                     anchor=Cancel
    SwitchBrowser               1
    RefreshPage
    VerifyElement               (//span[text()\='In Progress'])[1]
    Logout

Verify that in XOL Binder - Referral Reason for Actual Premium less than 85% of Technical Premium is displayed 
    [Tags]                      Regression_Test_Accountants                             Regression_Test
    [Documentation]             Insured Info page
    # Author = Amol
    #TC=78990
    Home2
    Creating a new Account
    Validate Aqueous New submission Fields
    VerifyText                  Underwriter Workbench
    #Validate field on Insured info
    Add Account name on Insured info page                   ${uniqueName}
    Click on save button
    ClickText                   NEXT:Submission Info >
    #Validate NewSubmission Init on Submission info page
    Select and add broker
    Select and add Profession                               Accountants
    Select and add Largest work type                        Mergers, Acquisitions, Disposals, Take-overs or Corporate Finance
    ClickText                   Next                        anchor=Cancel
    VerifyText                  Submission Info             anchor=*Submission Name
    ClickText                   NEXT:Underwriter Analysis >
    VerifyText                  Proposal Form Info
    #Validate Underwriter Analysis Fields
    Add Details In Underwriter Analysis Page
    ClickText                   Check Risk Health
    ClickText                   New Excess Quote
    Select Binder Name          XOL
    sleep                       25 sec
    VerifyText                  Quote Details
    Enter Expiration Date
    Enter Details in Layer
    Enter Final AP to reduce PA
    Click Rate After Amendment
    ClickElement                (//button[text()\='Finalize'])[1]
    VerifyElement               (//span[text()\='Referred'])[1]
    Logout

Verify that the user is able to approve refferal request with level 1    
    [Tags]                      Regression_Test_Accountants                             Regression_Test
    [Documentation]             Insured Info page
    # Author = Amol
    #TC=78990
    Home2
    Creating a new Account
    Validate Aqueous New submission Fields
    VerifyText                  Underwriter Workbench
    #Validate field on Insured info
    Add Account name on Insured info page                   ${uniqueName}
    Click on save button
    ClickText                   NEXT:Submission Info >
    #Validate NewSubmission Init on Submission info page
    Select and add broker
    Select and add Profession                               Accountants
    Select and add Largest work type                        Mergers, Acquisitions, Disposals, Take-overs or Corporate Finance
    ClickText                   Next                        anchor=Cancel
    VerifyText                  Submission Info             anchor=*Submission Name
    ClickText                   NEXT:Underwriter Analysis >
    VerifyText                  Proposal Form Info
    Add Details In Underwriter Analysis Page
    ClickText                   Check Risk Health
    ClickText                   New Excess Quote
    Select Binder Name          GAIC
    VerifyText                  Quote Details
    Enter Expiration Date
    Enter Details in Layer
    Enter Final AP to reduce PA
    # ClickText                 Save                        anchor=Cancel
    Click Rate After Amendment
    ClickText                   Finalize
    VerifyElement               (//span[text()\='Referred'])[1]
    ${referred_submission_link}=                            GetUrl
    Log To Console              ${referred_submission_link}
    Set Global Variable         ${referred_submission_link}
    OpenBrowser                 ${login_url}                chrome
    Login
    Go To                       ${referred_submission_link}
    ClickElement                //lightning-icon[@title\='View Referral Reasons']
    VerifyText                  Referral Reasons
    ClickText                   Go to Approval
    SwitchWindow                2
    VerifyText                  Approval Details
    ClickText                   Approve
    TypeText                    Comments                    Please Approve
    ClickText                   Approve                     anchor=Cancel
    SwitchBrowser               1
    RefreshPage
    VerifyElement               (//span[text()\='In Progress'])[1]
    Logout

Verify that the refferal message is displayed , when user logged in with L1 User and Fire protection consultant work type split percentage is 26%(Should not auto approved)
    [Tags]                      Regression_Test_Miscellaneous                           Regression_Test
    [Documentation]             Insured Info page
    # Author = Amol
    #TC=78990
    Creating a new Account
    Validate Aqueous New submission Fields
    VerifyText                  Underwriter Workbench
    #Validate field on Insured info
    Add Account name on Insured info page                   ${uniqueName}
    Click on save button
    ClickText                   NEXT:Submission Info >
    #Validate NewSubmission Init on Submission info page
    Select and add broker
    Select and add Profession                               Miscellaneous
    Select and add Largest work type                        Adjudicator
    ClickText                   Next                        anchor=Cancel
    VerifyText                  Submission Info             anchor=*Submission Name
    ClickText                   NEXT:Underwriter Analysis >
    VerifyText                  Proposal Form Info
    TypeText                    Annual gross fees / turnover - change                   50000
    TypeText                    Professional Business Description                       Test Description
    ClickElement                (//button[@class\='slds-button slds-button_icon slds-button_icon-container'])[2]
    ClickElement                //div[text()\='Fire protection consultant']/parent::*/preceding-sibling::td
    ClickElement                //div[text()\='Adjudicator']/parent::*/preceding-sibling::td
    ClickElement                //button[@title\='Add']
    TypeText                    (//input[contains(@name,'_split')])[1]                  26
    TypeText                    (//input[contains(@name,'_split')])[2]                  74
    ClickText                   Check Risk Health
    ClickText                   New Primary Quote
    Sleep                       30 sec
    VerifyText                  Quote Details
    ClickElement                (//button[text()\='Finalize'])[1]
    VerifyElement               (//span[text()\='Referred'])[1]
    Logout