*** Settings ***
Library                         QWeb
Library                         QForce
#Library                        QVision
Library                         FakerLibrary
Library                         String
Library                         BuiltIn
Library                         DateTime
Resource                        ../resources/common.robot
Resource                        ../PageObjects/PageObjects_Account.robot
#Resource                       ../PageObjects/PageObjects_HomePage.robot
Resource                        ../PageObjects/PageObjects_Submission.robot
Resource                        ../PageObjects/PageObjects_InsuredInfo.robot
Resource                        ../PageObjects/PageObjects_SubmissionInit.robot
Library                         RetryFailed                 global_retries=${retry_count}
Suite Setup                     Setup Browser
Suite Teardown                  CloseAllBrowsers
Resource                        ../resources/common.robot
Resource                        ../PageObjects/PageObjects_SubmissionInfo.robot
Resource                        ../PageObjects/PageObjects_UnderwriterAnalysis.robot
Resource                        ../PageObjects/PageObjects_QuoteConsole.robot
Resource                        ../PageObjects/PageObjects_PreBindPage.robot
Resource                        ../PageObjects/PageObjects_PolicyPage.robot
Resource                        ../PageObjects/PageObjects_SendEmail.robot
Library                         ../../libraries/MailLib.py                              ${tenant_id}         ${client_id_mail}        ${client_secret_mail}

Library                         ../libraries/graph.py
Resource                        ../resources/graph.resource

*** Test Cases ***

Send Email On Policy Page
    #Author=Amol Gaymukhe
    [Documentation]             Send Email Functionality
    [Tags]                      Smoke_Test
    Creating a new Account
    Validate Aqueous New submission Fields
    VerifyText                  Underwriter Workbench
    #Validate field on Insured info
    Add Account name on Insured info page                   ${uniqueName}
    Click on save button
    ClickText                   NEXT:Submission Info >
    #Validate NewSubmission Init on Submission info page
    Select and add broker
    Select and add Profession                               Accountants
    Select and add Largest work type                        Directorships
    ClickText                   Next                        anchor=Cancel
    VerifyText                  Submission Info             anchor=*Submission Name
    ClickText                   NEXT:Underwriter Analysis >
    VerifyText                  Proposal Form Info
    #Validate Underwriter Analysis Fields
    Add Details In Underwriter Analysis Page
    ClickText                   Check Risk Health
    ClickText                   New Primary Quote
    Sleep                       30s
    VerifyText                  Quote Details
    Enter Broker Commission
    Enter Expiration Date
    Click On Rate
    Click On Finalize
    Sleep                       20s
    Generate Document
    Click Proceed To Bind
    Select first Quote
    Sleep                       15s
    Click On Bind
    Send Mail On Submission Page                            Bind Email Primary
    Send Mail On Submission Page                            Generic Email
