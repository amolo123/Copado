*** Settings ***
Library                         QWeb
Library                         QForce
#Library                        QVision
Library                         FakerLibrary
Library                         String
Library                         BuiltIn
Library                         DateTime
Resource                        ../resources/common.robot
Resource                        ../PageObjects/PageObjects_Account.robot

*** Keywords ***
Validate field on Insured info
    #Author= Saurabh
    [tags]                      InsuredInfo

    VerifyText                  Insured Name
    VerifyText                  Insured Address
    VerifyText                  Country
    VerifyText                  County
    Verifytext                  Street
    VerifyText                  City
    VerifyText                  Province
    VerifyText                  PostalCode
    VerifyText                  KYC Status
    VerifyText                  Sanction Status
    VerifyText                  Sanction Date
    VerifyText                  SIC Industry Code
    VerifyText                  SIC Industry Description
    VerifyText                  Credit Score
    VerifyText                  Rating Reason
    VerifyText                  Number Of Directors
    VerifyText                  Date Business Established
    VerifyText                  Group Size
    VerifyText                  Net Worth
    VerifyText                  Latest Financials Net Income
    VerifyText                  Total Revenues
    VerifyText                  Total Assets
    VerifyText                  Current Liabilities
    VerifyText                  otal Liabilities
    VerifyText                  Save
    VerifyText                  Create D&B Account
    VerifyText                  NEXT:Submission Info >
    Log To Console              ----- Insured Info Page Elements Varified Successfully -----
    Log To Console              ----- Insured Info Page Elements Varified Successfully -----
Add Account name on Insured info page 
    #Author= Saurabh
    [tags]                      InsuredInfo
    [Arguments]                 ${AccountName}                 

    VerifyText                  Insured Name                timeout=120s
    ClickElement                (//input[@placeholder\="Search..."])[1]
    TypeText                  Search...                   ${AccountName}    anchor=Insured Name
    ClickElement                (//li[@role\='presentation']/span)[1]
    Log To Console              ----- Insured Info page Add Account Verified Successfully -----