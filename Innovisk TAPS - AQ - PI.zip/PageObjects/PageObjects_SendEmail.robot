*** Settings ***
Library                    QWeb
Library                    QForce
#Library                   QVision
Library                    FakerLibrary
Library                    String
Library                    BuiltIn
Library                    DateTime
Resource                   ../resources/common.robot
Resource                   ../PageObjects/PageObjects_Account.robot
Resource                   ../PageObjects/PageObjects_InsuredInfo.robot

Library                    ../libraries/MailLib.py                       ${tenant_id}             ${client_id_mail}        ${client_secret_mail}

Library                    ../libraries/graph.py
Resource                   ../resources/graph.resource


*** Keywords ***

Send Mail On Submission Page
    #Author=Amol
    [Documentation]        Sending Mail From Submission Page
    [Tags]                 Validating
    [Arguments]            ${Mailtype}
    ClickText              Send Email
    UseModal               On
    ClickElement           //select
    # #ClickText           Binder Transmittal
    IF                     "${Mailtype}"=="Bind Email Primary"
        DropDown           Select a Template:          [[1]]
    ELSE IF                "${Mailtype}"=="Generic Email"
        DropDown           Select a Template:          [[2]]
    ELSE IF                "${Mailtype}"=="Bind Cancellation Email-Primary"
        DropDown           Select a Template:          [[1]]
        VerifyElement      //a[text()\='Reset File']/parent::div[contains(text(),'PolicyCancelScheduleFlat')]
    ELSE IF                "${Mailtype}"=="Quote Email Excess"
        DropDown           Select a Template:          [[3]]
        VerifyElement      //a[text()\='Reset File']/parent::div[contains(text(),'QuoteScheduleExcess')]
    END
    ${subjectline}=        GetInputValue               Subject:             timeout=45s
    Log To Console         ${subjectline}
    Set Global Variable    ${subjectline}
    ClickText              Send                        anchor=Cancel
    Sleep                  40s
    ${body}=               Get Email Content           ${client_id_mail}    ${client_secret_mail}    ${tenant_id}             QA.Testing.Inbox@innovisk.global              ${subjectline}
    #Log To Console        ${body}
    Set Global Variable    ${body}
    Log To Console         --------Send Email for ${Mailtype} is successfull------