*** Settings ***
Library                         QWeb
Library                         QForce
#Library                        QVision
Library                         FakerLibrary
Library                         String
Library                         BuiltIn
Library                         DateTime
Resource                        ../resources/common.robot
Resource                        ../PageObjects/PageObjects_Account.robot
Resource                        ../PageObjects/PageObjects_InsuredInfo.robot

*** Keywords ***
Validate Pre Bind Page
    #Author=Amol gaymukhe
    [Documentation]    Validate Page Elements
    VerifyText    ${uniqueName}
    VerifyText    Pre Bind Quote Options
    VerifyText    Limit    
    VerifyText    MP    
    VerifyText    Annual BP     
    VerifyText    Annual TP    
    VerifyText    Annual AP    
    VerifyText    Annual BNDP    
    VerifyText    Annual Fee    
    VerifyText    TPD%    
    VerifyText    FD%    
    VerifyText    PA%    
    VerifyText    Final AP    
    VerifyText    Final BNDP    
    VerifyText    Final Fee

    VerifyText    Back to Quote
    VerifyText    Bind

Select first Quote
    #Author=Amol gaymukhe
    [Documentation]    Click On Bind
    ClickElement          //span[text()\='Select Item 1']
    Sleep                 15s

Click On Bind
    #Author=Amol gaymukhe
    [Documentation]    Click On Bind
    ClickElement       //button[text()\='Bind']
    VerifyText         Success    anchor=Bind quote successfully!         timeout=45s    partial_match= false

