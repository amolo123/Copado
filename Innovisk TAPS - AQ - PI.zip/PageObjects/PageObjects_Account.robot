*** Settings ***
Library                         QWeb
Library                         QForce
#Library                        QVision
Library                         FakerLibrary
Library                         String
Library                         BuiltIn
Library                         DateTime
Resource                        ../resources/common.robot



*** Keywords ***
Account click
    # Author = Pinki
    [tags]                      Contacts
    ClickText                   Accounts
    VerifyText                  Recently Viewed             anchor=span                 timeout=40s
    Log To Console              ------Account Clicked Successfully-------

Validate new Account record fields
    # Author = Pinki
    [tags]                      ContactTypes
    ClickText                   Accounts
    VerifyText                  Recently Viewed             anchor=span                 timeout=40s
    ClickText                   New
    UseModal                    On
    VerifyText                  Busisness
    VerifyText                  Broker
    VerifyText                  Insurance Company
    Log To Console              ------Account fields verified Successfully-------


Validate account form fields
    # Author = Pinki
    [tags]                      Verify Account Fields
    Home
    ClickText                   Accounts
    VerifyText                  Recently Viewed             anchor=Accounts                timeout=40s
    ClickElement                //*[text()\='New']
    UseModal                    On
    VerifyText                  Business
    VerifyText                  Broker
    VerifyText                  Insurance Company
    # ClickText                   Busines
    ClickText                   Next                        partial_match=off
    VerifyText                  Account Name
    VerifyText                  Website
    VerifyText                  Account Owner
    VerifyText                  Account Record Type
    VerifyText                  Parent Account
    VerifyText                  Phone
    VerifyText                  Renewal Warning
    VerifyText                  Renewal Warning Reason
    VerifyText                  Account Currency
    VerifyText                  FEIN
    VerifyText                  Billing Address
    VerifyText                  Billing Country
    VerifyText                  Billing Street
    VerifyText                  Billing City
    VerifyText                  Billing State/Province
    VerifyText                  Billing Zip/Postal Code
    VerifyText                  KYC Status
    VerifyText                  Sanction Status
    VerifyText                  Sanction Date
    VerifyText                  Review Note
    Verify Text                 Review Requested
    Verify Text                 Reviewed By
    Verify Text                 Review Requested By
    Verify Text                 Reviewed On
    Verify Text                 Decline Reason
    VerifyText                  SIC Code
    VerifyText                  SIC Description
    VerifyText                  Number Of Directors
    VerifyText                  Credit Score
    VerifyText                  Group Size
    VerifyText                  Net Income
    VerifyText                  Total Assets
    VerifyText                  Total Liabilities
    VerifyText                  Net Worth
    VerifyText                  Date Started
    VerifyText                  Rating Reason
    VerifyText                  Cancel                      partial_match=false
    VerifyText                  Save & New                  partial_match=false
    VerifyText                  Save                        partial_match=false

    Log To Console              ------Account Form Fields Validated Successfully-------
    VerifyAttribute             //label[text()\='Account Name']/parent::div//input      type                   text
    VerifyAttribute             //label[text()\='Account Name']/parent::div//input      maxlength              255
    VerifyAttribute             //label[text()\='Website']/parent::div//input           type                   text
    VerifyAttribute             //label[text()\='Website']/parent::div//input           maxlength              255
    VerifyAttribute             //label[text()\='Phone']/parent::div//input             type                   text
    VerifyAttribute             //label[text()\='Phone']/parent::div//input             maxlength              40
    VerifyAttribute             //label[text()\='FEIN']/parent::div//input              type                   text
    VerifyAttribute             //label[text()\='FEIN']/parent::div//input              maxlength              30
    VerifyAttribute             //button[@aria-label\='Account Currency']               aria-haspopup          listbox
    VerifyAttribute             //label[text()\='Renewal Warning Reason']/parent::lightning-textarea//div/textarea         maxlength        131072
    VerifyAttribute             //label[text()\='Renewal Warning Reason']/parent::lightning-textarea//div/textarea         type             textarea
    VerifyAttribute             //label[text()\='Parent Account']/parent::lightning-grouped-combobox//div/input            maxlength        255
    VerifyAttribute             //label[text()\='Parent Account']/parent::lightning-grouped-combobox//div/input            type             text
    VerifyAttribute             //label[text()\='Billing Street']/parent::lightning-textarea//textarea         maxlength        255
    VerifyAttribute             //label[text()\='Billing Street']/parent::lightning-textarea//textarea         type        textarea
    VerifyAttribute             //label[text()\='Billing City']/parent::div//input      maxlength              40
    VerifyAttribute             //label[text()\='Billing City']/parent::div//input      type                   text
    VerifyAttribute             //label[text()\='Billing Zip/Postal Code']/parent::div//input                  maxlength        20
    VerifyAttribute             //label[text()\='Billing Zip/Postal Code']/parent::div//input                  type        text
    VerifyAttribute             //label[text()\='Rating Reason']/parent::lightning-textarea//div/textarea      maxlength        32768
    VerifyAttribute             //label[text()\='Rating Reason']/parent::lightning-textarea//div/textarea      type        textarea
    # Could Not find Max Length
    VerifyAttribute             (//legend[text()\='Billing Address']/parent::fieldset//div/input)[1]           role        combobox         anchor=1
    VerifyAttribute             (//legend[text()\='Billing Address']/parent::fieldset//div/input)[1]           type        text             anchor=1
    VerifyAttribute             //label[text()\='Billing Country']/parent::div//input                          role        combobox
    VerifyAttribute             //label[text()\='Billing Country']/parent::div//input                          type        text
    VerifyAttribute             //label[text()\='Billing State/Province']/parent::div//input                   role        combobox
    VerifyAttribute             //label[text()\='Billing State/Province']/parent::div//input                   type        text
    VerifyElement               //span[text()\='Renewal Warning']


    Log To Console              ------Account Form Buttons Validated Successfully -------

Validate New submission
    # Author = Pinki
    [Documentation]             Checking LawyerGuard
    [tags]                      All
    Home
    ClickElement                //button[@class\='slds-button slds-show']
    TypeText                    //input[@placeholder\='Search apps and items...']       Lawyer
    ClickText                   LawyerGuard
    VerifyText                  LawyerGuard                 anchor=Home
    VerifyText                  New Submission
    VerifyText                  Existing Submission
    VerifyText                  Post Bind Endorsement
    ClickText                   Next
    
    ${RR}                       Istext                      Record Type
    Log To Console              ${RR}
    IF                          "${RR}" == "False"
        Log                     Enter Product Selection from My Submmision popup.
        ClickText               Submissions                 anchor=Quote
        Sleep                   5s
        ClickElement            //button[text()\="New"]
    END


    UseModal                    On
    VerifyText                  New Submission
    VerifyText                  Record Type
    ClickText                   LawyerGuard                 anchor=Record Type
    VerifyText                  Product
    ClickText                   LawyerGuard                 anchor=Product
    ClickText                   Next                        anchor=Cancel
    Log To Console              ------New Submission Elements Validated Successfully -------


Creating a new Account
    # Author = Pinki
    [tags]                      Account
    Home
    ClickText                   Accounts
    VerifyText                  Recently Viewed             anchor=Accounts                 timeout=40s
    ClickElement               //*[text()\='New']

    UseModal                    On
    # VerifyText                  New Account
    # ClickText                   Business
    # Log To Console              Buisness Clicked
    ClickText                   Next                        anchor=span                 timeout=20s
    Log To Console              ------New Buisness Account Clicked-------


    ## Entering data in the Account
    ${currTime}=                Get Current Date            result_format=%-d%-m%Y%-H%f
    ${name1}=                   Name Male
    Set Global Variable         ${name1}
    ${random_email}=            Set Variable                ${name1}@gmail.com
    Set Global Variable         ${random_email}
    ${uniqueName}=              Set Variable                ${name1}${currTime}
    Set Global Variable         ${uniqueName}
    Log To Console              ${uniqueName}
    ${pdf_insuredname}=         Set Variable                ${uniqueName}
    Set Global Variable         ${pdf_insuredname}
    ${currency}=                Set Variable                GBP - British Pound
    Set Global Variable         ${currency}
    ${parentaccount}=           Set Variable                Test AQ3
    Set Global Variable         ${parentaccount}
    ${phone}=                   Generate Random String      10                          [NUMBERS]
    Log To Console              ${phone}
    Set Global Variable         ${phone}
    ${fein}=                    Generate Random String      10                          [NUMBERS]
    Log To Console              ${fein}
    Set Global Variable         ${fein}
    ${renewal_warning_reason}=                              Generate Random String      255
    Log To Console              ${renewal_warning_reason}
    Set Global Variable         ${renewal_warning_reason}
    ${billingaddress}=          Set Variable                60 Asfordby Street
    Set Global Variable         ${billingaddress}
    ${rating_reason}=           Generate Random String      255
    Log To Console              ${rating_reason}
    Set Global Variable         ${rating_reason}
    ${account_owner}=           Set Variable                Copado-AQPI, Automation-user
    Set Global Variable         ${account_owner}
    # ${currdate}=                Get Current Date            result_format=%-m/%d/%Y
    # Log To Console              ${currdate}

    #${accrecordtype}=          Set Variable                Business
    #Set Global Variable        ${accrecordtype}

    Log To Console              ------Global Variables Saved Successfully-------

    VerifyText                  Account Name
    TypeText                    Account Name                ${uniqueName}
    TypeText                    Website                     ${random_email}
    PickList                    Account Currency            ${currency}
    TypeText                    Phone                       ${phone}
    TypeText                    FEIN                        ${fein}
    TypeText                    Renewal Warning Reason      ${renewal_warning_reason}
    TypeText                    Billing Address             ${billingaddress}
    ClickText                   60 Asfordby Street
    # TypeText                    Date Started                ${currdate}
    TypeText                    Rating Reason               ${rating_reason}
    ClickText                   Save                        partial_match=false
    UseModal                    Off
    # VerifyField               Account Record Type         ${accrecordtype}
    #VerifyField                Account Owner               ${account_owner}
    #VerifyField                Account Record Type         ${accrecordtype}


    Log To Console              ------New Account Created Successfully-------

Verify Account Created Fields
    # Author = Pinki
    [Tags]                      VerifyAccount
    Home
    Account click
    VerifyText                  Recently Viewed             timeout=120s
    VerifyText                  ${uniqueName}               anchor=Details
    ClickText                   ${uniqueName}               anchor=Details
    VerifyField                 Account Name                ${uniqueName}
    #VerifyField                Account Record Type         Business
    VerifyField                 Website                     ${random_email}

    #phone no validation
    ${pno}=                     GetFieldValue               Phone
    ${pno1}=                    Remove String               ${pno}                      -                      (           )    ${SPACE}
    Log To Console              ${pno1}
    ${phone2}=                  Remove String               ${phone}                    -                      (           )    ${SPACE}
    IF                          '${phone2}' == '${pno1}'
        Log To Console          Success
    ELSE
        Fail                    Assertion Failed
    END
    Log Screenshot

    #Verifying address
    ${Address}=                 Set Variable                60 Asfordby StreetLeicester, LE5 3QGUnited Kingdom
    ${sf_address}=              GetFieldValue               Billing Address
    Log To Console              ${sf_address}
    ${words}=                   Remove String               ${sf_address}               \n
    Log To Console              ${words}
    IF                          '${Address}' == '${words}'
        Log To Console          Success
    ELSE
        Fail                    Assertion Failed
    END
    Log Screenshot

    Log To Console              ------New Account Created Fields Validated Successfully-------

Validate Account Elements
    # Author = Pinki
    [Tags]                      VerifyAccount
    Home
    ClickText                   Accounts
    VerifyText                  Recently Viewed             anchor=Accounts
    ClickText                   ${uniqueName}
    # ClickElement                (//a[@data-refid\='recordId'])[1]
    # ClickElement                (//table//tr//a)[10]
    VerifyText                  Details
    VerifyText                  Account Product             anchor=Details
    VerifyText                  Insurance Items             anchor=Details
    VerifyText                  Related                     anchor=Details
    VerifyText                  Claims                      anchor=Details
    VerifyText                  Account History             anchor=Details              partial_match=false
    VerifyText                  Sanction                    anchor=Details
    VerifyText                  Follow
    VerifyText                  Edit
    VerifyText                  New Note
    VerifyText                  Update D&B

    Log To Console              ------ Account Page Elements Validated Successfully-------

Editing the Account    
    # Author = Pinki
    [Tags]                      EditingAccount
    [Documentation]             Editing Account
    Home
    ClickText                   Accounts
    VerifyText                  Recently Viewed             anchor=Accounts
    ClickText                   ${uniqueName}
    # ClickElement                (//a[@data-refid\='recordId'])[1]
    ClickText                     Show more actions         anchor=${uniqueName}
    Sleep                         2s
    ClickElement                //button[text()\='Edit'][1]
    # ClickText                     Edit                      anchor=Delete

    Log To Console              ------ Edit Button Clicked on Account Successfully-------
    UseModal                    On
    #TypeText                   Account Name                A
    PressKey                    Account Name                {CONTROL + A + DELETE}
    PressKey                    Website                     {CONTROL + A + DELETE}
    PressKey                    Phone                       {CONTROL + A + DELETE}
    PressKey                    FEIN                        {CONTROL + A + DELETE}
    PressKey                    Renewal Warning Reason      {CONTROL + A + DELETE}
    PressKey                    Billing Street              {CONTROL + A + DELETE}
    PressKey                    Billing City                {CONTROL + A + DELETE}
    PressKey                    Billing Zip/Postal Code     {CONTROL + A + DELETE}
    PressKey                    Date Started                {CONTROL + A + DELETE}
    #VerifyText                 Parent Account
    PressKey                    Rating Reason               {CONTROL + A + DELETE}

    Log To Console              ------ Account Fields Cleared Successfully-------

    ${currTime}=                Get Current Date            result_format=%-d%-m%Y%-H%f
    ${name2}=                   Name Male
    ${uniquename1}=             Set Variable                ${name2}${currTime}
    Set Global Variable         ${uniquename1}
    ${random_email}=            Set Variable                ${name2}@gmail.com
    ${currency}=                Set Variable                GBP - British Pound
    Set Global Variable         ${currency}
    ${parentaccount}=           Set Variable                Test AQ3
    Set Global Variable         ${parentaccount}
    ${phone}=                   Generate Random String      10                          [NUMBERS]
    Log To Console              ${phone}
    Set Global Variable         ${phone}
    ${fein}=                    Generate Random String      10                          [NUMBERS]
    Log To Console              ${fein}
    Set Global Variable         ${fein}
    ${renewal_warning_reason}=                              Generate Random String      255
    Log To Console              ${renewal_warning_reason}
    Set Global Variable         ${renewal_warning_reason}
    ${billingaddress}=          Set Variable                60 Asfordby Place
    Set Global Variable         ${billingaddress}
    ${rating_reason}=           Generate Random String      255
    Log To Console              ${rating_reason}
    Set Global Variable         ${rating_reason}
    ${account_owner}=           Set Variable                Copado-AQPI, Automation-user
    Set Global Variable         ${account_owner}
    ${currdate}=                Get Current Date            result_format=%m/%d/%Y
    Log To Console              ${currdate}

    TypeText                    Account Name                ${uniquename1}
    TypeText                    Website                     ${random_email}
    TypeText                    Phone                       ${phone}
    TypeText                    FEIN                        ${fein}
    TypeText                    Renewal Warning Reason      ${renewal_warning_reason}
    TypeText                    Billing Address             ${billingaddress}
    ClickText                   60 Asfordby Place
    TypeText                    Date Started                ${currdate}
    TypeText                    Rating Reason               ${rating_reason}
    Log Screenshot
    ClickText                   Save                        partial_match=false
    UseModal                    Off

    Log To Console              ------ New Field Values Added and Record Saved Successfully-------
    Log Screenshot



Delete Account Click   
    # Author = Pinki
    [Tags]                      Delete Account
    Home
    ClickText                   Accounts
    VerifyText                  Recently Viewed             anchor=Accounts
    # ClickElement                (//a[@data-refid\='recordId'])[1]
    # ClickElement                (//table//tr//a)[10]
    ClickElement                (//span[text()\='Show more actions']/parent::button)[1]
    ClickElement                //span[text()\='Delete']/parent::a
    ClickText                   Delete                      anchor=Cancel
    Log To Console              ------ Account Deleted -------


Creating a new Account with Save and new
    # Author = Pinki
    [tags]                      Account
    Home
    ClickText                   Accounts
    VerifyText                  Recently Viewed             anchor=Accounts                 timeout=40s
    ClickElement                //*[text()\='New']

    UseModal                    On
    VerifyText                  New Account
    # ClickText                   Business
    # Log To Console              Buisness Clicked
    ClickText                   Next                        anchor=span                 timeout=20s

    Log To Console              ------ Navigated to Account -------

    ## Entering data in the Account
    ${currTime}=                Get Current Date            result_format=%-d%-m%Y%-H%f
    ${name1}=                   Name Male
    Set Global Variable         ${name1}
    ${random_email}=            Set Variable                ${name1}@gmail.com
    Set Global Variable         ${random_email}
    ${uniqueName}=              Set Variable                ${name1}${currTime}
    Set Global Variable         ${uniqueName}
    Log To Console              ${uniqueName}
    ${pdf_insuredname}=         Set Variable                ${uniqueName}
    Set Global Variable         ${pdf_insuredname}
    ${currency}=                Set Variable                GBP - British Pound
    Set Global Variable         ${currency}
    ${parentaccount}=           Set Variable                Test AQ3
    Set Global Variable         ${parentaccount}
    ${phone}=                   Generate Random String      10                          [NUMBERS]
    Log To Console              ${phone}
    Set Global Variable         ${phone}
    ${fein}=                    Generate Random String      10                          [NUMBERS]
    Log To Console              ${fein}
    Set Global Variable         ${fein}
    ${renewal_warning_reason}=                              Generate Random String      255
    Log To Console              ${renewal_warning_reason}
    Set Global Variable         ${renewal_warning_reason}
    ${billingaddress}=          Set Variable                60 Asfordby Street
    Set Global Variable         ${billingaddress}
    ${rating_reason}=           Generate Random String      255
    Log To Console              ${rating_reason}
    Set Global Variable         ${rating_reason}
    ${account_owner}=           Set Variable                Copado-AQPI, Automation-user
    Set Global Variable         ${account_owner}
    ${currdate}=                Get Current Date            result_format=%m/%d/%Y
    Log To Console              ${currdate}

    #${accrecordtype}=          Set Variable                Business
    #Set Global Variable        ${accrecordtype}

    Log To Console              ------ Global Variabled are Set -------

    VerifyText                  Account Name
    TypeText                    Account Name                ${uniqueName}
    TypeText                    Website                     ${random_email}
    PickList                    Account Currency            ${currency}
    TypeText                    Phone                       ${phone}
    TypeText                    FEIN                        ${fein}
    TypeText                    Renewal Warning Reason      ${renewal_warning_reason}
    TypeText                    Billing Address             ${billingaddress}
    ClickText                   60 Asfordby Street
    TypeText                    Date Started                ${currdate}
    TypeText                    Rating Reason               ${rating_reason}
    ClickText                   Save & New                  partial_match=false

    Log To Console              ------ Account Fileds Entered and Account is Saved Variabled are Set -------

    UseModal                    On
    VerifyText                  New Account
    # ClickText                   Business
    # Log To Console              Buisness Clicked
    ClickText                   Next                        anchor=span                 timeout=20s

    Log To Console              ------ Save and New Clicked -------

    ## Entering data in the Account
    ${currTime}=                Get Current Date            result_format=%-d%-m%Y%-H%f
    ${namesaveandnew1}=         Name Male
    Set Global Variable         ${namesaveandnew1}
    ${random_email}=            Set Variable                ${namesaveandnew1}@gmail.com
    Set Global Variable         ${random_email}
    ${uniqueName2}=             Set Variable                ${namesaveandnew1}${currTime}
    Log To Console              ${uniqueName2}
    Set Global Variable         ${uniqueName2}
    ${currency}=                Set Variable                GBP - British Pound
    Set Global Variable         ${currency}
    ${parentaccount}=           Set Variable                Test AQ3
    Set Global Variable         ${parentaccount}
    ${phone}=                   Generate Random String      10                          [NUMBERS]
    Log To Console              ${phone}
    Set Global Variable         ${phone}
    ${fein}=                    Generate Random String      10                          [NUMBERS]
    Log To Console              ${fein}
    Set Global Variable         ${fein}
    ${renewal_warning_reason}=                              Generate Random String      255
    Log To Console              ${renewal_warning_reason}
    Set Global Variable         ${renewal_warning_reason}
    ${billingaddress}=          Set Variable                60 Asfordby Street
    Set Global Variable         ${billingaddress}
    ${rating_reason}=           Generate Random String      255
    Log To Console              ${rating_reason}
    Set Global Variable         ${rating_reason}
    ${account_owner}=           Set Variable                Copado-AQPI, Automation-user
    Set Global Variable         ${account_owner}
    ${currdate}=                Get Current Date            result_format=%m/%d/%Y
    Log To Console              ${currdate}


    Log To Console              ------ Global Variabled Set -------

    TypeText                    Account Name                ${uniqueName2}
    TypeText                    Website                     ${random_email}
    PickList                    Account Currency            ${currency}
    TypeText                    Phone                       ${phone}
    TypeText                    FEIN                        ${fein}
    TypeText                    Renewal Warning Reason      ${renewal_warning_reason}
    TypeText                    Billing Address             ${billingaddress}
    ClickText                   60 Asfordby Street
    TypeText                    Date Started                ${currdate}
    TypeText                    Rating Reason               ${rating_reason}
    ClickText                   Save                        partial_match=false
    Log To Console              ------ Second Account Creted Successfully -------

    UseModal                    Off
    ClickText                   Accounts
    VerifyText                  Recently Viewed             anchor=span
    VerifyText                  ${uniquename}
    VerifyText                  ${uniqueName2}
    Log To Console              ------ Both Created Accounts Are Validated -------

Creation of Account Cancel 
    # Author = Pinki
    [tags]                      Account
    Home
    ClickText                   Accounts
    VerifyText                  Recently Viewed             anchor=Accounts                 timeout=40s
    ClickElement                //*[text()\='New']

    UseModal                    On
    VerifyText                  New Account
    # ClickText                   Business
    # Log To Console              Buisness Clicked
    ClickText                   Next                        anchor=span                 timeout=20s

    Log To Console              ------ Creating Global Variables -------
    ## Entering data in the Account
    ${currTime}=                Get Current Date            result_format=%-d%-m%Y%-H%f
    ${name1}=                   Name Male
    Set Global Variable         ${name1}
    ${random_email}=            Set Variable                ${name1}@gmail.com
    Set Global Variable         ${random_email}
    ${uniqueName}=              Set Variable                ${name1}${currTime}
    Set Global Variable         ${uniqueName}
    ${currency}=                Set Variable                GBP - British Pound
    Set Global Variable         ${currency}
    ${parentaccount}=           Set Variable                Test AQ3
    Set Global Variable         ${parentaccount}
    ${phone}=                   Generate Random String      10                          [NUMBERS]
    Log To Console              ${phone}
    Set Global Variable         ${phone}
    ${fein}=                    Generate Random String      10                          [NUMBERS]
    Log To Console              ${fein}
    Set Global Variable         ${fein}
    ${renewal_warning_reason}=                              Generate Random String      255
    Log To Console              ${renewal_warning_reason}
    Set Global Variable         ${renewal_warning_reason}
    ${billingaddress}=          Set Variable                60 Asfordby Street
    Set Global Variable         ${billingaddress}
    ${rating_reason}=           Generate Random String      255
    Log To Console              ${rating_reason}
    Set Global Variable         ${rating_reason}
    ${account_owner}=           Set Variable                Copado-AQPI, Automation-user
    Set Global Variable         ${account_owner}
    ${currdate}=                Get Current Date            result_format=%m/%d/%Y
    Log To Console              ${currdate}


    Log To Console              ------ Global Variabled For Account Set Successfully -------

    VerifyText                  Account Name
    TypeText                    Account Name                ${uniqueName}
    TypeText                    Website                     ${random_email}
    PickList                    Account Currency            ${currency}
    TypeText                    Phone                       ${phone}
    TypeText                    FEIN                        ${fein}
    TypeText                    Renewal Warning Reason      ${renewal_warning_reason}
    TypeText                    Billing Address             ${billingaddress}
    ClickText                   60 Asfordby Street
    TypeText                    Date Started                ${currdate}
    TypeText                    Rating Reason               ${rating_reason}
    ClickText                   Cancel                      partial_match=false
    UseModal                    Off
    Log To Console              ------ Cancel Clicked Successfully -------

Follow Edit and Delete Account Click
    #Author=Pinki
    [Tags]                      Account
    Home
    ClickText                   Accounts
    VerifyText                  Recently Viewed             anchor=span
    # ClickElement                (//a[@data-refid\='recordId'])[1]
    # ClickElement                (//table//tr//a)[10]
    ClickText                   ${uniqueName}
    VerifyText                  Follow
    ClickText                   Follow
    Log To Console              ------ Follow Clicked Successfully -------
    Editing the Account
    Log To Console              ------ Editing the Account Successfully -------
    Delete Account Click
    Log To Console              ------ Account Deleted Successfully -------



