*** Settings ***
Library                      QWeb
Library                      QForce
Library                      FakerLibrary
Library                      String
Library                      BuiltIn
Library                      DateTime
Resource                     ../resources/common.robot
Resource                     ../PageObjects/PageObjects_Account.robot
#Resource                    ../PageObjects/PageObjects_InsuredInfo.robot

*** Keywords ***

Validate NewSubmission Init on Submission info page 
    #Author=Pinki
    VerifyText               New Submission Form
    VerifyText               *Submission Name
    VerifyText               *Submission Owner
    VerifyText               *Submission Currency
    VerifyText               * Broker Contact
    VerifyText               *Main Profession
    VerifyText               Largest Work Type
    VerifyText               Next
    VerifyElement            //button[text()\='Next']
    VerifyText               Cancel
    VerifyElement            //button[text()\='Cancel']


    Log To Console           ----- Submission Init Values Validated Successfully -----

Select and add broker
    #Author= Pinki
    [tags]                   Broker
    VerifyText               * Broker Contact
    ${broker}=               Set Variable                Automation AQ Broker
    Log To Console           ${broker}
    ClickElement             (//input[@placeholder\="Search..."])[2]
    TypeText                 (//input[@placeholder\="Search..."])[2]                 ${broker}
    ClickText                ${broker}                   anchor=Broker Contact
    Log To Console           ----- broker added Successfully -----

Validate Main Professions on SubmissionInt Form
    #Author= Pinki
    [tags]                   Broker

    VerifyText               Main Profession
    VerifyPicklist           Main Profession
    ${Profession_value}=     GetPicklist                 Main Profession
    Log To Console           ${Profession_value}
    @{Profession_list}=      Create List                 None                        Accountants                 Architects                  Design & Construct          Engineers                   Insurance Brokers           IT Consultants              Media Professionals         Miscellaneous               Property Professionals      Solicitors
    Log To Console           ${Profession_list}
    Lists Should Be Equal    ${Profession_Value}         ${Profession_Value}         ignore_order=true
    Log To Console           ----- Main Professions Data Verified Successfully -----

Select and add Profession
    [Arguments]              ${profession}
    #Author= Pinki
    [tags]                   Profession
    VerifyText               *Main Profession
    PickList                 Main Profession             ${profession}
    Log To Console           ----- Profession added Successfully -----

Select and add Largest work type
    [Arguments]              ${worktype}
    #Author= Pinki
    [tags]                   Lergest Work Type
    VerifyText               *Largest Work Type
    PickList                 Largest Work Type           ${worktype}
    Log To Console           ----- Profession added Successfully -----

Validate largest worktype according to profession
    [Documentation]          Validate largest worktype according to profession
    #Author= Pinki
    [Arguments]              ${Profession_s}


    IF                       "${Profession_s}" == "Accountants"

        PickList             Main Profession             ${Profession_s}
        ${wrktype_one}=      GetPickList                 Largest Work Type
        ${wrktype_list}=     Create List                 --None--                    Auditing, preparation of accounts, company tax - for other clients (Unquoted companies / small traders)         Auditing, preparation of accounts, company tax - for Quoted Companies               Book Keeping / Payroll      Computer consultancy        Directorships               Executorship & Trusteeship                              Forensic Accountancy        General Accounting          General Insurance income    Insolvencies, Liquidations or Receiverships (not Individual Voluntary Arrangement or Bankruptcy)                Investment income           IVA (Individual Voluntary Arrangement) & Bankruptcy     Management Consultancy    Mergers, Acquisitions, Disposals, Take-overs or Corporate Finance                   Other (Accountant)          Other Pure Tax              Personal Taxation           Probate                     Secretarial & share registration / Registrar            Training

        Lists Should Be Equal                            ${wrktype_one}              ${wrktype_list}             ignore_order=false
        Log To Console       ----- Worktypes for Accountants                         Verified Successfully -----

    ELSE IF                  "${Profession_s}" == "Architects"

        PickList             Main Profession             ${Profession_s}
        ${wrktype_one}=      GetPickList                 Largest Work Type
        ${wrktype_list}=     Create List                 --None--                    Arbitrator                  Architectural consultancy                               Architectural - New Build                               Architectural - refurbishment / non structural          Architectural - refurbishment / structural              Asbestos Inspections        Biomass                     Building Inspections & Building surveying (no valuations)                           Building Surveying: Party walls, schedules of dilapidation, specification & supervision of repairs, redecoration & refurbishment            Chemical Engineering        Civil Engineering           Cladding / Curtain Wall     Drafting Services (with no design)                    Electrical Engineering      Electronic Engineers        Feasibility Studies         Flooring                    Foundations / Underpinning                              Glazing                     Heating, Ventilation & Air Conditioning Engineering     Interior Design - non structural                        Interior Design - structural                            Landscape Design            Mechanical Engineering: Production Lines / Lifts(ex Process Engineering)            Mechanical Engineering (not Production Lines / Process engineering / Lifts)                               Other (Architects)          Principal designer under "CDM regulations" / CDM consultancy                        Process Engineering         Project Co-ordination (no project management)         Project Management      Quantity surveying (excluding project co-ordination & project management)       Roofing               Setting Out            Soil Engineering                              Solar / PV Panels      Structural Engineering      Structural Survey / Inspection Reports (no valuations)                   Surveys                Town Planning               Wind Turbines
        Lists Should Be Equal                            ${wrktype_one}              ${wrktype_list}             ignore_order=false
        Log To Console       ----- Worktypes for Architects                          Verified Successfully -----

    ELSE IF                  "${Profession_s}" == "Design & Construct"

        PickList             Main Profession             ${Profession_s}
        ${wrktype_one}=      GetPickList                 Largest Work Type
        ${wrktype_list}=     Create List                 --None--                    Architectural - New Build                               Architectural - refurbishment / non structural          Architectural - refurbishment / structural              Biomass                     Building Inspections & Building surveying (no valuations)                           Chemical Engineering        Civil Engineering           Cladding / Curtain Wall     Drafting Services (with no design)                      Electrical Engineering      Electronic Engineers        Feasibility Studies         Flooring                    Foundations / Underpinning                              General Building            Glazing                   Heating, Ventilation & Air Conditioning Engineering     Interior Design - non structural                        Interior Design - structural                            Landscape Design            Mechanical Engineering: Production Lines / Lifts(ex Process Engineering)            Mechanical Engineering (not Production Lines / Process engineering / Lifts)         Other (D&C)                 Principal designer under "CDM regulations" / CDM consultancy                        Process Engineering         Project Management          Roofing               Setting Out                 Soil Engineering            Solar / PV Panels           Structural Engineering      Structural Survey / Inspection Reports (no valuations)                              Town Planning               Wind Turbines
        Lists Should Be Equal                            ${wrktype_one}              ${wrktype_list}             ignore_order=false
        Log To Console       ----- Worktypes for Design & Construct                  Verified Successfully -----

    ELSE IF                  "${Profession_s}" == "Engineers"

        PickList             Main Profession             ${Profession_s}
        ${wrktype_one}=      GetPickList                 Largest Work Type
        ${wrktype_list}=     Create List                 --None--                    Arbitrator                  Architectural consultancy                               Architectural - New Build                               Architectural - refurbishment / non structural          Architectural - refurbishment / structural              Asbestos Inspections        Biomass                     Building Inspections & Building surveying (no valuations)                           Building Surveying: Party walls, schedules of dilapidation, specification & supervision of repairs, redecoration & refurbishment            Chemical Engineering        Civil Engineering           Cladding / Curtain Wall     Drafting Services (with no design)                    Electrical Engineering      Electronic Engineers        Feasibility Studies         Flooring                    Foundations / Underpinning                              Glazing                     Heating, Ventilation & Air Conditioning Engineering     Interior Design - non structural                        Interior Design - structural                            Landscape Design            Mechanical Engineering: Production Lines / Lifts(ex Process Engineering)            Mechanical Engineering (not Production Lines / Process engineering / Lifts)                               Other (Engineers)           Principal designer under "CDM regulations" / CDM consultancy                        Process Engineering         Project Co-ordination (no project management)         Project Management      Quantity surveying (excluding project co-ordination & project management)       Roofing               Setting Out            Soil Engineering                              Solar / PV Panels      Structural Engineering      Structural Survey / Inspection Reports (no valuations)                   Surveys                Town Planning               Wind Turbines
        Lists Should Be Equal                            ${wrktype_one}              ${wrktype_list}             ignore_order=false
        Log To Console       ----- Worktypes for Engineers                           Verified Successfully -----

    ELSE IF                  "${Profession_s}" == "Insurance Brokers"
        PickList             Main Profession             ${Profession_s}
        ${wrktype_one}=      GetPickList                 Largest Work Type
        ${wrktype_list}=     Create List                 --None--                    Bloodstock                  Commercial (non motor/construction/PI/reinsurance/marine/Aviation)                  Construction                Guaranteed Asset Protection Insurance (GAP)             Investment income           Loss Assessing / Claims Adjusting                       Marine / Aviation - Commercial                          Motor (personal or commercial)                          Other (Insurance Brokers)                               Payment Protection Insurance (PPI)                      Personal lines (non motor)                              Private Medical Insurance                               Professional Indemnity    Reinsurance                 Risk Management Consultancy                             Secondary Intermediary sales (where insurance is not the primary sale to the customer)                          Warranty
        Lists Should Be Equal                            ${wrktype_one}              ${wrktype_list}             ignore_order=false
        Log To Console       ----- Worktypes for Insurance Brokers                   Verified Successfully -----

    ELSE IF                  "${Profession_s}" == "IT Consultants"
        PickList             Main Profession             ${Profession_s}
        ${wrktype_one}=      GetPickList                 Largest Work Type
        ${wrktype_list}=     Create List                 --None--                    Data Processing             General Computer Advice or Consultancy                  Hardware distribution of third party brands             Hardware Installation or Maintenance                    Hardware sale of own brand                              Other (IT)                  Provision of contract staff                             Provision of Out-sourced / managed services             Sales of third party shrink wrapped software            Software customisation      Software - developing bespoke applications              Software Installation Including Configuration           Software maintenance        Software - Own written    Training                    Web-site Design
        Lists Should Be Equal                            ${wrktype_one}              ${wrktype_list}             ignore_order=false
        Log To Console       ----- Worktypes for IT Consultants                      Verified Successfully -----

    ELSE IF                  "${Profession_s}" == "Media Professionals"
        PickList             Main Profession             ${Profession_s}
        ${wrktype_one}=      GetPickList                 Largest Work Type
        ${wrktype_list}=     Create List                 --None--                    Brand / Image / Corporate Identity Consultancy          Conference / Event / Exhibition Organisers - with no tour operating                 Copywriter                  Direct marketing - database management and list broking                             Direct Marketing mailshots and postage costs            Games / Competitions        Graphic Design              Marketing                   Market Research             Non TV advertisement media spend                        Non TV advertisement production                         Other (Media)               Printed literature and documents                        Public Relations          Sales Promotion             Telemarketing               TV Advertisement media costs                            TV advertisement production
        Lists Should Be Equal                            ${wrktype_one}              ${wrktype_list}             ignore_order=false
        Log To Console       ----- Worktypes for Media Professionals                 Verified Successfully -----

    ELSE IF                  "${Profession_s}" == "Miscellaneous"
        PickList             Main Profession             ${Profession_s}
        ${wrktype_one}=      GetPickList                 Largest Work Type
        ${wrktype_list}=     Create List                 --None--                    Access / Disability Consultancy                         Accident / Theft Investigation                          Accident Investigation      Acoustic Consultants        Actuaries                   Adjudicator                 Agricultural Consultant     Animal Behaviour Consultant                             Anthropology                Arbitrator                  Arboriculture Consultancy                               Archaeology                 Auctioneering               Average Adjuster            Baby Sitting Agency         Badger Consultancy          Bailiff                     Bat Consultancy             Bid Support Consultancy                               Bookbinding Consultant      Business Analyst            Business Change Manager     Business Coaching           Business Consultancy        Business Continuity Consultancy                         Business Development Consultancy                        Business Development Manager                            Business Management and Administrative Services         Business Management Consultancy                         Business Operations Consultancy                         Business Support Services                         CAD technician (non architectural/engineering)          Calligraphy                 Careers Advisory Service    Catering Consultant         Chamber of Commerce         Charity - High              Charity - Standard          Chartered Secretary       Childcare Advisor       Clerical Services Consultancy                       Clerical Training Consultancy                     Clinical Trials        Coaching/Counselling                          Coaching and leadership development                Coaching and mentoring    Community care & support services              Company Formation and Registration                 Company Registrars          Company Search Agents       Compliance Audit Consultancy                        Compliance Consultancy      Computer consultancy        Concierge                   Conference Organiser                 Construction contract law advisors                      Consulting chemist                       Counselling Service                              Court Reporter    Credit Reporter or Researcher                 Culture Consultancy        Customer and Regulatory Advice                    Data Protection Advice      Debt Counsellor         Disability And Access Consultancy                       Disability Assessor                     Disability Student Assessor (DSA)               Draughtsman and Detailer                  Ecologist (ex pollution control advice)    Education Advisory Service                              Education Consultant        Emergency Call Out Service                         Employment Agent: Fees for the provision of Permanent Staff                         Employment Agent: Turnover for the provision of Temporary Staff          Energy Assessors          Enquiry Agent         Environmental consultants            Equality & Diversity Consultancy     Events Organiser                     Excel Consultancy    Executive Coaching          Exhibition Organisation                   Expert Witness              Export Consultant             Feng Shui Consultancy       Fingerprint Examination           Fire protection consultant                      First Aid Training          Food Industry Consultant                     Forensic Consultants        Forensic Practitioners & Experts           Forestry Consultant - ex valuations, financial advice, subsidies             Freelance Tutor             Freight Forwarder    Fuel Efficiency consultant          Funeral Director         Garden/landscape Design                       Genealogist              Handwriting Consultancy                         Head Hunting                Health & Safety Consultant                          Health & Safety Training Consultancy                 Health and Safety Training                  Heritage Consultancy        Home Inventory Services                          Horticultural Consultancy                               Hotel and Catering Consultancy                     Human Resource Consultancy                       Immigration Consultant                   Import Consultancy          Inspirational Speaker       Insurance Investigator    Interim Management          Interior Designer          Interpreting                Inventory Clerk             Language Tutor              Law Centre          Law Costs Draftsman     Law Search Agents       Legal Department - but not lawyer/solicitor firms       Life coaching        Lifestyle Consultancy       Lifting equipment tester                       Linguist               Literary Agent     Local Authority Searches                  Loss Adjuster               Loss Assessor               Management Consultant       Management Training               Map Drawing / Cartography                    Marine Cargo Surveyor       Marine Surveyors                Marriage Guidance Services                              Mediator                    Media Training        Mentoring                   Messenger at Arms      Motor Accident Investigation      Motor Engineer (ex design)                Museum and Heritage Consultancy                  Museum Consultant           Non destructive tester      Notary         Nutrition Consultancy      NVQ Assessment       Occupational Health Consultancy                         Office Space Planning                         Ofsted Inspector         Other (High - Miscellaneous)            Other (Standard - Miscellaneous)                        Outsourcing Consultancy    Patent administration    Personnel Consultancy    Personnel Management & Selection    Pharmaceutical consultant    Photographer    Photographer and Videographer    Photographic Library    Political Consultancy    Portable Appliance Testing    Principal designer under "CDM regulations" / CDM consultancy    Private Investigator    Procurement Consultancy    Product designers    Professional Association    Proofreading    Property Search Agent    Public Health Consultancy    Public Records Search Agency    Purchasing Consultancy    Quality Assurance Consultancy    Recruitment Consultancy    Regeneration Consultancy    Regulatory Affairs Consultancy    Regulatory Compliance Consultancy    Relocation Agent    Research association    Research Consultancy    Residential Inventory Agency    Risk Management Consultancy    Scene Examination    Secretarial and Clerical    Secretarial Service    Secretarial Training    Security consultant    Sheriff Officer    Shipbroker    Shipping and forwarding agent    Sign Language Interpreting    Sign Language Translating    Small Business Advisory Services    Social Worker    Sound Therapy    Space Planning    Speech-to-text Reporter    Statistician (ex actuarial)    Statutory body    Stocktaker    Strategic Management Consultancy    Supply Chain Consultancy    Surface coatings consultant    Tachograph Analyst    Timber treatment consultant    Tourist Association    Tour Operating    Town Planner    Training    Translator    Travel Agent    Travel Agent: Tailor made package design    Tutoring Services    Urban Regeneration Consultancy    User Experience Consultancy, Design & Development    Videography    Video Inventory Service    Virtual Assistant    Wedding & Corporate Videography    Wedding & Portrait Photography    Wedding Photography    Wedding Videography    Wellbeing Consultancy    Wildlife Consultancy    Will Writing    Yacht Broking (ex surveys and valuations)    Yacht Broking (surveys and valuations)    Zoologist
        Lists Should Be Equal                            ${wrktype_one}              ${wrktype_list}             ignore_order=false
        Log To Console       ----- Worktypes for Miscellaneous                       Verified Successfully -----

    ELSE IF                  "${Profession_s}" == "Property Professionals"
        PickList             Main Profession             ${Profession_s}
        ${wrktype_one}=      GetPickList                 Largest Work Type
        ${wrktype_list}=     Create List                 --None--                    Adjudicator                 Agricultural Consultancy - Crop & Fertisiler            Agricultural Consultancy - Foresty (no financial)       Agricultural Consultancy - Single Farm Payment & Subsidies                          Arbitrator                  Architectural - New Build                               Architectural - refurbishment / non structural          Architectural - refurbishment / structural              Asbestos Inspections        Asset Management (no investment advice or guarantees)                               Asset Management (with investment advice or guarantees)                             Asset Valuations          Auctioneering (ex fine art)                             Auctioneering (fine art)    Building Inspections & Building surveying (no valuations)                           Building Survey / Structural Report with no valuations                              Building Surveying: Party walls, schedules of dilapidation, specification & supervision of repairs, redecoration & refurbishment            Clerk of Works              Commercial Estate Agency    Commercial Lending Valuations                           Commercial Property Management / Land Management                              Council Tax Rating including rating appeals             Employers Agent             Energy Assessments          Environmental               Expert Witness              General Insurance income    Homebuyer Report with no valuation                Insurance / Reinstatement Valuations                Interior Design - non structural                  Interior Design - structural             Investment income           Landscape Design       Land Surveying including Topographical (ex Setting Out, Measured Building Surveys)                   Leasehold Enfranchisement                          Matrimonial / Divorce Valuations                        Measured Building Surveys                           Mediator                    Other (Property Professionals)                          Planning & Development Agency (no investment advice or guarantees)                           Planning & Development Agency (with investment advice or guarantees)                      Principal designer under "CDM regulations" / CDM consultancy    Probate Valuations         Project Co-ordination (no project management)     Project Management          Quantity surveying (excluding project co-ordination & project management)       Rent Reviews / Lease Renewals           Residential Estate Agency                       Residential Lending Valuations            Residential Letting Agency                 Residential Property Management                         Setting Out                 Stocktaking             Structural Survey / Inspection Reports (no valuations)                             Town Planning
        Lists Should Be Equal                            ${wrktype_one}              ${wrktype_list}             ignore_order=false
        Log To Console       ----- Worktypes for Property Professionals              Verified Successfully -----

    ELSE IF                  "${Profession_s}" == "Solicitors"
        PickList             Main Profession             ${Profession_s}
        ${wrktype_one}=      GetPickList                 Largest Work Type
        ${wrktype_list}=     Create List                 --None--                    Adjudication                Administering oaths, taking affidavits and notary public                            Agency Advocacy             Arbitration                 Children Work               Commercial / Corporate Work (excluding work relating to Public Companies)           Commercial / Corporate Work for Public Companies        Conveyancing (Commercial)                               Conveyancing (Residential)                              Criminal Law                Debt Collection             EC competition law and human rights                     E-commerce and/or information technology work           Employment work (non-litigious / non contentious)     Expert Witness              Financial Advice and Services                           Immigration work            Intellectual Property including patent, trademark and copyright                     Landlord and Tenant Work    Lecturing and related activities                        Litigious Defendant work for insurers                   Litigious Work (other)      Marine Law - litigious      Matrimonial / Family        Mediation                   Mental Health Tribunal      Mergers and Acquisitions including Management Buy-Outs and Buy-Ins            Non Litigious work other than in any other category     Offices and Appointments    Other (High)                Other (Standard)            Parliamentary Agency        Personal Injury (for defendants)                      Personal Injury -Claimant / Litigation work only (non defendant work)       Property selling, valuations and property management                     Town and Country Planning                     Welfare work           Wills, Trust, Tax planning, Probate and Estate Administration
        Lists Should Be Equal                            ${wrktype_one}              ${wrktype_list}             ignore_order=false
        Log To Console       ----- Worktypes for Solicitors                          Verified Successfully -----

    ELSE

        Log To Console       ---Invalid argument passed ---

    END