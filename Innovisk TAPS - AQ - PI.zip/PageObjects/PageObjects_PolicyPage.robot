*** Settings ***
Library                      QWeb
Library                      QForce
#Library                     QVision
Library                      FakerLibrary
Library                      String
Library                      BuiltIn
Library                      DateTime
Resource                     ../resources/common.robot
Resource                     ../PageObjects/PageObjects_Account.robot
Resource                     ../PageObjects/PageObjects_InsuredInfo.robot


*** Keywords ***
Validate Policy Page Details
    #Author=Amol
    [Documentation]          submission
    VerifyText               Change Policy
    VerifyText               Send Email
    VerifyText               Renew                       partial_match=False

    ClickElement             //span[text()\='Show more actions']
    VerifyText               New Note
    VerifyText               Clone
    VerifyText               Submit for Approval
    VerifyText               Change Record Type
    VerifyText               Sharing
    VerifyText               Change Owner
    VerifyText               Edit                        anchor=Change Owner
    VerifyText               Printable View

    VerifyText               Policy Details
    VerifyText               Broker Agency Name
    VerifyText               Insured Account Name
    VerifyText               Main Profession
    VerifyText               Largest Work Type
    VerifyText               Master Binder
    VerifyText               Latest Bound Limit
    VerifyText               Underlying Limit
    VerifyText               Actual Excess
    VerifyText               Owner
    VerifyText               Inception Date
    VerifyText               Expiration Date             anchor=2
    VerifyText               Retroactive Date
    VerifyText               Quote Bound Date

    VerifyText               Total Premium               anchor=2
    VerifyText               Initial Premium
    VerifyText               Endorsement Premium
    VerifyText               Amount Due
    VerifyText               Total Tax
    VerifyText               Initial Tax
    VerifyText               Endorsement Tax
    VerifyText               Total Fee
    VerifyText               Initial Fee
    VerifyText               Endorsement Fee

    VerifyText               Quote Name
    ${curr_date}=            Get Current Date            result_format=%-m/%-d/%Y
    VerifyText               ${uniqueName} PI ${curr_date} Primary 1                 anchor=1


Validate Change Policy Dropdown Values
    #Author=Amol
    [Documentation]          Change Policy
    ClickText                //button[text()\='Change Policy']
    VerifyText               New Endorsement
    Sleep                    10s
    ${Endorsement_Type}=     GetDropDownValues           Endorsement Type
    Log To Console           ${Endorsement_Type}
    @{endorsement_list}=     Create List                 Full Amendment              Coverage Amendment    Insured Account Update    Midterm Cancellation    Flat Cancellation    Coverage Cancel & Replace                            Full Cancel & Replace     Policy Duration Change
    Log To Console           ${endorsement_list}
    Lists Should Be Equal    ${Endorsement_Type}         ${endorsement_list}         ignore_order=true


Change Policy 
    #Author=Amol
    [Documentation]          Change Policy
    [Arguments]              ${Endorsement_Type}
    ClickElement             //button[text()\='Change Policy']
    VerifyText               New Endorsement
    DropDown                 Endorsement Type            ${Endorsement_Type}


Full Amendment Input
    #Author=Amol
    [Documentation]          Change Policy
    DropDown                 Endorsement Reason          Acquisition
    ${curr_date}=            Get Current Date            result_format=%b %-d, %Y
    Log To Console           ${curr_date}
    TypeText                 Endorsement Effective Date                              ${curr_date}
    ClickText                Confirm                     anchor=Back
    VerifyText               Success!                    anchor=Full Amendement successful!                timeout=65s

Coverage Amendement Input
    #Author=Amol
    [Documentation]          Change Policy


Insured Account Update Input
    #Author=Amol
    [Documentation]          Change Policy



Midterm Cancellation Input
    #Author=Amol
    [Documentation]          Change Policy
    DropDown                 Endorsement Reason          Product too expensive
    ${curr_date}=            Get Current Date            result_format=%b %-d, %Y
    Log To Console           ${curr_date}
    TypeText                 Cancellation Date*          ${curr_date}
    ClickText                Confirm                     anchor=Back
    VerifyText               Success!                    anchor=Midterm Cancellation successful!           timeout=65s

Reinstatement Input
    #Author=Amol
    [Documentation]          Change Policy
    ClickText                Confirm                     anchor=Back
    VerifyText               Success!                    anchor=Reinstatement successful!                  timeout=65s               partial_match=false

Flat Cancellation Input
    #Author=Amol
    [Documentation]          Change Policy
    DropDown                 Endorsement Reason          Product too expensive
    ClickText                Confirm                     anchor=Back
    VerifyText               Success!                    anchor=Flat Cancellation successful!              timeout=65s



Coverage Cancel & Replace Input
    #Author=Amol
    [Documentation]          Change Policy



Full Cancel & Replace Input
    #Author=Amol
    [Documentation]          Change Policy




Policy Duration Change Input
    #Author=Amol
    [Documentation]          Change Policy


Click On Renew
    #Author=Amol Gaymukhe
    [Documentation]          Change Policy
    ClickElement             //button[text()\='Renew']
    #ClickElement             (//span[text()\='Select Item 2']/parent::*)
    #ClickText                Confirm                     anchor=Cancel
    #VerifyText               Success                     anchor=Policy Renewed Successfully    partial_match=False
Select Policy from PolicyPage
    #Author= Amol Gaymukhe
    ClickElement             (//lightning-primitive-cell-factory[@data-label\='Document Name']//a)[1]
    VerifyText               Document Revision
    ClickText                View Document
    VerifyText               Success                     anchor=Document has been downloaded sucessfully!                            timeout=55s

Select Amendment Policy from PolicyPage
    #Author= Amol Gaymukhe
    ClickElement             (//lightning-primitive-cell-factory[@data-label\='Document Name']//a)[3]
    VerifyText               Document Revision
    ClickText                View Document
    VerifyText               Success                     anchor=Document has been downloaded sucessfully!                            timeout=55s


Click On Submission
    #Author= Amol Gaymukhe
    ClickElement             //lightning-primitive-cell-factory[@data-label\='Submission Name']//a         index=1


Click On First Policy 
    #Author= Amol Gaymukhe
    # ClickElement           (//a[@data-refid\='recordId'])[1]
    ClickElement             (//table//tr//a)[8]


Select Excess Binder On Policy
    # Author = Amol Gaymukhe
    [Documentation]          Quote
    [tags]                   Quote
    [Arguments]              ${type}
    VerifyText               Excess Binder
    IF                       "${type}" == "Binder"
        ClickElement         (//span[text()\='Select Item 1']/parent::*)[last()]
    ELSE IF                  "${type}" == "GAIC"
        ClickElement         (//span[text()\='Select Item 2']/parent::*)[last()]
    ELSE IF                  "${type}" == "XOL"
        ClickElement         (//span[text()\='Select Item 3']/parent::*)[last()]
    ELSE
        Log To Console       No Parameters Given
        Fail
    END
    ClickText                Confirm                     anchor=Cancel
    VerifyText               Success                     anchor=Policy Renewed Successfully                timeout=35s


Check Quote Type as renewal on Policy  
    ${quoteTypePolicy}=                GetText                    //lightning-primitive-custom-cell//span[@title\='Renewal']
    Log To Console              ${quoteTypePolicy}
    IF                          '${quoteTypePolicy}' == 'Renewal'
        Log To Console          ${quoteTypePolicy} match
    ELSE
        Fail

    END