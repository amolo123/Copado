*** Settings ***
Library                         QWeb
Library                         QForce
#Library                        QVision
Library                         FakerLibrary
Library                         String
Library                         BuiltIn
Library                         DateTime
Resource                        ../resources/common.robot
Resource                        ../PageObjects/PageObjects_Account.robot
Resource                        ../PageObjects/PageObjects_InsuredInfo.robot

*** Keywords ***
Validate all the quote console elements
    # Author = Amol Gaymukhe
    [tags]                      Quote Console
    VerifyText                  Quote Details
    VerifyText                  Status
    VerifyText                  Inception Date
    VerifyText                  Quote Number
    VerifyText                  Policy Wording Document
    VerifyText                  Layer
    VerifyText                  Quote Type
    VerifyText                  Expiry Date
    VerifyText                  Policy
    VerifyText                  IPID Document
    VerifyText                  Insurer Special Acceptance?

    VerifyText                  System Details
    VerifyText                  Created By
    VerifyText                  Created Date
    VerifyText                  Bound Date
    VerifyText                  Last Modified By
    VerifyText                  Last Modified Date
    VerifyText                  Winback / Pipeline

    VerifyText                  Commission Details
    VerifyText                  MGA Commission %
    VerifyText                  Broker Commission %
    VerifyText                  Binder
    VerifyText                  Policy Wording
    VerifyText                  Retroactive Date
    Date
    VerifyText                  Territorial Limits
    VerifyText                  Jurisdiction Limits
    VerifyText                  Limit Basis
    VerifyText                  Excess Basis

    VerifyText                  Book Excess
    VerifyText                  Discretion
    VerifyText                  Actual Excess

    VerifyText                  Quote Options
    VerifyText                  Free Form

    VerifyText                  Rate
    VerifyText                  Finalize
    VerifyText                  New Primary Quote
    VerifyText                  New Excess Quote

    VerifyElement               //lightning-icon[@title\='Generate Document']
    VerifyElement               //lightning-icon[@title\='Endorsements & Subjectivities']
    VerifyElement               //lightning-icon[@title\='View Referral Reasons']
    VerifyElement               //button[@title\='Clone']
    VerifyElement               //lightning-icon[@title\='Close']
    VerifyElement               //lightning-datatable//table

Validate Dates on Quote Console
    # Author = Amol Gaymukhe
    [Documentation]             Dates on Quote Console
    [tags]                      Dates
    ${get_inception_date}=      GetInputValue               Inception Date
    Log To Console              ${get_inception_date}
    ${get_expiry_date}=         GetInputValue               Expiry Date
    Log To Console              ${get_expiry_date}

    ${exp_date}=                Get Current Date            increment= 364 days         result_format=%b %-d, %Y
    Log To Console              ${exp_date}

    IF                          "${exp_date}" == "${get_expiry_date}"
        Log To Console          Success

    ELSE
        Fail
    END


Validate dropdown Values
    # Author = Amol Gaymukhe
    [Documentation]             Dates on Quote Console
    [tags]                      Dates

    ${Retro_Date}=              GetPicklist                 Retroactive Date
    Log To Console              ${Retro_Date}
    @{Retro_Date_list}=         Create List                 None                        Retro - Inception date      Date
    Log To Console              ${Retro_Date_list}
    Lists Should Be Equal       ${Retro_Date}               ${Retro_Date_list}          ignore_order=true

    ${Terrirotial_Limits}=      GetPicklist                 Territorial Limits
    Log To Console              ${Terrirotial_Limits}
    @{Terrirotial_Limits_list}=                             Create List                 Worldwide excluding USA/Canada                          Worldwide                   United Kingdom and the European Union                   United Kingdom              United Kingdom and Ireland
    Log To Console              ${Terrirotial_Limits_list}
    Lists Should Be Equal       ${Terrirotial_Limits}       ${Terrirotial_Limits_list}                              ignore_order=true

    ${Policy_Wording_Date}=     GetPicklist                 Policy Wording
    Log To Console              ${Policy_Wording_Date}
    @{Policy_Wording_list}=     Create List                 AQUW/AC/04.19 Accountants Professional Indemnity Policy Wording                     AQUW/DC/04.19 Design & Construction Professional Indemnity Policy Wording           AQUW/IB/04.19 Insurance Brokers Professional Indemnity Policy Wording               AQUW/IT/04.19 Technology & IT Professional Indemnity Policy Wording                 AQUW/MP/04.19 Miscellaneous Professions Professional Indemnity Policy Wording       AQUW/AD/04.19 Media, Marketing & Communication Professional Indemnity Policy Wording    AQUW/PP/04.19 Property Professionals Professional Indemnity Policy Wording    AQUW/AE/04.19 Architects & Engineers Professional Indemnity Policy Wording    AQUW/AC/04.22 Accountants Professional Indemnity Policy Wording    AQUW/DC/04.22 Design & Construction Professional Indemnity Policy Wording    AQUW/IB/04.22 Insurance Brokers Professional Indemnity Policy Wording    AQUW/IT/04.22 Technology & IT Professional Indemnity Policy Wording    AQUW/MP/04.22 Miscellaneous Professions Professional Indemnity Policy Wording    AQUW/AD/04.22 Media, Marketing & Communication Professional Indemnity Policy Wording    AQUW/PP/04.22 Property Professionals Professional Indemnity Policy Wording    AQUW/AE/04.22 Architects & Engineers Professional Indemnity Policy Wording    Aqueous 07.24 Lockton Solicitors Excess Layer Policy Wording (July 2024)    AQUW/PP/07.24 Property Professionals Professional Indemnity Policy Wording
    Log To Console              ${Policy_Wording_list}
    Lists Should Be Equal       ${Policy_Wording_Date}      ${Policy_Wording_list}      ignore_order=true

    ${Jurisdiction_Limits_Date}=                            GetPicklist                 Jurisdiction Limits
    Log To Console              ${Jurisdiction_Limits_Date}
    @{Jurisdiction_Limits_list}=                            Create List                 Worldwide excluding USA/Canada                          Worldwide                   United Kingdom and the European Union                   United Kingdom              United Kingdom and Ireland
    Log To Console              ${Jurisdiction_Limits_list}
    Lists Should Be Equal       ${Jurisdiction_Limits_Date}                             ${Jurisdiction_Limits_list}                             ignore_order=true

    ${Excess_Basis_Date}=       GetPicklist                 Excess Basis
    Log To Console              ${Excess_Basis_Date}
    @{Excess_Basis_list}=       Create List                 Per Single Claim - Not Applicable to Defence Costs      Per Single Claim - Applicable to Defence Costs          Per Single Claim or Claimant - Not Applicable to Defence Costs                      Per Single Claim or Claimant - Applicable to Defence Costs
    Log To Console              ${Excess_Basis_list}
    Lists Should Be Equal       ${Excess_Basis_Date}        ${Excess_Basis_list}        ignore_order=true


Enter Broker Commission
    # Author = Amol Gaymukhe
    [Documentation]             Broker Commision
    [tags]                      Broker Commision
    TypeText                    Broker Commission %         10

Click On Save
    # Author = Amol Gaymukhe
    [Documentation]             Broker Commision
    [tags]                      Broker Commision
    ClickElement                //lightning-button-icon//button[@title\='Save']
    Usemodal                    On
    VerifyText                  Confirmation
    ClickText                   Confirm                     anchor=Cancel
    VerifyText                  Success                     anchor=Update records successfully!                     timeout=75s
    Log To Console              ------Save Successfully---------

Click On Clone
    # Author = Amol Gaymukhe
    [Documentation]             Broker Commision
    [tags]                      Broker Commision
    RefreshPage
    ClickElement                (//div[@class\='slds-page-header__controls']//button[@title\='Clone'])[1]
    # Usemodal                  On
    # VerifyText                Confirmation
    # ClickText                 Confirm                     anchor=Cancel
    # VerifyText                Success                     anchor=Updated records successfully!                    timeout=75s


Click On Rate
    # Author = Amol Gaymukhe
    [Documentation]             Rate
    [tags]                      Rating
    ClickElement                (//button[text()\='Rate'])[1]
    Usemodal                    On
    VerifyText                  Confirmation
    ClickText                   Confirm                     anchor=Cancel
    VerifyText                  Success                     anchor=Rating successfully!                             timeout=75s                 partial_match= false
    Log To Console              ------Rate Successfully---------

Click Rate After Amendment
    # Author = Amol Gaymukhe
    [Documentation]             Rate
    [tags]                      Rating
    ClickElement                //button[text()\='Rate']
    ${confirmation}=            IsText                      Confirmation
    Log To Console              ${confirmation}
    ${confirmation}=            IsText                      Confirmation
    Log To Console              ${confirmation}
    IF                          "${confirmation}" == "True"
        ClickElement            //button[text()\='Confirm']                             anchor=Cancel
    ELSE
        VerifyText              Success                     anchor=Rating successfully!                             partial_match=false
    END

    Sleep                       30sec

Click On Finalize 
    # Author = Amol Gaymukhe
    [Documentation]             Finalize
    [tags]                      Finalize
    ClickElement                (//button[text()\='Finalize'])[1]
    VerifyText                  Success                     anchor=Finalize quote successfully!                     timeout=65s                 partial_match= false
    Sleep                       15s
    Log To Console              ------Finalize Successfully---------

Create New Primary Quote 
    # Author = Amol Gaymukhe
    [Documentation]             Quote
    [tags]                      Quote
    ClickText                   New Primary Quote
    VerifyText                  Success                     anchor=Rating Successful    timeout=45s

Verify After Creating Primary
    # Author = Amol Gaymukhe
    [Documentation]             Quote
    [tags]                      Quote
    VerifyText                  Primary Quotes (2)


Create New Excess Quote 
    # Author = Amol Gaymukhe
    [Documentation]             Quote
    [tags]                      Quote
    [Arguments]                 ${type}
    ClickText                   New Excess Quote
    UseModal                    On
    VerifyText                  Master Binders
    IF                          "${type}" == "Binder"
        ClickElement            (//span[text()\='Select Item 1']/parent::*)[last()]
    ELSE IF                     "${type}" == "GAIC"
        ClickElement            (//span[text()\='Select Item 2']/parent::*)[last()]
    ELSE IF                     "${type}" == "XOL"
        ClickElement            (//span[text()\='Select Item 3']/parent::*)[last()]
    ELSE
        Log To Console          No Parameters Given
        Fail
    END
    ClickText                   Proceed to Quote
    VerifyText                  Success                     anchor=Rating Successful    timeout=45s


Verify After Creating Excess
    # Author = Amol Gaymukhe
    [Documentation]             Quote
    [tags]                      Quote
    VerifyText                  Excess Quotes (1)


Verify Referral Reasons
    # Author = Amol Gaymukhe
    [Documentation]             Quote
    [tags]                      Quote
    ClickElement                (//div[@class\='slds-page-header__controls']//lightning-icon[@title\='View Referral Reasons'])[1]
    VerifyText                  There are no Referral Reasons found. Try Rating the quote.                          timeout=45s


Click On Endorsements and Subjectivities
    # Author = Amol Gaymukhe
    [Documentation]             Quote
    [tags]                      Quote
    ClickElement                (//div[@class\='slds-page-header__controls']//lightning-icon[@title\='Endorsements & Subjectivities'])[1]
    UseModal                    On
    VerifyText                  Endorsement and Subjectivity                            timeout=45s

Click On Return To Quote Process
    # Author = Amol Gaymukhe
    [Documentation]             Quote
    [tags]                      Quote
    ClickText                   Return Quote Process

Click On Close Quote
    #Author = Amol Gaymukhe
    [Documentation]             Quote
    [tags]                      Quote
    ClickElement                (//div[@class\='slds-page-header__controls']//lightning-icon[@title\='Close'])[1]
    ClickText                   *Closed Reason
    ClickText                   No activity
    ClickText                   Yes                         anchor=No

Click on First Quote with xpath
    #Author = Amol Gaymukhe
    [Documentation]             Quote
    [tags]                      Quote
    ClickElement                //dt[text()\='Quote Name:']/parent::*//a


Click On First Quote
    #Author = Amol Gaymukhe
    [Documentation]             Quote
    [tags]                      Quote
    ${curr_date}=               Get Current Date            result_format=%-m/%-d/%Y
    Log To Console              ${curr_date}
    ${first_Quote}=             Set Variable                ${uniqueName} PI ${curr_date} Primary 1
    Log To Console              ${first_Quote}
    ClickElement                //dd/a[text()\='${first_Quote}']


Generate Document
    #Author = Amol Gaymukhe
    [Documentation]             Quote
    [tags]                      Quote
    ClickElement                (//div[@class\='slds-page-header__controls']//lightning-icon[@title\='Generate Document'])[1]
    VerifyText                  Success                     anchor=Document has been generated successfully!        timeout=45s

Click On First Quote Letter
    #Author = Amol Gaymukhe
    [Documentation]             Quote
    [tags]                      Quote
    ClickElement                //a[contains(text(),'QuoteSchedule')]
    VerifyText                  Success                     anchor=Document has been downloaded successfully!       timeout=25s


Click On First Excess Quote
    #Author = Amol Gaymukhe
    [Documentation]             Quote
    [tags]                      Quote
    ${curr_date}=               Get Current Date            result_format=%-m/%-d/%Y
    Log To Console              ${curr_date}
    ${first_Quote}=             Set Variable                ${uniqueName} PI ${curr_date} Excess 1
    Log To Console              ${first_Quote}
    ClickElement                //dd/a[text()\='${first_Quote}']


Click On First Excess Quote with xpath
    #Author = Amol Gaymukhe
    [Documentation]             Quote
    [tags]                      Quote
    ClickElement                (//dt[text()\='Quote Name:']/parent::*//a)[2]

Enter Details in Layer
    #Author = Amol Gaymukhe
    [Documentation]             Quote
    [tags]                      Quote
    ClickElement                (//div[@class\='slds-page-header__controls']//lightning-icon[@title\='Endorsements & Subjectivities'])[1]
    UseModal                    On
    VerifyText                  Endorsement and Subjectivity                            timeout=45s
    ClickText                   Insurer Layer               partial_match=False
    ClickElement                //td[@data-label\='Insurer']
    TypeText                    //td[@data-label\='Insurer']//input                     Test 1
    TypeText                    //td[@data-label\='Insurer Policy Number']//input       234223
    ClickText                   Save                        anchor=Add a Layer
    VerifyText                  Success                     anchor=Data Saved Successfully!                         timeout=20s
    ClickText                   Return Quote Process
    Sleep                       10s
    Log To Console              ------Layer Entered Correctly---------

Click Proceed To Bind
    #Author = Amol Gaymukhe
    [Documentation]             Quote
    [tags]                      Quote
    ClickText                   Proceed to Bind
    Log To Console              ------Proceed To Bind Successfully---------


Select Date From Calendar
    ClickText                   Expiry Date
    ClickText                   Next Month
    ClickText                   4                           partial_match=False

Enter Expiration Date
    #Author = Amol Gaymukhe
    [Documentation]             Quote
    [tags]                      Quote
    ClickElement                //label[text()\='Expiry Date']/parent::*//input
    PressKey                    //label[text()\='Expiry Date']/parent::*//input         {CONTROL + A + DELETE}
    ${curr_date}=               Get Current Date            result_format=%b %-d, %Y    increment=24 days
    Log To Console              ${curr_date}
    Typetext                    //label[text()\='Expiry Date']/parent::*//input         ${curr_date}
    ClickText                   Quote Number                partial_match=false


Enter Expiration Date variable
    #Author = Amol Gaymukhe
    [Documentation]             Quote
    [tags]                      Quote
    [Arguments]                 ${days}
    ${curr_date}=               Get Current Date            result_format=%-d %b %Y     increment=${days} days
    Log To Console              ${curr_date}
    Typetext                    Expiry Date                 ${curr_date}
    ClickText                   Quote Number                partial_match=false


Edit Limit and Enter Value
    #Author = Amol Gaymukhe
    [Arguments]                 ${limit}
    ClickElement                //span[text()\='Edit Limit']
    TypeText                    //label[text()\='Limit']//following::input              ${limit}


Check Limit
    #Author = Amol Gaymukhe
    ${limit}=                   GetText                     //th[@data-label\='Limit']//lightning-formatted-number
    Log To Console              ${limit}
    IF                          "${limit}" == "£2,000,000.00"
        Log To Console          Success
    ELSE
        Fail
    END

Click On Bind On Quote console
    #Author = Amol Gaymukhe
    ClickElement                //button[text()\='Bind']
    VerifyText                  Success                     anchor=Bind quote successfully!                         timeout=45s

Edit BNDP Actual and Fee APRP
    #Author = Amol Gaymukhe
    [Arguments]                 ${BNDP}                     ${Actual}                   ${Fee}
    ClickElement                //span[text()\='Edit BNDP AP/RP']
    TypeText                    //label[text()\='BNDP AP/RP']//following::input         900                         #${BNDP}
    ClickElement                //span[text()\='Edit Actual AP/RP']
    TypeText                    //label[text()\='Actual AP/RP']//following::input       900                         #${Actual}
    ClickElement                //span[text()\='Edit Fee AP/RP']
    TypeText                    //label[text()\='Fee AP/RP']//following::input          200                         #${Fee}



Select Fee and check Rated state
    #Author=Amol GAymukhe
    ClickElement                //span[text()\='Edit Fee AP/RP']
    TypeText                    //label[text()\='Fee AP/RP']//following::input          200
    Sleep                       2s
    ClickText                   Quote Options
    Sleep                       2s
    ClickText                   Save                        anchor=Cancel
    Sleep                       2s
    VerifyElement               (//span[text()\='Rated'])[last()]


Edit BNDP
    #Author=Amol Gaymukhe
    ClickElement                (//span[text()\='Edit Final BNDP'])[last()]
    TypeText                    (//label[text()\='Final BNDP'])//following::input       3000
    Sleep                       2s
    ClickText                   Quote Options
    ClickText                   Save                        anchor=Cancel


Verify MGA change
    #Author= Amol Gaymukhe
    ${mga}=                     GetInputValue               MGA Commission %
    Log To Console              ${mga}
    IF                          "${mga}" == "44.00%"
        Log To Console          Success
    ELSE
        Fail
    END


Click on Endorsement
    #Author= Amol Gaymukhe
    ClickElement                //lightning-icon[@title\='Endorsements & Subjectivities']
    VerifyText                  Endorsement and Subjectivity


Select Endorsement
    [Arguments]                 ${Endorsement_name}
    Usemodal                    On
    TypeText                    //input[@placeholder\='Search for Endorsements']        ${Endorsement_name}
    PressKey                    //input[@placeholder\='Search for Endorsements']        {ENTER}
    Sleep                       2s
    ClickElement                //span[text()\='Select Item 1']
    ClickElement                //button[@title\='Add']
    VerifyText                  Success                     anchor=The data is saved successfully                   timeout=15s
    ClickText                   Return Quote Process


Enter Data in the Endorsement
    Usemodal                    On
    TypeText                    //input[@placeholder\='Search for Endorsements']        AQUW153B
    PressKey                    //input[@placeholder\='Search for Endorsements']        {ENTER}
    Sleep                       2s
    ClickElement                //b[text()\='Selected Endorsements']/parent::*//button[@title\='Edit']
    ClickElement                //span[text()\='Select a date for ']//parent::*/parent::*/parent::*
    ${curr_date}=               Get Current Date            result_format=%-m/%d/%Y
    Log To Console              ${curr_date}
    TypeText                    //span[text()\='Select a date for ']//parent::*/parent::*/parent::*                 ${curr_date}
    TypeText                    (//input[@placeholder\='Enter a value...'])[2]          Test
    ClickText                   Save                        anchor=Cancel
    ClickText                   Return Quote Process


Enter Final AP to reduce PA 
    ClickElement                (//span[text()\='Edit Final AP'])[last()]
    TypeText                    (//label[text()\='Final AP'])//following::input         1500
    ClickText                   Quote Options
    ${confirmation}=            IsText                      Confirmation
    Log To Console              ${confirmation}
    IF                          "${confirmation}" == "True"
        ClickElement            //button[text()\='Confirm']                             anchor=Cancel
    ELSE
        ClickText               Save                        anchor=Cancel
    END
    Sleep                       20sec

Delete Default added Endorsement
    ClickElement                //lightning-icon[@title\='Endorsements & Subjectivities']
    VerifyText                  Endorsement and Subjectivity
    Usemodal                    On
    ScrollTo                    Selected Endorsements
    VerifyText                  Selected Endorsements
    # ClickText                 Delete
    ClickElement                //lightning-button-icon[@data-id\='1']//button[@title\='Delete']
    ClickText                   Return Quote Process
    Sleep                       15s
    ClickElement                //button[text()\='Rate']
    ClickElement                //button[text()\="Confirm"]

Add Endorsement Detail Amount 
    [Arguments]                 ${Endorsement_name}
    ScrollTo                    ${Endorsement_name}
    ClickElement                //button[@title\='Edit']
    TypeText                    //c-endorsement-tab-lwc-aq-cel//div/input               2000
    ClickText                   Save                        anchor=Cancel
    ClickText                   Return Quote Process


Binder Name Inception Date
    ${binder}=                  GetText                     //label[contains(., '2025')]
    Log To Console              ${binder}

    ${mga}=                     GetInputValue                     //input[contains(@name, 'MGA Commission')]
    Log to Console              ${mga}

    IF                          "${binder}" == '2025 XOL Excess Binder: Jun - May'
        Log To Console          ${binder}
        IF                      '${mga}' == '34.25%'
            Log To Console      $(mga)
        ELSE
            Fail

        END

    ELSE IF                     "${binder}" == '2025 GAIC Excess Binder: Jun - May'
        Log To Console          ${binder}
        IF                      '${mga}' == '35.25%'
            Log To Console      $(mga)
        ELSE
            Fail

        END

    ELSE IF                     "${binder}" == '2025 Binder: Jun - May'
        Log To Console          ${binder}
        IF                      '${mga}' == '33.50%'
            Log To Console      $(mga)
        ELSE
            Fail

        END

    ELSE IF                     "${binder}" == '2025 Solicitors Binder: Jun - May'
        Log To Console          ${binder}
        IF                      '${mga}' == '33.50%'
            Log To Console      $(mga)
        ELSE
            Fail

        END

    ELSE IF                     "${binder}" == '2025 GA AmTrust Solicitors Binder June - May'
        Log To Console          ${binder}
        IF                      '${mga}' == '33.50%'
            Log To Console      $(mga)
        ELSE
            Fail

        END

    ELSE
        Fail
    END


Check Quote Type as Renewal on Quote   
    ${quoteType}=                GetText                   //span[@part\='input-button-value' and contains(text(), 'Renewal')]
    Log To Console              ${quoteType}
    IF                          '${quoteType}' == 'Renewal'
        Log To Console          ${quoteType} match
    ELSE
        Fail

    END

Select Endorsement AQUW229
    [Arguments]                 ${Endorsement_name}
    Usemodal                    On
    TypeText                    //input[@placeholder\='Search for Endorsements']        ${Endorsement_name}
    PressKey                    //input[@placeholder\='Search for Endorsements']        {ENTER}
    Sleep                       2s
    ClickElement                //span[text()\='Select Item 1']
    ClickElement                //button[@title\='Add']
    VerifyText                  Success                     anchor=The data is saved successfully                   timeout=15s
 