*** Settings ***
Library                 QWeb
Library                 QForce
#Library                QVision
Library                 FakerLibrary
Library                 String
Library                 BuiltIn
Library                 DateTime
Resource                ../resources/common.robot
Resource                ../PageObjects/PageObjects_Account.robot
Resource                ../PageObjects/PageObjects_InsuredInfo.robot

*** Keywords ***

Add Proposal date
    #Author=Amol
    [tags]              UnderwriterAnalysis
    [Documentation]     Complete Documentation
    ${cur_date}=        Get Current Date            result_format=%-m/%-d/%Y
    ${cur_date2}=       Get Current Date            result_format=%-m/%-d/%Y
    Log To Console      ${cur_date}
    TypeText            Proposal Form Date          ${cur_date2}
    TypeText            Date of Last Full Proposal Form on file                 ${cur_date2}

Add Split Percentage
    [tags]              UnderwriterAnalysis
    [Documentation]     Complete Documentation
    TypeText            Professional Business Description                       Text
    ClickElement        (//button[@class\='slds-button slds-button_icon slds-button_icon-container'])[2]
    ClickElement        (//c-work-type-analysis-section//lightning-primitive-input-checkbox)[2]
    ClickElement        //button[@title\='Add']
    Sleep               3s
    TypeText            //input[contains(@name,'_split')]                       100

Save Details and check risk health
    [tags]              UnderwriterAnalysis
    [Documentation]     Complete Documentation
    ClickText           Save                        anchor=Check Risk Health
    VerifyText          Success                     anchor=Update records successfully!
    ClickText                   Check Risk Health
Dynamic element of Solicitors
    [tags]              UnderwriterAnalysis
    [Documentation]     Complete Documentation
    TypeText                    *Number of Partners         3
    TypeText                    *Claims Experience – Incurred in last 5 years          5000
    TypeText                    //span[text()\='Annual gross fees / turnover']/parent::td[last()]/following::td[1]//input    40000
    ClickElement                //span[normalize-space()\='Select an Option'][1]
    ClickElement                //span[normalize-space()\='Partnership']
    
