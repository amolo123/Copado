*** Settings ***
Library               QWeb
Library               QForce
#Library              QVision
Library               FakerLibrary
Library               String
Library               BuiltIn
Library               DateTime
Resource              ../resources/common.robot




*** Keywords ***

Validate Aqueous New submission Fields
    #Author=Pinki
    [tags]            submission
    Home
    #ClickElement     //button[@class\='slds-button slds-show']
    ClickElement      //span[text()\='App Launcher']
    TypeText          //input[@placeholder\='Search apps and items...']    Aqueous
    ClickText         Aqueous Underwriting
    Sleep             2s
    RefreshPage
    VerifyText        Aqueous Underwriting        anchor=Home
    ClickText         Home                        anchor=Accounts
    VerifyText        Home                        timeout=10s
    VerifyText        New Submission
    VerifyText        Existing Submission
    VerifyText        Existing Policy Submission
    ClickText         Next

    ${RR}             Istext                      Record Type
    Log To Console    ${RR}
    IF                "${RR}" == "False"
        Log           Enter Product Selection from My Submmision popup.
        ClickText     Submissions                 anchor=Quote
        Sleep         5s
        ClickElement                              //button[text()\="New"]
    END

    UseModal          On
    VerifyText        New Submission
    VerifyText        Record Type
    ClickText         Aqueous                     anchor=Record Type
    VerifyText        Product
    ClickText         Professional Indemnity      anchor=Product
    ClickText         Next                        anchor=Cancel
    UseModal          Off
    Log To Console    ----- New Submission Fields Validated Successfully -----

Checking Cancel Button On New Submission
    #Author=Pinki
    [tags]            submission
    Home
    #ClickElement     //button[@class\='slds-button slds-show']
    ClickElement      //span[text()\='App Launcher']
    TypeText          //input[@placeholder\='Search apps and items...']    Aqueous
    ClickText         Aqueous Underwriting
    Sleep             2s
    RefreshPage
    VerifyText        Aqueous Underwriting        anchor=Home
    ClickText         Home                        anchor=Accounts
    VerifyText        Home                        timeout=10s
    VerifyText        New Submission
    VerifyText        Existing Submission
    VerifyText        Existing Policy Submission
    ClickText         Next

    ${RR}             Istext                      Record Type
    IF                "${RR}" == "False"
        ClickText     Submissions                 anchor=Quote
        Sleep         5s
        ClickElement                              //button[text()\="New"]
    END

    UseModal          On
    VerifyText        New Submission
    VerifyText        Record Type
    ClickText         Aqueous                     anchor=Record Type
    VerifyText        Product
    ClickText         Professional Indemnity      anchor=Product
    ClickText         Cancel                      anchor=Cancel
    UseModal          Off
    Log To Console    ----- Cancel Button Validated Successfully -----
