*** Settings ***
Library                     QWeb
Library                     QForce
#Library                    QVision
Library                     FakerLibrary
Library                     String
Library                     BuiltIn
Library                     DateTime
Resource                    ../resources/common.robot
Resource                    ../PageObjects/PageObjects_Account.robot
Resource                    ../PageObjects/PageObjects_InsuredInfo.robot

*** Keywords ***
Validate Underwriter Analysis Fields
    #Author=Amol
    [tags]                  UnderwriterAnalysis
    [Documentation]         Complete Documentation
    VerifyText              Account                     partial_match=false
    VerifyText              Agency
    VerifyText              Underwriter                 partial_match=false
    VerifyText              Effective Date
    VerifyText              Stage
    VerifyText              Quoted Premium
    VerifyText              ${uniquename}               anchor=Account
    VerifyText              Automation AQ Broker
    VerifyText              Automation-user Copado-AQPI
    VerifyText              Professional Indemnity
    VerifyText              Proposal Form Date
    VerifyText              Is the Proposal Form a full Proposal?
    VerifyText              Date of Last Full Proposal Form on file
    VerifyText              Capture
    VerifyText              Annual gross fees / turnover
    VerifyText              Average Fee
    VerifyText              Is the business regulated by the Association of Chartered Certified Accountants?
    VerifyText              Annual gross fees / turnover - change
    VerifyText              Largest fee / income from one client
    VerifyText              Average Fee
    VerifyText              Is the business regulated by the Institute of Chartered Accountants?
    VerifyText              PI Technical Adjustments
    VerifyText              Quality
    VerifyText              Length Established
    VerifyText              Foreign exposures
    VerifyText              Run off
    VerifyText              Excess
    VerifyText              Other
    VerifyText              Apply Technical Adjustments to Minimum Premium
    VerifyText              Claims Experience
    VerifyText              Specialists
    VerifyText              Retroactive exposure / date established
    VerifyText              Contract Values / type of construction
    VerifyText              Coverage
    VerifyText              Total Technical Adjustments
    VerifyText              Rateable Exposure
    VerifyText              Rateable Exposure - Previous Year
    VerifyText              Rateable Exposure - Change
    VerifyText              Rating Info
    VerifyText              Professional Business Description
    VerifyText              Splits Table
    VerifyText              Professional Work Splits - Accountants
    VerifyText              Territory Splits
    VerifyText              Work Type
    VerifyText              Split %
    VerifyText              Amount
    VerifyText              Heat Map
    VerifyText              Delete
    VerifyText              Territory                   anchor=Delete
    VerifyText              Risk Capture %
    VerifyText              Claim Details (0)


Add Details In Underwriter Analysis Page 
    #Author=Amol
    [tags]                  UnderwriterAnalysis
    [Documentation]         Complete Documentation
    ${cur_date}=            Get Current Date            result_format=%-m/%d/%Y
    ${cur_date2}=           Get Current Date            result_format=%-m/%d/%Y
    Log To Console          ${cur_date}
    TypeText                Proposal Form Date          ${cur_date2}
    ClickText               Date of Last Full Proposal Form on file                 #${cur_date2}
    TypeText                Annual gross fees / turnover - change                   40000
    ClickElement            (//span[text()\='Yes'])[2]
    ClickElement            (//span[text()\='Yes'])[3]
    TypeText                Professional Business Description                       Text
    ClickElement            (//button[@class\='slds-button slds-button_icon slds-button_icon-container'])[2]
    ClickElement            (//c-work-type-analysis-section//lightning-primitive-input-checkbox)[6]
    ClickElement            //button[@title\='Add']
    Sleep                   10s
    TypeText                //input[contains(@name,'_split')]                       100
    ClickText               Save                        anchor=Check Risk Health
    VerifyText              Success                     anchor=Update records successfully!    partial_match=false

Add Details On Underwriter
    #Author=Amol
    [tags]                  UnderwriterAnalysis
    [Documentation]         Complete Documentation
    ${cur_date}=            Get Current Date            result_format=%-m/%d/%Y
    ${cur_date2}=           Get Current Date            result_format=%-m/%d/%Y
    Log To Console          ${cur_date}
    TypeText                Proposal Form Date          ${cur_date2}
    ClickText               Date of Last Full Proposal Form on file                 #${cur_date2}
    TypeText                Annual gross fees / turnover - change                   40000
    ClickElement            (//span[text()\='Yes'])[2]
    ClickElement            (//span[text()\='Yes'])[3]
    TypeText                Professional Business Description                       Text

Select split independantly
    #Author= Amol
    [Arguments]             ${no}
    ClickElement            (//button[@class\='slds-button slds-button_icon slds-button_icon-container'])[2]
    ClickElement            (//c-work-type-analysis-section//lightning-primitive-input-checkbox)[${no}]
    ClickElement            //button[@title\='Add']

Select Split
    #Author= Amol
    [Arguments]             ${no}
    ClickElement            (//button[@class\='slds-button slds-button_icon slds-button_icon-container'])[2]
    ClickElement            (//c-work-type-analysis-section//lightning-primitive-input-checkbox)[${no}]
    ClickElement            //button[@title\='Add']
    Sleep                   3s
    TypeText                //input[contains(@name,'_split')]                       100
    ClickText               Save                        anchor=Check Risk Health
    VerifyText              Success                     anchor=Update records successfully!

Add Details on underwriter For Dynamic Element Change
    ClickElement            (//button[@class\='slds-button slds-button_icon slds-button_icon-container'])[2]
    Usemodal                On
    ClickElement            (//c-work-type-analysis-section//lightning-primitive-input-checkbox)[2]
    ClickElement            //button[@title\='Add']
    TypeText                //input[contains(@name,'_split')]                       100
    TypeText                Professional Business Description                       Test this field
    ClickText               Save                        anchor=Check Risk Health
    VerifyText              Success                     anchor=Update records successfully!

Add Details on underwriter For Dynamic Element Change for Design and construct  
    ClickElement            (//button[@class\='slds-button slds-button_icon slds-button_icon-container'])[2]
    Usemodal                On
    ClickElement            (//c-work-type-analysis-section//lightning-primitive-input-checkbox)[2]
    ClickElement            //button[@title\='Add']
    TypeText                //input[contains(@name,'_split')]                       100
    TypeText                (//input[contains(@name,'_split')])[2]                  100
    TypeText                Professional Business Description                       Test this field
    ClickText               Save                        anchor=Check Risk Health
    VerifyText              Success                     anchor=Update records successfully!

Add Details on underwriter For Dynamic Element Change for Property Professionals
    ClickElement            (//button[@class\='slds-button slds-button_icon slds-button_icon-container'])[2]
    Usemodal                On
    ClickElement            (//c-work-type-analysis-section//lightning-primitive-input-checkbox)[2]
    ClickElement            //button[@title\='Add']
    TypeText                //input[contains(@name,'_split')]                       100
    TypeText                Professional Business Description                       Test this field
    ClickElement            (//span[text()\='Yes'])[2]
    ClickText               Save                        anchor=Check Risk Health
    VerifyText              Success                     anchor=Update records successfully!

Check Endorsements According to Profession
    #Author=Amol Gaymukhe
    [Documentation]         Check the Endorsements for different states
    [Arguments]             ${Profession}

    #ClickElement           //lightning-icon[@title\='Endorsements']
    Import Variables        ${CURDIR}/ProfessionToUnderwrittingAnalysis.py          ${Profession}
    Log To Console          ${CURDIR}

    FOR                     ${index}                    IN RANGE                    ${amounts}
        Log                 ${index}                    # 0-9
        ${rownum}=          Evaluate                    ${index}+1

        Log To Console      ${list}[${index}]
        VerifyText          ${list}[${index}]
        # UseTable          Endorsement Name
        # ${text}=          GetCellText                 r${rownum}c2
        # Log To Console    ${text}
        # IF                '${list}[${index}]'=='${text}'
        #                   Log To Console              Success
        # ELSE
        #                   FAIL
        # END
    END


Enter Proposal Date
    ${curr_date}=           Get Current Date            result_format=%-m/%d/%Y
    Log To Console          ${curr_date}
    TypeText                Proposal Form Date          ${curr_date}


Select Binder Name
    # Author = Amol Gaymukhe
    [Documentation]     Quote
    [tags]              Quote
    [Arguments]         ${type}
    VerifyText          Master Binders
    IF                  "${type}" == "Binder"
        VerifyText      2025 Binder: Jun - May
        VerifyText      2025-06-01
        VerifyText      2026-05-31
        ClickElement    (//span[text()\='Select Item 1']/parent::*)[last()]
    ELSE IF             "${type}" == "GAIC"
        VerifyText      2025 GAIC Excess Binder: Jun - May
        VerifyText      2025-06-01
        VerifyText      2026-05-31
        ClickElement    (//span[text()\='Select Item 2']/parent::*)[last()]
    ELSE IF             "${type}" == "XOL"
        VerifyText      2025 XOL Excess Binder: Jun - May
        VerifyText      2025-06-01
        VerifyText      2026-05-31
        ClickElement    (//span[text()\='Select Item 3']/parent::*)[last()]
        
    ELSE IF             "${type}" == "Solicitors"
        VerifyText      2025 Solicitors Binder: Jun - May
        VerifyText      2025-06-01
        VerifyText      2026-05-31
        ClickElement    (//span[text()\='Select Item 1']/parent::*)[last()]    

    ELSE IF             "${type}" == "Solicitors GA AmTrust"
        VerifyText      2025 GA AmTrust Solicitors Binder June - May
        VerifyText      2025-06-01
        VerifyText      2026-05-31
        ClickElement    (//span[text()\='Select Item 2']/parent::*)[last()]   

    ELSE
        Log To Console                              No Parameters Given
        Fail
    END
    ClickText           Proceed to Quote


Check Foreign Exposure Value
    ${value}=               GetInputValue               Foreign exposures
    Log To Console          ${value}
    IF                      ${value} == "1.16"
        Log To Console      Success
    ELSE
        Log To Console      Fail
    END

Check Solicitor Partner field
    [Arguments]             ${NumberofPartners}
    # ${NumberofPartners}=    Set Variable                3
    TypeText                *Number of Partners         ${NumberofPartners}
    IF                      "${Number of Partners}" <= '0'
        ClickText           *Number of Partners
        VerifyText          Invalid input, the value should be greater than 0 and number format only.
    ELSE
        TypeText            *Claims Experience – Incurred in last 5 years           5000
        TypeText            //span[text()\='Annual gross fees / turnover']/parent::td[last()]/following::td[1]//input    40000
        ClickElement        //span[normalize-space()\='Select an Option'][1]
        ClickElement        //span[normalize-space()\='Partnership']
    END